﻿use AWSWeighingService;
go

ALTER TABLE [Sites]
  ADD [Installed] [nvarchar](max) NULL;
go

ALTER TABLE [Sites]
  ADD [Certificate] [nvarchar](max) NULL;
go




