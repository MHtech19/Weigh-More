﻿use AWSWeighingService;
go

ALTER TABLE VehicleConfigurations
  ADD Tare decimal(18, 2) NOT NULL default 0;
go

ALTER TABLE VehicleConfigurations
  ADD MaxLoad decimal(18, 2) NOT NULL default 0;
go




