﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using AWSWeighingService.Models;

namespace AWSWeighingService.DataAccess
{
	public class DataServiceManager
	{
		private IRestService restService;
        private string _DataServiceUrlRootPart;

		public DataServiceManager (IRestService service, string dataServiceUrlRootPart)
		{
			restService = service;
            _DataServiceUrlRootPart = dataServiceUrlRootPart;

        }

        //BinContainer
        public async Task<List<BinContainer>> GetBinContainers()
        {
            return await restService.RefreshTEntityListAsynce<BinContainer>(_DataServiceUrlRootPart + Constants.BinContainerRestUrl);

        }

        public async Task CreateBinContainerAsync(BinContainer aBinContainer)
        {
            await restService.CreateTEntityAsync<BinContainer>(aBinContainer, _DataServiceUrlRootPart + Constants.BinContainerRestUrl);
        }


        public async Task UpdateBinContainerAsync(BinContainer aBinContainer)
        {
            await restService.UpdateTEntityAsync<BinContainer>(aBinContainer, _DataServiceUrlRootPart + Constants.BinContainerRestUrl);
        }

        public async Task DeleteBinContainerAsync(BinContainer aBinContainer)
        {
            await restService.DeleteTEntityAsync<BinContainer>(aBinContainer.ID, _DataServiceUrlRootPart + Constants.BinContainerRestUrl);
        }


        //CompanyProfile
        public async Task<List<CompanyProfile>> GetCompanyProfiles()
        {
            return await restService.RefreshTEntityListAsynce<CompanyProfile>(_DataServiceUrlRootPart + Constants.CompanyProfileRestUrl);

        }

        public async Task CreateCompanyProfileAsync(CompanyProfile CompanyProfile)
        {
            await restService.CreateTEntityAsync<CompanyProfile>(CompanyProfile, _DataServiceUrlRootPart + Constants.CompanyProfileRestUrl);
        }

        public async Task UpdateCompanyProfileAsync(CompanyProfile CompanyProfile)
        {
            await restService.UpdateTEntityAsync<CompanyProfile>(CompanyProfile, _DataServiceUrlRootPart + Constants.CompanyProfileRestUrl);
        }

        public async Task DeleteCompanyProfileAsync(CompanyProfile CompanyProfile)
        {
            await restService.DeleteTEntityAsync<CompanyProfile>(CompanyProfile.ID, _DataServiceUrlRootPart + Constants.CompanyProfileRestUrl);
        }

        //Container
        public async Task<List<Container>> GetContainers()
        {
            return await restService.RefreshTEntityListAsynce<Container>(_DataServiceUrlRootPart + Constants.ContainerRestUrl);

        }

        public async Task CreateContainerAsync(Container aContainer)
        {
            await restService.CreateTEntityAsync<Container>(aContainer, _DataServiceUrlRootPart + Constants.ContainerRestUrl);
        }


        public async Task UpdateContainerAsync(Container aContainer)
        {
            await restService.UpdateTEntityAsync<Container>(aContainer, _DataServiceUrlRootPart + Constants.ContainerRestUrl);
        }

        public async Task DeleteContainerAsync(Container aContainer)
        {
            await restService.DeleteTEntityAsync<Container>(aContainer.ID, _DataServiceUrlRootPart + Constants.ContainerRestUrl);
        }


        //Customer
        public async Task<List<Customer>> GetCustomers()
        {
            return await restService.RefreshTEntityListAsynce<Customer>(_DataServiceUrlRootPart + Constants.CustomerRestUrl);
        }

        public async Task<ObservableCollection<Customer>> GetObservableCustomersAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<Customer>(_DataServiceUrlRootPart + Constants.SiteCustomerRestUrl + site.ID.ToString());
        }

        public async Task CreateCustomerAsync(Customer aCustomer)
        {
            await restService.CreateTEntityAsync<Customer>(aCustomer, _DataServiceUrlRootPart + Constants.CustomerRestUrl);
        }

        
        public async Task UpdateCustomerAsync(Customer aCustomer)
        {
            await restService.UpdateTEntityAsync<Customer>(aCustomer, _DataServiceUrlRootPart + Constants.CustomerRestUrl);
        }

        public async Task DeleteCustomerAsync(Customer aCustomer)
        {
            await restService.DeleteTEntityAsync<Customer>(aCustomer.ID, _DataServiceUrlRootPart + Constants.CustomerRestUrl);
        }

        //Destination
        public async Task<List<Destination>> GetDestinations()
        {
            return await restService.RefreshTEntityListAsynce<Destination>(_DataServiceUrlRootPart + Constants.DestinationRestUrl);

        }

        public async Task<ObservableCollection<Destination>> GetObservableDestinationsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<Destination>(_DataServiceUrlRootPart + Constants.SiteDestinationRestUrl + site.ID.ToString());
        }

        public async Task CreateDestinationAsync(Destination aDestination)
        {
            await restService.CreateTEntityAsync<Destination>(aDestination, _DataServiceUrlRootPart + Constants.DestinationRestUrl);
        }


        public async Task UpdateDestinationAsync(Destination aDestination)
        {
            await restService.UpdateTEntityAsync<Destination>(aDestination, _DataServiceUrlRootPart + Constants.DestinationRestUrl);
        }

        public async Task DeleteDestinationAsync(Destination aDestination)
        {
            await restService.DeleteTEntityAsync<Destination>(aDestination.ID, _DataServiceUrlRootPart + Constants.DestinationRestUrl);
        }

        

        //Driver
        public async Task<List<Driver>> GetDrivers()
        {
            return await restService.RefreshTEntityListAsynce<Driver>(_DataServiceUrlRootPart + Constants.DriverRestUrl);

        }

        public async Task CreateDriverAsync(Driver aDriver)
        {
            await restService.CreateTEntityAsync<Driver>(aDriver, _DataServiceUrlRootPart + Constants.DriverRestUrl);
        }


        public async Task UpdateDriverAsync(Driver aDriver)
        {
            await restService.UpdateTEntityAsync<Driver>(aDriver, _DataServiceUrlRootPart + Constants.DriverRestUrl);
        }

        public async Task DeleteDriverAsync(Driver aDriver)
        {
            await restService.DeleteTEntityAsync<Driver>(aDriver.ID, _DataServiceUrlRootPart + Constants.DriverRestUrl);
        }

        /*
        //FirstWeigh
        public async Task<List<FirstWeigh>> GetFirstWeighs()
        {
            return await restService.RefreshTEntityListAsynce<FirstWeigh>(_DataServiceUrlRootPart + Constants.FirstWeighRestUrl);
        }

        public async Task CreateFirstWeighAsync(FirstWeigh aFirstWeigh)
        {
            await restService.CreateTEntityAsync<FirstWeigh>(aFirstWeigh, _DataServiceUrlRootPart + Constants.FirstWeighRestUrl);
        }

        public async Task UpdateFirstWeighAsync(FirstWeigh aFirstWeigh)
        {
            await restService.UpdateTEntityAsync<FirstWeigh>(aFirstWeigh, _DataServiceUrlRootPart + Constants.FirstWeighRestUrl);
        }

        public async Task DeleteFirstWeighAsync(FirstWeigh aFirstWeigh)
        {
            await restService.DeleteTEntityAsync<FirstWeigh>(aFirstWeigh.ID, _DataServiceUrlRootPart + Constants.FirstWeighRestUrl);
        }
         */

        //Job
        public async Task<List<Job>> GetJobs()
        {
            return await restService.RefreshTEntityListAsynce<Job>(_DataServiceUrlRootPart + Constants.JobRestUrl);

        }

        public async Task<ObservableCollection<Job>> GetObservableJobsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<Job>(_DataServiceUrlRootPart + Constants.SiteJobRestUrl + site.ID.ToString());
        }

        public async Task CreateJobAsync(Job aJob)
        {
            await restService.CreateTEntityAsync<Job>(aJob, _DataServiceUrlRootPart + Constants.JobRestUrl);
        }


        public async Task UpdateJobAsync(Job aJob)
        {
            await restService.UpdateTEntityAsync<Job>(aJob, _DataServiceUrlRootPart + Constants.JobRestUrl);
        }

        public async Task DeleteJobAsync(Job aJob)
        {
            await restService.DeleteTEntityAsync<Job>(aJob.ID, _DataServiceUrlRootPart + Constants.JobRestUrl);
        }

        //JobProductPrice
        public async Task<ObservableCollection<JobProductPrice>> GetObservableJobProductPriceWithJobID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsynce<JobProductPrice>(id, _DataServiceUrlRootPart + Constants.JobProductPriceRestUrl);
        }

        //Operator
        public async Task<List<Operator>> GetOperators()
        {
            return await restService.RefreshTEntityListAsynce<Operator>(_DataServiceUrlRootPart + Constants.OperatorRestUrl);
        }

        public async Task CreateOperatorAsync(Operator aOperator)
        {
            await restService.CreateTEntityAsync<Operator>(aOperator, _DataServiceUrlRootPart + Constants.OperatorRestUrl);
        }

        public async Task UpdateOperatorAsync(Operator aOperator)
        {
            await restService.UpdateTEntityAsync<Operator>(aOperator, _DataServiceUrlRootPart + Constants.OperatorRestUrl);
        }

        public async Task DeleteOperatorAsync(Operator aOperator)
        {
            await restService.DeleteTEntityAsync<Operator>(aOperator.ID, _DataServiceUrlRootPart + Constants.OperatorRestUrl);
        }

        //Product
        public async Task<List<Product>> GetProducts()
        {
            return await restService.RefreshTEntityListAsynce<Product>(_DataServiceUrlRootPart + Constants.ProductRestUrl);

        }

        public async Task<ObservableCollection<Product>> GetObservableProductsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<Product>(_DataServiceUrlRootPart + Constants.SiteProductRestUrl + site.ID.ToString());
        }

        public async Task CreateProductAsync(Product aProduct)
        {
            await restService.CreateTEntityAsync<Product>(aProduct, _DataServiceUrlRootPart + Constants.ProductRestUrl);
        }


        public async Task UpdateProductAsync(Product aProduct)
        {
            await restService.UpdateTEntityAsync<Product>(aProduct, _DataServiceUrlRootPart + Constants.ProductRestUrl);
        }

        public async Task DeleteProductAsync(Product aProduct)
        {
            await restService.DeleteTEntityAsync<Product>(aProduct.ID, _DataServiceUrlRootPart + Constants.ProductRestUrl);
        }

        //ProductCategory
        public async Task<List<ProductCategory>> GetProductCategories()
        {
            return await restService.RefreshTEntityListAsynce<ProductCategory>(_DataServiceUrlRootPart + Constants.ProductCategoryRestUrl);
        }

        public async Task CreateProductCategoryAsync(ProductCategory aProductCategory)
        {
            await restService.CreateTEntityAsync<ProductCategory>(aProductCategory, _DataServiceUrlRootPart + Constants.ProductCategoryRestUrl);
        }


        public async Task UpdateProductCategoryAsync(ProductCategory aProductCategory)
        {
            await restService.UpdateTEntityAsync<ProductCategory>(aProductCategory, _DataServiceUrlRootPart + Constants.ProductCategoryRestUrl);
        }

        public async Task DeleteProductCategoryAsync(ProductCategory aProductCategory)
        {
            await restService.DeleteTEntityAsync<ProductCategory>(aProductCategory.ID, _DataServiceUrlRootPart + Constants.ProductCategoryRestUrl);
        }

        //Weighmen
        public async Task<List<Weighman>> GetWeighmenAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityListAsynce<Weighman>(_DataServiceUrlRootPart + Constants.SiteWeighmanRestUrl + site.ID.ToString());
        }

        //Site
        public async Task<List<Site>> GetSites()
        {
            return await restService.RefreshTEntityListAsynce<Site>(_DataServiceUrlRootPart + Constants.SiteRestUrl);
        }

        public async Task<ObservableCollection<Site>> GetObservableSites()
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<Site>(_DataServiceUrlRootPart + Constants.SiteRestUrl);
        }


        public async Task CreateSiteAsync(Site aSite)
        {
            await restService.CreateTEntityAsync<Site>(aSite, _DataServiceUrlRootPart + Constants.SiteRestUrl);
        }

        public async Task UpdateSiteAsync(Site aSite)
        {
            await restService.UpdateTEntityAsync<Site>(aSite, _DataServiceUrlRootPart + Constants.SiteRestUrl);
        }

        public async Task DeleteSiteAsync(Site aSite)
        {
            await restService.DeleteTEntityAsync<Site>(aSite.ID, _DataServiceUrlRootPart + Constants.SiteRestUrl);
        }
        
        //Source
        public async Task<List<Source>> GetSources()
        {
            return await restService.RefreshTEntityListAsynce<Source>(_DataServiceUrlRootPart + Constants.SourceRestUrl);
        }

        public async Task<ObservableCollection<Source>> GetObservableSourcesAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<Source>(_DataServiceUrlRootPart + Constants.SiteSourceRestUrl + site.ID.ToString());
        }

        public async Task CreateSourceAsync(Source anSource)
        {
            await restService.CreateTEntityAsync<Source>(anSource, _DataServiceUrlRootPart + Constants.SourceRestUrl);
        }

        public async Task UpdateSourceAsync(Source anSource)
        {
            await restService.UpdateTEntityAsync<Source>(anSource, _DataServiceUrlRootPart + Constants.SourceRestUrl);
        }

        public async Task DeleteSourceAsync(Source anSource)
        {
            await restService.DeleteTEntityAsync<Source>(anSource.ID, _DataServiceUrlRootPart + Constants.SourceRestUrl);
        }
        
       

        //Transaction
        public async Task<List<Transaction>> GetTransactions()
        {
            return await restService.RefreshTEntityListAsynce<Transaction>(_DataServiceUrlRootPart + Constants.TransactionRestUrl);
        }

        public async Task<Transaction> CreateTransactionAsync(Transaction aTransaction)
        {
            return await restService.CreateTEntityAsync<Transaction>(aTransaction, _DataServiceUrlRootPart + Constants.TransactionRestUrl);
        }

        public async Task UpdateTransactionAsync(Transaction aTransaction)
        {
            await restService.UpdateTEntityAsync<Transaction>(aTransaction, _DataServiceUrlRootPart + Constants.TransactionRestUrl);
        }

        public async Task DeleteTransactionAsync(Transaction aTransaction)
        {
            await restService.DeleteTEntityAsync<Transaction>(aTransaction.ID, _DataServiceUrlRootPart + Constants.TransactionRestUrl);
        }
        
        //Truck
        public async Task<List<Truck>> GetTrucks()
        {
            return await restService.RefreshTEntityListAsynce<Truck>(_DataServiceUrlRootPart + Constants.TruckRestUrl);
        }

        public async Task<ObservableCollection<Truck>> GetObservableTrucks()
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<Truck>(_DataServiceUrlRootPart + Constants.TruckRestUrl);
        }

        public async Task CreateTruckAsync(Truck anTruck)
        {
            await restService.CreateTEntityAsync<Truck>(anTruck, _DataServiceUrlRootPart + Constants.TruckRestUrl);
        }
        
        public async Task UpdateTruckAsync(Truck anTruck)
        {
            await restService.UpdateTEntityAsync<Truck>(anTruck, _DataServiceUrlRootPart + Constants.TruckRestUrl);
        }

        public async Task DeleteTruckAsync(Truck anTruck)
        {
            await restService.DeleteTEntityAsync<Truck>(anTruck.ID, _DataServiceUrlRootPart + Constants.TruckRestUrl);
        }

        //VehicleConfiguration
        public async Task<List<VehicleConfiguration>> GetTruckConfigurations()
        {
            return await restService.RefreshTEntityListAsynce<VehicleConfiguration>(_DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl);
        }

        public async Task<ObservableCollection<VehicleConfiguration>> GetObservableVehicleConfigurations()
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<VehicleConfiguration>(_DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl);
        }


        public async Task CreateTruckConfigurationAsync(VehicleConfiguration aTruckConfiguration)
        {
            await restService.CreateTEntityAsync<VehicleConfiguration>(aTruckConfiguration, _DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl);
        }

        public async Task UpdateTruckConfigurationAsync(VehicleConfiguration aTruckConfiguration)
        {
            await restService.UpdateTEntityAsync<VehicleConfiguration>(aTruckConfiguration, _DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl);
        }

        public async Task DeleteTruckConfigurationAsync(VehicleConfiguration aTruckConfiguration)
        {
            await restService.DeleteTEntityAsync<VehicleConfiguration>(aTruckConfiguration.ID, _DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl);
        }

        //Vehicle
        public async Task<List<Vehicle>> GetVehicles()
        {
            return await restService.RefreshTEntityListAsynce<Vehicle>(_DataServiceUrlRootPart + Constants.VehicleRestUrl);
        }

        public async Task<ObservableCollection<Vehicle>> GetObservableVehicles()
        {
            return await restService.RefreshTEntityObservableCollectionAsynce<Vehicle>(_DataServiceUrlRootPart + Constants.VehicleRestUrl);
        }

        public async Task CreateVehicleAsync(Vehicle aVehicle)
        {
            await restService.CreateTEntityAsync<Vehicle>(aVehicle, _DataServiceUrlRootPart + Constants.VehicleRestUrl);
        }

        public async Task UpdateVehicleAsync(Vehicle aVehicle)
        {
            await restService.UpdateTEntityAsync<Vehicle>(aVehicle, _DataServiceUrlRootPart + Constants.VehicleRestUrl);
        }

        public async Task DeleteVehicleAsync(Vehicle aVehicle)
        {
            await restService.DeleteTEntityAsync<Vehicle>(aVehicle.ID, _DataServiceUrlRootPart + Constants.VehicleRestUrl);
        }

        //VehicleProductPrice
        public async Task<ObservableCollection<VehicleProductPrice>> GetObservableVehicleProductPriceWithVehicleID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsynce<VehicleProductPrice>(id, _DataServiceUrlRootPart + Constants.VehicleProductPriceRestUrl);
        }

        //Visitor
        public async Task<List<Visitor>> GetVisitors()
        {
            return await restService.RefreshTEntityListAsynce<Visitor>(_DataServiceUrlRootPart + Constants.VisitorRestUrl);
        }

        public async Task CreateVisitorAsync(Visitor aVisitor)
        {
            await restService.CreateTEntityAsync<Visitor>(aVisitor, _DataServiceUrlRootPart + Constants.VisitorRestUrl);
        }

        public async Task UpdateVisitorAsync(Visitor aVisitor)
        {
            await restService.UpdateTEntityAsync<Visitor>(aVisitor, _DataServiceUrlRootPart + Constants.VisitorRestUrl);
        }

        public async Task DeleteVisitorAsync(Visitor aVisitor)
        {
            await restService.DeleteTEntityAsync<Visitor>(aVisitor.ID, _DataServiceUrlRootPart + Constants.VisitorRestUrl);
        }

        //WeighPass
        public async Task<List<WeighPass>> GetWeighPasses()
        {
            return await restService.RefreshTEntityListAsynce<WeighPass>(_DataServiceUrlRootPart + Constants.WeighPassRestUrl);
        }

        public async Task CreateWeighPassAsync(WeighPass aWeighPass)
        {
            await restService.CreateTEntityAsync<WeighPass>(aWeighPass, _DataServiceUrlRootPart + Constants.WeighPassRestUrl);
        }

        public async Task UpdateWeighPassAsync(WeighPass aWeighPass)
        {
            await restService.UpdateTEntityAsync<WeighPass>(aWeighPass, _DataServiceUrlRootPart + Constants.WeighPassRestUrl);
        }

        public async Task DeleteWeighPassAsync(WeighPass aWeighPass)
        {
            await restService.DeleteTEntityAsync<WeighPass>(aWeighPass.ID, _DataServiceUrlRootPart + Constants.WeighPassRestUrl);
        }

        //Docket
        public async Task<string> GetDocketNumber(int siteID)
        {
            return await restService.GetNextDocketNumber(siteID, _DataServiceUrlRootPart + Constants.DocketRestUrl);
        }

        //RealWeight
        public async Task<RealTimeWeight> GetRealTimeWeight(int weightID)
        {
            return await restService.GetTEntityAsync<RealTimeWeight>(weightID, _DataServiceUrlRootPart + Constants.RealTimeWeightRestUrl);
        }


    }
}
