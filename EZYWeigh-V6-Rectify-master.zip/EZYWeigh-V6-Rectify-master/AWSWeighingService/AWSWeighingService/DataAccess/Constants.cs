﻿using System;
using System.Collections.Generic;

namespace AWSWeighingService.DataAccess
{
	public static class Constants
	{
        public static readonly string CentralSiteName = "CENTRAL";   // its ID  is NAEntityID = 1
        public static readonly string MasterWeighmanName = "MASTER"; // its ID  is NAEntityID = 1
        public static readonly string NAEntityName = "NA";
        public static readonly int NAEntityID = 1;

        //Payments
        public static readonly string ACCOUNT = "Account";  
        public static readonly string CASH = "Cash"; 
        public static readonly string CHEQUE = "Cheque";
        public static readonly string EFTPOS = "EFTPOS";  
        public static readonly string CREDITCARD = "CreditCard"; 

        //Directions
        public static readonly string IN = "In";   
        public static readonly string OUT = "Out"; 

        //Vehicle Owner
        public static readonly string PRIVATE = "Private";  
        public static readonly string COMPANY = "Company";

        //Charge Rate
        public static readonly string LOCAL = "Local";
        public static readonly string VISITOR = "Visitor";

        //Transaction Type
        public static readonly string COUNTED = "Counted";
        public static readonly string STANDARD = "Standard";
        public static readonly string REGO = "Rego";
        public static readonly string FIRST = "First";
        public static readonly string SECOND = "Second";
       

        //Aussie States
        public static readonly string NSW = "NSW";
        public static readonly string ACT = "ACT";
        public static readonly string QLD = "QLD";
        public static readonly string VIC = "VIC";
        public static readonly string TAS = "TAS";
        public static readonly string SA = "SA";
        public static readonly string WA = "WA";
        public static readonly string NT = "NT";

        public static readonly List<string> LOADTYPES = new List<string>
        {
            COUNTED,
            STANDARD,
            REGO,
            FIRST,
            SECOND
           
        };

        public static readonly List<string> PAYMENTS = new List<string>
        {
            ACCOUNT,
            CASH,
            CHEQUE,
            EFTPOS,
            CREDITCARD
        };

        public static readonly List<string> AUS_STATES = new List<string>
        {
            NSW,
            ACT,
            QLD,
            VIC,
            TAS,
            SA,
            WA,
            NT
        };


        // URL of REST service

        //BinContainer Url
        public static string BinContainerRestUrl = "api/ApiBinContainer";

        //CompanyProfile Url
        public static string CompanyProfileRestUrl = "api/ApiCompanyProfile";

        //Container Url
        public static string ContainerRestUrl = "api/ApiContainer";

        //Customer Url
        public static string CustomerRestUrl = "api/Customer";
        public static string SiteCustomerRestUrl = "api/SiteCustomer/";

        //Destination Url
        public static string DestinationRestUrl = "api/Destination";
        public static string SiteDestinationRestUrl = "api/SiteDestination/";

        //Driver Url
        public static string DriverRestUrl = "api/Driver";

        //FirstWeigh Url
        public static string FirstWeighRestUrl = "api/FirstWeigh";

        //Job Url
        public static string JobRestUrl = "api/Job";
        public static string SiteJobRestUrl = "api/SiteJob/";

        //JobProductPrice Url
        public static string JobProductPriceRestUrl = "api/JobProductPrice";

        //VehicleProductPrice Url
        public static string VehicleProductPriceRestUrl = "api/VehicleProductPrice";

        //Operator Url
        public static string OperatorRestUrl = "api/ApiOperator";

        //Product Url
        public static string ProductRestUrl = "api/Product";
        public static string SiteProductRestUrl = "api/SiteProduct/";

        //ProductCategory Url
        public static string ProductCategoryRestUrl = "api/ApiProductCategory";


        //Source URL
        public static string SourceRestUrl = "api/Source";
        public static string SiteSourceRestUrl = "api/SiteSource/";

        //Site URL
        public static string SiteRestUrl = "api/Site";

        //Weighman
        public static string WeighmanRestUrl = "api/Weighman";
        public static string SiteWeighmanRestUrl = "api/SiteWeighman/";

        //Transaction URL
        public static string TransactionRestUrl = "api/Transaction";

        //Truck Url
        public static string TruckRestUrl = "api/Truck";

        //TruckConfiguration Url
        public static string VehicleConfigurationRestUrl = "api/VehicleConfiguration";

        //Vehicle Url
        public static string VehicleRestUrl = "api/Vehicle";
        
        //Visitor Url
        public static string VisitorRestUrl = "api/Visitor";

        //WeighPass Url
        public static string WeighPassRestUrl = "api/WeighPass";

        //Docket Url
        public static string DocketRestUrl = "api/Docket";

        //RealTimeWeight Url
        public static string RealTimeWeightRestUrl = "api/RealTimeWeight";

        // Credentials that are hard coded into the REST service
        public static string Username = "Xamarin";
		public static string Password = "Pa$$w0rd";
	}
}
