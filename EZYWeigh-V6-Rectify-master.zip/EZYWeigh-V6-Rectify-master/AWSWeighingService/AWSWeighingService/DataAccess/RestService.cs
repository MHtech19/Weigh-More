﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using AWSWeighingService.Models;

namespace AWSWeighingService.DataAccess
{
	public class RestService : IRestService
	{
		HttpClient client;
        
		public RestService()
		{
			//var authData = string.Format ("{0}:{1}", Constants.Username, Constants.Password);
			//var authHeaderValue = Convert.ToBase64String (Encoding.UTF8.GetBytes (authData));

			client = new HttpClient ();
			client.MaxResponseContentBufferSize = 256000;
			//client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue ("Basic", authHeaderValue);
		}
		
        public async Task<List<TEntity>> RefreshTEntityListAsynce<TEntity>(string uriString) where TEntity : IEntityID
        {
            var entities = new List<TEntity>();
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, string.Empty));

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entities = JsonConvert.DeserializeObject<List<TEntity>>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entities;
        }

        public async Task<ObservableCollection<TEntity>> RefreshTEntityObservableCollectionAsynce<TEntity>(string uriString) where TEntity : IEntityID
        {
            var entities = new ObservableCollection<TEntity>();
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, string.Empty));

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entities = JsonConvert.DeserializeObject<ObservableCollection<TEntity>>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entities;
        }

        public async Task<TEntity> CreateTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID
        {
            TEntity returnedEntity = default(TEntity); ;
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, entity.ID));

            try
            {
                var json = JsonConvert.SerializeObject(entity);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = null;
                response = await client.PostAsync(uri, content);
            
                if (response.IsSuccessStatusCode)
                {
                    var returnedContent = await response.Content.ReadAsStringAsync();
                    returnedEntity = JsonConvert.DeserializeObject<TEntity>(returnedContent);
                    Debug.WriteLine(@"				TodoItem successfully saved.");
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return returnedEntity;
        }

        public async Task UpdateTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID
        {
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, entity.ID));

            try
            {
                var json = JsonConvert.SerializeObject(entity);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = null;
                response = await client.PutAsync(uri, content);

                if (response.IsSuccessStatusCode)
                {
                    Debug.WriteLine(@"				TodoItem successfully saved.");
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }
        }

        public async Task DeleteTEntityAsync<TEntity>(int id, string uriString) where TEntity : IEntityID
        {
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, id));

            try
            {
                var response = await client.DeleteAsync(uri);

                if (response.IsSuccessStatusCode)
                {
                    Debug.WriteLine(@"				TodoItem successfully deleted.");
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }
        }

        public async Task<TEntity> GetTEntityAsync<TEntity>(int id, string uriString) where TEntity :  IEntityID
        {
            //TEntity entity; ;
            TEntity entity = default(TEntity);
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format("{0}/{1}", uriString, id));

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entity = JsonConvert.DeserializeObject<TEntity>(content);
                    

                }
               
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entity;
        }

        public async Task<string> GetNextDocketNumber(int siteID, string uriString)
        {
            string docketNumber = null;

            var uri = new Uri(string.Format("{0}/{1}", uriString, siteID));

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    docketNumber = JsonConvert.DeserializeObject<string>(content);


                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return docketNumber;

       }

        public async Task<ObservableCollection<TEntity>> GetTEntityObservableCollectionWithIDAsynce<TEntity>(int id, string uriString) where TEntity : IEntityID
        {
            var entities = new ObservableCollection<TEntity>();
            var uri = new Uri(string.Format("{0}/{1}", uriString, id));

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entities = JsonConvert.DeserializeObject<ObservableCollection<TEntity>>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entities;
        }
    }
}
