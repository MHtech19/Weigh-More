﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace AWSWeighingService.DataAccess
{
	public interface IRestService 
	{
        //TEntity
        Task<List<TEntity>> RefreshTEntityListAsynce<TEntity>(string uriString) where TEntity : IEntityID;
        Task<TEntity> GetTEntityAsync<TEntity>(int id, string uriString) where TEntity : IEntityID;
        Task<ObservableCollection<TEntity>> RefreshTEntityObservableCollectionAsynce<TEntity>(string uriString) where TEntity : IEntityID;
        Task<ObservableCollection<TEntity>> GetTEntityObservableCollectionWithIDAsynce<TEntity>(int id, string uriString) where TEntity : IEntityID;
        Task<TEntity> CreateTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID;
        Task UpdateTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID;
        Task DeleteTEntityAsync<TEntity>(int id, string uriString) where TEntity : IEntityID;
        Task<string> GetNextDocketNumber(int siteID, string uriString);
        
    }
}
