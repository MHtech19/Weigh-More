﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace AWSWeighingService
{
    /// <summary>
    /// Here check the Client-Secret key in the Request
    /// This filter used for to authorize the api from the WinClient
    /// </summary>

    public class ClientAuthorizationFilter : ActionFilterAttribute
    {

        public override void OnActionExecuting(HttpActionContext actionContext)
        {

            string connectionStringName = (string)HttpContext.Current.Request.QueryString["connectionStringName"];

            if (SkipAuthorization(actionContext)) return;
            if (connectionStringName == null)
            {
                actionContext = setActionContext(actionContext);
            }
            else
            {
                // This key is coming from the wms clients
                string clientSecret = (string)HttpContext.Current.Request.Headers["X-Client-Secret"];


                if (clientSecret == null)
                {
                    actionContext = setActionContext(actionContext);
                }
                else
                {
                    try
                    {
                        AWSWeighingServiceContext db = new AWSWeighingServiceContext(connectionStringName);

                        int clientId = int.Parse(clientSecret.Decrypt());
                        List<Weighman> currentClientToken = db.Weighmen.Where(t => t.ID == clientId).ToList();

                        if (currentClientToken.Count() <= 0)
                        {
                            actionContext = setActionContext(actionContext);
                        }
                    }
                    catch
                    {
                        actionContext = setActionContext(actionContext);
                    }
                }
            }

            base.OnActionExecuting(actionContext);
        }

        public HttpActionContext setActionContext(HttpActionContext actionContext)
        {

            HttpError errorMessagError = new HttpError("You are not authorized to perform this action.");

            HttpResponseMessage response = actionContext.Request.CreateErrorResponse(HttpStatusCode.Unauthorized, errorMessagError);

            actionContext.Response = response;

            return actionContext;

        }

        private static bool SkipAuthorization(HttpActionContext actionContext)
        {
            return actionContext.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any()
                        || actionContext.ControllerContext.ControllerDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any();
        }

    }
}