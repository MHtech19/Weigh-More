﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using WeighBridge.Core.Device;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService
{
    /// <summary>
    /// This class is to check the filter attributes for the apis
    /// </summary>

    public class CheckForAccess : ActionFilterAttribute
    {
        private string _accessFor = "";
        public CheckForAccess(string accessFor)
        {
            _accessFor = accessFor;
        }

        /// <summary>
        /// Here it checks the session role 
        /// If the role is not allowed for the action it sends the exception
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var src = (Role)filterContext.HttpContext.Session["Role"];
            bool _allowed = (bool)src.GetType().GetProperty(_accessFor).GetValue(src, null);

            if (!_allowed)
            {
                throw new SystemException();
            }
            base.OnActionExecuting(filterContext);
        }
    }

    /// <summary>
    /// This filter is checking for connection string, current session
    /// If not satisfy the conditions it is redirected to login page
    /// </summary>
    public class SessionAccess : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string sessionLogonWeighManName = (string)HttpContext.Current.Session["CurrentWeighmanName"];
            if (sessionLogonWeighManName != null)
            {
                string logonWeighManNameFromSession = (string)sessionLogonWeighManName;
                string[] splitLogonName = logonWeighManNameFromSession.Split(DeviceConstants.CHAR_DOT);

                //if (splitLogonName.Length <= 1)
                //{
                //    filterContext.Result = new RedirectToRouteResult(
                //        new RouteValueDictionary(new { controller = "Logon", action = "Login", returnUrl = filterContext.HttpContext.Request.RawUrl }));
                //}
                //else
                //{
                var connStrName = string.Empty;
                if (splitLogonName.Length <= 1)
                {
                    connStrName= CoreConstants.AWSConnectionStringName;
                }
                else
                {
                    connStrName = splitLogonName[0];
                }
                
                var db = new AWSWeighingServiceContext(connStrName);

                    if (db == null)
                    {
                        filterContext.Result = new RedirectToRouteResult(
                            new RouteValueDictionary(new { controller = "Logon", action = "Login", returnUrl = filterContext.HttpContext.Request.RawUrl }));
                    }
                    else
                    {
                        if (filterContext.RouteData.Values["connStrName"] == null)
                            filterContext.RouteData.Values.Add("connStrName", connStrName);
                        if (filterContext.RouteData.Values["db"] == null)
                            filterContext.RouteData.Values.Add("db", db);
                        Site currentSite = null;
                        var sessionCurrentSiteID = filterContext.HttpContext.Session["CurrentSiteID"];
                        var sessionLogonWeighMan = filterContext.HttpContext.Session["CurrentWeighmanID"];
                        var sessionLogonWeighManSiteName = filterContext.HttpContext.Session["CurrentSiteName"];
                        var sessionRole = filterContext.HttpContext.Session["Role"];

                        if ((sessionCurrentSiteID == null) || (sessionLogonWeighManSiteName == null))
                        {

                            filterContext.Result = new RedirectToRouteResult(
                                 new RouteValueDictionary(new { controller = "Logon", action = "Login", returnUrl = filterContext.HttpContext.Request.RawUrl }));
                        }
                        else
                        {
                            int logOnSiteIDFromSession = (int)sessionCurrentSiteID;
                            currentSite = db.Sites.Where(s => s.ID == logOnSiteIDFromSession).FirstOrDefault();

                            int logOnWeighManIDFromSession = (int)sessionLogonWeighMan;

                            var logOnWeighman = db.Weighmen.Where(w => w.ID == logOnWeighManIDFromSession).FirstOrDefault();
                            var logOnRole = sessionRole as Role;

                            if (filterContext.RouteData.Values["logOnSite"] == null)
                                filterContext.RouteData.Values.Add("logOnSite", currentSite);
                            if (filterContext.RouteData.Values["logOnWeighman"] == null)
                                filterContext.RouteData.Values.Add("logOnWeighman", logOnWeighman);
                            if (filterContext.RouteData.Values["logOnRole"] == null)
                                filterContext.RouteData.Values.Add("logOnRole", logOnRole);
                        }

                    }
                //}
            }
            else
            {
                filterContext.Result = new RedirectToRouteResult(
                           new RouteValueDictionary(new { controller = "Logon", action = "Login", returnUrl = filterContext.HttpContext.Request.RawUrl }));
            }
            base.OnActionExecuting(filterContext);
        }

        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            filterContext.HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
            filterContext.HttpContext.Response.Cache.SetValidUntilExpires(false);
            filterContext.HttpContext.Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);
            filterContext.HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            filterContext.HttpContext.Response.Cache.SetNoStore();
            base.OnResultExecuting(filterContext);
        }
    }
}