﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using PagedList;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class SiteController : EntityController<Site>
    {
        /// <summary>
        /// Get the list of Site based on the filters - Render the index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="state"></param>
        /// <param name="suburb"></param>
        /// <param name="postCode"></param>
        /// <returns></returns>
        // GET: Site
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string state, string suburb, string postCode)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSite;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSite;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSite;

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");

            ViewBag.SuburbSortParm = (sortOrder == "Suburb" ? "Suburb_Desc" : "Suburb");
            ViewBag.StateSortParm = (sortOrder == "State" ? "State_Desc" : "State");
            ViewBag.PostcodeSortParm = (sortOrder == "Postcode" ? "Postcode_Desc" : "Postcode");
            ViewBag.CountrySortParm = (sortOrder == "Country" ? "Country_Desc" : "Country");
            ViewBag.PhoneSortParm = (sortOrder == "Phone" ? "Phone_Desc" : "Phone");
            ViewBag.ContactSortParm = (sortOrder == "Contact" ? "Contact_Desc" : "Contact");
            ViewBag.EmailSortParm = (sortOrder == "Email" ? "Email_Desc" : "Email");

            ViewBag.DisplayTitle = "Sites";

            entities = from e in db.Sites select e;

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                entities = from e in db.Sites where e.ID == logOnSite.ID select e;
                ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Site");
            }


            //Filters

            ViewBag.States = Constants.AUS_STATES.ToList();
            ViewBag.Suburbs = db.Sites.Where(e => e.Suburb != null).GroupBy(r => r.Suburb).Select(group => group.Key).ToList();


            ViewBag.name = name;
            ViewBag.state = state;
            ViewBag.suburb = suburb;
            ViewBag.postCode = postCode;

            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!String.IsNullOrEmpty(state) && state != "All")
            {
                entities = entities.Where(e => e.State.ToUpper().Contains(state.ToUpper()));
            }

            if (!String.IsNullOrEmpty(suburb) && suburb != "All")
            {
                entities = entities.Where(e => e.Suburb.ToUpper().Contains(suburb.ToUpper()));
            }

            if (!String.IsNullOrEmpty(postCode))
            {
                entities = entities.Where(e => e.Postcode.Contains(postCode));
            }


            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;

                case "Suburb":
                    entities = entities.OrderBy(e => e.Suburb);
                    break;
                case "Suburb_Desc":
                    entities = entities.OrderByDescending(e => e.Suburb);
                    break;
                case "State":
                    entities = entities.OrderBy(e => e.State);
                    break;
                case "State_Desc":
                    entities = entities.OrderByDescending(e => e.State);
                    break;
                case "Postcode":
                    entities = entities.OrderBy(e => e.Postcode);
                    break;
                case "Postcode_Desc":
                    entities = entities.OrderByDescending(e => e.Postcode);
                    break;
                case "Country":
                    entities = entities.OrderBy(e => e.Country);
                    break;
                case "Country_Desc":
                    entities = entities.OrderByDescending(e => e.Country);
                    break;
                case "Phone":
                    entities = entities.OrderBy(e => e.Phone);
                    break;
                case "Phone_Desc":
                    entities = entities.OrderByDescending(e => e.Phone);
                    break;
                case "Contact":
                    entities = entities.OrderBy(e => e.Contact);
                    break;
                case "Contact_Desc":
                    entities = entities.OrderByDescending(e => e.Contact);
                    break;
                case "Email":
                    entities = entities.OrderBy(e => e.Email);
                    break;
                case "Email_Desc":
                    entities = entities.OrderByDescending(e => e.Email);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);

            pageSize = filterPageSize ?? pageSize;

            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Render the details page - from the grid details action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        // GET: Site/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSite;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSite;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSite;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Sites.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Navigate to create site page - from the index page
        /// </summary>
        /// <returns></returns>
        // GET: Site/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSite;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSite;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSite;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);

            var centralSite = db.Sites.Find(1);
            string strSiteCountAllowed = centralSite.SiteCount.Decrypt();
            int intSiteCountAllowed;
            if (!int.TryParse(strSiteCountAllowed, out intSiteCountAllowed))
            {
                intSiteCountAllowed = 1;
            }

            int intSiteCountActual = db.Sites.Count() - 1; //minus central site

            if (intSiteCountActual >= intSiteCountAllowed)
            {
                TempData["UserMessage"] = "Exceeds Maximum Site Number Licence. Contact Weigh-More Solutions Sales Team if an Increase is Required at: sales@Qweigh-more.com.au";
                return RedirectToAction("Index");
            }

            return View();
        }

        /// <summary>
        /// Create a new site and saved to DB
        /// </summary>
        /// <param name="site"></param>
        /// <returns></returns>

        // POST: Site/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewSite")]
        public ActionResult Create([Bind(Include = "ID,Code,Name,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Fax,Mobile,Contact,Email,CurrentDocket,DocketHead")] Site site)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSite;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSite;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSite;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, site.State);

            var nameExist = db.Sites.FirstOrDefault(e => e.Name == site.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "Site already exists");
                return View(site);
            }
            if (ModelState.IsValid)
            {
                site.Customers = new List<Customer> { db.Customers.Find(CoreConstants.NA_ID) };
                site.Products = new List<Product> { db.Products.Find(CoreConstants.NA_ID) };
                site.Destinations = new List<Destination> { db.Destinations.Find(CoreConstants.NA_ID) };
                site.Sources = new List<Source> { db.Sources.Find(CoreConstants.NA_ID) };
                site.Jobs = new List<Job> { db.Jobs.Find(CoreConstants.NA_ID) };

                db.Sites.Add(site);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(site.Name + " created successfully!");
                return RedirectToAction("Edit/" + site.ID.ToString());
            }

            return View(site);
        }

        /// <summary>
        /// Navigate to edit page for the site  - Navigate from the grid edit action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        // GET: Site/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSite;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSite;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSite;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Sites.Find(id);
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);

            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Update site details and saved to DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Site/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditSite")]
        public ActionResult EditPost(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSite;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSite;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSite;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");


            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Sites.Find(id);
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);
            if (TryUpdateModel(entity, "", new string[] { "Name", "Description", "Code", "Address1", "Address2", "Suburb", "State", "Postcode",
                "Country", "Phone", "Fax", "Mobile", "Contact", "Email", "CurrentDocket", "DocketHead" }))
            {
                try
                {
                    var siteExist = db.Sites.FirstOrDefault(e => e.Name == entity.Name);
                    if (siteExist != null)
                    {
                        if (siteExist.ID == entity.ID)
                        {
                            if (ModelState.IsValid)
                            {
                                var entityUpdate = db.Sites.Find(entity.ID);
                                entityUpdate.Name = entity.Name;
                                entityUpdate.Description = entity.Description;
                                entityUpdate.Code = entity.Code;
                                entityUpdate.Address1 = entity.Address1;
                                entityUpdate.Address2 = entity.Address2;
                                entityUpdate.Suburb = entity.Suburb;
                                entityUpdate.State = entity.State;
                                entityUpdate.Postcode = entity.Postcode;
                                entityUpdate.Country = entity.Country;
                                entityUpdate.Phone = entity.Phone;
                                entityUpdate.Fax = entity.Fax;
                                entityUpdate.Mobile = entity.Mobile;
                                entityUpdate.Contact = entity.Contact;
                                entityUpdate.Email = entity.Email;
                                entityUpdate.CurrentDocket = entity.CurrentDocket;
                                entityUpdate.DocketHead = entity.DocketHead;

                                if (TryUpdateModel(entityUpdate, "",
                                         new string[] { "Name", "Description", "Code", "Address1", "Address2", "Suburb", "State", "Postcode", "Country", "Phone", "Fax", "Mobile", "Contact", "Email", "CurrentDocket", "DocketHead" }))

                                    db.SaveChanges();

                                //Adding to the ReplicationLogItem for data sync
                                WriteReplicationLog(entityUpdate.ID, entityUpdate.ID, CoreConstants.UpdateOp, logOnSite.ID, db);

                                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                                return RedirectToAction("Edit/" + entity.ID.ToString());
                            }
                        }
                        else
                        {
                            ModelState.AddModelError("Name", "Site already exists");
                            return View(entity);
                        }
                    }


                    if (ModelState.IsValid)
                    {
                        db.Entry(entity).State = EntityState.Modified;
                        db.SaveChanges();
                        TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully!");
                        return RedirectToAction("Edit/" + entity.ID.ToString());
                    }

                }
                catch (RetryLimitExceededException)
                {

                    //Log the error (uncomment dex variable name and add a line here to write a log.
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }

            }

            return View(entity);
        }

        /// <summary>
        /// Navigate to the delete site page - from the grid delete action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Site/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSite;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSite;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSite;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Sites.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Remove the site from the site table
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Site/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteSite")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSite;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSite;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSite;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");
            try
            {
                entity = db.Sites.Find(id);
                db.Sites.Remove(entity);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This site " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }

        
        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
