﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using PagedList;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class CustomerController : EntityController<Customer>
    {
        /// <summary>
        /// Get Customer list for index grid
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="customerType"></param>
        /// <param name="name"></param>
        /// <param name="accountNumber"></param>
        /// <param name="state"></param>
        /// <param name="suburb"></param>
        /// <param name="site"></param>
        /// <param name="deliveryState"></param>
        /// <param name="paymentType"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult Index(string sortOrder, string customerType, string name, string accountNumber, string state, string suburb,
                                                    string site, string deliveryState, string paymentType, string status, int? page, int? filterPageSize)
        {            
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewCustomer;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditCustomer;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteCustomer;
            if (customerType == null)
            {
                customerType = "C"; // should be "C",  not used to be "CUS", 
            }

            ViewBag.CustomerType = customerType;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView(GetDisplayTitle(customerType, true));

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.AccountNumberSortParm = (sortOrder == "AccountNumber" ? "AccountNumber_Desc" : "AccountNumber");
            ViewBag.PaymentMethodSortParm = (sortOrder == "PaymentMethod" ? "PaymentMethod_Desc" : "PaymentMethod");
            ViewBag.SuburbSortParm = (sortOrder == "Suburb" ? "Suburb_Desc" : "Suburb");
            ViewBag.StateSortParm = (sortOrder == "State" ? "State_Desc" : "State");
            ViewBag.PostcodeSortParm = (sortOrder == "Postcode" ? "Postcode_Desc" : "Postcode");
            ViewBag.CountrySortParm = (sortOrder == "Country" ? "Country_Desc" : "Country");
            ViewBag.Action = "Index";
            ViewBag.Controller = "Customer";

            //Filters

            ViewBag.AllStates = Constants.AUS_STATES.ToList();
            ViewBag.Sites = db.Sites.Where(s => s.ID > 1).ToList();
            ViewBag.Suburbs = db.Customers.Where(e => e.Suburb != null).GroupBy(r => r.Suburb).Select(group => group.Key).ToList();
            ViewBag.DeliveryStates = Constants.AUS_STATES.ToList();
            ViewBag.PaymentTypes = Constants.PAYMENTS.ToList();

            status = String.IsNullOrEmpty(status) ? "true" : status;

            ViewBag.name = name;
            ViewBag.accountNumber = accountNumber;
            ViewBag.state = state;
            ViewBag.suburb = suburb;
            ViewBag.site = site;
            ViewBag.deliveryState = deliveryState;
            ViewBag.paymentType = paymentType;
            ViewBag.status = status;


            entities = from e in db.Customers where e.CustomerType == customerType select e; // used to : db

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.Customers == null)
                {
                    entities = from e in db.Customers where e.Name == CoreConstants.NA select e;
                }
                else
                {
                    entities = logOnSite.Customers.Where(e => ((e.ID > CoreConstants.NA_ID) && (e.CustomerType == customerType))).AsQueryable<Customer>();                    
                }

            }

            if (!string.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!string.IsNullOrEmpty(accountNumber))
            {
                entities = entities.Where(e => e.AccountNumber.ToUpper().Contains(accountNumber.ToUpper()));
            }

            if (!string.IsNullOrEmpty(state) && state != "All")
            {
                entities = entities.Where(e => e.State == state);
            }

            if (!string.IsNullOrEmpty(suburb) && suburb != "All")
            {
                entities = entities.Where(e => e.Suburb == suburb);
            }

            if (!string.IsNullOrEmpty(site) && site != "All")
            {
                int siteId = int.Parse(site);
                var list = db.Sites.Where(r => r.ID == siteId).Select(e => e.Customers).ToList();
                entities = entities.Where(e => e.Sites.Any(st => st.ID == siteId));
            }

            if (!string.IsNullOrEmpty(deliveryState) && deliveryState != "All")
            {
                entities = entities.Where(e => e.DeliveryState == deliveryState);
            }

            if (!string.IsNullOrEmpty(paymentType))
            {
                entities = entities.Where(e => e.PaymentMethod.ToUpper().Contains(paymentType.ToUpper()));
            }

            if (!string.IsNullOrEmpty(status) && status != "All")
            {
                bool statusId = bool.Parse(status);
                entities = entities.Where(e => e.Active == statusId);
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "AccountNumber":
                    entities = entities.OrderBy(e => e.AccountNumber);
                    break;
                case "AccountNumber_Desc":
                    entities = entities.OrderByDescending(e => e.AccountNumber);
                    break;
                case "PaymentMethod":
                    entities = entities.OrderBy(e => e.PaymentMethod);
                    break;
                case "PaymentMethod_Desc":
                    entities = entities.OrderByDescending(e => e.PaymentMethod);
                    break;
                case "Suburb":
                    entities = entities.OrderBy(e => e.Suburb);
                    break;
                case "Suburb_Desc":
                    entities = entities.OrderByDescending(e => e.Suburb);
                    break;
                case "State":
                    entities = entities.OrderBy(e => e.State);
                    break;
                case "State_Desc":
                    entities = entities.OrderByDescending(e => e.State);
                    break;
                case "Postcode":
                    entities = entities.OrderBy(e => e.Postcode);
                    break;
                case "Postcode_Desc":
                    entities = entities.OrderByDescending(e => e.Postcode);
                    break;
                case "Country":
                    entities = entities.OrderBy(e => e.Country);
                    break;
                case "Country_Desc":
                    entities = entities.OrderByDescending(e => e.Country);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;
          
            try
            {                
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }

        }

        /// <summary>
        /// Get the Customer details based on the customer Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Customer/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditCustomer;



            entity = new Customer { Name = "Connection Failed! Retry later." };
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                
                entity = db.Customers.Include(c => c.Sites).Where(c => c.ID == id).Single();
                if (entity == null)
                {
                    return HttpNotFound();
                }

                ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");
                ViewBag.CustomerOrSupplier = GetDisplayTitle(entity.CustomerType, false);

            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }

            return View(entity);
        }

        [SessionAccess]
        public ActionResult Create(string customerType)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewCustomer;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditCustomer;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteCustomer;

            if (customerType == null)
            {
                customerType = CoreConstants.CustomerType;
            }

            ViewBag.CustomerType = customerType;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create"); ;
            ViewBag.CustomerOrSupplier = GetDisplayTitle(customerType, false);

            ViewBag.PaymentMethod = new SelectList(CoreConstants.PAYMENTS, CoreConstants.PAYMENT_ACCOUNT);
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);
            ViewBag.DeliveryState = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);
            ViewBag.TicketCopies = new SelectList(CoreConstants.TICKET_COPIES, "1");

            entity = new Customer() { };
            entity.Active = true;

            entity.Sites = new List<Site>();
           
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            return View(entity);
        }

        /// <summary>
        ///  To create a new Customer
        /// </summary>
        /// <param name="customer"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>

        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewCustomer")]
        public ActionResult Create([Bind(Include = "Name,CustomerType,Description,AccountNumber,Address1,Address2,Suburb,State,Postcode,Country,Phone,Fax,Mobile,Contact,Email,ABN,Delivery,DeliveryAddress1,DeliveryAddress2,DeliverySuburb,DeliveryState,DeliveryPostcode,DeliveryZone,DeliveryPhone,TagID,PaymentMethod,FixedCharge,NoGST,Active,HidePriceOnTicket,TicketCopies,FixedCartage,IsOrderNoRequired,Discount")] Customer customer, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewCustomer;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditCustomer;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteCustomer;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create"); ;
            ViewBag.CustomerOrSupplier = GetDisplayTitle(customer.CustomerType, false);
            ViewBag.PaymentMethod = new SelectList(CoreConstants.PAYMENTS, customer.PaymentMethod);
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, customer.State);
            ViewBag.DeliveryState = new SelectList(CoreConstants.AUS_STATES, customer.DeliveryState);
            ViewBag.TicketCopies = new SelectList(CoreConstants.TICKET_COPIES, customer.TicketCopies.ToString());

            entity = new Customer();
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

            if (!logOnSiteIsCentral) // not central site
            {
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
                customer.SiteCreated = true;
                customer.Name = logOnSite.PrefixEntityName(customer.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
            }

            if (selectedSites != null)
            {
                customer.Sites = entity.Sites;
                foreach (var site in selectedSites)
                {
                    var siteToAdd = db.Sites.Find(int.Parse(site));
                    customer.Sites.Add(siteToAdd);                   
                }
                List<AssignedSiteData> siteData = GetEntityAssignedSiteData(db, customer.Sites);
                ViewBag.Sites = siteData;
            }

            try
            {
                var nameExist = db.Customers.FirstOrDefault(e => e.Name == customer.Name);
                if (nameExist != null)
                {
                    var custType = nameExist.CustomerType == "C" ? "Customer" : "Supplier";
                    ModelState.AddModelError("Name", custType + " already exists");
                    return View(customer);
                }

                if (ModelState.IsValid)
                {
                    customer.Name = customer.Name.ToUpper();
                    db.Customers.Add(customer);
                    db.SaveChanges();

                    //Adding to the ReplicationLogItem for data sync
                    if (selectedSites != null)
                    {
                        foreach (var site in selectedSites)
                        {
                            var siteToAdd = db.Sites.Find(int.Parse(site));
                            if (siteToAdd != null)
                            {
                                WriteReplicationLog(siteToAdd.ID, customer.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                            }

                        }

                    }

                    TempData["UserMessage"] = ComposeTempDisplayMessage(customer.Name + " created successfully! ", logOnSite);                    
                    return RedirectToAction("Edit/" + customer.ID.ToString());
                }

            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }

            return View(customer);
        }

        // GET: Customer/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewCustomer;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditCustomer;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteCustomer;

            entity = new Customer { Name = "Connection Failed! Retry later." };

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            try
            {                
                entity = db.Customers.Include(c => c.Sites).Where(c => c.ID == id).Single();

                if (entity == null)
                {
                    return HttpNotFound();
                }

                ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

                ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit"); ;
                ViewBag.CustomerOrSupplier = GetDisplayTitle(entity.CustomerType, false);
                ViewBag.PaymentMethod = new SelectList(CoreConstants.PAYMENTS, entity.PaymentMethod);
                ViewBag.State = new SelectList(Constants.AUS_STATES, entity.State);
                ViewBag.DeliveryState = new SelectList(CoreConstants.AUS_STATES, entity.DeliveryState);
                ViewBag.TicketCopies = new SelectList(CoreConstants.TICKET_COPIES, entity.TicketCopies.ToString());
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }

            return View(entity);
        }

        /// <summary>
        /// Edit the customer based on the customer id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>

        // POST: Customer/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditCustomer")]
        //public ActionResult Edit([Bind(Include = "ID,Name,Description,AccountNumber,CreationDate,Address1,Address2,Suburb,State,Postcode,Country,Phone,Fax,Mobile,Contact,Comment,Email,ABN,Delivery,DeliveryAddress1,DeliveryAddress2,DeliverySuburb,DeliveryState,DeliveryPostcode,DeliveryZone,DeliveryPhone,TagID,PaymentMethod,NoGST")] Customer customer, string[] selectedSites)
        public ActionResult Edit(int? id, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            if (logOnSite == null)
            {
                return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            }
            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewCustomer;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditCustomer;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteCustomer;

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            if (!logOnSiteIsCentral) // not central site
            {

                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
            }

            entity = db.Customers.Include(c => c.Sites).Where(c => c.ID == id).Single();

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");
            ViewBag.CustomerOrSupplier = GetDisplayTitle(entity.CustomerType, false);
            ViewBag.PaymentMethod = new SelectList(CoreConstants.PAYMENTS, entity.PaymentMethod);
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);
            ViewBag.DeliveryState = new SelectList(CoreConstants.AUS_STATES, entity.DeliveryState);
            ViewBag.TicketCopies = new SelectList(CoreConstants.TICKET_COPIES, entity.TicketCopies.ToString());
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            if (TryUpdateModel(entity, "", new string[] { "Name", "Description", "AccountNumber", "PaymentMethod", "Address1", "Address2", "Suburb",
                "State", "Postcode", "Country", "Phone", "Fax", "Mobile", "Contact",  "Email","ABN", "Delivery", "DeliveryAddress1", "DeliveryAddress2",
                "DeliverySuburb", "DeliveryState", "DeliveryPostcode", "DeliveryZone", "DeliveryPhone", "FixedCharge", "NoGST", "Active", "HidePriceOnTicket", "TicketCopies", "FixedCartage","IsOrderNoRequired","Discount" }))
            {
                try
                {
                    var customerExist = db.Customers.FirstOrDefault(e => e.Name == entity.Name);
                    if (customerExist != null)
                    {
                        if (customerExist.ID == entity.ID)
                        {
                            if (ModelState.IsValid)
                            {
                                var entityUpdate = db.Customers.Find(entity.ID);
                                entityUpdate.Name = entity.Name.ToUpper();
                                entityUpdate.Description = entity.Description;
                                entityUpdate.AccountNumber = entity.AccountNumber;
                                entityUpdate.PaymentMethod = entity.PaymentMethod;
                                entityUpdate.Address1 = entity.Address1;
                                entityUpdate.Address2 = entity.Address2;
                                entityUpdate.Suburb = entity.Suburb;
                                entityUpdate.State = entity.State;
                                entityUpdate.Postcode = entity.Postcode;
                                entityUpdate.Country = entity.Country;
                                entityUpdate.Phone = entity.Phone;
                                entityUpdate.Fax = entity.Description;
                                entityUpdate.Mobile = entity.Mobile;
                                entityUpdate.Contact = entity.Contact;
                                entityUpdate.Email = entity.Email;
                                entityUpdate.ABN = entity.ABN;
                                entityUpdate.Delivery = entity.Delivery;
                                entityUpdate.DeliveryAddress1 = entity.DeliveryAddress1;
                                entityUpdate.DeliveryAddress2 = entity.DeliveryAddress2;
                                entityUpdate.DeliverySuburb = entity.DeliverySuburb;
                                entityUpdate.DeliveryState = entity.DeliveryState;
                                entityUpdate.DeliveryPostcode = entity.DeliveryPostcode;
                                entityUpdate.DeliveryZone = entity.DeliveryZone;
                                entityUpdate.DeliveryPhone = entity.DeliveryPhone;
                                entityUpdate.FixedCharge = entity.FixedCharge;
                                entityUpdate.NoGST = entity.NoGST;
                                entityUpdate.Active = entity.Active;
                                entityUpdate.HidePriceOnTicket = entity.HidePriceOnTicket;
                                entityUpdate.TicketCopies = entity.TicketCopies;
                                entityUpdate.FixedCartage = entity.FixedCartage;
                                entityUpdate.IsOrderNoRequired = entity.IsOrderNoRequired;
                                entityUpdate.Discount = entity.Discount;

                                UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
                                if (TryUpdateModel(entityUpdate, "",
                                         new string[] { "Name", "Description", "AccountNumber", "PaymentMethod", "Address1", "Address2", "Suburb",
                                "State", "Postcode", "Country", "Phone", "Fax", "Mobile", "Contact",  "Email","ABN", "Delivery", "DeliveryAddress1", "DeliveryAddress2",
                                "DeliverySuburb", "DeliveryState", "DeliveryPostcode", "DeliveryZone", "DeliveryPhone", "FixedCharge", "NoGST", "Active", "HidePriceOnTicket", "TicketCopies", "FixedCartage","IsOrderNoRequired","Discount"}))

                                    db.SaveChanges();

                                //Adding to the ReplicationLogItem for data sync
                                if (selectedSites != null)
                                {
                                    foreach (var site in selectedSites)
                                    {
                                        var siteToAdd = db.Sites.Find(int.Parse(site));
                                        if (siteToAdd != null)
                                        {
                                            WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                        }

                                    }

                                }
                                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                                //                                return RedirectToAction("Index", new { customerType = entity.CustomerType });
                                return RedirectToAction("Edit/" + entity.ID.ToString());

                            }
                        }
                        else
                        {
                            var custType = entity.CustomerType == "C" ? "Customer" : "Supplier";
                            ModelState.AddModelError("Name", custType + " already exists");
                            return View(entity);
                        }
                    }
                    if (ModelState.IsValid)
                    {
                        entity.Name = entity.Name.ToUpper();
                        UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
                        if (!logOnSiteIsCentral) // not central site
                        {
                            entity.Name = logOnSite.PrefixEntityName(entity.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
                        }
                        db.Entry(entity).State = EntityState.Modified;
                        db.SaveChanges();

                        //Adding to the ReplicationLogItem for data sync
                        if (selectedSites != null)
                        {
                            foreach (var site in selectedSites)
                            {
                                var siteToAdd = db.Sites.Find(int.Parse(site));
                                if (siteToAdd != null)
                                {
                                    WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                }

                            }

                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ", logOnSite);                        
                        return RedirectToAction("Edit/" + entity.ID.ToString());
                    }

                }
                catch (RetryLimitExceededException)
                {

                    //Log the error (uncomment dex variable name and add a line here to write a log.
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }

            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
            return View(entity);

        }

        /// <summary>
        /// Delete the customer based on the customer id - it navigates to the details page before you delete
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewCustomer;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditCustomer;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteCustomer;

            entity = new Customer { Name = "Connection Failed! Retry later." };
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                entity = db.Customers.Find(id);
                if (entity == null)
                {
                    return HttpNotFound();
                }

                ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");
                ViewBag.CustomerOrSupplier = GetDisplayTitle(entity.CustomerType, false);

            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(entity);
        }
        /// <summary>
        /// Remove the customer from the DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Customer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteCustomer")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewCustomer;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditCustomer;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteCustomer;
            entity = new Customer();
            try
            {
                entity = db.Customers.Find(id);                
                entity.Active = false;
                db.Entry(entity).State = EntityState.Modified;
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
                db.SaveChanges();

                var siteList = db.Sites.Where(s => s.ID > 1).ToList();
                foreach (var siteItem in siteList)
                {
                    WriteReplicationLog(siteItem.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                }
            }
            catch (Exception)
            {
                var custType = entity.CustomerType == "C" ? "Customer" : "Supplier";
                TempData["UserMessage"] = ComposeTempDisplayMessage("This " + custType + " " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }
          
            return RedirectToAction("Index", new { customerType = entity.CustomerType });

        }

        public ActionResult Reset()
        {
            ModelState.Clear();
            ViewBag.filterState = null;
            ViewBag.filterPaymenr = null;
            ViewBag.accountNumber = null;

            return View("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}