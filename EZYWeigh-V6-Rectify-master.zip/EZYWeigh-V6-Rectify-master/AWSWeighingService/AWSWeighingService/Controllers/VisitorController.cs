﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using PagedList;
using System.Data.Entity.Infrastructure;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
   
    public class VisitorController : EntityController<Visitor>
    {
        // GET: Visitor

        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Visitors");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.OrganisationSortParm = (sortOrder == "Organisation" ? "Organisation_Desc" : "Organisation");
            ViewBag.PhoneSortParm = (sortOrder == "Phone" ? "Phone_Desc" : "Phone");
            ViewBag.MobileSortParm = (sortOrder == "Mobile" ? "Mobile_Desc" : "Mobile");
            ViewBag.SiteSortParm = (sortOrder == "Site" ? "Site_Desc" : "Site");
            ViewBag.WeighmanSortParm = (sortOrder == "Weighman" ? "Weighman_Desc" : "Weighman");
            ViewBag.DateTimeInSortParm = (sortOrder == "DateTimeIn" ? "DateTimeIn_Desc" : "DateTimeIn");
            ViewBag.DateTimeOutSortParm = (sortOrder == "DateTimeOut" ? "DateTimeOut_Desc" : "DateTimeOut");

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            entities = db.Visitors.Include(v => v.Site).Include(v => v.Weighman);

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.Visitors == null)
                {
                    entities = from e in db.Visitors where e.ID == CoreConstants.NA_ID select e;
                }
                else
                {
                    entities = logOnSite.Visitors.AsQueryable<Visitor>();
                }
            }


            if (!String.IsNullOrEmpty(searchString))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(searchString.ToUpper())
                                          || e.Organisation.ToUpper().Contains(searchString.ToUpper())
                                          || e.Phone.ToUpper().Contains(searchString.ToUpper())
                                          || e.Mobile.ToUpper().Contains(searchString.ToUpper())
                                          || e.Site.Name.ToUpper().Contains(searchString.ToUpper())
                                          || e.Weighman.Name.ToUpper().Contains(searchString.ToUpper())

                                         );
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Organisation":
                    entities = entities.OrderBy(e => e.Organisation);
                    break;
                case "Organisation_Desc":
                    entities = entities.OrderByDescending(e => e.Organisation);
                    break;

                case "Phone":
                    entities = entities.OrderBy(e => e.Phone);
                    break;
                case "Phone_Desc":
                    entities = entities.OrderByDescending(e => e.Phone);
                    break;

                case "Mobile":
                    entities = entities.OrderBy(e => e.Mobile);
                    break;
                case "Mobile_Desc":
                    entities = entities.OrderByDescending(e => e.Mobile);
                    break;

                case "Site":
                    entities = entities.OrderBy(e => e.Site.Name);
                    break;
                case "Site_Desc":
                    entities = entities.OrderByDescending(e => e.Site.Name);
                    break;
                case "Weighman":
                    entities = entities.OrderBy(e => e.Weighman.Name);
                    break;
                case "Weighman_Desc":
                    entities = entities.OrderByDescending(e => e.Weighman.Name);
                    break;
                case "DateTimeIn":
                    entities = entities.OrderBy(e => e.DateTimeIn);
                    break;
                case "DateTimeIn_Desc":
                    entities = entities.OrderByDescending(e => e.DateTimeIn);
                    break;
                case "DateTimeOut":
                    entities = entities.OrderBy(e => e.DateTimeOut);
                    break;
                case "DateTimeOut_Desc":
                    entities = entities.OrderByDescending(e => e.DateTimeOut);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }


            pageNumber = (page ?? 1);

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        // GET: Visitor/Details/5
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Visitors.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        // GET: Visitor/Create
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            if (logOnSiteIsCentral)
            {
                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            }
            else
            {
                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen, "ID", "Name");
            }

            return View();
        }

        // POST: Visitor/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Name,Description,Organisation,Phone,Mobile,HasLeft,DateTimeIn,DateTimeOut,SiteID,WeighmanID")] Visitor visitor)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            if (ModelState.IsValid)
            {
                db.Visitors.Add(visitor);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(visitor.Name + " created successfully! ");
                return RedirectToAction("Index");
            }

            if (logOnSiteIsCentral)
            {
                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            }
            else
            {
                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen, "ID", "Name");
            }

            return View(visitor);
        }

        // GET: Visitor/Edit/5
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Visitors.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }

            if (logOnSiteIsCentral)
            {
                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            }
            else
            {
                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen, "ID", "Name");
            }

            return View(entity);
        }

        // POST: Visitor/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Name,Description,Organisation,Phone,Mobile,HasLeft,DateTimeIn,DateTimeOut,SiteID,WeighmanID")] Visitor visitor)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (ModelState.IsValid)
            {
                db.Entry(visitor).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(visitor.Name + " edited successfully! ");
                return RedirectToAction("Index");
            }

            if (logOnSiteIsCentral)
            {
                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            }
            else
            {
                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen, "ID", "Name");
            }

            return View(visitor);
        }

        // GET: Visitor/Delete/5
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Visitors.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        // POST: Visitor/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            entity = db.Visitors.Find(id);
            db.Visitors.Remove(entity);
            db.SaveChanges();
            TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
            return RedirectToAction("Index");
        }

        [NonAction]
        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
