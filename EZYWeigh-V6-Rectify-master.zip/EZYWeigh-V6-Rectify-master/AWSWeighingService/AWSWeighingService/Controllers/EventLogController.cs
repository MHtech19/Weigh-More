﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using System;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace AWSWeighingService.Controllers
{
    public class EventLogController : EntityController<WMSEventLog>
    {
        /// <summary>
        /// Get the EventLog list - navigates to the index page
        /// </summary>
        /// <returns></returns>

        [SessionAccess]
        public ActionResult Index()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = "Event Log";

            WMSEventLogViewModel viewModelObj = new WMSEventLogViewModel() { };
            viewModelObj.StartDate = DateTime.Now;
            viewModelObj.EndDate = DateTime.Now.AddDays(1);

            return View(viewModelObj);
        }

        /// <summary>
        /// Get the list of events in the WMSEventLog table - bind to the index grid
        /// </summary>
        /// <param name="sidx"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></paramGetEventLogList
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="eventTypeId"></param>
        /// <returns></returns>
        [SessionAccess]
        public JsonResult GetEventLogList(string sord, int page, int rows, DateTime? startDate, DateTime? endDate, int? eventTypeId)
        {
            //DataBaseConnectionStringName = GetConnectionStringNameFromSession();

            //if (DataBaseConnectionStringName != string.Empty)
            //{
            //    RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            //}
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();

            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            var listResults = db.WMSEventLogs.Select(e => e);           

            if (startDate != null && endDate != null)
            {
                listResults = listResults.Where(e => DbFunctions.TruncateTime(e.EventDateTime) >= DbFunctions.TruncateTime(startDate) && DbFunctions.TruncateTime(e.EventDateTime) <= DbFunctions.TruncateTime(endDate));
            }

            if (eventTypeId != null)
            {
                listResults = listResults.Where(e => e.EventType == eventTypeId);
            }

            var finalResults = listResults.ToList().Select(a => new
            {
                Id = a.ID,
                EventType = a.EventType,
                EventTypeName = this.GetWMSEventTypeName(a.EventType),
                DateStamp = a.DateStamp,
                Name = a.Name,
                Registration = a.Registration,
                EventDateTime = a.EventDateTime
            });

            int totalRecords = finalResults.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);

            if (sord.ToUpper() == "DESC")
            {
                finalResults = finalResults.OrderByDescending(s => s.EventDateTime);
                finalResults = finalResults.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                finalResults = finalResults.OrderBy(s => s.EventDateTime);
                finalResults = finalResults.Skip(pageIndex * pageSize).Take(pageSize);
            }

            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = finalResults
            };
            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Get the event name based on the event type
        /// </summary>
        /// <param name="eventType"></param>
        /// <returns></returns>
        private string GetWMSEventTypeName(int eventType)
        {
            string name = string.Empty;
            switch (eventType)
            {
                case 0:
                    name = "System";
                    break;
                case 1:
                    name = "First Weigh";
                    break;
                case 2:
                    name = "Incomplete Transaction";
                    break;
                case 3:
                    name = "Complete Transaction";
                    break;
                case 4:
                    name = "Visiting";
                    break;
                case 5:
                    name = "Offence";
                    break;
                default:
                    name = "Other";
                    break;
            }
            return name;
        }
    }
}