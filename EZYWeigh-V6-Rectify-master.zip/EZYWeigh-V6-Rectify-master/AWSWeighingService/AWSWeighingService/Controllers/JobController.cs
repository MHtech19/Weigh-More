﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using PagedList;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class JobController : EntityController<Job>
    {

        /// <summary>
        /// Get the Job list - navigate to index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <param name="orderNumber"></param>
        /// <param name="product"></param>
        /// <param name="customer"></param>
        /// <param name="site"></param>
        /// <param name="source"></param>
        /// <param name="destination"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        /// 
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string code, string orderNumber, string product, string customer,
                                  string site, string source, string destination, string status)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Jobs");


            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");
            ViewBag.OrderNumberSortParm = (sortOrder == "OrderNumber" ? "OrderNumber_Desc" : "OrderNumber");
            ViewBag.ProductSortParm = (sortOrder == "Product" ? "Product_Desc" : "Product");
            ViewBag.CustomerSortParm = (sortOrder == "Customer" ? "Customer_Desc" : "Customer");

            entities = from e in db.Jobs select e;

            IEnumerable<int> sourcelist;
            IEnumerable<int> destinationlist;

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.Jobs == null)
                {
                    entities = from e in db.Jobs where e.Name == CoreConstants.NA select e;
                }
                else
                {
                    entities = logOnSite.Jobs.AsQueryable<Job>();
                }
            }

            entities = entities.Include(e => e.Product).Include(e => e.Customer).Where(e => e.ID > CoreConstants.NA_ID);

            //Filters

            ViewBag.Customers = db.Customers.Select(e => new { Id = e.ID, Name = e.Name }).OrderBy(r => r.Name).ToList();
            ViewBag.Products = db.Products.Select(e => new { Id = e.ID, Name = e.Name }).OrderBy(r => r.Name).ToList();
            ViewBag.Sources = db.Sources.Select(e => new { Id = e.ID, Name = e.Name }).OrderBy(r => r.Name).ToList();
            ViewBag.Destinations = db.Destinations.Select(e => new { Id = e.ID, Name = e.Name }).OrderBy(r => r.Name).ToList();
            ViewBag.Sites = db.Sites.Where(s => s.ID > 1).ToList();

            //Be default load all active jobs
            status = status ?? "true";

            ViewBag.name = name;
            ViewBag.code = code;
            ViewBag.orderNumber = orderNumber;
            ViewBag.product = product;
            ViewBag.customer = customer;
            ViewBag.site = site;
            ViewBag.source = source;
            ViewBag.destination = destination;
            ViewBag.status = status;


            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }


            if (!String.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));
            }

            if (!String.IsNullOrEmpty(orderNumber))
            {
                entities = entities.Where(e => e.OrderNumber.ToUpper().Contains(orderNumber.ToUpper()));
            }

            if (!String.IsNullOrEmpty(customer) && customer != "All")
            {
                var customerId = int.Parse(customer);
                entities = entities.Where(e => e.CustomerID == customerId);
            }

            if (!string.IsNullOrEmpty(site) && site != "All")
            {
                int siteId = int.Parse(site);
                entities = entities.Where(s => s.Sites.Any(st => st.ID == siteId));
            }

            if (!String.IsNullOrEmpty(product) && product != "All")
            {
                var productId = int.Parse(product);
                entities = entities.Where(e => e.ProductID == productId);
            }


            if (!String.IsNullOrEmpty(source) && source != "All")
            {
                int sourceId = int.Parse(source);

                sourcelist = (from js in db.JobSource
                              join src in db.Sources on js.SourceID equals src.ID
                              where src.ID == sourceId
                              select js.JobID).Distinct();

                entities = entities.Where(e => sourcelist.Contains(e.ID));
            }

            if (!String.IsNullOrEmpty(destination) && destination != "All")
            {
                int destinationId = int.Parse(destination);

                destinationlist = (from jd in db.JobDestination
                                   join dest in db.Destinations on jd.DestinationID equals dest.ID
                                   where dest.ID == destinationId
                                   select jd.JobID).Distinct();

                entities = entities.Where(e => destinationlist.Contains(e.ID));
            }



            if (!String.IsNullOrEmpty(status) && status != "All")
            {
                var statusId = bool.Parse(status);
                entities = entities.Where(e => e.IsActive == statusId);
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;

                case "OrderNumber":
                    entities = entities.OrderBy(e => e.OrderNumber);
                    break;
                case "OrderNumber_Desc":
                    entities = entities.OrderByDescending(e => e.OrderNumber);
                    break;

                case "Product":
                    entities = entities.OrderBy(e => e.Product.Name);
                    break;
                case "Product_Desc":
                    entities = entities.OrderByDescending(e => e.Product.Name);
                    break;

                case "Customer":
                    entities = entities.OrderBy(e => e.Customer.Name);
                    break;
                case "Customer_Desc":
                    entities = entities.OrderByDescending(e => e.Customer.Name);
                    break;

                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }
            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Get the details of the job based on the job id - navigate to the details page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Job/Details/5

        [SessionAccess]
        public ActionResult Details(int? id)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;

            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Jobs.Include(e => e.Customer).Include(e => e.Product).Include(e => e.Sites).Single(e => e.ID == id);
            entity.DestinationNames = string.Join(",", (from td in db.JobDestination
                                                        join d in db.Destinations on td.DestinationID equals d.ID
                                                        where td.JobID == id
                                                        select d.Name).ToArray());
            entity.SourceNames = string.Join(",", (from ts in db.JobSource
                                                   join s in db.Sources on ts.SourceID equals s.ID
                                                   where ts.JobID == id
                                                   select s.Name).ToArray());
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Navigate to the create job page
        /// </summary>
        /// <returns></returns>
        // GET: Job/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            entity = new Job() { };
            entity.IsActive = true;
            entity.Sites = new List<Site>();


            if (!logOnSiteIsCentral)
            {
                ViewBag.Sites = new List<AssignedSiteData>();
                ViewBag.CustomerID = new SelectList(logOnSite.Customers.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.ProductID = new SelectList(logOnSite.Products.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.DestinationID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(logOnSite.Destinations.OrderBy(e => e.Name), "ID", "Name"));
                ViewBag.SourceID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(logOnSite.Sources.OrderBy(e => e.Name), "ID", "Name"));

            }
            else
            {
                ViewBag.Sites = GetEntityAssignedSiteData(db, entity.Sites);
                ViewBag.CustomerID = new SelectList(db.Customers.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.ProductID = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.DestinationID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name"));
                ViewBag.SourceID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name"));

            }

            ViewBag.JobState = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);

            return View(entity);
        }

        /// <summary>
        /// Create a job - Added in the DB
        /// </summary>
        /// <param name="job"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Job/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewJob")]
        public ActionResult Create([Bind(Include = "ID,Name,Code,Description,OrderNumber,Department,CustomerID,JobAddress1,JobAddress2,JobSuburb,JobState,JobPostcode,JobZone,JobPhone,ProductID,DestinationID,SourceID,JobDestination,JobSource, CartagePerTonne, MinimumCartage,CartageCostPerTonne,JobTonnesRunningTotal,JobEmail,IsActive,DocketsShouldBeSigned,JobTonnesOrdered,WorkOrderSystemCode,OverLoadFee,TonnageFee")] Job job, string[] selectedSites)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            entity = new Job() { };
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            if (!logOnSiteIsCentral) // not central site
            {
                ViewBag.IsCentralSite = false;
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
                job.SiteCreated = true;
                job.Name = logOnSite.PrefixEntityName(job.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
            }

            if (selectedSites != null)
            {
                job.Sites = new List<Site>();
                foreach (var site in selectedSites)
                {
                    var siteToAdd = db.Sites.Find(int.Parse(site));
                    job.Sites.Add(siteToAdd);
                }
            }

            JobProductPrice jobProductPrice = new JobProductPrice { JobID = job.ID, ProductID = job.ProductID, Price = 0 };

            ViewBag.DestinationID = new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.SourceID = new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name");

            if (!logOnSiteIsCentral)
            {
                ViewBag.Sites = new List<AssignedSiteData>();
                ViewBag.CustomerID = new SelectList(logOnSite.Customers.OrderBy(e => e.Name), "ID", "Name", job.CustomerID);
                ViewBag.ProductID = new SelectList(logOnSite.Products.OrderBy(e => e.Name), "ID", "Name", job.ProductID);
            }
            else
            {
                ViewBag.Sites = job.Sites != null ? GetEntityAssignedSiteData(db, job.Sites) : GetEntityAssignedSiteData(db, entity.Sites);
                ViewBag.CustomerID = new SelectList(db.Customers.OrderBy(e => e.Name), "ID", "Name", job.CustomerID);
                ViewBag.ProductID = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name", job.ProductID);
            }
            ViewBag.JobState = new SelectList(CoreConstants.AUS_STATES, job.JobState);


            var nameExist = db.Jobs.FirstOrDefault(e => e.Name == job.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "Job already exists");
                return View(job);
            }


            if (ModelState.IsValid)
            {
                job.Name = job.Name.ToUpper();
                db.Jobs.Add(job);
                db.JobProductPrices.Add(jobProductPrice);
                db.SaveChanges();
                if (job.ID > 0)
                {
                    SaveJobDestination(job);
                    SaveJobSource(job);
                }

                //Adding to the ReplicationLogItem for data sync
                if (selectedSites != null)
                {
                    foreach (var site in selectedSites)
                    {
                        var siteToAdd = db.Sites.Find(int.Parse(site));
                        if (siteToAdd != null)
                        {
                            WriteReplicationLog(siteToAdd.ID, job.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                        }

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(job.Name + " created successfully! ", logOnSite);
                return RedirectToAction("Edit/" + job.ID.ToString());
            }

            return View(job);
        }

        /// <summary>
        /// Get the deatils of the job and Navigate to the edit page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Job/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = new Job { Name = "Connection Failed! Retry later." };

            try
            {
                entity = db.Jobs.Include(e => e.Customer).Include(e => e.Product).Include(e => e.Sites).Single(e => e.ID == id);

                if (entity == null)
                {
                    return HttpNotFound();
                }
                entity.JobDestination = db.JobDestination.Where(p => p.JobID == id).Select(p => p.DestinationID).ToArray();
                entity.JobSource = db.JobSource.Where(p => p.JobID == id).Select(p => p.SourceID).ToArray();

                if (entity.JobDestination != null)
                {
                    entity.JobDestinationValues = string.Join(",", entity.JobDestination);
                }

                if (entity.JobSource != null)
                {
                    entity.JobSourceValues = string.Join(",", entity.JobSource);
                }

                var jobProdPricelist = from jobProdPrice in db.JobProductPrices
                                       join allProduct in db.Products on jobProdPrice.ProductID equals allProduct.ID
                                       where jobProdPrice.JobID == id
                                       select new { ID = jobProdPrice.ProductID, Name = allProduct.Name };
                if (jobProdPricelist.IsEmpty())
                {
                    var prodListOfNA = new List<Product> { new Product { ID = 1, Name = "NA" } };
                    ViewBag.ProductID = new SelectList(prodListOfNA, "ID", "Name", 1);
                }
                else
                {
                    ViewBag.ProductID = new SelectList(jobProdPricelist.OrderBy(e => e.Name), "ID", "Name", entity.ProductID);
                }


                if (!logOnSiteIsCentral)
                {
                    ViewBag.Sites = new List<AssignedSiteData>();
                    ViewBag.CustomerID = new SelectList(logOnSite.Customers.OrderBy(e => e.Name), "ID", "Name", entity.CustomerID);
                    ViewBag.DestinationID = GetSortedList(entity.JobDestination, new SelectList(logOnSite.Destinations.OrderBy(e => e.Name), "ID", "Name"));
                    ViewBag.SourceID = GetSortedList(entity.JobSource, new SelectList(logOnSite.Sources.OrderBy(e => e.Name), "ID", "Name"));

                }
                else
                {
                    ViewBag.Sites = GetEntityAssignedSiteData(db, entity.Sites);
                    ViewBag.CustomerID = new SelectList(db.Customers.OrderBy(e => e.Name), "ID", "Name", entity.CustomerID);
                    ViewBag.DestinationID = GetSortedList(entity.JobDestination, new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name"));
                    ViewBag.SourceID = GetSortedList(entity.JobSource, new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name"));

                }

            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            ViewBag.JobState = new SelectList(CoreConstants.AUS_STATES, entity.JobState);
            return View(entity);
        }

        /// <summary>
        /// Update the job based on the details - Updated in the DB
        /// </summary>
        /// <param name="id"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Job/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditJob")]
        //public ActionResult Edit([Bind(Include = "ID,Name,Code,Description,OrderNumber,Department,CustomerID,JobAddress1,JobAddress2,JobSuburb,JobState,JobPostcode,JobZone,JobPhone")] Job job)
        public ActionResult Edit(int? id, string[] selectedSites)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            if (!logOnSiteIsCentral) // not central site
            {
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
            }

            entity = db.Jobs.Include(e => e.Customer).Include(e => e.Product).Include(e => e.Sites).Single(e => e.ID == id);


            if (!logOnSiteIsCentral)
            {
                ViewBag.Sites = new List<AssignedSiteData>();
                ViewBag.CustomerID = new SelectList(logOnSite.Customers.OrderBy(e => e.Name), "ID", "Name", entity.CustomerID);
                ViewBag.ProductID = new SelectList(logOnSite.Products.OrderBy(e => e.Name), "ID", "Name", entity.ProductID);
                ViewBag.DestinationID = new SelectList(logOnSite.Destinations.OrderBy(e => e.Name), "ID", "Name");
                ViewBag.SourceID = new SelectList(logOnSite.Sources.OrderBy(e => e.Name), "ID", "Name");
            }
            else
            {
                ViewBag.Sites = GetEntityAssignedSiteData(db, entity.Sites);
                ViewBag.CustomerID = new SelectList(db.Customers.OrderBy(e => e.Name), "ID", "Name", entity.CustomerID);
                ViewBag.ProductID = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name", entity.ProductID);
                ViewBag.DestinationID = new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name");
                ViewBag.SourceID = new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name");
            }
            ViewBag.JobState = new SelectList(CoreConstants.AUS_STATES, entity.JobState);

            if (TryUpdateModel(entity, "", new string[] { "Name", "Description", "Code", "OrderNumber", "CustomerID", "Department", "JobAddress1", "JobAddress2", "JobSuburb", "JobState", "JobPostcode", "JobZone", "JobPhone", "ProductID", "DestinationID", "SourceID", "JobDestination", "JobSource", "CartagePerTonne", "MinimumCartage", "CartageCostPerTonne", "JobTonnesRunningTotal", "JobDestinationValues", "JobSourceValues", "JobEmail", "IsActive", "DocketsShouldBeSigned", "JobTonnesOrdered", "WorkOrderSystemCode", "OverLoadFee", "TonnageFee" }))
            {
                try
                {
                    var jobExist = db.Jobs.FirstOrDefault(e => e.Name == entity.Name);
                    if (jobExist != null)
                    {
                        if (jobExist.ID == entity.ID)
                        {
                            if (ModelState.IsValid)
                            {
                                var entityUpdate = db.Jobs.Find(entity.ID);
                                entityUpdate.Name = entity.Name.ToUpper();
                                entityUpdate.Description = entity.Description;
                                entityUpdate.OrderNumber = entity.OrderNumber;
                                entityUpdate.CustomerID = entity.CustomerID;
                                entityUpdate.Department = entity.Department;
                                entityUpdate.Code = entity.Code;
                                entityUpdate.JobAddress1 = entity.JobAddress1;
                                entityUpdate.JobAddress2 = entity.JobAddress2;
                                entityUpdate.JobSuburb = entity.JobSuburb;
                                entityUpdate.JobState = entity.JobState;
                                entityUpdate.JobPostcode = entity.JobPostcode;
                                entityUpdate.JobZone = entity.JobZone;
                                entityUpdate.JobPhone = entity.JobPhone;
                                entityUpdate.ProductID = entity.ProductID;
                                entityUpdate.JobDestination = entity.JobDestination;
                                entityUpdate.JobSource = entity.JobSource;
                                entityUpdate.CartagePerTonne = entity.CartagePerTonne;
                                entityUpdate.MinimumCartage = entity.MinimumCartage;
                                entityUpdate.CartageCostPerTonne = entity.CartageCostPerTonne;
                                entityUpdate.JobEmail = entity.JobEmail;
                                entityUpdate.IsActive = entity.IsActive;
                                entityUpdate.DocketsShouldBeSigned = entity.DocketsShouldBeSigned;
                                entityUpdate.JobTonnesRunningTotal = entity.JobTonnesRunningTotal;
                                entityUpdate.JobTonnesOrdered = entity.JobTonnesOrdered;
                                entityUpdate.WorkOrderSystemCode = entity.WorkOrderSystemCode;
                                entityUpdate.OverLoadFee = entity.OverLoadFee;
                                entityUpdate.TonnageFee = entity.TonnageFee;

                                if (entityUpdate.JobDestination != null)
                                {
                                    entityUpdate.JobDestinationValues = string.Join(",", entityUpdate.JobDestination);
                                }

                                if (entityUpdate.JobSource != null)
                                {
                                    entityUpdate.JobSourceValues = string.Join(",", entityUpdate.JobSource);
                                }

                                UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);

                                if (TryUpdateModel(entityUpdate, "",
                                         new string[] { "Name", "Description", "Code", "OrderNumber", "CustomerID", "Department", "JobAddress1", "JobAddress2", "JobSuburb", "JobState", "JobPostcode", "JobZone", "JobPhone", "ProductID", "JobDestination", "JobSource", "CartagePerTonne", "MinimumCartage", "CartageCostPerTonne", "JobTonnesRunningTotal", "JobEmail", "IsActive", "DocketsShouldBeSigned", "JobTonnesOrdered", "WorkOrderSystemCode", "OverLoadFee", "TonnageFee" }))

                                    db.SaveChanges();


                                if (entity.ID > 0)
                                {
                                    DeleteJobDestination(entity.ID);
                                    DeleteJobSource(entity.ID);

                                    SaveJobDestination(entity);
                                    SaveJobSource(entity);
                                }

                                //Adding to the ReplicationLogItem for data sync
                                if (selectedSites != null)
                                {
                                    foreach (var site in selectedSites)
                                    {
                                        var siteToAdd = db.Sites.Find(int.Parse(site));
                                        if (siteToAdd != null)
                                        {
                                            WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                        }

                                    }

                                }

                                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ", logOnSite);
                                return RedirectToAction("Edit/" + id.ToString());

                            }
                        }
                        else
                        {
                            ModelState.AddModelError("Name", "Job already exists");
                            return View(entity);
                        }
                    }
                    if (ModelState.IsValid)
                    {
                        entity.Name = entity.Name.ToUpper();
                        UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
                        if (!logOnSiteIsCentral) // not central site
                        {
                            entity.Name = logOnSite.PrefixEntityName(entity.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
                        }
                        db.Entry(entity).State = EntityState.Modified;
                        db.SaveChanges();
                        if (entity.ID > 0)
                        {
                            DeleteJobDestination(entity.ID);
                            DeleteJobSource(entity.ID);

                            SaveJobDestination(entity);
                            SaveJobSource(entity);
                        }

                        //Adding to the ReplicationLogItem for data sync
                        if (selectedSites != null)
                        {
                            foreach (var site in selectedSites)
                            {
                                var siteToAdd = db.Sites.Find(int.Parse(site));
                                if (siteToAdd != null)
                                {
                                    WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                }

                            }

                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ", logOnSite);
                        return RedirectToAction("Index");
                    }
                }
                catch (RetryLimitExceededException)
                {
                    //Log the error (uncomment dex variable name and add a line here to write a log.
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }


            UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
            return View(entity);
        }

        /// <summary>
        /// Get the deatils of the job based on the id - navigates to the delete page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Job/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Jobs.Include(e => e.Customer).Include(e => e.Product).Single(e => e.ID == id);
            entity.DestinationNames = string.Join(",", (from td in db.JobDestination
                                                        join d in db.Destinations on td.DestinationID equals d.ID
                                                        where td.JobID == id
                                                        select d.Name).ToArray());
            entity.SourceNames = string.Join(",", (from ts in db.JobSource
                                                   join s in db.Sources on ts.SourceID equals s.ID
                                                   where ts.JobID == id
                                                   select s.Name).ToArray());
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Delete the job - removed job from the DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Job/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteJob")]
        public ActionResult DeleteConfirmed(int id)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");
            try
            {
                entity = db.Jobs.Find(id);
                if (entity != null)
                {
                    entity.IsActive = false;
                    db.Entry(entity).State = EntityState.Modified;
                    db.SaveChanges();

                    var siteList = db.Sites.Where(s => s.ID > 1).ToList();
                    foreach (var siteItem in siteList)
                    {
                        WriteReplicationLog(siteItem.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                    }
                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This job " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Add a product based on the product id- navigate to the AddProduct/id?productId=?
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        [SessionAccess]
        [CheckForAccess("CanNewJob")]
        public ActionResult AddProduct(int productId, int id = 1)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            Job currentJob = db.Jobs.FirstOrDefault(e => e.ID == id);
            JobProductPrice jobProductPrice = new JobProductPrice();
            List<Product> AllProductsExceptLinked = null;

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;

            try
            {
                jobProductPrice = db.JobProductPrices.Include(e => e.Job).FirstOrDefault(e => e.JobID == id && e.ProductID == productId);

                if (jobProductPrice == null)
                {
                    jobProductPrice = new JobProductPrice
                    {
                        JobID = id,
                        ProductID = productId
                    };
                    db.JobProductPrices.Add(jobProductPrice);
                    db.SaveChanges();
                }

                var jobProdPricelist = from jobProdPrice in db.JobProductPrices
                                       join allProduct in db.Products on jobProdPrice.ProductID equals allProduct.ID
                                       where jobProdPrice.JobID == id
                                       select new { ID = jobProdPrice.ProductID, Name = allProduct.Name };
                if (!jobProdPricelist.IsEmpty())
                {

                    ViewBag.ProductID = new SelectList(jobProdPricelist.OrderBy(e => e.Name), "ID", "Name", jobProductPrice.ProductID);
                }

                if (!logOnSiteIsCentral)
                {
                    AllProductsExceptLinked = logOnSite.Products.OrderBy(e => e.Name).ToList();

                }
                else
                {
                    AllProductsExceptLinked = db.Products.OrderBy(e => e.Name).ToList();

                }

                foreach (var jplist in jobProdPricelist.ToList())
                {
                    //Product deleProduct = db.Products.FirstOrDefault(e => e.ID == jplist.ID);
                    Product deleProduct = db.Products.Where(e => e.ID == jplist.ID).FirstOrDefault();
                    if (deleProduct != null)
                    {
                        AllProductsExceptLinked.Remove(deleProduct);
                    }
                }

                ViewBag.DisplayTitle = "Add Products to Job: " + currentJob.Name;
                ViewBag.AllProductID = new SelectList(AllProductsExceptLinked, "ID", "Name", 1);
                ViewBag.SelectedJobID = jobProductPrice.JobID;
                ViewBag.ShowDropButton = (jobProdPricelist.Count() > 1);

            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(jobProductPrice);

        }

        /// <summary>
        /// Saved the product details in the DB
        /// </summary>
        /// <param name="allProductID"></param>
        /// <param name="jobID"></param>
        /// <param name="price"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        public ActionResult AddProduct(int allProductID, int jobID, decimal price = 0)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            JobProductPrice jobProductPrice = new JobProductPrice { JobID = jobID, ProductID = allProductID, Price = price };
            List<Product> AllProductsExceptLinked = null;

            Product newlyLinkedProduct = db.Products.FirstOrDefault(e => e.ID == allProductID);


            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;
            ViewBag.DisplayTitle = "Add Product";

            if (ModelState.IsValid)
            {
                db.JobProductPrices.Add(jobProductPrice);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(newlyLinkedProduct.Name + " linked successfully! ", logOnSite);
            }

            var jobProdPricelist = from jProdPrice in db.JobProductPrices
                                   join allProduct in db.Products on jProdPrice.ProductID equals allProduct.ID
                                   where jProdPrice.JobID == jobProductPrice.JobID
                                   select new { ID = jProdPrice.ProductID, Name = allProduct.Name };

            if (!jobProdPricelist.IsEmpty())
            {

                ViewBag.ProductID = new SelectList(jobProdPricelist.OrderBy(e => e.Name), "ID", "Name", jobProductPrice.ProductID);
            }

            if (!logOnSiteIsCentral)
            {
                AllProductsExceptLinked = logOnSite.Products.OrderBy(e => e.Name).ToList();

            }
            else
            {
                AllProductsExceptLinked = db.Products.OrderBy(e => e.Name).ToList();

            }

            foreach (var jplist in jobProdPricelist.ToList())
            {
                Product deleProduct = db.Products.FirstOrDefault(e => e.ID == jplist.ID);
                AllProductsExceptLinked.Remove(deleProduct);
            }

            ViewBag.AllProductID = new SelectList(AllProductsExceptLinked, "ID", "Name", 1);
            ViewBag.ShowDropButton = (jobProdPricelist.Count() > 1);



            return View(jobProductPrice);

        }

        /// <summary>
        /// Drop the product from the list
        /// </summary>
        /// <param name="productID"></param>
        /// <param name="jobLinkedID"></param>
        /// <returns></returns>

        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteJob")]
        public ActionResult DropProduct(int? productID, int jobLinkedID)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            bool defaultLinkedProductDropped = false;

            JobProductPrice jobProductPriceDropped = db.JobProductPrices.Include(e => e.Product).FirstOrDefault(e => e.JobID == jobLinkedID && e.ProductID == productID);
            List<Product> AllProductsExceptLinked = null;

            Job hostJob = db.Jobs.FirstOrDefault(e => e.ID == jobLinkedID);
            if (jobProductPriceDropped != null)
                defaultLinkedProductDropped = (hostJob.ProductID == jobProductPriceDropped.ProductID);

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewJob;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditJob;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteJob;
            ViewBag.DisplayTitle = "Add Product";

            string prodName = jobProductPriceDropped.Product.Name;

            if (ModelState.IsValid)
            {
                if (jobProductPriceDropped != null)
                {
                    db.JobProductPrices.Remove(jobProductPriceDropped);
                    db.SaveChanges();
                    TempData["UserMessage"] = ComposeTempDisplayMessage(prodName + " droped successfully! ", logOnSite);
                }
            }
            if (jobProductPriceDropped != null)
            {
                var jobProdPricelist = from jProdPrice in db.JobProductPrices
                                       join allProduct in db.Products on jProdPrice.ProductID equals allProduct.ID
                                       where jProdPrice.JobID == jobProductPriceDropped.JobID
                                       select new { ID = jProdPrice.ProductID, Name = allProduct.Name };

                if (!jobProdPricelist.IsEmpty())
                {

                    ViewBag.ProductID = new SelectList(jobProdPricelist.OrderBy(e => e.Name), "ID", "Name", jobProductPriceDropped.ProductID);
                }

                if (!logOnSiteIsCentral)
                {
                    AllProductsExceptLinked = logOnSite.Products.OrderBy(e => e.Name).ToList();

                }
                else
                {
                    AllProductsExceptLinked = db.Products.OrderBy(e => e.Name).ToList();

                }

                foreach (var jpplist in jobProdPricelist.ToList())
                {
                    Product deleProduct = db.Products.FirstOrDefault(e => e.ID == jpplist.ID);
                    AllProductsExceptLinked.Remove(deleProduct);
                }
            }

            ViewBag.AllProductID = new SelectList(AllProductsExceptLinked, "ID", "Name", 1);


            var jPPList = db.JobProductPrices.Where(e => e.JobID == jobLinkedID).OrderBy(e => e.Product.Name);

            ViewBag.ShowDropButton = (jPPList.Count() > 1);

            JobProductPrice jPP = jPPList.ToArray().ElementAt<JobProductPrice>(0);

            if (defaultLinkedProductDropped)
            {
                hostJob.ProductID = jPP.ProductID;
                db.Entry(hostJob).State = EntityState.Modified;
                db.SaveChanges();
            }

            return RedirectToAction("AddProduct", new { Id = jPP.JobID, productId = jPP.ProductID });


        }

        /// <summary>
        /// Get the price of the product based on the product and job id
        /// </summary>
        /// <param name="productID"></param>
        /// <param name="jobID"></param>
        /// <returns></returns>

        public JsonResult GetJobProductPriceShownJson(int productID, int jobID)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }
            var jpprice = db.JobProductPrices.Include(e => e.Job).Include(e => e.Product).Single(e => e.ProductID == productID && e.JobID == jobID);
            var jppriceJson = new JobProductPriceViewModel { Job = jpprice.Job.Name, JobID = jpprice.JobID, Product = jpprice.Product.Name, ProductID = jpprice.ProductID, Price = jpprice.Price };
            return Json(jppriceJson, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Update the product price from the model
        /// </summary>
        /// <param name="jobProductPrice"></param>
        /// <returns></returns>

        public JsonResult UpdateJobProductPriceShownJson(JobProductPrice jobProductPrice)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }

            var jpprice = db.JobProductPrices.Include(e => e.Job).Include(e => e.Product).Single(e => e.ProductID == jobProductPrice.ProductID && e.JobID == jobProductPrice.JobID);
            if (TryUpdateModel(jpprice, "", new string[] { "Price" }))
            {
                try
                {
                    if (ModelState.IsValid)
                    {

                        db.Entry(jpprice).State = EntityState.Modified;
                        db.SaveChanges();

                    }
                }
                catch (RetryLimitExceededException)
                {

                }
            }
            
            var jppriceJson = new JobProductPriceViewModel { Job = jpprice.Job.Name, JobID = jpprice.JobID, Product = jpprice.Product.Name, ProductID = jpprice.ProductID, Price = jpprice.Price };
            return Json(jppriceJson, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Get the product price shown -  when select a product from the list of the products
        /// </summary>
        /// <param name="jobProductPrice"></param>
        /// <returns></returns>

        public PartialViewResult GetJobProductPriceShown([Bind(Include = "ProductID,JobID,Price")] JobProductPrice jobProductPrice)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }

            var jpprice = db.JobProductPrices.Include(e => e.Product).Single(e => e.ProductID == jobProductPrice.ProductID && e.JobID == jobProductPrice.JobID);
            return PartialView(jpprice);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Delete the destination from the job
        /// </summary>
        /// <param name="id"></param>
        private void DeleteJobDestination(int id)
        {
            var td = db.JobDestination.Where(p => p.JobID == id);
            db.JobDestination.RemoveRange(td);
            db.SaveChanges();
        }

        /// <summary>
        /// Delete the source from the job
        /// </summary>
        /// <param name="id"></param>
        private void DeleteJobSource(int id)
        {
            var ts = db.JobSource.Where(p => p.JobID == id);
            db.JobSource.RemoveRange(ts);
            db.SaveChanges();
        }

        /// <summary>
        /// Delete the truck from the job
        /// </summary>
        /// <param name="id"></param>
        private void DeleteTruckJob(int id)
        {
            var ts = db.TruckJobs.Where(p => p.JobID == id);
            db.TruckJobs.RemoveRange(ts);
            db.SaveChanges();
        }


        private void SaveJobDestination(Job job)
        {
            if (job.JobDestination != null)
            {
                foreach (var item in job.JobDestination)
                {
                    var jd = new JobDestination() { };
                    jd.JobID = job.ID;
                    jd.DestinationID = item;
                    db.JobDestination.Add(jd);
                }
                db.SaveChanges();
            }
        }

        private void SaveJobSource(Job job)
        {
            if (job.JobSource != null)
            {
                foreach (var item in job.JobSource)
                {
                    var js = new JobSource() { };
                    js.JobID = job.ID;
                    js.SourceID = item;
                    db.JobSource.Add(js);
                }
                db.SaveChanges();
            }
        }
        //To make all selected list into top
        private List<SelectListItem> GetSortedList(int[] intList, SelectList s)
        {
            List<SelectListItem> l = new List<SelectListItem>();
            if (s.Count() > 0)
            {
                foreach (var item in s.OrderBy(e => e.Text))
                {
                    SelectListItem i = new SelectListItem() { };
                    i.Text = item.Text;
                    i.Value = item.Value;
                    if (intList != null)
                    {
                        i.Selected = intList.Contains(Convert.ToInt32(i.Value));
                        l.Add(i);
                    }
                }
            }
            IEnumerable<SelectListItem> p = l.OrderByDescending(q => q.Selected);
            return p.ToList();
        }
    }
}
