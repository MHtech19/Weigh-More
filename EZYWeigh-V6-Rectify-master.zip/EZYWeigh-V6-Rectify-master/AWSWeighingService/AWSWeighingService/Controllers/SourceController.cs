﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using PagedList;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class SourceController : EntityController<Source>
    {
        /// <summary>
        /// Get the list of sources based on the filters  - Render the index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <param name="suburb"></param>
        /// <param name="state"></param>
        /// <param name="site"></param>
        /// <param name="postCode"></param>
        /// <param name="mobile"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        // GET: Source
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string code, string suburb, string state, string site,
                                  string postCode, string mobile, string status)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSource;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSource;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSource;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Sources");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");

            ViewBag.SuburbSortParm = (sortOrder == "Suburb" ? "Suburb_Desc" : "Suburb");
            ViewBag.StateSortParm = (sortOrder == "State" ? "State_Desc" : "State");
            ViewBag.PostcodeSortParm = (sortOrder == "Postcode" ? "Postcode_Desc" : "Postcode");
            ViewBag.CountrySortParm = (sortOrder == "Country" ? "Country_Desc" : "Country");
            ViewBag.PhoneSortParm = (sortOrder == "Phone" ? "Phone_Desc" : "Phone");
            ViewBag.ContactSortParm = (sortOrder == "Contact" ? "Contact_Desc" : "Contact");

            entities = from e in db.Sources select e;

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.Sources == null)
                {
                    entities = from e in db.Sources where e.Name == CoreConstants.NA select e;
                }
                else
                {
                    entities = logOnSite.Sources.AsQueryable<Source>();
                }
            }

            entities = entities.Where(e => e.ID > CoreConstants.NA_ID);

            //Filters

            ViewBag.States = Constants.AUS_STATES.ToList();
            ViewBag.Suburbs = db.Sources.Where(e => e.Suburb != null).GroupBy(r => r.Suburb).Select(group => group.Key).ToList();
            ViewBag.Sites = db.Sites.Where(s => s.ID > 1).ToList();

            status = status == null ? "true" : status;

            ViewBag.name = name;
            ViewBag.code = code;
            ViewBag.state = state;
            ViewBag.site = site;
            ViewBag.suburb = suburb;
            ViewBag.mobile = mobile;
            ViewBag.postCode = postCode;
            ViewBag.status = status;

            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }
            if (!String.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));
            }

            if (!String.IsNullOrEmpty(state) && state != "All")
            {
                entities = entities.Where(e => e.State.ToUpper().Contains(state.ToUpper()));
            }

            if (!String.IsNullOrEmpty(suburb) && suburb != "All")
            {
                entities = entities.Where(e => e.Suburb.ToUpper().Contains(suburb.ToUpper()));
            }


            if (!string.IsNullOrEmpty(site) && site != "All")
            {
                int siteId = int.Parse(site);
                entities = entities.Where(s => s.Sites.Any(st => st.ID == siteId));
            }


            if (!String.IsNullOrEmpty(postCode))
            {
                entities = entities.Where(e => e.Postcode.Contains(postCode));
            }

            if (!String.IsNullOrEmpty(mobile))
            {
                entities = entities.Where(e => e.Mobile.Contains(mobile));
            }

            if (!String.IsNullOrEmpty(status) && status != "All")
            {
                bool statusId = bool.Parse(status);

                entities = entities.Where(e => e.IsActive == statusId);
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;

                case "Suburb":
                    entities = entities.OrderBy(e => e.Suburb);
                    break;
                case "Suburb_Desc":
                    entities = entities.OrderByDescending(e => e.Suburb);
                    break;
                case "State":
                    entities = entities.OrderBy(e => e.State);
                    break;
                case "State_Desc":
                    entities = entities.OrderByDescending(e => e.State);
                    break;
                case "Postcode":
                    entities = entities.OrderBy(e => e.Postcode);
                    break;
                case "Postcode_Desc":
                    entities = entities.OrderByDescending(e => e.Postcode);
                    break;
                case "Country":
                    entities = entities.OrderBy(e => e.Country);
                    break;
                case "Country_Desc":
                    entities = entities.OrderByDescending(e => e.Country);
                    break;
                case "Phone":
                    entities = entities.OrderBy(e => e.Phone);
                    break;
                case "Phone_Desc":
                    entities = entities.OrderByDescending(e => e.Phone);
                    break;
                case "Contact":
                    entities = entities.OrderBy(e => e.Contact);
                    break;
                case "Contact_Desc":
                    entities = entities.OrderByDescending(e => e.Contact);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;

            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Get the details of the source - Navigate to details page from the grid details action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Source/Details/5

        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSource;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Sources.Include(e => e.Sites).Where(e => e.ID == id).Single();
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Create a new source - Navigate to create source page
        /// </summary>
        /// <returns></returns>

        // GET: Source/Create

        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSource;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSource;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSource;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);

            entity = new Source();
            entity.IsActive = true;
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

            return View(entity);
        }

        /// <summary>
        /// Save the new Source into the table
        /// </summary>
        /// <param name="source"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>

        // POST: Source/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewSource")]
        public ActionResult Create([Bind(Include = "ID,Name,Code,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Contact,Email,Waste_Stream,Sub_Stream,OWF_Source,OWF_EPL_Number,IsActive")] Source source, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSource;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSource;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSource;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);

            entity = new Source();
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

            if (!logOnSiteIsCentral) // not central site
            {
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
                source.SiteCreated = true;
                source.Name = logOnSite.PrefixEntityName(source.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
            }

            if (selectedSites != null)
            {
                source.Sites = new List<Site>();
                foreach (var site in selectedSites)
                {
                    var siteToAdd = db.Sites.Find(int.Parse(site));
                    source.Sites.Add(siteToAdd);
                }
                List<AssignedSiteData> siteData = GetEntityAssignedSiteData(db, source.Sites);
                ViewBag.Sites = siteData;
            }

            var nameExist = db.Sources.FirstOrDefault(e => e.Name == source.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "Source already exists");
                return View(source);
            }

            if (ModelState.IsValid)
            {
                source.Name = source.Name.ToUpper();
                db.Sources.Add(source);
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (selectedSites != null)
                {
                    foreach (var site in selectedSites)
                    {
                        var siteToAdd = db.Sites.Find(int.Parse(site));
                        if (siteToAdd != null)
                        {
                            WriteReplicationLog(siteToAdd.ID, source.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                        }

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(source.Name + " created successfully! ", logOnSite);
                return RedirectToAction("Edit/" + source.ID.ToString());
            }
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, source.State);
            return View(source);
        }

        /// <summary>
        /// Get the details of the source - navigate to the edit page from the grid edit page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Source/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSource;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSource;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSource;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = new Source { Name = "Connection Failed! Retry later." };

            try
            {
                entity = db.Sources.Include(e => e.Sites).Where(e => e.ID == id).Single();

                if (entity == null)
                {
                    return HttpNotFound();
                }

                ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
                ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);

            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }

            return View(entity);


        }

        /// <summary>
        /// Update the source details in the table
        /// </summary>
        /// <param name="id"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Source/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditSource")]
        //public ActionResult Edit([Bind(Include = "ID,Name,Code,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Contact,Contact")] Source source)
        public ActionResult Edit(int? id, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSource;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSource;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSource;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            entity = new Source();
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            if (!logOnSiteIsCentral) // not central site
            {
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
            }

            entity = db.Sources.Include(e => e.Sites).Where(e => e.ID == id).Single();

            if (TryUpdateModel(entity, "", new string[] { "Name", "Description", "Code", "Address1", "Address2", "Suburb", "State", "Postcode", "Country", "Phone", "Mobile", "Contact", "Email", "Waste_Stream", "Sub_Stream", "OWF_Source", "OWF_EPL_Number", "IsActive" }))
            {
                try
                {
                    var sourceExist = db.Sources.FirstOrDefault(e => e.Name == entity.Name);
                    if (sourceExist != null)
                    {
                        if (sourceExist.ID == entity.ID)
                        {
                            if (ModelState.IsValid)
                            {
                                var entityUpdate = db.Sources.Find(entity.ID);
                                entityUpdate.Name = entity.Name.ToUpper();
                                entityUpdate.Description = entity.Description;
                                entityUpdate.Code = entity.Code;
                                entityUpdate.Address1 = entity.Address1;
                                entityUpdate.Address2 = entity.Address2;
                                entityUpdate.Suburb = entity.Suburb;
                                entityUpdate.State = entity.State;
                                entityUpdate.Postcode = entity.Postcode;
                                entityUpdate.Country = entity.Country;
                                entityUpdate.Phone = entity.Phone;
                                entityUpdate.Mobile = entity.Mobile;
                                entityUpdate.Contact = entity.Contact;
                                entityUpdate.Email = entity.Email;
                                entityUpdate.IsActive = entity.IsActive;

                                UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);

                                if (TryUpdateModel(entityUpdate, "",
                                         new string[] { "Name", "Description", "Code", "Address1", "Address2", "Suburb", "State", "Postcode", "Country", "Phone", "Mobile", "Contact", "Email", "Waste_Stream", "Sub_Stream", "OWF_Source", "OWF_EPL_Number", "IsActive" }))

                                    db.SaveChanges();
                                //Adding to the ReplicationLogItem for data sync
                                if (selectedSites != null)
                                {
                                    foreach (var site in selectedSites)
                                    {
                                        var siteToAdd = db.Sites.Find(int.Parse(site));
                                        if (siteToAdd != null)
                                        {
                                            WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                        }

                                    }

                                }

                                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                                return RedirectToAction("Edit/" + entity.ID.ToString());
                            }
                        }
                        else
                        {
                            ModelState.AddModelError("Name", "Source already exists");
                            return View(entity);
                        }
                    }

                    if (ModelState.IsValid)
                    {
                        entity.Name = entity.Name.ToUpper();
                        UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
                        if (!logOnSiteIsCentral) // not central site
                        {
                            entity.Name = logOnSite.PrefixEntityName(entity.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
                        }
                        db.Entry(entity).State = EntityState.Modified;
                        db.SaveChanges();

                        //Adding to the ReplicationLogItem for data sync
                        if (selectedSites != null)
                        {
                            foreach (var site in selectedSites)
                            {
                                var siteToAdd = db.Sites.Find(int.Parse(site));
                                if (siteToAdd != null)
                                {
                                    WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                }

                            }

                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ", logOnSite);
                        return RedirectToAction("Edit/" + entity.ID.ToString());
                    }

                }
                catch (RetryLimitExceededException)
                {
                    //Log the error (uncomment dex variable name and add a line here to write a log.
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }

            UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
            return View(entity);
        }

        /// <summary>
        /// Get the details of the source - Navigate to the delete source page from the grid delete action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Source/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSource;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSource;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSource;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Sources.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Removed source from the source table
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Source/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteSource")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewSource;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditSource;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteSource;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");
            try
            {
                entity = db.Sources.Find(id);
                //db.Sources.Remove(entity);
                entity.IsActive = false;
                db.Entry(entity).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");

                var siteList = db.Sites.Where(s => s.ID > 1).ToList();
                foreach (var siteItem in siteList)
                {
                    WriteReplicationLog(siteItem.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                }
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This source " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }
        
        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
