﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using PagedList;
using System.Data.Entity.Infrastructure;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{    
    public class RealTimeWeightController : EntityController<RealTimeWeight>
    {
        /// <summary>
        /// Get the list of RealTimeWeight based on the filter
        /// Renders index page
        /// </summary> 
        /// <param name="sortOrder"></param>
        /// <param name="currentFilter"></param>
        /// <param name="searchString"></param>
        /// <param name="page"></param>
        /// <returns></returns>

        // GET: RealTimeWeight
        [SessionAccess]
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Real Time Weights");

            ViewBag.CurrentSort = sortOrder;

            ViewBag.PlatformIDSortParm = (String.IsNullOrEmpty(sortOrder) ? "PlatformID_Desc" : "");
            ViewBag.CurrentWeightSortParm = (sortOrder == "CurrentWeight" ? "CurrentWeight_Desc" : "CurrentWeight");
            ViewBag.DateTimeStampSortParm = (sortOrder == "DateTimeStamp" ? "DateTimeStamp_Desc" : "DateTimeStamp");
            ViewBag.SiteSortParm = (sortOrder == "Site" ? "Site_Desc" : "Site");
            ViewBag.WeighmanSortParm = (sortOrder == "Weighman" ? "Weighman_Desc" : "Weighman");

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            entities = db.RealTimeWeights.Include(e => e.Site).Include(e => e.Weighman);

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.RealTimeWeights == null)
                {
                    entities = from e in db.RealTimeWeights where e.ID == CoreConstants.NA_ID select e;
                }
                else
                {
                    entities = logOnSite.RealTimeWeights.AsQueryable<RealTimeWeight>();
                }
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                entities = entities.Where(e => e.PlatformID.ToUpper().Contains(searchString.ToUpper())
                                          || e.CurrentWeight.ToString().ToUpper().Contains(searchString.ToUpper())
                                          || e.DateTimeStamp.ToString().ToUpper().Contains(searchString.ToUpper())
                                          || e.Site.Name.ToUpper().Contains(searchString.ToUpper())
                                          || e.Weighman.Name.ToUpper().Contains(searchString.ToUpper())

                                         );
            }

            switch (sortOrder)
            {
                case "PlatformID_Desc":
                    entities = entities.OrderByDescending(e => e.PlatformID);
                    break;


                case "CurrentWeight":
                    entities = entities.OrderBy(e => e.CurrentWeight);
                    break;
                case "CurrentWeight_Desc":
                    entities = entities.OrderByDescending(e => e.CurrentWeight);
                    break;
                case "DateTimeStamp":
                    entities = entities.OrderBy(e => e.DateTimeStamp);
                    break;
                case "DateTimeStamp_Desc":
                    entities = entities.OrderByDescending(e => e.DateTimeStamp);
                    break;
                case "Site":
                    entities = entities.OrderBy(e => e.Site.Name);
                    break;
                case "Site_Desc":
                    entities = entities.OrderByDescending(e => e.Site.Name);
                    break;
                case "Weighman":
                    entities = entities.OrderBy(e => e.Weighman.Name);
                    break;
                case "Weighman_Desc":
                    entities = entities.OrderByDescending(e => e.Weighman.Name);
                    break;
                default:
                    entities = entities.OrderBy(e => e.PlatformID);
                    break;
            }

            //return View(entities.ToList());
            pageNumber = (page ?? 1);

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        // GET: RealTimeWeight/Details/5       
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            entity = db.RealTimeWeights.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        // GET: RealTimeWeight/Create     
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
            ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            return View();
        }

        // POST: RealTimeWeight/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        public ActionResult Create([Bind(Include = "ID,CurrentWeigh,PlatformID,SiteID,WeighmanID")] RealTimeWeight realTimeWeight)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            if (ModelState.IsValid)
            {
                db.RealTimeWeights.Add(realTimeWeight);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name", realTimeWeight.SiteID);
            ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name", realTimeWeight.WeighmanID);
            return View(realTimeWeight);
        }

        // GET: RealTimeWeight/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (DataBaseConnectionStringName == null)
            {
                return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            }

            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }
            logOnSite = GetSiteFromSession(db);
            if (logOnSite == null)
            {
                return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            }
            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            entity = db.RealTimeWeights.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name", entity.SiteID);
            ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name", entity.WeighmanID);
            return View(entity);
        }

        // POST: RealTimeWeight/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        public ActionResult Edit([Bind(Include = "ID,CurrentWeigh,PlatformID,SiteID,WeighmanID")] RealTimeWeight realTimeWeight)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (ModelState.IsValid)
            {
                db.Entry(realTimeWeight).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name", realTimeWeight.SiteID);
            ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name", realTimeWeight.WeighmanID);
            return View(realTimeWeight);
        }

        // GET: RealTimeWeight/Delete/5   
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            entity = db.RealTimeWeights.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        // POST: RealTimeWeight/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            entity = db.RealTimeWeights.Find(id);
            db.RealTimeWeights.Remove(entity);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        
        protected override void Dispose(bool disposing)
        {
            if (disposing && db!=null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
