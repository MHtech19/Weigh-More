﻿using AWSWeighingService.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WeighBridge.Core.Device;

namespace AWSWeighingService.Controllers
{
    public class ExportController : Controller
    {
        private AWSWeighingServiceContext db = new AWSWeighingServiceContext();

        private string DataBaseConnectionStringName;

        protected string GetConnectionStringNameFromSession()
        {
            string connStrName = null;
            var sessionLogonWeighManName = Session["CurrentWeighmanName"];
            if (sessionLogonWeighManName == null) return connStrName;

            string logonWeighManNameFromSession = (string)sessionLogonWeighManName;
            string[] splitLogonName = logonWeighManNameFromSession.Split(DeviceConstants.CHAR_DOT);
            if (splitLogonName.Length > 1)
            {
                connStrName = splitLogonName[0];
            }
            else
            {
                connStrName = string.Empty;
            }
            return connStrName;
        }

        protected void RecreatDbContextByConnStringName(string connStringName)
        {
            db = new AWSWeighingServiceContext(connStringName);
        }



        // GET: Export
        public ActionResult Index()
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (DataBaseConnectionStringName == null)
            {
                return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            }

            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }
       
            return View();
        }
    }
}