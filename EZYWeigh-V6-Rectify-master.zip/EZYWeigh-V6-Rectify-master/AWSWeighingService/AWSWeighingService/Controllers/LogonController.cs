﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Data.Entity.Infrastructure;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using AWSWeighingService.Infrastructure;
using WeighBridge.Core.Device;

namespace AWSWeighingService.Controllers
{

    public class LogonController : Controller
    {
        private AWSWeighingServiceContext db = new AWSWeighingServiceContext();

        private string DataBaseConnectionStringName = string.Empty;

        protected string ExtractConnectionStringNameFromUserName(string userName)
        {
            string connStrName = string.Empty;

            if (userName != null)
            {
                string[] splitLogonName = userName.Split(DeviceConstants.CHAR_DOT);
                if (splitLogonName.Length > 1)
                {
                    connStrName = splitLogonName[0];
                }
            }
            return connStrName;
        }

        protected void RedirectClientDbFromSession(string userName)
        {
            DataBaseConnectionStringName = ExtractConnectionStringNameFromUserName(userName);
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
                db = new AWSWeighingServiceContext(DataBaseConnectionStringName);
        }

        [AllowAnonymous]
        public ActionResult Login(string returnUrl, int siteID = 1) // id stands for currentSiteID
        {
            //Session["Role"] = null;
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            LoginViewModel loginViewModel = new LoginViewModel
            {
                SiteID = siteID,
                //SiteSelectListItems = new SelectList(db.Sites, "ID", "Name"),
            };

            //ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");

            ViewBag.ReturnUrl = returnUrl != null && returnUrl.Contains("ExportCSV_Transaction") ? "/Transaction/Exportwizard" : returnUrl;

            return View(loginViewModel);
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(LoginViewModel model, string returnUrl)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string userName, passWrod;
                    int logonSiteID;

                    bool authenticationOK = false;
                    bool adminPermissionOK = false;

                    userName = model.UserName;
                    passWrod = model.Password;
                    logonSiteID = model.SiteID;

                    //var Credentials = db.Weighmen.Where(w => w.Name == userName && w.Password == passWrod).Select(w=> new { Name = w.Name, passWrod = w.Password });

                    //var userResults = from u in db.Weighmen where String.Equals(u.Name, userName, StringComparison.OrdinalIgnoreCase) && String.Equals(u.Password, passWrod, StringComparison.OrdinalIgnoreCase) select u;
                    //var userResults = from u in db.Weighmen.AsEnumerable()
                    //                  where String.Equals(u.Name, userName, StringComparison.OrdinalIgnoreCase) && String.Equals(u.Password, passWrod, StringComparison.OrdinalIgnoreCase)
                    //                  select new
                    //                  {
                    //                      Name = u.Name,
                    //                      Password = u.Password
                    //                  };

                    //Weighman currentWeighman = db.Weighmen.Where(w => w.RoleID == curentRole.ID && w.Password == passWrod).FirstOrDefault();
                    RedirectClientDbFromSession(userName);

                    //////Weighman currentWeighman = db.Weighmen.Where(w => w.Name == userName && w.Password == passWrod && w.IsDeleted==false).FirstOrDefault();

                    //////if (currentWeighman == null)
                    //////{
                    //////    Session["Role"] = null;
                    //////}
                    //////else
                    //////{
                    //////    Role curentRole = db.Roles.Where(r => r.ID == currentWeighman.RoleID).FirstOrDefault();
                    //////    Session["Role"] = curentRole;
                    //////}

                    ////////if (String.Equals(userResults.Select(x => x.Name).ToString(), userName, StringComparison.OrdinalIgnoreCase) && String.Equals(userResults.Select(x => x.Password).ToString(), passWrod, StringComparison.OrdinalIgnoreCase))
                    ////////{
                    //////if (currentWeighman != null)
                    //////{
                    //////    authenticationOK = true;
                    //////    adminPermissionOK = (logonSiteID != Constants.NAEntityID) || ((logonSiteID == Constants.NAEntityID) && currentWeighman.IsAdmin);

                    //////}

                    ////////}


                    Weighman currentWeighman = db.Weighmen.Where(w => w.Name == userName && w.IsDeleted == false).FirstOrDefault();
                    string encryptedPwd = passWrod.Encrypt();
                    bool passwordVerified = encryptedPwd.Equals(currentWeighman.Password);

                    if (currentWeighman == null || !passwordVerified)
                    {
                        Session["Role"] = null;
                    }
                    else
                    {
                        Role curentRole = db.Roles.Where(r => r.ID == currentWeighman.RoleID).FirstOrDefault();
                        Session["Role"] = curentRole;
                    }

                    if (currentWeighman != null && passwordVerified)
                    {
                        authenticationOK = true;
                        adminPermissionOK = (logonSiteID != Constants.NAEntityID) || ((logonSiteID == Constants.NAEntityID) && currentWeighman.IsAdmin);
                    }
                    if (!authenticationOK || !adminPermissionOK)
                    {
                        model.SiteSelectListItems = new SelectList(db.Sites, "ID", "Name");
                        ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                    }

                    if (authenticationOK)
                    {
                        //Site currentSite = db.Sites.Find(model.SiteID);
                        Site currentSite = db.Sites.Where(x => x.ID == 1).Single();

                        if (adminPermissionOK)
                        {
                            Session["CurrentWeighmanName"] = currentWeighman.Name;
                            Session["CurrentWeighmanID"] = currentWeighman.ID;


                            Session["CurrentSiteName"] = currentSite.Name;
                            Session["CurrentSiteID"] = currentSite.ID;

                            FormsAuthentication.SetAuthCookie(model.UserName, false);  // true : remember me, false, not remember me

                            ViewBag.SiteName = currentSite.Name;
                            if ((Session["Role"] as Role).Name == "Driver")
                                return Redirect(returnUrl ?? Url.Action("Index", "DocketLookup"));
                            else
                                return Redirect(returnUrl ?? Url.Action("Index", "Home"));

                        }
                        else
                        {
                            ModelState.AddModelError("", "The user does not have Administrative Permissions to logon to " + currentSite.Name);

                            return View(model);
                        }

                    }
                    else
                    {
                        ModelState.AddModelError("", "The user name or password provided is incorrect.");

                        return View(model);

                    }

                }
                else
                {

                    ModelState.AddModelError("", "The user name or password provided is incorrect.");
                    return View(model);
                }
            }
            catch
            {
                //throw;
                ModelState.AddModelError("", "The user name or password provided is incorrect.");
                return View(model);
            }
        }


    }
}
