﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using PagedList;
using System.Data.Entity.Infrastructure;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    [SessionAccess]
    public class WeightMoveController : EntityController<WeightMove>
    {
        // GET: WeighPass

        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();


            ViewBag.DisplayTitle = "Weight Movements" + " @ " + logOnSite.Name;

            ViewBag.CurrentSort = sortOrder;
            ViewBag.RegistrationSortParm = (String.IsNullOrEmpty(sortOrder) ? "Registration_Desc" : "");
            ViewBag.PlatformSortParm = (sortOrder == "Platform" ? "Platform_Desc" : "Platform");
            ViewBag.WeightPassedSortParm = (sortOrder == "WeightPassed" ? "WeightPassed_Desc" : "WeightPassed");
            ViewBag.DateTimeInSortParm = (sortOrder == "DateTimeIn" ? "DateTimeIn_Desc" : "DateTimeIn");
            ViewBag.SiteSortParm = (sortOrder == "Site" ? "Site_Desc" : "Site");
            ViewBag.WeighmanSortParm = (sortOrder == "Weighman" ? "Weighman_Desc" : "Weighman");

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            entities = db.WeightMoves.Include(w => w.Site).Include(w => w.Weighman);

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.WeightMoves == null)
                {
                    entities = from e in db.WeightMoves where e.ID == CoreConstants.NA_ID select e;
                }
                else
                {
                    entities = logOnSite.WeightMoves.AsQueryable<WeightMove>();
                }
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                entities = entities.Where(e => e.Registration.ToUpper().Contains(searchString.ToUpper())
                                          || e.PlatformID.ToUpper().Contains(searchString.ToUpper())
                                          || e.Site.Name.ToUpper().Contains(searchString.ToUpper())
                                          || e.WeightPassed.ToString().ToUpper().Contains(searchString.ToUpper())
                                          || e.Weighman.Name.ToUpper().Contains(searchString.ToUpper())

                                         );
            }

            switch (sortOrder)
            {
                case "Registration_Desc":
                    entities = entities.OrderByDescending(e => e.Registration);
                    break;
                case "Platform":
                    entities = entities.OrderBy(e => e.PlatformID);
                    break;
                case "Platform_Desc":
                    entities = entities.OrderByDescending(e => e.PlatformID);
                    break;

                case "WeightPassed":
                    entities = entities.OrderBy(e => e.WeightPassed);
                    break;
                case "WeightPassed_Desc":
                    entities = entities.OrderByDescending(e => e.WeightPassed);
                    break;
                case "DateTimeIn":
                    entities = entities.OrderBy(e => e.DateTimeIn);
                    break;
                case "DateTimeIn_Desc":
                    entities = entities.OrderByDescending(e => e.DateTimeIn);
                    break;
                case "Site":
                    entities = entities.OrderBy(e => e.Site.Name);
                    break;
                case "Site_Desc":
                    entities = entities.OrderByDescending(e => e.Site.Name);
                    break;
                case "Weighman":
                    entities = entities.OrderBy(e => e.Weighman.Name);
                    break;
                case "Weighman_Desc":
                    entities = entities.OrderByDescending(e => e.Weighman.Name);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Registration);
                    break;
            }

            //return View(entities.ToList());
            pageNumber = (page ?? 1);

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        // GET: WeighPass/Details/5
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();


            ViewBag.DisplayTitle = "Details" + " @ " + logOnSite.Name;

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WeightMove weighPass = db.WeightMoves.Find(id);
            if (weighPass == null)
            {
                return HttpNotFound();
            }
            return View(weighPass);
        }

        // GET: WeighPass/Create
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            if (logOnSiteIsCentral)
            {
                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            }
            else
            {
                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen, "ID", "Name");
            }

            return View();
        }

        // POST: WeighPass/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,WeightPassed,IsWeighPass,DateTimeIn,Registration,Platform,SiteID,WeighmanID")] WeightMove weighPass)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();


            if (ModelState.IsValid)
            {
                db.WeightMoves.Add(weighPass);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage("Weigh Pass at " + weighPass.DateTimeIn.ToString() + " created successfully!");
                return RedirectToAction("Index");
            }

            if (logOnSiteIsCentral)
            {
                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            }
            else
            {
                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen, "ID", "Name");
            }
            return View(weighPass);
        }

        // GET: WeighPass/Edit/5
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();


            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.WeightMoves.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }

            if (logOnSiteIsCentral)
            {
                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            }
            else
            {
                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen, "ID", "Name");
            }

            return View(entity);
        }

        // POST: WeighPass/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,WeightPassed,IsWeighPass,DateTimeIn,Registration,Platform,SiteID,WeighmanID")] WeightMove weighPass)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();


            if (ModelState.IsValid)
            {
                db.Entry(weighPass).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage("Weigh Pass at " + weighPass.DateTimeIn.ToString() + " edited successfully!");
                return RedirectToAction("Index");
            }

            if (logOnSiteIsCentral)
            {
                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen, "ID", "Name");
            }
            else
            {
                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen, "ID", "Name");
            }

            return View(weighPass);
        }

        // GET: WeighPass/Delete/5
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();



            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.WeightMoves.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        // POST: WeighPass/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();



            entity = db.WeightMoves.Find(id);
            db.WeightMoves.Remove(entity);
            db.SaveChanges();
            TempData["UserMessage"] = ComposeTempDisplayMessage("Weigh Pass at " + entity.DateTimeIn.ToString() + " deleted successfully!");
            return RedirectToAction("Index");
        }

        [NonAction]
        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
