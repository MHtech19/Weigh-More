﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using PagedList;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers{
    
    public class TruckController : EntityController<Truck>
    {
        private decimal[] tareWeights = { 0, 0, 0, 0, 0 };
        IEnumerable<int> joblist;
        IEnumerable<int> customerlist;
        IEnumerable<int> sourcelist;
        IEnumerable<int> destinationlist;
        IEnumerable<int> productionlist;
        IEnumerable<int> truckconfiglist;

        
        private void ShiftLeftTareWeights(int startIndex)
        {
            for (int i = startIndex; i <= tareWeights.Length - 2; i++)
            {
                tareWeights[i] = tareWeights[i + 1];

            }

            tareWeights[tareWeights.Length - 1] = 0;

        }

        
        private void ValidateTareOrders(Truck truck)
        {
            tareWeights[0] = truck.Tare1;
            tareWeights[1] = truck.Tare2;
            tareWeights[2] = truck.Tare3;
            tareWeights[3] = truck.Tare4;
            tareWeights[4] = truck.Tare5;

            for (int i = 0; i <= 3; i++)
            {
                int j = i + 1;
                if (tareWeights[i] == 0)
                {
                    while (tareWeights[j] == 0 && (j < 4))
                    {
                        j++;
                    }

                    tareWeights[i] = tareWeights[j];
                    tareWeights[j] = 0;

                }
            }

            truck.Tare1 = tareWeights[0];
            truck.Tare2 = tareWeights[1];
            truck.Tare3 = tareWeights[2];
            truck.Tare4 = tareWeights[3];
            truck.Tare5 = tareWeights[4];
        }

        /// <summary>
        /// Get the list of truckes based on the filtes -Navigate to the index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <param name="loadType"></param>
        /// <param name="vehicle"></param>
        /// <param name="site"></param>
        /// <param name="job"></param>
        /// <param name="customer"></param>
        /// <param name="source"></param>
        /// <param name="destination"></param>
        /// <param name="product"></param>
        /// <param name="truckConfig"></param>
        /// <param name="vehicleType"></param>
        /// <param name="direction"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        // GET: Truck
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string code, string loadType, string vehicle, string site,
                                  string job, string customer, string source, string destination, string product, string truckConfig, string vehicleType, string direction, string status)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruck;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruck;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruck;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Vehicles");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");

            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");

            ViewBag.CustomerSortParm = (sortOrder == "Customer" ? "Customer_Desc" : "Customer");
            ViewBag.ProductSortParm = (sortOrder == "Product" ? "Product_Desc" : "Product");
            ViewBag.JobSortParm = (sortOrder == "Job" ? "Job_Desc" : "Job");
            ViewBag.TareSortParm = (sortOrder == "Tare" ? "Tare_Desc" : "Tare");
            ViewBag.MaxLoadSortParm = (sortOrder == "MaxLoad" ? "MaxLoad_Desc" : "MaxLoad");
            ViewBag.IsActiveSortParm = (sortOrder == "IsActive" ? "IsActive_Desc" : "IsActive");
            
            var entities = db.Trucks.Include(e => e.Driver).Include(e => e.Mark).Where(e => e.ID > CoreConstants.NA_ID);

            //Filters

            ViewBag.Jobs = db.Jobs.Select(e => new { Id = e.ID, Name = e.Name }).ToList();
            ViewBag.Customers = db.Customers.Select(e => new { Id = e.ID, Name = e.Name }).ToList();
            ViewBag.Sources = db.Sources.Select(e => new { Id = e.ID, Name = e.Name }).ToList();
            ViewBag.Destinations = db.Destinations.Select(e => new { Id = e.ID, Name = e.Name }).ToList();
            ViewBag.Products = db.Products.Select(e => new { Id = e.ID, Name = e.Name }).ToList();
            ViewBag.TruckConfigs = db.VehicleConfigurations.Select(e => new { Id = e.ID, Name = e.Name }).ToList();
            ViewBag.Vehicles = db.Vehicles.Select(e => new { Id = e.ID, Name = e.Name }).ToList();
            ViewBag.Sites = db.Sites.Where(s => s.ID > 1).ToList();
            ViewBag.LoadTypes = CoreConstants.LOADTYPES_NoSecond;
            ViewBag.Directions = CoreConstants.DIRECTIONS;

            status = status ?? "true";

            ViewBag.name = name;
            ViewBag.code = code;
            ViewBag.loadType = loadType;
            ViewBag.vehicle = vehicle;
            ViewBag.direction = direction;
            ViewBag.status = status;
            ViewBag.job = job;
            ViewBag.customer = customer;
            ViewBag.site = site;
            ViewBag.source = source;
            ViewBag.destionation = destination;
            ViewBag.product = product;
            ViewBag.truckConfig = truckConfig;


            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!String.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));
            }

            if (!String.IsNullOrEmpty(loadType) && loadType != null)
            {

                entities = entities.Where(e => e.LoadType.ToUpper().Contains(loadType.ToUpper()));
            }

            if (!String.IsNullOrEmpty(vehicle) && vehicle != "All")
            {
                int vehicleId = int.Parse(vehicle);
                entities = entities.Where(e => e.VehicleID == vehicleId);
            }

            if (!string.IsNullOrEmpty(site) && site != "All")
            {
                int siteId = int.Parse(site);
                entities = entities.Where(s => s.Sites.Any(st => st.ID == siteId));
            }

            if (!String.IsNullOrEmpty(job) && job != "All")
            {
                int jobId = int.Parse(job);
                joblist = (from tj in db.TruckJobs
                           join j in db.Jobs on tj.JobID equals j.ID
                           where j.ID == jobId
                           select tj.TruckID).Distinct();

                entities = entities.Where(e => joblist.Contains(e.ID));
            }


            if (!String.IsNullOrEmpty(customer) && customer != "All")
            {
                int customerId = int.Parse(customer);
                customerlist = (from tc in db.TruckCustomers
                                join cust in db.Customers on tc.CustomerID equals cust.ID
                                where cust.ID == customerId
                                select tc.TruckID).Distinct();

                entities = entities.Where(e => customerlist.Contains(e.ID));
            }

            if (!String.IsNullOrEmpty(source) && source != "All")
            {
                int sourceId = int.Parse(source);
                sourcelist = (from ts in db.TruckSource
                              join src in db.Sources on ts.SourceID equals src.ID
                              where src.ID == sourceId
                              select ts.TruckID).Distinct();

                entities = entities.Where(e => sourcelist.Contains(e.ID));
            }

            if (!String.IsNullOrEmpty(destination) && destination != "All")
            {
                int destinationId = int.Parse(destination);
                destinationlist = (from td in db.TruckDestination
                                   join dest in db.Destinations on td.DestinationID equals dest.ID
                                   where dest.ID == destinationId
                                   select td.TruckID).Distinct();

                entities = entities.Where(e => destinationlist.Contains(e.ID));
            }

            if (!String.IsNullOrEmpty(product) && product != "All")
            {
                int productId = int.Parse(product);
                productionlist = (from tp in db.TruckProducts
                                  join prod in db.Products on tp.ProductID equals prod.ID
                                  where prod.ID == productId
                                  select tp.TruckID).Distinct();

                entities = entities.Where(e => productionlist.Contains(e.ID));
            }

            if (!String.IsNullOrEmpty(truckConfig) && truckConfig != "All")
            {
                int truckConfigId = int.Parse(truckConfig);
                truckconfiglist = (from tc in db.TruckConfigs
                                   join vconfig in db.VehicleConfigurations on tc.VehicleConfigurationID equals vconfig.ID
                                   where vconfig.ID == truckConfigId
                                   select tc.TruckID).Distinct();

                entities = entities.Where(e => truckconfiglist.Contains(e.ID));
            }

            if (!String.IsNullOrEmpty(direction))
            {
                direction = direction == "NA" ? null : direction;
                entities = entities.Where(e => e.InOrOut == direction);
            }

            if (!String.IsNullOrEmpty(status) && status != "All")
            {
                bool statusId = bool.Parse(status);
                entities = entities.Where(e => e.IsActive == statusId);
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;
               
                case "Tare":
                    entities = entities.OrderBy(e => e.Tare1);
                    break;
                case "Tare_Desc":
                    entities = entities.OrderByDescending(e => e.Tare1);
                    break;
                case "MaxLoad":
                    entities = entities.OrderBy(e => e.MaxLoad);
                    break;
                case "MaxLoad_Desc":
                    entities = entities.OrderByDescending(e => e.MaxLoad);
                    break;
                case "IsActive_Desc":
                    entities = entities.OrderByDescending(e => e.IsActive);
                    break;
                case "IsActive":
                    entities = entities.OrderBy(e => e.IsActive);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;


            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Here get the  truck details based on the transaction id- From grid details action
        /// It navigates to the Details page with truck details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Truck/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruck;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Trucks.Include(c => c.Sites).Where(c => c.ID == id).Single();
            entity.JobNames = string.Join(",", (from tj in db.TruckJobs
                                                join j in db.Jobs on tj.JobID equals j.ID
                                                where tj.TruckID == id
                                                select j.Name).ToArray());
            entity.ProductNames = string.Join(",", (from tp in db.TruckProducts
                                                    join p in db.Products on tp.ProductID equals p.ID
                                                    where tp.TruckID == id
                                                    select p.Name).ToArray());
            entity.DestinationNames = string.Join(",", (from td in db.TruckDestination
                                                        join d in db.Destinations on td.DestinationID equals d.ID
                                                        where td.TruckID == id
                                                        select d.Name).ToArray());
            entity.CustomerNames = string.Join(",", (from tc in db.TruckCustomers
                                                     join c in db.Customers on tc.CustomerID equals c.ID
                                                     where tc.TruckID == id && c.CustomerType == "C"
                                                     select c.Name).ToArray());// where (c.CustomerType == "C" || c.CustomerType == null) && tc.TruckID == id
            if (String.IsNullOrEmpty(entity.CustomerNames))
                entity.CustomerNames = "NA";
            entity.SupplierNames = string.Join(",", (from tc in db.TruckCustomers
                                                     join c in db.Customers on tc.CustomerID equals c.ID
                                                     where tc.TruckID == id && c.CustomerType == "S"
                                                     select c.Name).ToArray());
            if (String.IsNullOrEmpty(entity.SupplierNames))
                entity.SupplierNames = "NA";
            entity.SourceNames = string.Join(",", (from ts in db.TruckSource
                                                   join s in db.Sources on ts.SourceID equals s.ID
                                                   where ts.TruckID == id
                                                   select s.Name).ToArray());
            entity.VehicleConfigNames = string.Join(",", (from vc in db.TruckConfigs
                                                          join c in db.VehicleConfigurations on vc.VehicleConfigurationID equals c.ID
                                                          where vc.TruckID == id
                                                          select c.Name).ToArray());

            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Here it navigates to create a new truck page with default values
        /// 
        /// </summary>
        /// <returns></returns>
        // GET: Truck/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruck;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruck;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruck;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPES_NoSecond, CoreConstants.Load_First);
            ViewBag.ChargeRate = new SelectList(CoreConstants.CHARGE_RATES, CoreConstants.RATE_LOCAL);
            ViewBag.DriverID = new SelectList(db.Drivers.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.MarkID = new SelectList(db.Marks.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.CustomerID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Customers.Where(e => (e.CustomerType == "C" || e.CustomerType == null)).OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.SupplierID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Customers.Where(e => (e.CustomerType == "S" || e.CustomerType == null)).OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.DestinationID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.JobID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Jobs.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.ProductID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.SourceID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.VehicleConfigurationID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name"));
            //ViewBag.VehicleConfigurationID = new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.VehicleID = new SelectList(db.Vehicles.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.InOrOut = new SelectList(new List<string> { "", "In", "Out" });

            Truck entity = new Truck() { };
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            return View(entity);
        }

        /// <summary>
        /// Create a new truck - stored in the truck table
        /// </summary>
        /// <param name="truck"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Truck/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewTruck")]
        public ActionResult Create([Bind(Include = "ID,Name,Code,Description,Registration2,Registration3,Fleet,TagID,Tare1,Tare2,Tare3,Tare4,Tare5,MaxLoad,CustomerID,ProductID,JobID,DestinationID,SourceID,DriverID,VehicleConfigurationID,MarkID,LoadType,VehicleID,TareTerm,SiteOwned,ChargeRate,TruckJobs,TruckProducts,TruckDestination,TruckCustomers,TruckSource,TruckConfig,TruckSuppliers,IsActive,InOrOut,SplitTare,ChargeSiteOwned,ABN")] Truck truck, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruck;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruck;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruck;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPES_NoSecond, truck.LoadType);
            ViewBag.ChargeRate = new SelectList(CoreConstants.CHARGE_RATES, truck.ChargeRate);
            ViewBag.CustomerID = new SelectList(db.Customers.Where(e => (e.CustomerType == "C" || e.CustomerType == null)).OrderBy(e => e.Name), "ID", "Name");
            ViewBag.SupplierID = new SelectList(db.Customers.Where(e => (e.CustomerType == "S" || e.CustomerType == null)).OrderBy(e => e.Name), "ID", "Name");
            // getSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Customers.Where(e => e.CustomerType == "S" && e.SiteCreated == false).OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.DestinationID = new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.DriverID = new SelectList(db.Drivers.OrderBy(e => e.Name), "ID", "Name", truck.DriverID);
            ViewBag.JobID = new SelectList(db.Jobs.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.MarkID = new SelectList(db.Marks.OrderBy(e => e.Name), "ID", "Name", truck.MarkID);
            //ViewBag.ProductID = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.ProductID = GetSortedList(new int[] { CoreConstants.NA_ID }, new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.SourceID = new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.VehicleConfigurationID = new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.VehicleID = new SelectList(db.Vehicles.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.InOrOut = new SelectList(new List<string> { "", "In", "Out" });
            ViewBag.Sites = new List<AssignedSiteData>();
            var allSiteIDs = db.Sites.Where(t => t.ID > CoreConstants.NA_ID).Select(t => t.ID).ToList();

            var nameExist = db.Trucks.FirstOrDefault(e => e.Name == truck.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "Vehicle already exists");
                return View(truck);
            }

            if (selectedSites != null)
            {
                truck.Sites = new List<Site>();
                foreach (var site in selectedSites)
                {
                    var siteToAdd = db.Sites.Find(int.Parse(site));
                    truck.Sites.Add(siteToAdd);
                }
                ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, truck.Sites) : new List<AssignedSiteData>();
            }
            else
            {
                ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, new List<Site>()) : new List<AssignedSiteData>();
            }

            if (ModelState.IsValid)
            {
                truck.Name = truck.Name.ToUpper();
                ValidateVehicleInput(truck, true);
                db.Trucks.Add(truck);
                db.SaveChanges();
                if (truck.ID > 0)
                {
                    SaveTrcukJobs(truck);
                    SaveTrcukProducts(truck);
                    SaveTrcukDestination(truck);
                    SaveTrcukCustomers(truck);
                    SaveTrcukSource(truck);
                    SaveTrcukConfig(truck);
                    SaveTrcukSuppliers(truck);

                    //Adding to the ReplicationLogItem for data sync
                    if (allSiteIDs != null)
                    {
                        foreach (var siteID in allSiteIDs)
                        {
                            WriteReplicationLog(siteID, truck.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                        }
                    }
                }
                TempData["UserMessage"] = ComposeTempDisplayMessage(truck.Name + " created successfully!");
                //                return RedirectToAction("Index");
                return RedirectToAction("Edit/" + truck.ID.ToString());
            }
            return View(truck);
        }

        /// <summary>
        /// Here get the details of the truck based on the truck id and navigates to edit page
        /// from the grid edit action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Truck/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruck;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruck;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruck;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Trucks.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            entity.TruckJobs = db.TruckJobs.Where(p => p.TruckID == id).Select(p => p.JobID).ToArray();
            entity.TruckProducts = db.TruckProducts.Where(p => p.TruckID == id).Select(p => p.ProductID).ToArray();
            entity.TruckDestination = db.TruckDestination.Where(p => p.TruckID == id).Select(p => p.DestinationID).ToArray();

            entity.TruckCustomers = (from tc in db.TruckCustomers
                                     join c in db.Customers on tc.CustomerID equals c.ID
                                     where tc.TruckID == id && (tc.CustomerType == "C")
                                     select tc.CustomerID).ToArray();

            entity.TruckSuppliers = (from tc in db.TruckCustomers
                                     join c in db.Customers on tc.CustomerID equals c.ID
                                     where tc.TruckID == id && (tc.CustomerType == "S")
                                     select tc.CustomerID).ToArray();

            entity.TruckSource = db.TruckSource.Where(p => p.TruckID == id).Select(p => p.SourceID).ToArray();
            entity.TruckConfig = db.TruckConfigs.Where(p => p.TruckID == id).Select(p => p.VehicleConfigurationID).ToArray();

            if (entity.TruckJobs != null)
            {
                entity.TruckJobValues = string.Join(",", entity.TruckJobs);
            }

            if (entity.TruckProducts != null)
            {
                entity.TruckProductValues = string.Join(",", entity.TruckProducts);
            }

            if (entity.TruckDestination != null)
            {
                entity.TruckDestinationValues = string.Join(",", entity.TruckDestination);
            }

            if (entity.TruckCustomers != null)
            {
                entity.TruckCustomerValues = string.Join(",", entity.TruckCustomers);
            }

            if (entity.TruckSuppliers != null)
            {
                entity.TruckSupplierValues = string.Join(",", entity.TruckSuppliers);
            }

            if (entity.TruckSource != null)
            {
                entity.TruckSourceValues = string.Join(",", entity.TruckSource);
            }

            if (entity.TruckConfig != null)
            {
                entity.TruckConfigValues = string.Join(",", entity.TruckConfig);
            }

            ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPES_NoSecond, entity.LoadType);
            ViewBag.ChargeRate = new SelectList(CoreConstants.CHARGE_RATES, entity.ChargeRate);
            ViewBag.DriverID = new SelectList(db.Drivers.OrderBy(e => e.Name), "ID", "Name", entity.DriverID);
            ViewBag.MarkID = new SelectList(db.Marks.OrderBy(e => e.Name), "ID", "Name", entity.MarkID);
            ViewBag.JobID = GetSortedList(entity.TruckJobs, new SelectList(db.Jobs.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.CustomerID = GetSortedList(entity.TruckCustomers, new SelectList(db.Customers.Where(e => (e.CustomerType == "C" || e.CustomerType == null)).OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.SupplierID = GetSortedList(entity.TruckSuppliers, new SelectList(db.Customers.Where(e => (e.CustomerType == "S" || e.CustomerType == null)).OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.DestinationID = GetSortedList(entity.TruckDestination, new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.ProductID = GetSortedList(entity.TruckProducts, new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.SourceID = GetSortedList(entity.TruckSource, new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name"));            
            ViewBag.VehicleConfigurationID = GetSortedList(entity.TruckConfig, new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name"));
            ViewBag.VehicleID = new SelectList(db.Vehicles.OrderBy(e => e.Name), "ID", "Name", entity.VehicleID);
            ViewBag.InOut = new SelectList(new List<string> { "", "In", "Out" }, entity.InOrOut);
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            return View(entity);
        }

        /// <summary>
        /// Here update the details of the truck in the truck table based on the specified values in the edit page
        /// </summary>
        /// <param name="truck"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Truck/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditTruck")]
        public ActionResult Edit([Bind(Include = "ID,Name,Code,Description,Registration2,Registration3,Fleet,TagID,Tare1,Tare2,Tare3,Tare4,Tare5,MaxLoad,CustomerID,ProductID,JobID,DestinationID,SourceID,DriverID,VehicleConfigurationID,MarkID,LoadType,VehicleID,TareTerm,SiteOwned,ChargeRate,TruckJobs,TruckProducts,TruckDestination,TruckCustomers,TruckSource,TruckConfig,TruckSuppliers,IsActive,InOrOut,SplitTare,ChargeSiteOwned,ABN,LastTareDate")] Truck truck, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruck;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruck;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruck;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            var allSiteIDs = db.Sites.Where(t => t.ID > CoreConstants.NA_ID).Select(t => t.ID).ToList();


            ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPES_NoSecond, truck.LoadType);
            ViewBag.ChargeRate = new SelectList(CoreConstants.CHARGE_RATES, truck.ChargeRate);
            ViewBag.DriverID = new SelectList(db.Drivers.OrderBy(e => e.Name), "ID", "Name", truck.DriverID);
            ViewBag.MarkID = new SelectList(db.Marks.OrderBy(e => e.Name), "ID", "Name", truck.MarkID);


            ViewBag.CustomerID = new SelectList(db.Customers.Where(e => e.CustomerType == "C" || e.CustomerType == null).OrderBy(e => e.Name), "ID", "Name");
            ViewBag.SupplierID = new SelectList(db.Customers.Where(e => e.CustomerType == "S" || e.CustomerType == null).OrderBy(e => e.Name), "ID", "Name");
            ViewBag.DestinationID = new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.JobID = new SelectList(db.Jobs.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.ProductID = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.SourceID = new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.VehicleConfigurationID = new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name");
            ViewBag.VehicleID = new SelectList(db.Vehicles.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.InOut = new SelectList(new List<string> { "", "In", "Out" });
            truck.Sites = db.Trucks.Include(c => c.Sites).FirstOrDefault(m => m.ID == truck.ID).Sites;
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, truck.Sites) : new List<AssignedSiteData>();
            var truckExist = db.Trucks.FirstOrDefault(m => m.ID == truck.ID);

            if (truckExist != null)
            {
                if (truckExist.ID == truck.ID)
                {
                    if (ModelState.IsValid)
                    {
                        ValidateVehicleInput(truck, false);
                        var entityUpdate = db.Trucks.Find(truck.ID);
                        entityUpdate.Name = truck.Name.ToUpper();
                        entityUpdate.Description = truck.Description;
                        entityUpdate.Code = truck.Code;
                        entityUpdate.Registration2 = truck.Registration2;
                        entityUpdate.Registration3 = truck.Registration3;
                        entityUpdate.Fleet = truck.Fleet;
                        entityUpdate.TagID = truck.TagID;
                        entityUpdate.Tare1 = truck.Tare1;
                        entityUpdate.Tare2 = truck.Tare2;
                        entityUpdate.Tare3 = truck.Tare3;
                        entityUpdate.Tare4 = truck.Tare4;
                        entityUpdate.Tare5 = truck.Tare5;
                        entityUpdate.MaxLoad = truck.MaxLoad;
                        entityUpdate.DriverID = truck.DriverID;
                        entityUpdate.MarkID = truck.MarkID;
                        entityUpdate.LoadType = truck.LoadType;
                        entityUpdate.VehicleID = truck.VehicleID;
                        entityUpdate.TareTerm = truck.TareTerm;
                        entityUpdate.SiteOwned = truck.SiteOwned;
                        entityUpdate.ChargeRate = truck.ChargeRate;
                        entityUpdate.TruckJobs = truck.TruckJobs;
                        entityUpdate.TruckProducts = truck.TruckProducts;
                        entityUpdate.TruckDestination = truck.TruckDestination;
                        entityUpdate.TruckCustomers = truck.TruckCustomers;
                        entityUpdate.TruckSource = truck.TruckSource;
                        entityUpdate.TruckConfig = truck.TruckConfig;
                        entityUpdate.TruckSuppliers = truck.TruckSuppliers;
                        entityUpdate.IsActive = truck.IsActive;
                        entityUpdate.InOrOut = truck.InOrOut;
                        entityUpdate.SplitTare = truck.SplitTare;
                        entityUpdate.ChargeSiteOwned = truck.ChargeSiteOwned;
                        entityUpdate.ABN = truck.ABN;
                        entityUpdate.LastTareDate = truck.LastTareDate;

                        if (entityUpdate.TruckJobs != null)
                        {
                            entityUpdate.TruckJobValues = string.Join(",", entityUpdate.TruckJobs);
                        }

                        if (entityUpdate.TruckProducts != null)
                        {
                            entityUpdate.TruckProductValues = string.Join(",", entityUpdate.TruckProducts);
                        }

                        if (entityUpdate.TruckDestination != null)
                        {
                            entityUpdate.TruckDestinationValues = string.Join(",", entityUpdate.TruckDestination);
                        }

                        if (entityUpdate.TruckCustomers != null)
                        {
                            entityUpdate.TruckCustomerValues = string.Join(",", entityUpdate.TruckCustomers);
                        }

                        if (entityUpdate.TruckSuppliers != null)
                        {
                            entityUpdate.TruckSupplierValues = string.Join(",", entityUpdate.TruckSuppliers);
                        }

                        if (entityUpdate.TruckSource != null)
                        {
                            entityUpdate.TruckSourceValues = string.Join(",", entityUpdate.TruckSource);
                        }

                        if (entityUpdate.TruckConfig != null)
                        {
                            entityUpdate.TruckConfigValues = string.Join(",", entityUpdate.TruckConfig);
                        }

                        if (selectedSites != null)
                        {
                            UpdateEntitySiteAssignments(db, selectedSites, truck.Sites);
                        }

                        if (TryUpdateModel(entityUpdate, "",
                                 new string[] { "Name", "Description", "Code", "Registration2", "Registration3", "Fleet", "TagID",
                                     "MaxLoad", "DriverID", "MarkID", "LoadType", "VehicleID","SiteOwned","ChargeRate",
                                     "TruckJobs","TruckProducts","TruckDestination","TruckCustomers","TruckSource","TruckConfig",
                                     "TruckSuppliers","IsActive","InOrOut","SplitTare","ChargeSiteOwned","ABN"}))

                            db.SaveChanges();
                        if (truck.ID > 0)
                        {
                            DeleteTrcukJobs(truck.ID);
                            DeleteTrcukProducts(truck.ID);
                            DeleteTrcukDestination(truck.ID);
                            DeleteTrcukCustomers(truck.ID);
                            DeleteTrcukSource(truck.ID);
                            DeleteTrcukConfig(truck.ID);

                            SaveTrcukJobs(truck);
                            SaveTrcukProducts(truck);
                            SaveTrcukDestination(truck);
                            SaveTrcukCustomers(truck);
                            SaveTrcukSuppliers(truck);
                            SaveTrcukSource(truck);
                            SaveTrcukConfig(truck);
                        }

                        //Adding to the ReplicationLogItem for data sync
                        if (allSiteIDs != null)
                        {
                            foreach (var siteID in allSiteIDs)
                            {
                                WriteReplicationLog(siteID, truck.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                            }
                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(truck.Name + " edited successfully!");                        
                        return RedirectToAction("Edit/" + truck.ID.ToString());
                    }
                }
                else
                {
                    ModelState.AddModelError("Name", "Vehicle already exists");
                    return View(truck);
                }
            }

            return View(truck);
        }

        /// <summary>
        /// Here it gets the list of products for the partial view
        /// It has a multiselect products
        /// </summary>
        /// <param name="truckId"></param>
        /// <param name="loadType"></param>
        /// <returns>products list</returns>
        
        public ActionResult GetProductList(int? truckId, string loadType)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (DataBaseConnectionStringName == null)
            {
                return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            }

            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }

            if (truckId == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var truck = db.Trucks.Find(truckId);
            truck.TruckProducts = db.TruckProducts.Where(p => p.TruckID == truckId).Select(p => p.ProductID).ToArray();
            if (truck == null)
            {
                return HttpNotFound();
            }
            if (loadType == "Counted")
            {
                List<Product> productList = db.Products.Where(x => x.ProductType == "I").ToList();
                ViewBag.ProductID = GetSortedList(truck.TruckProducts, new SelectList(productList, "ID", "Name"));
            }
            else
            {
                List<Product> productList = db.Products.Where(x => x.ProductType == "W").ToList();
                ViewBag.ProductID = GetSortedList(truck.TruckProducts, new SelectList(productList, "ID", "Name"));
            }
            return PartialView();
        }

        
        private void ValidateVehicleInput(Truck truck, bool isCreatingTruck)
        {
            if (truck.LoadType == CoreConstants.Load_First)
            {
                truck.IsStoredTare = false;
                truck.Tare1 = 0M;
                truck.Tare2 = 0M;
                truck.Tare3 = 0M;
                truck.Tare4 = 0M;
                truck.Tare5 = 0M;
                truck.TareTerm = 0;
                truck.LastTareDate = null;
            }
            else if (truck.HasStoredTare && truck.TareTerm > 0)
            {
                truck.LoadType = CoreConstants.Load_StoredTare;
                truck.IsStoredTare = true;
                truck.VehicleID = CoreConstants.NA_ID;
                ValidateTareOrders(truck);
                if (isCreatingTruck)
                {
                    truck.LastTareDate = DateTime.Now;
                }
            }
            else
            {
                truck.TareTerm = 0;                
                if (truck.LoadType != CoreConstants.Load_Standard)
                {
                    truck.VehicleID = CoreConstants.NA_ID;
                }
                else
                {
                    truck.MaxLoad = 0;
                }
            }
        }

        /// <summary>
        /// Here get the details of the truck based on the truck id
        /// Navigates the the delete truck page with the truck details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Truck/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruck;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruck;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruck;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Trucks.Find(id);

            entity.JobNames = string.Join(",", (from tj in db.TruckJobs
                                                join j in db.Jobs on tj.JobID equals j.ID
                                                where tj.TruckID == id
                                                select j.Name).ToArray());
            entity.ProductNames = string.Join(",", (from tp in db.TruckProducts
                                                    join p in db.Products on tp.ProductID equals p.ID
                                                    where tp.TruckID == id
                                                    select p.Name).ToArray());
            entity.DestinationNames = string.Join(",", (from td in db.TruckDestination
                                                        join d in db.Destinations on td.DestinationID equals d.ID
                                                        where td.TruckID == id
                                                        select d.Name).ToArray());
            entity.CustomerNames = string.Join(",", (from tc in db.TruckCustomers
                                                     join c in db.Customers on tc.CustomerID equals c.ID
                                                     where tc.TruckID == id
                                                     select c.Name).ToArray());
            entity.SourceNames = string.Join(",", (from ts in db.TruckSource
                                                   join s in db.Sources on ts.SourceID equals s.ID
                                                   where ts.TruckID == id
                                                   select s.Name).ToArray());
            entity.VehicleConfigNames = string.Join(",", (from vc in db.TruckConfigs
                                                          join c in db.VehicleConfigurations on vc.VehicleConfigurationID equals c.ID
                                                          where vc.TruckID == id
                                                          select c.Name).ToArray());
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Here remove the truck from the truck table based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Navigates to the index page</returns>
        // POST: Truck/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteTruck")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruck;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruck;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruck;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            try
            {
                entity = db.Trucks.Find(id);
                if (entity != null)
                {                   
                    entity.IsActive = false;
                    db.Entry(entity).State = EntityState.Modified;
                    db.SaveChanges();
                    TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");

                    var siteList = db.Sites.Where(s => s.ID > 1).ToList();
                    foreach (var siteItem in siteList)
                    {
                        WriteReplicationLog(siteItem.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                    }
                }
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This truck " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }

        
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Here add the truck-jobs to the truckjobs table
        /// </summary>
        /// <param name="truck"></param>
        
        private void SaveTrcukJobs(Truck truck)
        {
            if (truck.TruckJobs != null)
            {
                foreach (var item in truck.TruckJobs)
                {
                    var tj = new TruckJobs() { };
                    tj.TruckID = truck.ID;
                    tj.JobID = item;
                    db.TruckJobs.Add(tj);
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Here add the truck-products to the truckproducts table
        /// </summary>
        /// <param name="truck"></param>
        
        private void SaveTrcukProducts(Truck truck)
        {
            if (truck.TruckProducts != null)
            {
                foreach (var item in truck.TruckProducts)
                {
                    var tp = new TruckProducts() { };
                    tp.TruckID = truck.ID;
                    tp.ProductID = item;
                    db.TruckProducts.Add(tp);
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Here add the truck-destination to the truckdestination table
        /// </summary>
        /// <param name="truck"></param>
        
        private void SaveTrcukDestination(Truck truck)
        {
            if (truck.TruckDestination != null)
            {
                foreach (var item in truck.TruckDestination)
                {
                    var td = new TruckDestination() { };
                    td.TruckID = truck.ID;
                    td.DestinationID = item;
                    db.TruckDestination.Add(td);
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Here add the truck-customers to the truckcustomers table
        /// </summary>
        /// <param name="truck"></param>
        
        private void SaveTrcukCustomers(Truck truck)
        {
            if (truck.TruckCustomers != null)
            {
                foreach (var item in truck.TruckCustomers)
                {
                    var tc = new TruckCustomers() { };
                    tc.TruckID = truck.ID;
                    tc.CustomerID = item;
                    tc.CustomerType = "C";
                    db.TruckCustomers.Add(tc);
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Here add the truck-suppliers to the trucksuppliers table
        /// </summary>
        /// <param name="truck"></param>
        
        private void SaveTrcukSuppliers(Truck truck)
        {
            if (truck.TruckSuppliers != null)
            {
                foreach (var item in truck.TruckSuppliers)
                {
                    var tc = new TruckCustomers() { };
                    tc.TruckID = truck.ID;
                    tc.CustomerID = item;
                    tc.CustomerType = "S";
                    db.TruckCustomers.Add(tc);
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Here add the truck-source to the trucksource table
        /// </summary>
        /// <param name="truck"></param>
        
        private void SaveTrcukSource(Truck truck)
        {
            if (truck.TruckSource != null)
            {
                foreach (var item in truck.TruckSource)
                {
                    var ts = new TruckSource() { };
                    ts.TruckID = truck.ID;
                    ts.SourceID = item;
                    db.TruckSource.Add(ts);
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Here it add the configuration of the truck in the truckConfig table
        /// </summary>
        /// <param name="truck"></param>
        
        private void SaveTrcukConfig(Truck truck)
        {
            if (truck.TruckConfig != null)
            {
                foreach (var item in truck.TruckConfig)
                {
                    var tc = new TruckConfigs() { };
                    tc.TruckID = truck.ID;
                    tc.VehicleConfigurationID = item;
                    db.TruckConfigs.Add(tc);
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Here delete the truckjob from the truckjobs table based on the truckjob id
        /// </summary>
        /// <param name="id"></param>
        
        private void DeleteTrcukJobs(int id)
        {
            var tj = db.TruckJobs.Where(p => p.TruckID == id);
            db.TruckJobs.RemoveRange(tj);
            db.SaveChanges();
        }


        /// <summary>
        /// Here delete the truckproduct from the truckproducts table based on the truckproduct id
        /// </summary>
        /// <param name="id"></param>
        
        private void DeleteTrcukProducts(int id)
        {
            var tp = db.TruckProducts.Where(p => p.TruckID == id);
            db.TruckProducts.RemoveRange(tp);
            db.SaveChanges();
        }

        /// <summary>
        /// Here delete the truckdestination from the truckdestination table based on the truckdestination id
        /// </summary>
        /// </summary>
        /// <param name="id"></param>
        
        private void DeleteTrcukDestination(int id)
        {
            var td = db.TruckDestination.Where(p => p.TruckID == id);
            db.TruckDestination.RemoveRange(td);
            db.SaveChanges();
        }


        /// <summary>
        /// Here delete the truckcustomer from the truckcustomer table based on the truckcustomer id
        /// </summary>
        /// </summary>
        /// <param name="id"></param>
        
        private void DeleteTrcukCustomers(int id)
        {
            var tc = db.TruckCustomers.Where(p => p.TruckID == id);
            db.TruckCustomers.RemoveRange(tc);
            db.SaveChanges();
        }


        /// <summary>
        /// Here delete the trucksource from the trucksource table based on the trucksource id
        /// </summary>
        /// </summary>
        /// <param name="id"></param>
        
        private void DeleteTrcukSource(int id)
        {
            var ts = db.TruckSource.Where(p => p.TruckID == id);
            db.TruckSource.RemoveRange(ts);
            db.SaveChanges();
        }

        /// <summary>
        /// Here delete the truckconfig from the truckconfig table based on the truckconfig id
        /// </summary>
        /// </summary>
        /// <param name="id"></param>
        
        private void DeleteTrcukConfig(int id)
        {
            var tc = db.TruckConfigs.Where(p => p.TruckID == id);
            db.TruckConfigs.RemoveRange(tc);
            db.SaveChanges();
        }

        //To make all selected list into top
        
        private List<SelectListItem> GetSortedList(int[] intList, SelectList s)
        {
            List<SelectListItem> l = new List<SelectListItem>();
            if (s.Count() > 0)
            {
                foreach (var item in s.OrderBy(e => e.Text))
                {
                    SelectListItem i = new SelectListItem() { };
                    i.Text = item.Text;
                    i.Value = item.Value;
                    i.Selected = intList.Contains(Convert.ToInt32(i.Value));
                    l.Add(i);
                }
            }
            IEnumerable<SelectListItem> p = l.OrderByDescending(q => q.Selected);
            return p.ToList();
        }
    }
}
