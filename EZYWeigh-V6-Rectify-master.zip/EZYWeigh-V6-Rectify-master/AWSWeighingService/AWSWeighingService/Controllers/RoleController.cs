﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using PagedList;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    
    public class RoleController : EntityController<Role>
    {
        /// <summary>
        /// Get the Roles list - Index Grid
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="currentFilter"></param>
        /// <param name="searchString"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        // GET: Roles
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? filterPageSize, string currentFilter, string searchString, int? page)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewRole;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditRole;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteRole;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Roles");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            entities = from e in db.Roles select e;
            entities = entities.Where(r => r.IsAWSSupportRole != true);

            if (!String.IsNullOrEmpty(searchString))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(searchString.ToUpper()));
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Get the details of the role - Navigate to details page from the grid details action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Weighman/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewRole;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditRole;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteRole;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = new Role { Name = "Connection Failed! Retry later." };

            try
            {
                entity = db.Roles.Where(e => e.ID == id).Single();
                if (entity == null)
                {
                    return HttpNotFound();
                }

            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(entity);
        }

        /// <summary>
        /// Navigate to Create Role page from index page
        /// </summary>
        /// <returns></returns>
        // GET: Weighman/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewRole;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditRole;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteRole;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);

            entity = new Role();

            return View();
        }

        /// <summary>
        /// Save new role in the DB
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        // POST: Weighman/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewRole")]
        public ActionResult Create([Bind(Include = "ID,Name,CanNewProduct,CanEditProduct,CanNewProductCategory,CanEditProductCategory,CanNewCustomer,CanEditCustomer," +
            "CanNewDestination,CanEditDestination,CanNewSource,CanEditSource,CanNewJob,CanEditJob,CanNewTruck,CanEditTruck,CanNewTruckConfiguration," +
            "CanEditTruckConfiguration,CanNewVehicleType,CanEditVehicleType,CanNewWeighman,CanEditWeighman,CanNewDriver," +
            "CanEditDriver,CanNewTransaction,CanEditTransaction,CanNewRole,CanEditRole," +
            "CanReportJob,CanReportProduct,CanReportProductCategory,CanReportCustomer,CanReportDestination,CanReportSource,CanReportTruck,CanReportTruckConfiguration," +
            "CanReportVehicleType,CanReportWeighman,CanReportDriver,CanReportTransaction,CanReportRole," +
            "CanDeleteJob,CanDeleteProductCategory,CanDeleteDestination,CanDeleteTruck,CanDeleteVehicleType," +
            "CanDeleteDriver,CanDeleteRole,CanDeleteProduct,CanDeleteCustomer,CanDeleteSource,CanDeleteTruckConfiguration,CanDeleteWeighman,CanDeleteTransaction,CanViewPrintEventLog,CanUseExportWizard,CanNewSite,CanEditSite,CanDeleteSite,CanReportSite,"+
            "CanNewOffence,CanEditOffence,CanDeleteOffence,CanReportOffence,CanViewFirstWeigh,CanDeleteFirstWeigh,CanLookupDocketAddSignature,CanLookupDocketUpdSignature")] Role role)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewRole;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditRole;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteRole;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");


            if (!logOnSiteIsCentral) // not central site
            {
                ViewBag.IsCentralSite = false;
            }

            var nameExist = db.Roles.FirstOrDefault(e => e.Name == role.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "Role already exists");
                return View(role);
            }

            if (ModelState.IsValid)
            {
                db.Roles.Add(role);

                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(role.Name + " created successfully! ");

                db.SaveChanges();

                return RedirectToAction("Edit/" + role.ID.ToString());
            }

            return View(role);
        }

        /// <summary>
        /// Get the role details for edit - Navigate from the grid edit action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Role/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewRole;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditRole;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteRole;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = new Role { Name = "Connection Failed! Retry later." };
            try
            {
                entity = db.Roles.Where(e => e.ID == id).Single();

                if (entity == null)
                {
                    return HttpNotFound();
                }
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(entity);

        }

        /// <summary>
        /// Update the role details in the DB
        /// </summary>
        /// <param name="id"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>

        // POST: Role/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditRole")]
        //public ActionResult Edit([Bind(Include = "ID,Name,Password,ConfirmPassword,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Contact,Email")] Weighman weighman)
        public ActionResult Edit(int? id, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewRole;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditRole;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteRole;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Roles.Where(e => e.ID == id).Single();

            if (TryUpdateModel(entity, "", new string[] { "Name",
                                                          "CanNewProduct", "CanEditProduct", "CanNewProductCategory", "CanEditProductCategory", "CanNewCustomer", "CanEditCustomer", "CanNewDestination", "CanEditDestination", "CanNewSource", "CanEditSource",
                                                          "CanNewJob", "CanEditJob", "CanNewTruck", "CanEditTruck", "CanNewTruckConfiguration", "CanEditTruckConfiguration", "CanNewVehicleType", "CanEditVehicleType", "CanNewWeighman", "CanEditWeighman",
                                                          "CanNewDriver", "CanEditDriver", "CanNewTransaction", "CanEditTransaction","CanNewRole","CanEditRole",
                                                          "CanReportProduct", "CanReportProductCategory","CanReportCustomer","CanReportDestination","CanReportSource",
                                                          "CanReportJob","CanReportTruck","CanReportTruckConfiguration","CanReportVehicleType","CanReportWeighman",
                                                          "CanReportDriver","CanReportTransaction","CanReportRole","CanDeleteJob","CanDeleteProductCategory","CanDeleteDestination","CanDeleteTruck","CanDeleteVehicleType","CanDeleteDriver","CanDeleteRole","CanDeleteProduct","CanDeleteCustomer","CanDeleteSource","CanDeleteTruckConfiguration","CanDeleteWeighman","CanDeleteTransaction","CanViewPrintEventLog","CanUseExportWizard",
                                                          "CanNewSite","CanEditSite","CanDeleteSite","CanReportSite","CanNewOffence","CanEditOffence","CanDeleteOffence","CanReportOffence","CanViewFirstWeigh","CanDeleteFirstWeigh","CanLookupDocketAddSignature","CanLookupDocketUpdSignature"
                                                        }))
            {
                try
                {
                    var roleExist = db.Roles.FirstOrDefault(e => e.Name == entity.Name);
                    if (roleExist != null)
                    {
                        if (roleExist.ID == entity.ID)
                        {
                            if (ModelState.IsValid)
                            {
                                var entityUpdate = db.Roles.Find(entity.ID);
                                entityUpdate.Name = entity.Name.ToUpper();
                                entityUpdate.CanNewProduct = entity.CanNewProduct;
                                entityUpdate.CanEditProduct = entity.CanEditProduct;
                                entityUpdate.CanNewProductCategory = entity.CanNewProductCategory;
                                entityUpdate.CanEditProductCategory = entity.CanEditProductCategory;
                                entityUpdate.CanNewCustomer = entity.CanNewCustomer;
                                entityUpdate.CanEditCustomer = entity.CanEditCustomer;
                                entityUpdate.CanNewDestination = entity.CanNewDestination;
                                entityUpdate.CanEditDestination = entity.CanEditDestination;
                                entityUpdate.CanNewSource = entity.CanNewSource;
                                entityUpdate.CanEditSource = entity.CanEditSource;
                                entityUpdate.CanNewJob = entity.CanNewJob;
                                entityUpdate.CanEditJob = entity.CanEditJob;
                                entityUpdate.CanNewTruck = entity.CanNewTruck;
                                entityUpdate.CanEditTruck = entity.CanEditTruck;
                                entityUpdate.CanNewTruckConfiguration = entity.CanNewTruckConfiguration;
                                entityUpdate.CanEditTruckConfiguration = entity.CanEditTruckConfiguration;
                                entityUpdate.CanNewVehicleType = entity.CanNewVehicleType;
                                entityUpdate.CanEditVehicleType = entity.CanEditVehicleType;
                                entityUpdate.CanEditWeighman = entity.CanEditWeighman;
                                entityUpdate.CanNewDriver = entity.CanNewDriver;
                                entityUpdate.CanEditDriver = entity.CanEditDriver;
                                entityUpdate.CanNewTransaction = entity.CanNewTransaction;
                                entityUpdate.CanEditTransaction = entity.CanEditTransaction;
                                entityUpdate.CanNewRole = entity.CanNewRole;
                                entityUpdate.CanEditRole = entity.CanEditRole;
                                entityUpdate.CanReportProduct = entity.CanReportProduct;
                                entityUpdate.CanReportProductCategory = entity.CanReportProductCategory;
                                entityUpdate.CanReportCustomer = entity.CanReportCustomer;
                                entityUpdate.CanReportDestination = entity.CanReportDestination;
                                entityUpdate.CanReportSource = entity.CanReportSource;
                                entityUpdate.CanReportJob = entity.CanReportJob;
                                entityUpdate.CanReportTruck = entity.CanReportTruck;
                                entityUpdate.CanReportTruckConfiguration = entity.CanReportTruckConfiguration;
                                entityUpdate.CanReportVehicleType = entity.CanReportVehicleType;
                                entityUpdate.CanReportWeighman = entity.CanReportWeighman;
                                entityUpdate.CanReportDriver = entity.CanReportDriver;
                                entityUpdate.CanReportTransaction = entity.CanReportTransaction;
                                entityUpdate.CanReportRole = entity.CanReportRole;

                                entityUpdate.CanDeleteJob = entity.CanDeleteJob;
                                entityUpdate.CanDeleteProductCategory = entity.CanDeleteProductCategory;
                                entityUpdate.CanDeleteDestination = entity.CanDeleteDestination;
                                entityUpdate.CanDeleteTruck = entity.CanDeleteTruck;
                                entityUpdate.CanDeleteVehicleType = entity.CanDeleteVehicleType;
                                entityUpdate.CanDeleteDriver = entity.CanDeleteDriver;
                                entityUpdate.CanDeleteRole = entity.CanDeleteRole;
                                entityUpdate.CanDeleteProduct = entity.CanDeleteProduct;
                                entityUpdate.CanDeleteCustomer = entity.CanDeleteCustomer;
                                entityUpdate.CanDeleteSource = entity.CanDeleteSource;
                                entityUpdate.CanDeleteTruckConfiguration = entity.CanDeleteTruckConfiguration;
                                entityUpdate.CanDeleteWeighman = entity.CanDeleteWeighman;
                                entityUpdate.CanDeleteTransaction = entity.CanDeleteTransaction;

                                entityUpdate.CanViewPrintEventLog = entity.CanViewPrintEventLog;
                                entityUpdate.CanUseExportWizard = entity.CanUseExportWizard;

                                entityUpdate.CanNewSite = entity.CanNewSite;
                                entityUpdate.CanEditSite = entity.CanEditSite;
                                entityUpdate.CanDeleteSite = entity.CanDeleteSite;
                                entityUpdate.CanReportSite = entity.CanReportSite;

                                entityUpdate.CanNewOffence = entity.CanNewOffence;
                                entityUpdate.CanEditOffence = entity.CanEditOffence;
                                entityUpdate.CanDeleteOffence = entity.CanDeleteOffence;
                                entityUpdate.CanReportOffence = entity.CanReportOffence;
                                entityUpdate.CanViewFirstWeigh = entity.CanViewFirstWeigh;
                                entityUpdate.CanDeleteFirstWeigh = entity.CanDeleteFirstWeigh;
                                entityUpdate.CanLookupDocketAddSignature = entity.CanLookupDocketAddSignature;
                                entityUpdate.CanLookupDocketUpdSignature = entity.CanLookupDocketUpdSignature;

                                if (TryUpdateModel(entityUpdate, "",
                                         new string[] { "Name",
                                                          "CanNewProduct", "CanEditProduct", "CanNewProductCategory", "CanEditProductCategory", "CanNewCustomer", "CanEditCustomer", "CanNewDestination", "CanEditDestination", "CanNewSource", "CanEditSource",
                                                          "CanNewJob", "CanEditJob", "CanNewTruck", "CanEditTruck", "CanNewTruckConfiguration", "CanEditTruckConfiguration", "CanNewVehicleType", "CanEditVehicleType", "CanNewWeighman", "CanEditWeighman",
                                                          "CanNewDriver", "CanEditDriver", "CanNewTransaction", "CanEditTransaction","CanNewRole","CanEditRole",
                                                          "CanReportProduct", "CanReportProductCategory","CanReportCustomer","CanReportDestination","CanReportSource",
                                                          "CanReportJob","CanReportTruck","CanReportTruckConfiguration","CanReportVehicleType","CanReportWeighman",
                                                          "CanReportDriver","CanReportTransaction","CanReportRole","CanDeleteJob","CanDeleteProductCategory","CanDeleteDestination","CanDeleteTruck","CanDeleteVehicleType","CanDeleteDriver","CanDeleteRole","CanDeleteProduct",
                                                          "CanDeleteCustomer","CanDeleteSource","CanDeleteTruckConfiguration","CanDeleteWeighman","CanDeleteTransaction","CanViewPrintEventLog","CanUseExportWizard","CanNewSite","CanEditSite","CanDeleteSite","CanReportSite",
                                                          "CanNewOffence","CanEditOffence","CanDeleteOffence","CanReportOffence","CanViewFirstWeigh","CanDeleteFirstWeigh","CanLookupDocketAddSignature","CanLookupDocketUpdSignature"
                                         }))

                                    db.SaveChanges();


                                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                                return RedirectToAction("Edit/" + entity.ID.ToString());
                            }
                        }
                        else
                        {
                            ModelState.AddModelError("Name", "Role already exists");
                            return View(entity);
                        }
                    }



                    if (ModelState.IsValid)
                    {
                        db.Entry(entity).State = EntityState.Modified;

                        db.SaveChanges();
                        TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                        return RedirectToAction("Edit/" + entity.ID.ToString());
                    }
                }
                catch (RetryLimitExceededException)
                {
                    //Log the error (uncomment dex variable name and add a line here to write a log.
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }
            return View(entity);
        }

        /// <summary>
        /// Navigate to Delete page from the grid delete action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Weighman/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewRole;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditRole;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteRole;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Roles.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Remove role from the db
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        // POST: Weighman/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteRole")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewRole;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditRole;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteRole;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");
            try
            {
                entity = db.Roles.Find(id);
                db.Roles.Remove(entity);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This role " + entity.Name + " is being referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }
        
        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
