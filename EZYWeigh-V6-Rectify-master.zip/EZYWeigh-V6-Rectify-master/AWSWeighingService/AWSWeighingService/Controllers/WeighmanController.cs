﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using PagedList;
using System.Data.Entity.Infrastructure;
using AWSWeighingService.ViewModels;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    
    public class WeighmanController : EntityController<Weighman>
    {
        /// <summary>
        /// Here get the list of weighmans based on the filters
        /// Renders the index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="role"></param>
        /// <param name="state"></param>
        /// <param name="suburb"></param>
        /// <param name="site"></param>
        /// <param name="mobile"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        // GET: Weighman
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string role, string state, string suburb, string site, string mobile, string status)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewWeighman;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditWeighman;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteWeighman;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Operators");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.RoleSortParm = (sortOrder == "Role" ? "Role_Desc" : "Role");

            ViewBag.SuburbSortParm = (sortOrder == "Suburb" ? "Suburb_Desc" : "Suburb");
            ViewBag.StateSortParm = (sortOrder == "State" ? "State_Desc" : "State");
            ViewBag.PostcodeSortParm = (sortOrder == "Postcode" ? "Postcode_Desc" : "Postcode");
            ViewBag.CountrySortParm = (sortOrder == "Country" ? "Country_Desc" : "Country");
            ViewBag.PhoneSortParm = (sortOrder == "Phone" ? "Phone_Desc" : "Phone");
            ViewBag.MobileSortParm = (sortOrder == "Mobile" ? "Mobile_Desc" : "Mobile");
            ViewBag.EmailSortParm = (sortOrder == "Email" ? "Email_Desc" : "Email");

            entities = from e in db.Weighmen select e;


            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.Weighmen == null)
                {
                    entities = from e in db.Weighmen where e.Name == CoreConstants.NA select e;
                }
                else
                {
                    entities = logOnSite.Weighmen.AsQueryable<Weighman>();
                }
            }

            entities = entities.Where(w => w.IsAWSSupportUser != true);


            //Filters

            ViewBag.States = Constants.AUS_STATES.ToList();
            ViewBag.Suburbs = db.Weighmen.Where(e => e.Suburb != null).GroupBy(r => r.Suburb).Select(group => group.Key).ToList();
            ViewBag.Sites = db.Sites.Where(s => s.ID > 1).ToList();

            ViewBag.Roles = db.Roles.Where(r => r.IsAWSSupportRole != true).OrderBy(e => e.Name).ToList();


            //By default load the active weighman
            status = status ?? "false";

            ViewBag.name = name;
            ViewBag.role = role;
            ViewBag.state = state;
            ViewBag.suburb = suburb;
            ViewBag.mobile = mobile;
            ViewBag.status = status;
            ViewBag.site = site;

            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!String.IsNullOrEmpty(role))
            {
                int roleId = int.Parse(role);
                entities = entities.Where(e => e.RoleID == roleId);
            }

            if (!String.IsNullOrEmpty(role))
            {
                int roleId = int.Parse(role);
                entities = entities.Where(e => e.RoleID == roleId);
            }

            if (!string.IsNullOrEmpty(site) && site != "All")
            {
                int siteId = int.Parse(site);
                entities = entities.Where(s => s.Sites.Any(st => st.ID == siteId));
            }

            if (!String.IsNullOrEmpty(state) && state != "All")
            {
                entities = entities.Where(e => e.State.ToUpper().Contains(state.ToUpper()));
            }

            if (!String.IsNullOrEmpty(suburb) && suburb != "All")
            {
                entities = entities.Where(e => e.Suburb.ToUpper().Contains(suburb.ToUpper()));
            }

            if (!String.IsNullOrEmpty(status) && status != "All")
            {
                var statusId = bool.Parse(status);
                entities = entities.Where(e => e.IsDeleted == statusId);
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Role_Desc":
                    entities = entities.OrderByDescending(e => e.Role.Name);
                    break;

                case "Suburb":
                    entities = entities.OrderBy(e => e.Suburb);
                    break;
                case "Suburb_Desc":
                    entities = entities.OrderByDescending(e => e.Suburb);
                    break;
                case "State":
                    entities = entities.OrderBy(e => e.State);
                    break;
                case "State_Desc":
                    entities = entities.OrderByDescending(e => e.State);
                    break;
                case "Postcode":
                    entities = entities.OrderBy(e => e.Postcode);
                    break;
                case "Postcode_Desc":
                    entities = entities.OrderByDescending(e => e.Postcode);
                    break;
                case "Country":
                    entities = entities.OrderBy(e => e.Country);
                    break;
                case "Country_Desc":
                    entities = entities.OrderByDescending(e => e.Country);
                    break;
                case "Phone":
                    entities = entities.OrderBy(e => e.Phone);
                    break;
                case "Phone_Desc":
                    entities = entities.OrderByDescending(e => e.Phone);
                    break;
                case "Mobile":
                    entities = entities.OrderBy(e => e.Mobile);
                    break;
                case "Mobile_Desc":
                    entities = entities.OrderByDescending(e => e.Mobile);
                    break;
                case "Email":
                    entities = entities.OrderBy(e => e.Email);
                    break;
                case "Email_Desc":
                    entities = entities.OrderByDescending(e => e.Email);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Here get the details of the weighman based on the id
        /// Renders Details page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Weighman/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanEdit = (Session["Role"] as Role).CanEditWeighman;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = new Weighman { Name = "Connection Failed! Retry later." };

            try
            {
                entity = db.Weighmen.Include(e => e.Sites).Where(e => e.ID == id).Single();
                if (entity == null)
                {
                    return HttpNotFound();
                }

            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(entity);
        }

        /// <summary>
        /// Here it renders the creat page - for create a new weighman
        /// </summary>
        /// <returns></returns>
        // GET: Weighman/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewWeighman;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditWeighman;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteWeighman;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);
            ViewBag.RoleID = new SelectList(db.Roles.Where(r => r.IsAWSSupportRole != true).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            entity = new Weighman() { };
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

            var centralSite = db.Sites.Find(1);
            int siteNoOfUsersAllowed = centralSite.NoOfUsersAllowed;
            int existingUsersCount = db.Weighmen.Where(w => w.IsAWSSupportUser != true).Count();
            if (existingUsersCount >= siteNoOfUsersAllowed)
            {
                TempData["UserMessage"] = "Exceeds maximum site users under licence. Contact Weigh-More Solutions Sales Team if an Increase is Required at: sales@Qweigh-more.com.au";
                return RedirectToAction("Index");
            }

            return View();
        }

        /// <summary>
        /// Here save the new weighman to the weighman table
        /// Renders the edit page
        /// </summary>
        /// <param name="weighman"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Weighman/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        // public ActionResult Create([Bind(Include = "ID,Name,Password,ConfirmPassword,IsAdmin,DefaultLogon,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Contact,Email,CanNewProduct,CanEditProduct,CanNewProductCategory,CanEditProductCategory,CanNewCustomer,CanEditCustomer,CanNewDestination,CanEditDestination,CanNewSource,CanEditSource,CanNewJob,CanEditJob,CanNewTruck,CanEditTruck,CanNewTruckConfiguration,CanEditTruckConfiguration,CanNewVehicleType,CanEditVehicleType,CanNewWeighman,CanEditWeighman,CanNewDriver,CanEditDriver,CanNewTransaction,CanEditTransaction,RoleID")] Weighman weighman, string[] selectedSites)
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewWeighman")]
        public ActionResult Create([Bind(Include = "ID,RoleID,Name,Password,IsAdmin,DefaultLogon,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Contact,Email")] Weighman weighman, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewWeighman;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditWeighman;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteWeighman;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            entity = new Weighman() { };
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            if (!logOnSiteIsCentral) // not central site
            {
                ViewBag.IsCentralSite = false;
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
                weighman.SiteCreated = true;
            }

            if (selectedSites != null)
            {
                weighman.Sites = new List<Site>();
                foreach (var site in selectedSites)
                {
                    var siteToAdd = db.Sites.Find(int.Parse(site));
                    weighman.Sites.Add(siteToAdd);
                }
                List<AssignedSiteData> siteData = GetEntityAssignedSiteData(db, weighman.Sites);
                ViewBag.Sites = siteData;
            }

            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, weighman.State);
            ViewBag.RoleID = new SelectList(db.Roles.Where(r => r.IsAWSSupportRole != true).OrderBy(e => e.Name), "ID", "Name", weighman.RoleID);

            var weighmanExist = db.Weighmen.FirstOrDefault(e => e.Name == weighman.Name);
            if (weighmanExist != null)
            {
                ModelState.AddModelError("Name", "Weighman already exists");
                return View(weighman);
            }
            if (ModelState.IsValid)
            {
                weighman.Password = weighman.Password.Encrypt();
                db.Weighmen.Add(weighman);

                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (selectedSites != null)
                {
                    foreach (var site in selectedSites)
                    {
                        var siteToAdd = db.Sites.Find(int.Parse(site));
                        if (siteToAdd != null)
                        {
                            WriteReplicationLog(siteToAdd.ID, weighman.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                        }

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(weighman.Name + " created successfully! ");

                if (weighman.DefaultLogon)
                {
                    foreach (var weiman in db.Weighmen.Where(w => w.ID != weighman.ID))
                    {
                        weiman.DefaultLogon = false;
                    }
                }
                db.SaveChanges();


                return RedirectToAction("Index");
            }

            return View(weighman);
        }

        /// <summary>
        /// Here get the deatils of the weighman based on the id
        /// Renders edit page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Weighman/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewWeighman;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditWeighman;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteWeighman;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = new Weighman { Name = "Connection Failed! Retry later." };

            try
            {
                entity = db.Weighmen.Include(e => e.Sites).Where(e => e.ID == id).Single();
                entity.Password = entity.Password.Decrypt();
                if (entity == null)
                {
                    return HttpNotFound();
                }

                ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
                ViewBag.RoleID = new SelectList(db.Roles.Where(r => r.IsAWSSupportRole != true).OrderBy(e => e.Name), "ID", "Name", entity.RoleID);
                ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(entity);

        }

        /// <summary>
        /// Here update the details of the weighman in the weighman table
        /// Renders index page
        /// </summary>
        /// <param name="id"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Weighman/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditWeighman")]
        //public ActionResult Edit([Bind(Include = "ID,Name,Password,ConfirmPassword,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Contact,Email")] Weighman weighman)
        public ActionResult Edit(int? id, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewWeighman;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditWeighman;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteWeighman;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");
            entity = new Weighman() { };
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            if (!logOnSiteIsCentral) // not central site
            {
                ViewBag.IsCentralSite = false;
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
            }

            entity = db.Weighmen.Include(e => e.Sites).Where(e => e.ID == id).Single();
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);
            ViewBag.RoleID = new SelectList(db.Roles.Where(r => r.IsAWSSupportRole != true).OrderBy(e => e.Name), "ID", "Name", entity.RoleID);

            if (TryUpdateModel(entity, "", new string[] { "RoleID", "Name", "Password", "IsAdmin", "DefaultLogon", "Description", "Address1", "Address2", "Suburb", "State", "Postcode", "Country", "Phone", "Mobile", "Contact", "Email" }))
            {
                try
                {
                    var weighmanExist = db.Weighmen.FirstOrDefault(e => e.Name == entity.Name);
                    if (weighmanExist != null)
                    {
                        if (weighmanExist.ID == entity.ID)
                        {
                            if (ModelState.IsValid)
                            {
                                var entityUpdate = db.Weighmen.Find(entity.ID);
                                entityUpdate.Name = entity.Name.ToUpper();
                                entityUpdate.Password = entity.Password.Encrypt();
                                entityUpdate.Address1 = entity.Address1;
                                entityUpdate.Address2 = entity.Address2;
                                entityUpdate.Suburb = entity.Suburb;
                                entityUpdate.State = entity.State;
                                entityUpdate.Postcode = entity.Postcode;
                                entityUpdate.Country = entity.Country;
                                entityUpdate.Phone = entity.Phone;
                                entityUpdate.Mobile = entity.Mobile;
                                entityUpdate.Email = entity.Email;
                                entityUpdate.Description = entity.Description;
                                entityUpdate.RoleID = entity.RoleID;
                                entityUpdate.IsAdmin = entity.IsAdmin;
                                entityUpdate.DefaultLogon = entity.DefaultLogon;

                                UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
                                if (TryUpdateModel(entityUpdate, "",
                                         new string[] { "RoleID", "Name", "Password", "IsAdmin", "DefaultLogon", "Description", "Address1", "Address2", "Suburb", "State", "Postcode", "Country", "Phone", "Mobile", "Contact", "Email" }))

                                    entityUpdate.Password = entity.Password.Encrypt();
                                db.SaveChanges();


                                //Adding to the ReplicationLogItem for data sync
                                if (selectedSites != null)
                                {
                                    foreach (var site in selectedSites)
                                    {
                                        var siteToAdd = db.Sites.Find(int.Parse(site));
                                        if (siteToAdd != null)
                                        {
                                            WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                        }
                                    }
                                }
                                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                                return RedirectToAction("Index");
                            }
                        }
                        else
                        {
                            ModelState.AddModelError("Name", "Operator already exists");
                            return View(entity);
                        }
                    }


                    if (ModelState.IsValid)
                    {
                        UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
                        entity.Password = entity.Password.Encrypt();
                        db.Entry(entity).State = EntityState.Modified;

                        if (entity.DefaultLogon)
                        {
                            foreach (var weighman in db.Weighmen.Where(w => w.ID != entity.ID))
                            {
                                weighman.DefaultLogon = false;
                            }
                        }

                        db.SaveChanges();

                        //Adding to the ReplicationLogItem for data sync
                        if (selectedSites != null)
                        {
                            foreach (var site in selectedSites)
                            {
                                var siteToAdd = db.Sites.Find(int.Parse(site));
                                if (siteToAdd != null)
                                {
                                    WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                }
                            }
                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                        return RedirectToAction("Index");
                    }
                }
                catch (RetryLimitExceededException)
                {
                    //Log the error (uncomment dex variable name and add a line here to write a log.
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }
            UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
            return View(entity);
        }

        /// <summary>
        /// Here get the details of the weighman for delete
        /// Renders Delete page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        // GET: Weighman/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewWeighman;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditWeighman;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteWeighman;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Weighmen.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Here Remove the weighman from the weighman table
        /// Renders Index page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Weighman/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteWeighman")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewWeighman;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditWeighman;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteWeighman;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");
            try
            {
                entity = db.Weighmen.Find(id);
                entity.IsDeleted = true;
                db.Entry(entity).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
            }
            catch
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This weighman " + entity.Name + " is being referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }

        
        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
