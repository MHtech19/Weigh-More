﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using iText.Html2pdf;
using iText.IO.Font;
using iText.IO.Image;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Draw;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.File;
using Newtonsoft.Json;
using PagedList;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Hosting;
using System.Web.Http;
using System.Web.Mvc;
using WeighBridge.Core.Device;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using Image = iText.Layout.Element.Image;

namespace AWSWeighingService.Controllers
{
    class XeroAuths
    {
        public XeroAuth[] xeroAuth { get; set; }
    }

    class XeroAuth
    {
        public string Company { get; set; }
        public int SiteID { get; set; }
        public string SiteName { get; set; }
        public string AppKey { get; set; }
        public string CertificateFile { get; set; }
        public string Password { get; set; }
        public string ConsumerKey { get; set; }
        public string ConsumerSecret { get; set; }
        public string RunType { get; set; }
        public string StorageConnectionString { get; set; }
    }

    public class DocketLookupController : EntityController<Transaction>
    {
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string docketnum, string regno, string transactiondate)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Docket Lookup");
            if (string.IsNullOrEmpty(docketnum) && string.IsNullOrEmpty(regno) && string.IsNullOrEmpty(transactiondate))
                return View();

            else
            {
                int siteno = 0;
                docketnum = string.IsNullOrEmpty(docketnum) ? string.Empty : docketnum;
                regno = string.IsNullOrEmpty(regno) ? string.Empty : regno;
                transactiondate = string.IsNullOrEmpty(transactiondate) ? string.Empty : transactiondate;
                TempData["docketnum"] = docketnum;
                TempData["regno"] = regno;
                TempData["transactiondate"] = transactiondate;

                entities = from e in db.Transactions select e;
                if (!string.IsNullOrEmpty(docketnum))
                {
                    entities = entities.Where(x => x.Docket == docketnum);
                }

                if (!string.IsNullOrEmpty(regno))
                {
                    //entities = entities.Where(x => x.Docket == docketnum).Where(x => x.Registration1.Contains(regno) || x.Registration2.Contains(regno) || x.Registration3.Contains(regno));
                    entities = entities.Where(x => x.Registration1.ToLower().Contains(regno.ToLower()) || x.Registration2.ToLower().Contains(regno.ToLower()) || x.Registration3.ToLower().Contains(regno.ToLower()));
                }

                if (!string.IsNullOrEmpty(transactiondate))
                {
                    //DateTime TransDatetime = Convert.ToDateTime(transactiondate);
                    //if (string.IsNullOrEmpty(docketnum) && string.IsNullOrEmpty(regno))
                    //    entities = entities.Where(x => DbFunctions.TruncateTime(x.TransactionDate) == DbFunctions.TruncateTime(TransDatetime));
                    //else
                    //    entities = (entities.Where(x => x.Docket == docketnum).Where(x => x.Registration1.Contains(regno) || x.Registration2.Contains(regno) || x.Registration3.Contains(regno))).Where(x => DbFunctions.TruncateTime(x.TransactionDate) == DbFunctions.TruncateTime(TransDatetime));
                    DateTime TransDatetime = Convert.ToDateTime(transactiondate);
                    entities = entities.Where(x => DbFunctions.TruncateTime(x.TransactionDate) == DbFunctions.TruncateTime(TransDatetime));
                }
                if (entities == null || entities.Count() == 0)
                {
                    TempData["UserMessage"] = ComposeTempDisplayMessage("No records are found!");
                    return View();
                }
                if (entities.Count() == 1)
                {
                    //if (!string.IsNullOrEmpty(docketnum))
                    //{
                    foreach (Transaction tran in entities)
                    {
                        docketnum = tran.Docket;
                        siteno = tran.SiteID;
                    }
                    //  }
                    return RedirectToAction("Details", "DocketLookup", new { id = docketnum, siteid = siteno });
                }
                else
                {
                    pageNumber = (page ?? 1);

                    pageSize = filterPageSize ?? pageSize;

                    ViewBag.filterPageSize = pageSize;
                    try
                    {
                        return View(entities.OrderBy(e => e.TransactionDate).ToPagedList(pageNumber, pageSize));
                    }

                    catch (RetryLimitExceededException)
                    {
                        //Log the error (uncomment dex variable name and add a line here to write a log.
                        ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                        return HttpNotFound();
                    }

                }
            }
        }

        [SessionAccess]
        public ActionResult Details(string id, int siteid)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Docket Details");
            ViewBag.CanLookupDocketAddSignature = (Session["Role"] as AWSWeighingService.Models.Role).CanLookupDocketAddSignature;
            ViewBag.CanLookupDocketUpdSignature = (Session["Role"] as AWSWeighingService.Models.Role).CanLookupDocketUpdSignature;

            string regno = (string)TempData["regno"] is null ? string.Empty : (string)TempData["regno"];
            string TransDate = (string)TempData["transactiondate"] is null ? string.Empty : (string)TempData["regtransactiondateno"];
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Transactions.Where(x => x.Docket == id && x.SiteID == siteid).FirstOrDefault();

            if (entity == null)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage(id + " Invalid docket number!");
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.IsImage = null;
                ViewBag.ImageData = null;
                Signature objSig = db.Signatures.Where(x => x.TransactionID == entity.ID).FirstOrDefault();
                if (objSig != null)
                {
                    string imageBase64Data = Convert.ToBase64String(objSig.Content);
                    string imageDataURL = string.Format("data:image/png;base64,{0}", imageBase64Data);
                    ViewBag.ImageData = imageDataURL;
                    ViewBag.IsImage = "true";
                    ViewBag.FirstName = objSig.FirstName;
                    ViewBag.LastName = objSig.LastName;
                }

                LoadTransaction(entity);

                AWSConfiguration SysConfig = new AWSConfiguration();
                PublicWeigh.Config.Lib.CompanyProfile objCompanyProfile = new PublicWeigh.Config.Lib.CompanyProfile();
                objCompanyProfile.CountedItemAs = "m3";
                SysConfig.CompanyProfileSettings = objCompanyProfile;
                PublicWeigh.Config.Lib.Replication objReplication = new PublicWeigh.Config.Lib.Replication();
                objReplication.IsRoundOffCashPaymentToClosest5Cents = false;
                SysConfig.ReplicationSettings = objReplication;
                PublicWeigh.Config.Lib.Ticket objTicket = new PublicWeigh.Config.Lib.Ticket();
                objTicket.PrintVolume = false;
                SysConfig.TicketSettings = objTicket;
                //ObservableCollection<string> list = null;
                //TempData["EntityList"] = ViewBag.CurrentTicket = list = GenerateTicket(entity, SysConfig, true);
                TempData["EntityList"] = GenerateTicket(entity, SysConfig, true);
                ViewBag.CurrentTicket = string.Join(System.Environment.NewLine, ((new List<string>((ObservableCollection<string>)TempData["EntityList"])).ToArray()));
                TempData["TransID"] = entity.ID;
                TempData["FileName"] = entity.Site.Name + "-Docket_" + entity.Docket;
                TempData.Keep("FileName");
                TempData.Keep("EntityList");
                return View(entity);
            }
        }

        [System.Web.Mvc.HttpPost]
        [ValidateInput(false)]
        [SessionAccess]
        [Obsolete]
        public void Save(GeneratePDF data)
        {
            try
            {
                DateTime CaptureDate = DateTime.Now;
                string storageConnectionString = GetStorageConnectionString();
                if (storageConnectionString != "")
                {
                    if (String.IsNullOrEmpty(data.IsImage))
                    {
                        byte[] completedDocument = null;
                        byte[] photo = Convert.FromBase64String(data.Value);
                        string html = data.htmlValue;
                        using (Stream inputImageStream = new MemoryStream(photo, 0, photo.Length, true, true))
                        using (MemoryStream stream = new System.IO.MemoryStream())
                        {
                            PdfWriter writer = new PdfWriter(stream);
                            //Initialize PDF document
                            PdfDocument pdf = new PdfDocument(writer);
                            // pdf.SetDefaultPageSize(new PageSize(PageSize.A4));
                            Document document = new Document(pdf);
                            iText.Layout.Element.Image image = new Image(ImageDataFactory.Create(photo)); ;

                            string root = Server.MapPath("~");
                            string parent = System.IO.Path.GetDirectoryName(root) + "/fonts/Segoe UI.ttf";
                            //Setting styles
                            PdfFont fontCourier = PdfFontFactory.CreateFont(parent);
                            PdfFont bold = PdfFontFactory.CreateFont(FontConstants.HELVETICA_BOLD);
                            iText.Layout.Element.Table transtable = new iText.Layout.Element.Table(3)
                            .SetBorder(Border.NO_BORDER);
                            iText.Layout.Element.Table transtable2 = new iText.Layout.Element.Table(3)
                            .SetBorder(Border.NO_BORDER);
                            Cell transCell1 = new Cell()
                            .SetBorder(Border.NO_BORDER);
                            Cell transCell2 = new Cell()
                            .SetBorder(Border.NO_BORDER);
                            Cell transCell3 = new Cell()
                            .SetBorder(Border.NO_BORDER);
                            Cell transCell4 = new Cell()
                            .SetBorder(Border.NO_BORDER);
                            ObservableCollection<string> Datalist = (ObservableCollection<string>)TempData["EntityList"];
                            foreach (var element in Datalist.Select((value, ai) => new { ai, value }))
                            {
                                Paragraph paragraph = new Paragraph();
                                string[] splitEle = element.value.Split(new[] { ':' }, 2);

                                if (element.ai > 4)
                                {
                                    if (splitEle.Length >= 2)
                                    {
                                        if (string.IsNullOrEmpty(splitEle[0].Trim()))
                                        {
                                            transCell3.Add(new Paragraph("\n").SetFixedLeading(9));
                                            transCell4.Add(new Paragraph("\n").SetFixedLeading(9));

                                        }
                                        else
                                        {
                                            if (Datalist.Any(str => str.Contains("Mixed")))
                                            {
                                                if (splitEle[0].Contains("Amount Due"))
                                                {
                                                    transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold));
                                                    transCell4.Add(new Paragraph(": " + splitEle[1]).SetFixedLeading(9).SetFont(bold));

                                                }
                                                else
                                                {
                                                    transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9));

                                                    if (string.IsNullOrEmpty(splitEle[1].Trim()))
                                                        transCell4.Add(new Paragraph("\n").SetFixedLeading(9));
                                                    else
                                                        transCell4.Add(new Paragraph(": " + splitEle[1]).SetFixedLeading(9));
                                                }
                                            }
                                            else
                                            {
                                                if (splitEle[0].Contains("Amount Due"))
                                                {
                                                    transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold)).SetWidth(50);
                                                    transCell4.Add(new Paragraph(": " + splitEle[1].Trim()).SetFixedLeading(9).SetFont(bold));

                                                }
                                                else
                                                {
                                                    transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9)).SetWidth(50);

                                                    if (string.IsNullOrEmpty(splitEle[1].Trim()))
                                                        transCell4.Add(new Paragraph("\n").SetFixedLeading(9));
                                                    else
                                                        transCell4.Add(new Paragraph(": " + splitEle[1]).SetFixedLeading(9));
                                                }

                                            }
                                        }
                                    }
                                    else
                                    {
                                        string lstElement = splitEle[0];
                                        int count = lstElement.TakeWhile(Char.IsWhiteSpace).Count();
                                        // We create a list:
                                        if (string.IsNullOrEmpty(lstElement.Trim()))
                                        {
                                            transCell3.Add(new Paragraph("\n").SetFixedLeading(9)).SetWidth(100);
                                        }
                                        else
                                        {
                                            if (splitEle[0].ToLower().Contains("tax invoice"))
                                            {
                                                transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold)).SetWidth(100);
                                            }
                                            else
                                            {
                                                if (count > 1)
                                                    transCell3.Add(new Paragraph(splitEle[0]).SetFirstLineIndent(10).SetFixedLeading(9)).SetWidth(100);
                                                else
                                                    transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9)).SetWidth(100);

                                            }
                                        }

                                        transCell4.Add(new Paragraph("\n").SetFixedLeading(9));
                                    }


                                }
                                else
                                {
                                    // We create a list:
                                    if (string.IsNullOrEmpty(splitEle[0].Trim()))
                                    {
                                        transCell1.Add(new Paragraph("\n").SetFixedLeading(9)).SetWidth(100);
                                    }
                                    else
                                    {
                                        if (splitEle[0].ToLower().Contains("tax invoice"))
                                        {
                                            transCell1.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold)).SetWidth(100);
                                        }
                                        else if (element.ai == 2)
                                        {
                                            transCell1.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold).SetFontSize(9)).SetWidth(100);

                                        }
                                        else
                                        {
                                            transCell1.Add(new Paragraph(splitEle[0]).SetFixedLeading(9)).SetWidth(100);

                                        }
                                    }

                                }

                            }
                            //SolidLine line = new SolidLine(1f);
                            //LineSeparator ls = new LineSeparator(line);
                            transCell3.SetBorder(Border.NO_BORDER);
                            //transCell3.Add(new Paragraph("Signature      :").SetFont(fontCourier).SetMarginTop(30));
                            transCell4.SetBorder(Border.NO_BORDER);
                            //transCell4.Add(ls.SetWidth(80).SetMarginTop(40));
                            transtable.AddCell(transCell1.SetRelativePosition(-37, -33, 0, 0));
                            transtable.AddCell(transCell2.SetRelativePosition(-37, -33, 0, 0));
                            transtable2.AddCell(transCell3.SetRelativePosition(-37, -37, 0, 0));
                            transtable2.AddCell(transCell4.SetRelativePosition(-37, -37, 0, 0));

                            SolidLine line = new SolidLine(1f);
                            LineSeparator ls = new LineSeparator(line);
                            iText.Layout.Element.Table sigtable = new iText.Layout.Element.Table(3)
                            .SetBorder(Border.NO_BORDER);

                            Cell sigCell = new Cell()
                            .SetBorder(Border.NO_BORDER)
                            .Add(new Paragraph("Signature       :").SetFont(fontCourier).SetMarginTop(30));
                            Cell sigCell1 = new Cell()
                            .SetBorder(Border.NO_BORDER)
                           .Add(image.SetWidth(80).SetHeight(30).SetMarginTop(10));
                            sigCell1.Add(ls.SetWidth(80));

                            sigCell.Add(new Paragraph("Signed On      :").SetFont(fontCourier));
                            sigCell1.Add(new Paragraph(CaptureDate.ToString("dd/MM/yyyy HH:mm:ss tt")).SetFont(fontCourier).SetMarginTop(2));

                            sigtable.AddCell(sigCell);
                            sigtable.AddCell(sigCell1);

                            using (var pdfWriter = new PdfWriter(stream))
                            {
                                pdfWriter.SetCloseStream(false);
                                using (var document1 = HtmlConverter.ConvertToDocument("", pdfWriter))
                                {
                                    document1.SetTopMargin(0);
                                    document1.Add(transtable);
                                    document1.SetFont(fontCourier);
                                    document1.SetFontSize(8);
                                    document1.Add(transtable2);
                                    document1.SetFont(fontCourier);
                                    document1.SetFontSize(8);
                                    document1.Add(sigtable.SetBorder(Border.NO_BORDER).SetRelativePosition(-37, -37, 0, 0));

                                    document1.Add(new Paragraph("Thank You").SetFont(fontCourier).SetFont(bold).SetMarginTop(20).SetMarginLeft(85).SetRelativePosition(-37, -37, 0, 0));
                                }
                            }
                            var dir = new DirectoryInfo(System.IO.Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "DocketPDFS"));
                            Directory.CreateDirectory(dir.FullName);

                            //string filename = TempData["FileName"].ToString() + ".pdf";
                            completedDocument = stream.ToArray();
                            //using (System.IO.FileStream fs = System.IO.File.Create(System.IO.Path.Combine(dir.FullName, filename)))
                            //{
                            //    fs.Write(completedDocument, 0, completedDocument.Length);
                            //}

                            // Folder where the HelloWorld.png file resides 
                            // string localFolder = System.IO.Path.Combine(dir.FullName, filename);
                            int i = UploadFileinAzure(completedDocument, storageConnectionString);
                            //  System.IO.File.Delete(localFolder);
                        }
                        try
                        {
                            db = (AWSWeighingServiceContext)RouteData.Values["db"];
                            int TransID = (int)TempData["TransID"];
                            Signature objFindSignature = new Signature();
                            objFindSignature = db.Signatures.Where(x => x.TransactionID == TransID).FirstOrDefault();
                            if (objFindSignature == null)
                            {
                                Signature objSignature = new Signature();
                                objSignature.Content = photo;
                                objSignature.TransactionID = TransID;
                                objSignature.FirstName = data.FirstName;
                                objSignature.LastName = data.LastName;
                                objSignature.SignedOn = CaptureDate;
                                db.Signatures.Add(objSignature);
                                int i = db.SaveChanges();
                                RedirectToAction("Index", "DocketLookup", new { docketnum = "", vehicleno = "", transactiondate = "" });
                                if (i > 0)
                                    TempData["UserMessage"] = ComposeTempDisplayMessage(TempData["FileName"].ToString() + " docket saved successfully");
                            }
                            else
                            {
                                TryUpdateModel(objFindSignature, "", new string[] { "ID" });
                                if (string.IsNullOrEmpty(data.IsImage))
                                    objFindSignature.Content = photo;
                                objFindSignature.SignedOn = CaptureDate;
                                objFindSignature.FirstName = data.FirstName;
                                objFindSignature.LastName = data.LastName;
                                int i = db.SaveChanges();
                                if (i > 0)
                                    TempData["UserMessage"] = ComposeTempDisplayMessage(TempData["FileName"].ToString() + " docket updated successfully");
                            }
                        }
                        catch (Exception ex)
                        {
                            TempData["UserMessage"] = ComposeTempDisplayMessage("record not saved in DB! due to some issues.");
                        }
                    }
                    else
                    {
                        TempData["UserMessage"] = ComposeTempDisplayMessage(TempData["FileName"].ToString() + " docket has no changes");
                    }
                }
                else
                {
                    TempData["UserMessage"] = ComposeTempDisplayMessage("Azure Storage storageconnectionstring is not defined. Please check it");

                }
            }
            catch (Exception Ex)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Unable to generate the file! due to file is opened or some other issues.");
            }
        }

        public int UploadFileinAzure(byte[] data, string connectionString)
        {
            CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(connectionString);
            CloudFileClient cloudFileClient = storageAccount.CreateCloudFileClient();
            CloudFileShare cloudFileShare = null;
            CloudFileDirectory fileDirectory = null;
            CloudFile cloudFile = null;

            string shareName = "shareddata";
            string sourceFolder = "dockets";

            cloudFileShare = cloudFileClient.GetShareReference(shareName);
            try
            {
                cloudFileShare.CreateIfNotExistsAsync();
            }
            catch (StorageException exStorage)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Please make sure your storage account has storage file endpoint enabled and specified correctly");
            }
            catch (Exception ex)
            {

            }
            try
            {
                CloudFileDirectory rootDirectory = cloudFileShare.GetRootDirectoryReference();
                if (string.IsNullOrWhiteSpace(sourceFolder))
                {
                    fileDirectory = rootDirectory;
                }
                else
                {
                    fileDirectory = rootDirectory.GetDirectoryReference(sourceFolder);
                    fileDirectory.CreateIfNotExistsAsync();
                }

                // Set a reference to the file.
                cloudFile = fileDirectory.GetFileReference((string)TempData["FileName"]+".pdf");

                using (MemoryStream stream = new MemoryStream())
                {
                    stream.Write(data, 0, data.Length);
                    stream.Seek(0, SeekOrigin.Begin);
                    cloudFile.ServiceClient.DefaultRequestOptions.ParallelOperationThreadCount = 2;
                    cloudFile.UploadFromStream(stream);
                }
            }
            catch (Exception ex)
            {

            }
            return 1;
        }
        //public int UploadFileinAzure(string path, string filename)
        //{
        //    CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString();
        //    CloudFileClient cloudFileClient = storageAccount.CreateCloudFileClient();
        //    CloudFileShare cloudFileShare = null;
        //    CloudFileDirectory fileDirectory = null;
        //    CloudFile cloudFile = null;

        //    string shareName = "shareddata";
        //    string sourceFolder = "dockets";

        //    cloudFileShare = cloudFileClient.GetShareReference(shareName);
        //    try
        //    {
        //        cloudFileShare.CreateIfNotExistsAsync();
        //    }
        //    catch (StorageException exStorage)
        //    {
        //        TempData["UserMessage"] = ComposeTempDisplayMessage("Please make sure your storage account has storage file endpoint enabled and specified correctly");
        //    }
        //    catch (Exception ex)
        //    {

        //    }



        //    //***** Create a directory on the file share *****//
        //    CloudFileDirectory rootDirectory = cloudFileShare.GetRootDirectoryReference();
        //    if (string.IsNullOrWhiteSpace(sourceFolder))
        //    {
        //        fileDirectory = rootDirectory;
        //    }
        //    else
        //    {
        //        fileDirectory = rootDirectory.GetDirectoryReference(sourceFolder);
        //        fileDirectory.CreateIfNotExistsAsync();
        //    }

        //    // Set a reference to the file.
        //    cloudFile = fileDirectory.GetFileReference(filename);

        //    // Upload a file to the share.
        //    Console.WriteLine("Uploading file {0} to share", filename);

        //    // Set up the name and path of the local file.
        //    string sourceFile = path;
        //    if (System.IO.File.Exists(sourceFile))
        //    {
        //        // Upload from the local file to the file share in azure.
        //        cloudFile.UploadFromFileAsync(sourceFile).Wait();
        //        Console.WriteLine("    Successfully uploaded file to share.");
        //    }
        //    else
        //    {
        //        Console.WriteLine("File not found, so not uploaded.");
        //    }
        //    return 1;
        //}

        public int DownloadFileinAzure(string downloadfilepath, string filename)
        {
            CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(GetStorageConnectionString());
            CloudFileClient cloudFileClient = storageAccount.CreateCloudFileClient();
            CloudFileShare cloudFileShare = null;
            CloudFileDirectory fileDirectory = null;
            CloudFile cloudFile = null;

            string shareName = "shareddata";
            string sourceFolder = "dockets";

            cloudFileShare = cloudFileClient.GetShareReference(shareName);
            try
            {
                cloudFileShare.CreateIfNotExistsAsync();
            }
            catch (StorageException exStorage)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Storage Acccount has caught some issue!" + exStorage);
            }
            catch (Exception ex)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Application has caught some issue!" + ex);

            }
            //***** Create a directory on the file share *****//
            CloudFileDirectory rootDirectory = cloudFileShare.GetRootDirectoryReference();
            if (string.IsNullOrWhiteSpace(sourceFolder))
            {
                fileDirectory = rootDirectory;
            }
            else
            {
                fileDirectory = rootDirectory.GetDirectoryReference(sourceFolder);
                fileDirectory.CreateIfNotExistsAsync();
            }

            // Set a reference to the file.
            cloudFile = fileDirectory.GetFileReference(filename);
            if (!Directory.Exists(downloadfilepath))
            {
                Directory.CreateDirectory(downloadfilepath);
            }

            cloudFile.DownloadToFileAsync(System.IO.Path.Combine(downloadfilepath, filename), FileMode.OpenOrCreate);
            Console.WriteLine("    Successfully downloaded file from share to local temp folder.");
            return 1;
        }



        #region PrintTicketGeneration
        public ObservableCollection<string> GenerateTicket(Transaction currentTransaction, AWSConfiguration sysConfig, bool isReprint)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            ObservableCollection<string> generatedTicket = new ObservableCollection<string>();

            if (isReprint)
            {
                generatedTicket.AddRange(currentTransaction.GenerateTicket(sysConfig, isReprint));
                return generatedTicket;
            }

            if (currentTransaction.LoadType == CoreConstants.Load_First)
            {
                var currentFirstWeigh = new FirstWeigh(currentTransaction);
                generatedTicket.AddRange(currentFirstWeigh.GenerateTicket(currentTransaction, sysConfig));

                return generatedTicket;
            }

            if (currentTransaction.LoadType == CoreConstants.Load_Standard)
            {
                foreach (var p in currentTransaction.SelectedMixedProducts)
                {
                    p.SetCurrentCharges(currentTransaction, null, db.VehicleProductPrices.ToList());
                }


            }
            else if (currentTransaction.LoadType == CoreConstants.Load_Mixed)
            {
                foreach (var p in currentTransaction.SelectedMixedProducts)
                {
                    p.SetCurrentCharges(currentTransaction, db.JobProductPrices.ToList(), null); //(currentTransaction,  null, GlobalStaticUtilities.VehicleProductPrices);
                }

            }
            else
            {
                currentTransaction.Product.CurrentAmount = currentTransaction.Net;
                currentTransaction.Product.SetCurrentCharges(currentTransaction, db.JobProductPrices.ToList(), null);
                currentTransaction.Price = currentTransaction.Product.CurrentPrice;
                currentTransaction.GST = currentTransaction.Product.CurrentGST;
                currentTransaction.EPA = currentTransaction.Product.CurrentEPA;
                currentTransaction.CartageCharge = currentTransaction.Product.CurrentCartage;
                currentTransaction.CartageGST = currentTransaction.Product.CurrentCartageGST;
                currentTransaction.TotalCost = currentTransaction.Product.CurrentTotalCost;
                currentTransaction.TranCost = currentTransaction.Product.CurrentTranCost;
                currentTransaction.Royalty = currentTransaction.Product.CurrentRoyalty;
                currentTransaction.ProductRoyalty = currentTransaction.Product.Royalty;
                currentTransaction.Count = currentTransaction.Product.CurrentCount;
                currentTransaction.CustomerDiscount = currentTransaction.Product.CurrentCustomerDiscount;



                if (currentTransaction.Job != null && currentTransaction.JobID != CoreConstants.NA_ID && currentTransaction.Job.JobTonnesOrdered > 0 && sysConfig.TicketSettings.PrintJobTonnage)
                {
                    try
                    {
                        if (sysConfig.WeighBridgeSettings.OfflineMode.Value)
                        {
                            currentTransaction.Product.CurrentPrice = -1;
                            currentTransaction.Product.CurrentGST = -1;
                            currentTransaction.Product.CurrentEPA = -1;
                        }
                        else
                        {
                            JobTonnage jobTonnage = GetJobTonnage(currentTransaction.JobID);
                            if (jobTonnage != null)
                            {
                                currentTransaction.Product.CurrentGST = jobTonnage.TonnesOrdered;
                                currentTransaction.Product.CurrentPrice = jobTonnage.TonnesLeft - currentTransaction.Net;
                                currentTransaction.Product.CurrentEPA = jobTonnage.TonnesProcessed + currentTransaction.Net;
                            }
                            else
                            {
                                currentTransaction.Product.CurrentPrice = 0M;
                                currentTransaction.Product.CurrentGST = 0M;
                                currentTransaction.Product.CurrentEPA = 0M;
                            }
                        }
                    }
                    catch (Exception ecp)
                    {
                        currentTransaction.Product.CurrentPrice = -1;
                        currentTransaction.Product.CurrentGST = -1;
                        currentTransaction.Product.CurrentEPA = -1;
                        LogWMSSystemExceptionEvent(ecp);
                    }

                }

            }

            //   }

            generatedTicket.AddRange(currentTransaction.GenerateTicket(sysConfig, isReprint));
            return generatedTicket;
        }

        public void LogWMSSystemExceptionEvent(Exception ecp)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            string errMsg = ecp.Message.ToString();
            TempData["UserMessage"] = ComposeTempDisplayMessage(errMsg);

            WMSEventLog eventLog = new WMSEventLog
            {
                Name = "Web System Error",
                EventDateTime = DateTime.Now,
                DateStamp = DateTime.Now.ToString("dd/MM/yyyy"),
                WeighmanID = logOnWeighman.ID,
                SiteID = logOnSite.ID,
                Comment = errMsg + " from " + ecp.StackTrace,
                EventType = (int)WMSEventTypes.System,
                WeightPass = 0,
            };
            db.WMSEventLogs.Add(eventLog);
        }
        public JobTonnage GetJobTonnage(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            Job job = db.Jobs.Find(id);

            if (job == null)
            {
                return null;
            }

            JobTonnage jobTonnage = new JobTonnage()
            {
                TodayTotal = 0M,
                MonthlyTotal = 0M,
                RunningTotal = 0M,

                TonnesLeft = 0M,
                TonnesOrdered = 0M,
                TonnesProcessed = 0M
            };


            //old code end
            if (job != null)
            {
                jobTonnage.TonnesOrdered = job.JobTonnesOrdered;
                jobTonnage.TonnesProcessed = job.JobTonnesRunningTotal;
                jobTonnage.TonnesLeft = job.JobTonnesOrdered - job.JobTonnesRunningTotal;
            }

            return jobTonnage;
        }

        private void LoadTransaction(Transaction transaction)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            LoadData(transaction);
            if ((transaction.LoadType == CoreConstants.Load_Mixed) || (transaction.LoadType == CoreConstants.Load_Standard))
            {
                var multiTransactions = db.Transactions.Where(t => t.Docket == transaction.Docket).ToList();

                transaction.SelectedMixedProducts = new List<Product>();
                foreach (var tran in multiTransactions)
                {
                    var p = db.Products.FirstOrDefault(e => e.ID == tran.ProductID);
                    if (p != null)
                    {
                        p.CurrentAmount = tran.Net;

                        p.CurrentPrice = tran.Price;
                        p.CurrentGST = tran.GST;
                        p.CurrentEPA = tran.EPA;
                        p.CurrentTotalCost = tran.TotalCost;

                        transaction.SelectedMixedProducts.Add(p);
                    }

                }
            }
        }

        public void LoadData(Transaction transaction)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            if (transaction == null) return;

            var job = db.Jobs.FirstOrDefault(e => e.ID == transaction.JobID);
            if (job != null)
            {
                transaction.Job = job;
            }
            else
            {
                transaction.Job = db.Jobs.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Product = db.Products.FirstOrDefault(e => e.ID == transaction.ProductID);
            if (Product != null)
            {
                transaction.Product = Product;
            }
            else
            {
                transaction.Product = db.Products.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var ProductCategory = db.ProductCategories.FirstOrDefault(e => e.ID == transaction.ProductCategoryID);
            if (ProductCategory != null)
            {
                transaction.ProductCategory = ProductCategory;
            }
            else
            {
                transaction.ProductCategory = db.ProductCategories.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Customer = db.Customers.FirstOrDefault(e => e.ID == transaction.CustomerID);
            if (Customer != null)
            {
                transaction.Customer = Customer;
            }
            else
            {
                transaction.Customer = db.Customers.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Destination = db.Destinations.FirstOrDefault(e => e.ID == transaction.DestinationID);
            if (Destination != null)
            {
                transaction.Destination = Destination;
            }
            else
            {
                transaction.Destination = db.Destinations.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Source = db.Sources.FirstOrDefault(e => e.ID == transaction.SourceID);
            if (Source != null)
            {
                transaction.Source = Source;
            }
            else
            {
                transaction.Source = db.Sources.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Vehicle = db.Vehicles.FirstOrDefault(e => e.ID == transaction.VehicleID);
            if (Vehicle != null)
            {
                transaction.Vehicle = Vehicle;
            }
            else
            {
                transaction.Vehicle = db.Vehicles.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Site = db.Sites.FirstOrDefault(e => e.ID == transaction.SiteID);
            if (Site != null)
            {
                transaction.Site = Site;
            }
            else
            {
                transaction.Site = db.Sites.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Weighman = db.Weighmen.FirstOrDefault(e => e.ID == transaction.WeighmanID);
            if (Weighman != null)
            {
                transaction.Weighman = Weighman;
            }
            else
            {
                transaction.Weighman = db.Weighmen.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var driver = db.Drivers.FirstOrDefault(e => e.ID == transaction.DriverID);
            if (driver != null)
            {
                transaction.Driver = driver;
            }
            else
            {
                transaction.Driver = db.Drivers.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }
        }
        #endregion

        public CloudStorageAccount CreateStorageAccountFromConnectionString(string connectionString)
        {
            string storageConnectionString = connectionString;

            CloudStorageAccount storageAccount = null;
            try
            {
                storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            }
            catch (FormatException ex)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid!");

            }
            catch (ArgumentException)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid!");

            }
            return storageAccount;
        }
        protected string GetStorageConnectionString()
        {
            string storageConnectionString = "";
            string company = ExtractConnectionStringNameFromUserName(Session["CurrentWeighmanName"].ToString());
            string authPath = "~/XeroCertificates";
            DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(authPath));
            var authFile = dirInfo.FullName + @"\XeroAuthentication.JSON";
            string authData = System.IO.File.ReadAllText(authFile);
            XeroAuths xeroAuths = JsonConvert.DeserializeObject<XeroAuths>(authData);

            foreach (XeroAuth xeroAuth in xeroAuths.xeroAuth)
            {
                if (xeroAuth.Company.ToLower() == company.ToLower())
                {
                    storageConnectionString = xeroAuth.StorageConnectionString;
                    break;
                }
            }
            return storageConnectionString;
        }

        protected string ExtractConnectionStringNameFromUserName(string userName)
        {
            string connStrName = string.Empty;

            if (userName != null)
            {
                string[] splitLogonName = userName.Split(DeviceConstants.CHAR_DOT);
                if (splitLogonName.Length > 1)
                {
                    connStrName = splitLogonName[0];
                }
            }
            return connStrName;
        }


    }
}