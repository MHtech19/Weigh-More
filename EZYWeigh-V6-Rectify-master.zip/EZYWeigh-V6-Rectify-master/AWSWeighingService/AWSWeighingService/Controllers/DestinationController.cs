﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using PagedList;
using System.Data.Entity.Infrastructure;
using AWSWeighingService.ViewModels;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class DestinationController : EntityController<Destination>
    {
        /// <summary>
        /// Get Destination list for index grid
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <param name="state"></param>
        /// <param name="suburb"></param>
        /// <param name="site"></param>
        /// <param name="postCode"></param>
        /// <param name="mobile"></param>
        /// <param name="status"></param>
        /// <returns></returns>

        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string code, string state, string suburb,
                              string site, string postCode, string mobile, string status)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewDestination;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDestination;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDestination;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Destinations");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");

            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");

            ViewBag.SuburbSortParm = (sortOrder == "Suburb" ? "Suburb_Desc" : "Suburb");
            ViewBag.StateSortParm = (sortOrder == "State" ? "State_Desc" : "State");
            ViewBag.PostcodeSortParm = (sortOrder == "Postcode" ? "Postcode_Desc" : "Postcode");
            ViewBag.CountrySortParm = (sortOrder == "Country" ? "Country_Desc" : "Country");
            ViewBag.PhoneSortParm = (sortOrder == "Phone" ? "Phone_Desc" : "Phone");
            ViewBag.ContactSortParm = (sortOrder == "Contact" ? "Contact_Desc" : "Contact");

            entities = from e in db.Destinations select e;

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.Destinations == null)
                {
                    entities = from e in db.Destinations where e.Name == CoreConstants.NA select e;
                }
                else
                {
                    entities = logOnSite.Destinations.AsQueryable<Destination>();
                }
            }

            entities = entities.Where(e => e.ID > CoreConstants.NA_ID);


            //Filters

            ViewBag.States = Constants.AUS_STATES.ToList();
            ViewBag.Suburbs = db.Destinations.Where(e => e.Suburb != null).GroupBy(r => r.Suburb).Select(group => group.Key).ToList();
            ViewBag.Sites = db.Sites.Where(s => s.ID > 1).ToList();


            status = status ?? "true";

            ViewBag.name = name;
            ViewBag.code = code;
            ViewBag.state = state;
            ViewBag.suburb = suburb;
            ViewBag.site = site;
            ViewBag.postCode = postCode;
            ViewBag.status = status;
            ViewBag.mobile = mobile;

            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!String.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));
            }

            if (!String.IsNullOrEmpty(state) && state != "All")
            {
                entities = entities.Where(e => e.State.ToUpper().Contains(state.ToUpper()));
            }

            if (!String.IsNullOrEmpty(suburb) && suburb != "All")
            {
                entities = entities.Where(e => e.Suburb.ToUpper().Contains(suburb.ToUpper()));
            }

            if (!string.IsNullOrEmpty(site) && site != "All")
            {
                int siteId = int.Parse(site);
                entities = entities.Where(s => s.Sites.Any(st => st.ID == siteId));
            }

            if (!String.IsNullOrEmpty(status) && status != "All")
            {
                bool statusId = bool.Parse(status);
                entities = entities.Where(e => e.IsActive == statusId);
            }

            if (!String.IsNullOrEmpty(postCode))
            {
                entities = entities.Where(e => e.Postcode.ToUpper().Contains(postCode.ToUpper()));
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;

                case "Suburb":
                    entities = entities.OrderBy(e => e.Suburb);
                    break;
                case "Suburb_Desc":
                    entities = entities.OrderByDescending(e => e.Suburb);
                    break;
                case "State":
                    entities = entities.OrderBy(e => e.State);
                    break;
                case "State_Desc":
                    entities = entities.OrderByDescending(e => e.State);
                    break;
                case "Postcode":
                    entities = entities.OrderBy(e => e.Postcode);
                    break;
                case "Postcode_Desc":
                    entities = entities.OrderByDescending(e => e.Postcode);
                    break;
                case "Country":
                    entities = entities.OrderBy(e => e.Country);
                    break;
                case "Country_Desc":
                    entities = entities.OrderByDescending(e => e.Country);
                    break;
                case "Phone":
                    entities = entities.OrderBy(e => e.Phone);
                    break;
                case "Phone_Desc":
                    entities = entities.OrderByDescending(e => e.Phone);
                    break;
                case "Contact":
                    entities = entities.OrderBy(e => e.Contact);
                    break;
                case "Contact_Desc":
                    entities = entities.OrderByDescending(e => e.Contact);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;

            ViewBag.filterPageSize = pageSize;


            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }


        /// <summary>
        /// It gives the details of the destination based on the id from the grid action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Destination/Details/5

        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDestination;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDestination;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDestination;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Destinations.Include(e => e.Sites).Single(e => e.ID == id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Create a new Destinaton - navigate to the create 
        /// </summary>
        /// <returns></returns>
        // GET: Destination/Create

        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDestination;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDestination;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDestination;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);

            entity = new Destination();
            entity.IsActive = true;
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

            return View(entity);
        }


        /// <summary>
        /// Created a new destination based on the details given in the create page
        /// </summary>
        /// <param name="destination"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Destination/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewDestination")]
        public ActionResult Create([Bind(Include = "ID,Name,Code,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Contact,Email,EPA_Purpose,IsActive")] Destination destination, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDestination;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDestination;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDestination;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);

            entity = new Destination();
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

            if (!logOnSiteIsCentral) // not central site
            {
                ViewBag.IsCentralSite = false;
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
                destination.SiteCreated = true;
                destination.Name = logOnSite.PrefixEntityName(destination.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
            }

            if (selectedSites != null)
            {
                destination.Sites = new List<Site>();
                foreach (var site in selectedSites)
                {
                    var siteToAdd = db.Sites.Find(int.Parse(site));
                    destination.Sites.Add(siteToAdd);
                }
                List<AssignedSiteData> siteData = GetEntityAssignedSiteData(db, destination.Sites);
                ViewBag.Sites = siteData;
            }
            var nameExist = db.Destinations.FirstOrDefault(e => e.Name == destination.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "Destination already exists");
                return View(destination);
            }
            if (ModelState.IsValid)
            {
                destination.Name = destination.Name.ToUpper();
                db.Destinations.Add(destination);
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (selectedSites != null)
                {
                    foreach (var site in selectedSites)
                    {
                        var siteToAdd = db.Sites.Find(int.Parse(site));
                        if (siteToAdd != null)
                        {
                            WriteReplicationLog(siteToAdd.ID, destination.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                        }

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(destination.Name + " created successfully! ", logOnSite);
                return RedirectToAction("Edit/" + destination.ID.ToString());
            }
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, destination.State);
            return View(destination);
        }

        /// <summary>
        /// Get the details of destination based on the id from the grid actions
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Destination/Edit/5

        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDestination;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDestination;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDestination;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = new Destination { Name = "Connection Failed! Retry later." };

            try
            {
                entity = db.Destinations.Include(e => e.Sites).Where(e => e.ID == id).Single();

                if (entity == null)
                {
                    return HttpNotFound();
                }

                ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();
                ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(entity);

        }

        /// <summary>
        /// Update the destination details
        /// </summary>
        /// <param name="id"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Destination/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditDestination")]
        //public ActionResult Edit([Bind(Include = "ID,Name,Code,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Contact,Email")] Destination destination)
        public ActionResult Edit(int? id, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDestination;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDestination;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDestination;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");
            entity = new Destination();
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            if (!logOnSiteIsCentral) // not central site
            {
                ViewBag.IsCentralSite = false;
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
            }

            entity = db.Destinations.Include(e => e.Sites).Single(e => e.ID == id);
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);

            if (TryUpdateModel(entity, "", new string[] { "Name", "Description", "Code", "Address1", "Address2", "Suburb", "State", "Postcode", "Country", "Phone", "Mobile", "Contact", "Email", "EPA_Purpose", "IsActive" }))
            {
                try
                {
                    var destinationExist = db.Destinations.FirstOrDefault(e => e.Name == entity.Name);
                    if (destinationExist != null)
                    {
                        if (destinationExist.ID == entity.ID)
                        {
                            if (ModelState.IsValid)
                            {
                                var entityUpdate = db.Destinations.Find(entity.ID);
                                entityUpdate.Name = entity.Name.ToUpper();
                                entityUpdate.Description = entity.Description;
                                entityUpdate.Code = entity.Code;
                                entityUpdate.Address1 = entity.Address1;
                                entityUpdate.Address2 = entity.Address2;
                                entityUpdate.Suburb = entity.Suburb;
                                entityUpdate.State = entity.State;
                                entityUpdate.Postcode = entity.Postcode;
                                entityUpdate.Country = entity.Country;
                                entityUpdate.Phone = entity.Phone;
                                entityUpdate.Mobile = entity.Mobile;
                                entityUpdate.Contact = entity.Contact;
                                entityUpdate.Email = entity.Email;
                                entityUpdate.IsActive = entity.IsActive;

                                UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);

                                if (TryUpdateModel(entityUpdate, "",
                                         new string[] { "Name", "Description", "Code", "Address1", "Address2", "Suburb", "State", "Postcode", "Country", "Phone", "Mobile", "Contact", "Email", "EPA_Purpose", "IsActive" }))

                                    db.SaveChanges();

                                //Adding to the ReplicationLogItem for data sync
                                if (selectedSites != null)
                                {
                                    foreach (var site in selectedSites)
                                    {
                                        var siteToAdd = db.Sites.Find(int.Parse(site));
                                        if (siteToAdd != null)
                                        {
                                            WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                        }

                                    }

                                }

                                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                                return RedirectToAction("Edit/" + entity.ID.ToString());

                            }
                        }
                        else
                        {
                            ModelState.AddModelError("Name", "Destination already exists");
                            return View(entity);
                        }
                    }
                    if (ModelState.IsValid)
                    {
                        entity.Name = entity.Name.ToUpper();
                        UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
                        if (!logOnSiteIsCentral) // not central site
                        {
                            entity.Name = logOnSite.PrefixEntityName(entity.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
                        }
                        db.Entry(entity).State = EntityState.Modified;
                        db.SaveChanges();

                        //Adding to the ReplicationLogItem for data sync
                        if (selectedSites != null)
                        {
                            foreach (var site in selectedSites)
                            {
                                var siteToAdd = db.Sites.Find(int.Parse(site));
                                if (siteToAdd != null)
                                {
                                    WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                }

                            }

                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ", logOnSite);
                        return RedirectToAction("Edit/" + entity.ID.ToString());

                    }
                }
                catch (RetryLimitExceededException)
                {
                    //Log the error (uncomment dex variable name and add a line here to write a log.
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }
            UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
            return View(entity);
        }

        /// <summary>
        /// Delete the destination based on id from grid actions, it navigates to the view of the destination before delete it
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Destination/Delete/5

        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDestination;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDestination;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDestination;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Destinations.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Remove the destination from the DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        // POST: Destination/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteDestination")]
        public ActionResult DeleteConfirmed(int id)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDestination;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDestination;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDestination;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");
            try
            {
                entity = db.Destinations.Find(id);
                //db.Destinations.Remove(entity);
                entity.IsActive = false;
                db.Entry(entity).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");

                var siteList = db.Sites.Where(s=>s.ID>1).ToList();
                foreach (var siteItem in siteList)
                {
                    WriteReplicationLog(siteItem.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                }                
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This destination " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }
            return RedirectToAction("Index");

        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
