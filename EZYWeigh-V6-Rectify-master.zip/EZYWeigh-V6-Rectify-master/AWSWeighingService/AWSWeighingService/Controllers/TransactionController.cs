﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Infrastructure.EPA;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using PagedList;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web.Hosting;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using iText.Html2pdf;
using iText.IO.Font;
using iText.IO.Image;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.File;
using WeighBridge.Core.Device;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using Image = iText.Layout.Element.Image;
using Newtonsoft.Json;
using iText.Kernel.Pdf.Canvas.Draw;

namespace AWSWeighingService.Controllers
{
    public class TransactionController : EntityController<Transaction>
    {
        /// <summary>
        /// Get the list of transactions based on the filters - Renders the index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="sDate"></param>
        /// <param name="eDate"></param>
        /// <param name="sId"></param>
        /// <param name="docket"></param>
        /// <param name="rego"></param>
        /// <param name="ltype"></param>
        /// <param name="jId"></param>
        /// <param name="pId"></param>
        /// <param name="cId"></param>
        /// <param name="statusId"></param>
        /// <returns></returns>
        // GET: Transaction
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string sDate, string eDate, int? sId, string docket, string rego, string ltype, string jId, string pId, string cId, string statusId)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            if (Session["Role"] != null)
            {
                ViewBag.CanNew = (Session["Role"] as Role).CanNewTransaction;
                ViewBag.CanEdit = (Session["Role"] as Role).CanEditTransaction;
                ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTransaction;
            }
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Transactions");

            ViewBag.CurrentSort = sortOrder;

            ViewBag.DocketSortParm = (String.IsNullOrEmpty(sortOrder) ? "Docket_Desc" : "");
            ViewBag.TransactionDateSortParm = (sortOrder == "TransactionDate" ? "TransactionDate_Desc" : "TransactionDate");
            ViewBag.DirectionSortParm = (sortOrder == "Direction" ? "Direction_Desc" : "Direction");
            ViewBag.Registration1SortParm = (sortOrder == "Registration1" ? "Registration1_Desc" : "Registration1");
            ViewBag.CustomerSortParm = (sortOrder == "Customer" ? "Customer_Desc" : "Customer");
            ViewBag.ProductSortParm = (sortOrder == "Product" ? "Product_Desc" : "Product");
            ViewBag.SiteSortParm = (sortOrder == "Site" ? "Site_Desc" : "Site");

            ViewBag.TareSortParm = (sortOrder == "Tare" ? "Tare_Desc" : "Tare");
            ViewBag.GrossSortParm = (sortOrder == "Gross" ? "Gross_Desc" : "Gross");
            ViewBag.NetSortParm = (sortOrder == "Net" ? "Net_Desc" : "Net");
            ViewBag.PriceSortParm = (sortOrder == "Price" ? "Price_Desc" : "Price");
            ViewBag.TotalCostSortParm = (sortOrder == "TotalCost" ? "TotalCost_Desc" : "TotalCost");


            //Filters

            ViewBag.sDate = sDate;
            ViewBag.eDate = eDate;
            ViewBag.AllSites = db.Sites.Where(s => s.ID > 1).ToList();
            sId = sId ?? db.Sites.Where(s => s.ID > 1).FirstOrDefault().ID;
            ViewBag.sId = sId;
            ViewBag.docket = docket;
            ViewBag.rego = rego;
            ViewBag.LoadTypes = CoreConstants.LOADTYPE_NO_FIRST;
            ViewBag.ltype = ltype;
            ViewBag.AllJobs = db.Jobs.ToList();
            ViewBag.jId = jId;
            ViewBag.AllProducts = db.Products.ToList();
            ViewBag.pId = pId;
            ViewBag.AllCustomers = db.Customers.ToList();
            ViewBag.cId = cId;
            statusId = statusId ?? "1";
            ViewBag.statusId = statusId;

            entities = db.Transactions.Include(t => t.Customer).Include(t => t.Product).Include(t => t.Site);

            if (statusId == "1")
            {
                //all active
                entities = entities.Where(e => e.Deleted == false);
            }
            else if (statusId == "2")
            {
                //only manual entries
                entities = entities.Where(e => e.IsManualEntry == true);
            }
            else if (statusId == "3")
            {
                //only deleted
                entities = entities.Where(e => e.Deleted == true);
            }

            DateTime? paramStartDate = null;
            DateTime? paramEndDate = null;
            if (!string.IsNullOrEmpty(sDate))
            {

                paramStartDate = Convert.ToDateTime(sDate);
            }
            else
            {
                paramStartDate = DateTime.Now;
                ViewBag.sDate = paramStartDate.Value.Date.ToString("yyyy-MM-dd");
            }

            if (!string.IsNullOrEmpty(eDate))
            {

                paramEndDate = Convert.ToDateTime(eDate);

            }
            else
            {
                paramEndDate = DateTime.Now;
                ViewBag.eDate = paramEndDate.Value.Date.ToString("yyyy-MM-dd"); ;
            }


            entities = entities.Where(e => e.SiteID == sId && (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(paramStartDate.Value) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(paramEndDate.Value)));

            if (!string.IsNullOrEmpty(ltype) && ltype != "All")

            {
                entities = entities.Where(e => e.LoadType.ToUpper().Contains(ltype.ToUpper()));
            }

            if (!string.IsNullOrEmpty(jId) && jId != "All")
            {
                int intJobId = Convert.ToInt32(jId);
                entities = entities.Where(e => e.JobID == intJobId);
            }

            if (!string.IsNullOrEmpty(cId) && cId != "All")
            {
                int intCusId = Convert.ToInt32(cId);
                entities = entities.Where(e => e.CustomerID == intCusId);
            }

            if (!string.IsNullOrEmpty(pId) && pId != "All")
            {
                int intProductId = Convert.ToInt32(pId);

                entities = entities.Where(e => e.ProductID == intProductId);

            }

            if (!string.IsNullOrEmpty(rego))
            {
                entities = entities.Where(e => e.Registration1.ToUpper().Contains(rego.ToUpper()));
            }

            if (!string.IsNullOrEmpty(docket))
            {
                entities = entities.Where(e => e.Docket.ToUpper().Contains(docket.ToUpper()));
            }


            switch (sortOrder)
            {
                case "Docket_Desc":
                    entities = entities.OrderByDescending(e => e.Docket);
                    break;
                case "TransactionDate":
                    entities = entities.OrderBy(e => e.TransactionDate);
                    break;
                case "TransactionDate_Desc":
                    entities = entities.OrderByDescending(e => e.TransactionDate);
                    break;
                case "Direction":
                    entities = entities.OrderBy(e => e.Direction);
                    break;
                case "Direction_Desc":
                    entities = entities.OrderByDescending(e => e.Direction);
                    break;
                case "Registration1":
                    entities = entities.OrderBy(e => e.Registration1);
                    break;
                case "Registration1_Desc":
                    entities = entities.OrderByDescending(e => e.Registration1);
                    break;
                case "Customer":
                    entities = entities.OrderBy(e => e.Customer.Name);
                    break;
                case "Customer_Desc":
                    entities = entities.OrderByDescending(e => e.Customer.Name);
                    break;
                case "Product":
                    entities = entities.OrderBy(e => e.Product.Name);
                    break;
                case "Product_Desc":
                    entities = entities.OrderByDescending(e => e.Product.Name);
                    break;
                case "Site":
                    entities = entities.OrderBy(e => e.Site.Name);
                    break;
                case "Site_Desc":
                    entities = entities.OrderByDescending(e => e.Site.Name);
                    break;
                case "Tare":
                    entities = entities.OrderBy(e => e.Tare1);
                    break;
                case "Tare_Desc":
                    entities = entities.OrderByDescending(e => e.Tare1);
                    break;
                case "Gross":
                    entities = entities.OrderBy(e => e.Gross1);
                    break;
                case "Gross_Desc":
                    entities = entities.OrderByDescending(e => e.Gross1);
                    break;
                case "Net":
                    entities = entities.OrderBy(e => e.Net);
                    break;
                case "Net_Desc":
                    entities = entities.OrderByDescending(e => e.Net);
                    break;
                case "Price":
                    entities = entities.OrderBy(e => e.Price);
                    break;
                case "Price_Desc":
                    entities = entities.OrderByDescending(e => e.Price);
                    break;
                case "TotalCost":
                    entities = entities.OrderBy(e => e.TotalCost);
                    break;
                case "TotalCost_Desc":
                    entities = entities.OrderByDescending(e => e.TotalCost);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Docket);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Get the details of the transaction by id - Navigate to the details page from the grid details action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Transaction/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTransaction;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Transactions.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Navigate to the create a new transaction page from index page
        /// </summary>
        /// <returns></returns>
        // GET: Transaction/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            if (Session["Role"] != null)
            {
                ViewBag.CanNew = (Session["Role"] as Role).CanNewTransaction;
                ViewBag.CanEdit = (Session["Role"] as Role).CanEditTransaction;
                ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTransaction;
            }
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            ViewBag.Payments = new SelectList(CoreConstants.PAYMENTS, CoreConstants.PAYMENT_ACCOUNT);
            ViewBag.ChargeRate = new SelectList(CoreConstants.CHARGE_RATES, CoreConstants.RATE_LOCAL);
            ViewBag.Direction = new SelectList(CoreConstants.DIRECTIONS, CoreConstants.DIRECTION_IN).Where(x => x.Text != CoreConstants.NA);
            ViewBag.VehicleOwner = new SelectList(CoreConstants.OWNERS, CoreConstants.OWNER_PRIVATE);
            ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPE_NO_FIRST, CoreConstants.Load_Second);
            ViewBag.DriverID = new SelectList(db.Drivers.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.MarkID = new SelectList(db.Marks.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.TruckID = new SelectList(db.Trucks.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.VehicleID = new SelectList(db.Vehicles.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
            ViewBag.VehicleConfigurationID = new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);

            if (logOnSiteIsCentral)
            {
                ViewBag.CustomerID = new SelectList(db.Customers.Where(e => e.Active).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.DestinationID = new SelectList(db.Destinations.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.JobID = new SelectList(db.Jobs.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.ProductID = new SelectList(db.Products.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.SourceID = new SelectList(db.Sources.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.SiteID = new SelectList(db.Sites.OrderByDescending(s => s.ID), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(db.Weighmen.Where(e => e.IsDeleted == false).OrderBy(e => e.Name), "ID", "Name");
            }
            else
            {
                ViewBag.CustomerID = new SelectList(logOnSite.Customers.Where(e => e.Active).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.DestinationID = new SelectList(logOnSite.Destinations.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.JobID = new SelectList(logOnSite.Jobs.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.ProductID = new SelectList(logOnSite.Products.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                ViewBag.SourceID = new SelectList(logOnSite.Sources.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);

                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name");
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen.Where(e => e.IsDeleted == false).OrderBy(e => e.Name), "ID", "Name");
            }

            Transaction entity = new Transaction();

            return View(entity);
        }

        /// <summary>
        /// Create a new transaction - stored in the transaction table
        /// </summary>
        /// <param name="transaction"></param>
        /// <returns></returns>

        // POST: Transaction/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.

        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewTransaction")]
        public ActionResult Create([Bind(Include = "ID,TransactionDate,Comment,Payments,Direction,VehicleOwner,Registration1,Registration2,Registration3,Gross1,Gross2,Gross3,Gross4,Gross5,Tare1,Tare2,Tare3,Tare4,Tare5,Net,LoadType,OrderNumber,SiteID,WeighmanID,ProductCategoryID,ProductID,CustomerID,DestinationID,SourceID,JobID,TruckID,VehicleID,DriverID,VehicleConfigurationID,Haulage,VINNumber,CartageCharge,ChargeRate")] Transaction transaction)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTransaction;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTransaction;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTransaction;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            if (transaction.Registration1 == null || string.IsNullOrEmpty(transaction.Registration1.Trim()))
            {
                ModelState.AddModelError("Registration1", "The Registration1 field is required.");
            }

            if (transaction.Direction == null || transaction.Direction == "NA")
            {
                ModelState.AddModelError("Direction", "Please select Direction as IN/OUT.");
            }

            if (transaction.ProductID <= 1)
            {
                ModelState.AddModelError("ProductID", "Please select Product.");
            }

            if ((transaction.LoadType == CoreConstants.Load_Second) || (transaction.LoadType == CoreConstants.Load_StoredTare))
            {
                if (transaction.Gross <= 0)
                {
                    ModelState.AddModelError("Gross1", "Please enter Gross(t).");
                }
                if (transaction.Tare <= 0)
                {
                    ModelState.AddModelError("Tare1", "Please enter Tare(t).");
                }
            }

            if (transaction.LoadType == CoreConstants.Load_Counted)
            {
                if (transaction.Net <= 0)
                {
                    ModelState.AddModelError("Net", "Please enter counted number in Net(t) field.");
                }
            }

            if (transaction.LoadType == CoreConstants.Load_Standard)
            {
                if (transaction.VehicleID <= 1)
                {
                    ModelState.AddModelError("VehicleID", "Please select Vehicle Type.");
                }
            }

            //ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPE_NO_FIRST, CoreConstants.Load_Second);
            var errors = ModelState.Where(x => x.Value.Errors.Any())
                .Select(x => new { x.Key, x.Value.Errors });
            if (ModelState.IsValid)
            {
                Site site = db.Sites.Find(transaction.SiteID);
                site.CurrentDocket++;
                transaction.Docket = site.DocketHead + site.CurrentDocket.ToString();
                db.Entry(site).State = EntityState.Modified;

                //calculate prices
                transaction.Product = db.Products.Find(transaction.ProductID);
                if ((transaction.LoadType == CoreConstants.Load_ManualTare) || (transaction.LoadType == CoreConstants.Load_Second) || (transaction.LoadType == CoreConstants.Load_StoredTare))
                {
                    transaction.Net = Math.Abs(transaction.Gross - transaction.Tare);
                }

                if (transaction.LoadType == CoreConstants.Load_Rego)
                {
                    if (transaction.Gross > 0 && transaction.Tare > 0)
                    {
                        transaction.Net = Math.Abs(transaction.Gross - transaction.Tare);
                    }

                    if (transaction.Gross > 0 && transaction.Tare == 0)
                    {
                        transaction.Net = Math.Abs(transaction.Gross);
                    }

                    if (transaction.Gross == 0 && transaction.Tare > 0)
                    {
                        transaction.Net = Math.Abs(transaction.Tare);
                    }
                }
                transaction.Site = db.Sites.Find(transaction.SiteID);
                transaction.Job = db.Jobs.Find(transaction.JobID);
                transaction.Customer = db.Customers.Find(transaction.CustomerID);
                transaction.Destination = db.Destinations.Find(transaction.DestinationID);
                transaction.Source = db.Sources.Find(transaction.SourceID);
                transaction.Vehicle = db.Vehicles.Find(transaction.VehicleID);
                transaction.Product.CurrentAmount = transaction.Net;
                if (transaction.LoadType == CoreConstants.Load_Counted)
                {
                    transaction.Product.SetCurrentCharges(transaction, null, null, transaction.CartageCharge);
                }
                else
                {
                    transaction.Product.SetCurrentCharges(transaction, db.JobProductPrices.ToList(), db.VehicleProductPrices.ToList(), transaction.CartageCharge);
                }
                if (transaction.LoadType == CoreConstants.Load_Standard)
                {
                    transaction.Net = (transaction.Vehicle != null) ? transaction.Vehicle.NetWeight : 0;
                }
                transaction.Price = transaction.Product.CurrentPrice;
                transaction.EPARate = transaction.Product.EPALevy;
                transaction.GST = transaction.Product.CurrentGST;
                transaction.EPA = transaction.Product.CurrentEPA;
                transaction.CartageCharge = transaction.Product.CurrentCartage;
                transaction.CartageGST = transaction.Product.CurrentCartageGST;
                transaction.TranCost = transaction.Product.CurrentTranCost;
                transaction.TotalCost = transaction.Product.CurrentTotalCost;
                transaction.IsManualEntry = true;
                transaction.Royalty = transaction.Product.CurrentRoyalty;
                transaction.ProductRoyalty = transaction.Product.Royalty;
                transaction.CustomerDiscount = transaction.Product.CurrentCustomerDiscount;
                transaction.MinimumCharge = transaction.Product.CurrentMinimumCharge;

                Truck truckExistsByRego1 = db.Trucks.Where(t => t.Name == transaction.Registration1).FirstOrDefault();
                transaction.MaxLoad = (truckExistsByRego1 != null) ? truckExistsByRego1.MaxLoad : 0;

                db.Transactions.Add(transaction);
                TempData["UserMessage"] = ComposeTempDisplayMessage("Transaction " + transaction.Docket + " created successfully!");

                var stockActivation = db.ProductStockActivations.FirstOrDefault(s => s.ProductID == transaction.ProductID && s.SiteID == transaction.SiteID); //await DataManager.GetProductStockActivationAsync(tran.ProductID, tran.SiteID);

                if (stockActivation != null)
                {
                    var stockMove = transaction.GenerateProductStockMovement(stockActivation.STOCKLEVEL);

                    stockActivation.STOCKLEVEL = stockMove.STOCKLEVEL;
                    stockActivation.WeighmanID = transaction.WeighmanID;
                    db.Entry(stockActivation).State = EntityState.Modified;

                    db.ProductStockMovements.Add(stockMove);


                }

                db.SaveChanges();

                if (transaction.JobID != CoreConstants.NA_ID)
                {
                    var job = db.Jobs.Find(transaction.JobID);
                    if (job != null && job.JobTonnesOrdered > 0)
                    {
                        var listOfTrans = db.Transactions.Where(t => t.Deleted == false && t.JobID == transaction.JobID).ToList();
                        if (listOfTrans != null)
                        {
                            job.JobTonnesRunningTotal = listOfTrans.Sum(t => t.Net);
                            db.Entry(job).State = EntityState.Modified;
                            db.SaveChanges();

                            foreach (var item in db.Sites.Where(s => s.ID > 1).ToList())
                            {
                                ReplicationLogItem logItem = new ReplicationLogItem
                                {
                                    DestinationSiteID = item.ID,
                                    EntityType = "Job",
                                    EntityID = job.ID,
                                    Operation = "U",
                                    SourceSiteID = 1,
                                    LogCreated = DateTime.UtcNow
                                };

                                db.ReplicationLogItems.Add(logItem);
                                db.SaveChanges();

                            }
                        }
                    }
                }
                // if storageconnectionstring is defined, only then generate PDF and upload it to azure storage account.
                string storageConnectionString = GetStorageConnectionString();
                if (storageConnectionString != "")
                {
                    SavePDF(transaction, storageConnectionString);
                }

                return RedirectToAction("Index");
            }

            ViewBag.Payments = new SelectList(CoreConstants.PAYMENTS, transaction.Payments);
            ViewBag.ChargeRate = new SelectList(CoreConstants.CHARGE_RATES, transaction.ChargeRate);
            ViewBag.Direction = new SelectList(CoreConstants.DIRECTIONS, transaction.Direction).Where(x => x.Text != CoreConstants.NA);
            ViewBag.VehicleOwner = new SelectList(CoreConstants.OWNERS, transaction.VehicleOwner);
            ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPE_NO_FIRST, transaction.LoadType);

            ViewBag.DriverID = new SelectList(db.Drivers.OrderBy(e => e.Name), "ID", "Name", transaction.DriverID);
            ViewBag.MarkID = new SelectList(db.Marks.OrderBy(e => e.Name), "ID", "Name", transaction.MarkID);
            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories.OrderBy(e => e.Name), "ID", "Name", transaction.ProductCategoryID);
            ViewBag.TruckID = new SelectList(db.Trucks.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.TruckID);
            ViewBag.VehicleID = new SelectList(db.Vehicles.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.VehicleID);
            ViewBag.VehicleConfigurationID = new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name", transaction.VehicleConfigurationID);

            if (logOnSiteIsCentral)
            {
                ViewBag.CustomerID = new SelectList(db.Customers.Where(e => e.Active).OrderBy(e => e.Name), "ID", "Name", transaction.CustomerID);
                ViewBag.DestinationID = new SelectList(db.Destinations.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.DestinationID);
                ViewBag.JobID = new SelectList(db.Jobs.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.JobID);
                ViewBag.ProductID = new SelectList(db.Products.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.ProductID);
                ViewBag.SourceID = new SelectList(db.Sources.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.SourceID);

                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name", transaction.SiteID);
                ViewBag.WeighmanID = new SelectList(db.Weighmen.Where(e => e.IsDeleted == false).OrderBy(e => e.Name), "ID", "Name", transaction.WeighmanID);
            }
            else
            {
                ViewBag.CustomerID = new SelectList(logOnSite.Customers.Where(e => e.Active).OrderBy(e => e.Name), "ID", "Name", transaction.CustomerID);
                ViewBag.DestinationID = new SelectList(logOnSite.Destinations.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.DestinationID);
                ViewBag.JobID = new SelectList(logOnSite.Jobs.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.JobID);
                ViewBag.ProductID = new SelectList(logOnSite.Products.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.ProductID);
                ViewBag.SourceID = new SelectList(logOnSite.Sources.Where(e => e.IsActive).OrderBy(e => e.Name), "ID", "Name", transaction.SourceID);

                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name", transaction.SiteID);
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen.Where(e => e.IsDeleted == false).OrderBy(e => e.Name), "ID", "Name", transaction.WeighmanID);
            }

            return View(transaction);
        }

        #region GenerateandSavePDF
        public void SavePDF(Transaction entity, string storageConnectionString)
        {
            LoadTransaction(entity);
            TempData["TransID"] = entity.ID;
            AWSConfiguration SysConfig = new AWSConfiguration();
            PublicWeigh.Config.Lib.CompanyProfile objCompanyProfile = new PublicWeigh.Config.Lib.CompanyProfile();
            objCompanyProfile.CountedItemAs = "m3";
            SysConfig.CompanyProfileSettings = objCompanyProfile;
            PublicWeigh.Config.Lib.Replication objReplication = new PublicWeigh.Config.Lib.Replication();
            objReplication.IsRoundOffCashPaymentToClosest5Cents = false;
            SysConfig.ReplicationSettings = objReplication;
            PublicWeigh.Config.Lib.Ticket objTicket = new PublicWeigh.Config.Lib.Ticket();
            objTicket.PrintVolume = false;
            SysConfig.TicketSettings = objTicket;
            TempData["EntityList"] = GenerateTicket(entity, SysConfig, true);
            TempData["FileName"] = entity.Site.Name + "-Docket_" + entity.Docket + ".pdf";
            PdfGenerate(storageConnectionString);

        }
        public void PdfGenerate(string storageConnectionString)
        {
            try
            {
                DateTime CaptureDate = DateTime.Now; ;
                iText.Layout.Element.Image image = null;
                byte[] completedDocument = null;
                byte[] photo = null;
                int TransID = (int)TempData["TransID"];
                Signature objFindSignature = new Signature();
                objFindSignature = db.Signatures.Where(x => x.TransactionID == TransID).FirstOrDefault();
                if (objFindSignature != null)
                {
                    photo = objFindSignature.Content;
                    CaptureDate = Convert.ToDateTime(objFindSignature.SignedOn);
                    using (Stream inputImageStream = new MemoryStream(photo, 0, photo.Length, true, true)) ;
                }
                using (MemoryStream stream = new System.IO.MemoryStream())
                {
                    PdfWriter writer = new PdfWriter(stream);
                    //Initialize PDF document
                    PdfDocument pdf = new PdfDocument(writer);
                    // pdf.SetDefaultPageSize(new PageSize(PageSize.A4));
                    Document document = new Document(pdf);

                    string root = Server.MapPath("~");
                    string parent = System.IO.Path.GetDirectoryName(root) + "/fonts/Segoe UI.ttf";
                    //Setting styles
                    PdfFont fontCourier = PdfFontFactory.CreateFont(parent);
                    PdfFont bold = PdfFontFactory.CreateFont(FontConstants.HELVETICA_BOLD);
                    iText.Layout.Element.Table transtable = new iText.Layout.Element.Table(3)
                    .SetBorder(Border.NO_BORDER);
                    iText.Layout.Element.Table transtable2 = new iText.Layout.Element.Table(3)
                    .SetBorder(Border.NO_BORDER);
                    Cell transCell1 = new Cell()
                    .SetBorder(Border.NO_BORDER);
                    Cell transCell2 = new Cell()
                    .SetBorder(Border.NO_BORDER);
                    Cell transCell3 = new Cell()
                    .SetBorder(Border.NO_BORDER);
                    Cell transCell4 = new Cell()
                    .SetBorder(Border.NO_BORDER);
                    ObservableCollection<string> Datalist = (ObservableCollection<string>)TempData["EntityList"];
                    foreach (var element in Datalist.Select((value, ai) => new { ai, value }))
                    {
                        Paragraph paragraph = new Paragraph();
                        string[] splitEle = element.value.Split(new[] { ':' }, 2);

                        if (element.ai > 4)
                        {
                            if (splitEle.Length >= 2)
                            {
                                if (string.IsNullOrEmpty(splitEle[0].Trim()))
                                {
                                    transCell3.Add(new Paragraph("\n").SetFixedLeading(9));
                                    transCell4.Add(new Paragraph("\n").SetFixedLeading(9));

                                }
                                else
                                {
                                    if (Datalist.Any(str => str.Contains("Mixed")))
                                    {
                                        if (splitEle[0].Contains("Amount Due"))
                                        {
                                            transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold));
                                            transCell4.Add(new Paragraph(": " + splitEle[1]).SetFixedLeading(9).SetFont(bold));

                                        }
                                        else
                                        {
                                            transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9));

                                            if (string.IsNullOrEmpty(splitEle[1].Trim()))
                                                transCell4.Add(new Paragraph("\n").SetFixedLeading(9));
                                            else
                                                transCell4.Add(new Paragraph(": " + splitEle[1]).SetFixedLeading(9));
                                        }
                                    }
                                    else
                                    {
                                        if (splitEle[0].Contains("Amount Due"))
                                        {
                                            transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold)).SetWidth(50);
                                            transCell4.Add(new Paragraph(": " + splitEle[1].Trim()).SetFixedLeading(9).SetFont(bold));

                                        }
                                        else
                                        {
                                            transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9)).SetWidth(50);

                                            if (string.IsNullOrEmpty(splitEle[1].Trim()))
                                                transCell4.Add(new Paragraph("\n").SetFixedLeading(9));
                                            else
                                                transCell4.Add(new Paragraph(": " + splitEle[1]).SetFixedLeading(9));
                                        }

                                    }
                                }
                            }
                            else
                            {
                                string lstElement = splitEle[0];
                                int count = lstElement.TakeWhile(Char.IsWhiteSpace).Count();
                                // We create a list:
                                if (string.IsNullOrEmpty(lstElement.Trim()))
                                {
                                    transCell3.Add(new Paragraph("\n").SetFixedLeading(9)).SetWidth(100);
                                }
                                else
                                {
                                    if (splitEle[0].ToLower().Contains("tax invoice"))
                                    {
                                        transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold)).SetWidth(100);
                                    }
                                    else
                                    {
                                        if (count > 1)
                                            transCell3.Add(new Paragraph(splitEle[0]).SetFirstLineIndent(10).SetFixedLeading(9)).SetWidth(100);
                                        else
                                            transCell3.Add(new Paragraph(splitEle[0]).SetFixedLeading(9)).SetWidth(100);

                                    }
                                }

                                transCell4.Add(new Paragraph("\n").SetFixedLeading(9));
                            }


                        }
                        else
                        {
                            // We create a list:
                            if (string.IsNullOrEmpty(splitEle[0].Trim()))
                            {
                                transCell1.Add(new Paragraph("\n").SetFixedLeading(9)).SetWidth(100);
                            }
                            else
                            {
                                if (splitEle[0].ToLower().Contains("tax invoice"))
                                {
                                    transCell1.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold)).SetWidth(100);
                                }
                                else if (element.ai == 2)
                                {
                                    transCell1.Add(new Paragraph(splitEle[0]).SetFixedLeading(9).SetFont(bold).SetFontSize(9)).SetWidth(100);

                                }
                                else
                                {
                                    transCell1.Add(new Paragraph(splitEle[0]).SetFixedLeading(9)).SetWidth(100);

                                }
                            }

                        }

                    }
                    //SolidLine line = new SolidLine(1f);
                    //LineSeparator ls = new LineSeparator(line);
                    transCell3.SetBorder(Border.NO_BORDER);
                    //transCell3.Add(new Paragraph("Signature      :").SetFont(fontCourier).SetMarginTop(30));
                    transCell4.SetBorder(Border.NO_BORDER);
                    //transCell4.Add(ls.SetWidth(80).SetMarginTop(40));
                    transtable.AddCell(transCell1.SetRelativePosition(-37, -33, 0, 0));
                    transtable.AddCell(transCell2.SetRelativePosition(-37, -33, 0, 0));
                    transtable2.AddCell(transCell3.SetRelativePosition(-37, -37, 0, 0));
                    transtable2.AddCell(transCell4.SetRelativePosition(-37, -37, 0, 0));

                    SolidLine line = new SolidLine(1f);
                    LineSeparator ls = new LineSeparator(line);
                    iText.Layout.Element.Table sigtable = new iText.Layout.Element.Table(3)
                    .SetBorder(Border.NO_BORDER);

                    Cell sigCell = new Cell()
                    .SetBorder(Border.NO_BORDER)
                    .Add(new Paragraph("Signature       :").SetFont(fontCourier).SetMarginTop(30));
                    Cell sigCell1 = new Cell();
                    sigCell1.SetBorder(Border.NO_BORDER);
                    if (objFindSignature != null)
                    {
                        image = new Image(ImageDataFactory.Create(photo));
                        sigCell1.Add(image.SetWidth(80).SetHeight(30).SetMarginTop(10));
                        sigCell1.Add(ls.SetWidth(80));
                    }
                    else
                    {
                        sigCell1.Add(ls.SetWidth(80).SetMarginTop(40));
                    }
                    if (objFindSignature != null)
                    {
                        sigCell.Add(new Paragraph("Signed On      :").SetFont(fontCourier));
                        sigCell1.Add(new Paragraph(CaptureDate.ToString("dd/MM/yyyy HH:mm:ss tt")).SetFont(fontCourier).SetMarginTop(2));
                    }
                    sigtable.AddCell(sigCell);
                    sigtable.AddCell(sigCell1);

                    using (var pdfWriter = new PdfWriter(stream))
                    {
                        pdfWriter.SetCloseStream(false);
                        using (var document1 = HtmlConverter.ConvertToDocument("", pdfWriter))
                        {
                            document1.SetTopMargin(0);
                            document1.Add(transtable);
                            document1.SetFont(fontCourier);
                            document1.SetFontSize(8);
                            document1.Add(transtable2);
                            document1.SetFont(fontCourier);
                            document1.SetFontSize(8);
                            document1.Add(sigtable.SetBorder(Border.NO_BORDER).SetRelativePosition(-37, -37, 0, 0));

                            document1.Add(new Paragraph("Thank You").SetFont(fontCourier).SetFont(bold).SetMarginTop(20).SetMarginLeft(85).SetRelativePosition(-37, -37, 0, 0));
                        }
                    }
                    //var dir = new DirectoryInfo(System.IO.Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "DocketPDFS"));
                    //Directory.CreateDirectory(dir.FullName);
                    completedDocument = stream.ToArray();
                    // if storage account details are defined then upload pdf file.
                    int i = UploadFileinAzure(completedDocument, storageConnectionString);
                }
            }
            catch (Exception Ex)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Unable to generate the file! due to file is opened or some other issues.");
            }
        }
        public int UploadFileinAzure(byte[] data, string connectionString)
        {
            CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(connectionString);
            CloudFileClient cloudFileClient = storageAccount.CreateCloudFileClient();
            CloudFileShare cloudFileShare = null;
            CloudFileDirectory fileDirectory = null;
            CloudFile cloudFile = null;

            string shareName = "shareddata";
            string sourceFolder = "dockets";

            cloudFileShare = cloudFileClient.GetShareReference(shareName);
            try
            {
                cloudFileShare.CreateIfNotExistsAsync();
            }
            catch (StorageException exStorage)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Please make sure your storage account has storage file endpoint enabled and specified correctly");
            }
            catch (Exception ex)
            {

            }
            try
            {
                CloudFileDirectory rootDirectory = cloudFileShare.GetRootDirectoryReference();
                if (string.IsNullOrWhiteSpace(sourceFolder))
                {
                    fileDirectory = rootDirectory;
                }
                else
                {
                    fileDirectory = rootDirectory.GetDirectoryReference(sourceFolder);
                    fileDirectory.CreateIfNotExistsAsync();
                }

                // Set a reference to the file.
                cloudFile = fileDirectory.GetFileReference((string)TempData["FileName"]);

                using (MemoryStream stream = new MemoryStream())
                {
                    stream.Write(data, 0, data.Length);
                    stream.Seek(0, SeekOrigin.Begin);
                    cloudFile.ServiceClient.DefaultRequestOptions.ParallelOperationThreadCount = 2;
                    cloudFile.UploadFromStream(stream);
                }
            }
            catch (Exception ex)
            {

            }
            return 1;
        }
        public CloudStorageAccount CreateStorageAccountFromConnectionString(string connectionString)
        {
            string storageConnectionString = connectionString;

            CloudStorageAccount storageAccount = null;
            try
            {
                storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            }
            catch (FormatException ex)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid!");

            }
            catch (ArgumentException)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid!");

            }
            return storageAccount;
        }
        protected string GetStorageConnectionString()
        {
            string storageConnectionString = "";
            string company = ExtractConnectionStringNameFromUserName(Session["CurrentWeighmanName"].ToString());
            string authPath = "~/XeroCertificates";
            DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(authPath));
            var authFile = dirInfo.FullName + @"\XeroAuthentication.JSON";
            string authData = System.IO.File.ReadAllText(authFile);
            XeroAuths xeroAuths = JsonConvert.DeserializeObject<XeroAuths>(authData);

            foreach (XeroAuth xeroAuth in xeroAuths.xeroAuth)
            {
                if (xeroAuth.Company.ToLower() == company.ToLower())
                {
                    storageConnectionString = xeroAuth.StorageConnectionString;
                    break;
                }
            }
            return storageConnectionString;
        }
        protected string ExtractConnectionStringNameFromUserName(string userName)
        {
            string connStrName = string.Empty;

            if (userName != null)
            {
                string[] splitLogonName = userName.Split(DeviceConstants.CHAR_DOT);
                if (splitLogonName.Length > 1)
                {
                    connStrName = splitLogonName[0];
                }
            }
            return connStrName;
        }
        #endregion

        #region PrintTicketGeneration
        public ObservableCollection<string> GenerateTicket(Transaction currentTransaction, AWSConfiguration sysConfig, bool isReprint)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            ObservableCollection<string> generatedTicket = new ObservableCollection<string>();

            if (isReprint)
            {
                generatedTicket.AddRange(currentTransaction.GenerateTicket(sysConfig, isReprint));
                return generatedTicket;
            }

            if (currentTransaction.LoadType == CoreConstants.Load_First)
            {
                var currentFirstWeigh = new FirstWeigh(currentTransaction);
                generatedTicket.AddRange(currentFirstWeigh.GenerateTicket(currentTransaction, sysConfig));

                return generatedTicket;
            }

            if (currentTransaction.LoadType == CoreConstants.Load_Standard)
            {
                foreach (var p in currentTransaction.SelectedMixedProducts)
                {
                    p.SetCurrentCharges(currentTransaction, null, db.VehicleProductPrices.ToList());
                }


            }
            else if (currentTransaction.LoadType == CoreConstants.Load_Mixed)
            {
                foreach (var p in currentTransaction.SelectedMixedProducts)
                {
                    p.SetCurrentCharges(currentTransaction, db.JobProductPrices.ToList(), null); //(currentTransaction,  null, GlobalStaticUtilities.VehicleProductPrices);
                }

            }
            else
            {
                currentTransaction.Product.CurrentAmount = currentTransaction.Net;
                currentTransaction.Product.SetCurrentCharges(currentTransaction, db.JobProductPrices.ToList(), null);
                currentTransaction.Price = currentTransaction.Product.CurrentPrice;
                currentTransaction.GST = currentTransaction.Product.CurrentGST;
                currentTransaction.EPA = currentTransaction.Product.CurrentEPA;
                currentTransaction.CartageCharge = currentTransaction.Product.CurrentCartage;
                currentTransaction.CartageGST = currentTransaction.Product.CurrentCartageGST;
                currentTransaction.TotalCost = currentTransaction.Product.CurrentTotalCost;
                currentTransaction.TranCost = currentTransaction.Product.CurrentTranCost;
                currentTransaction.Royalty = currentTransaction.Product.CurrentRoyalty;
                currentTransaction.ProductRoyalty = currentTransaction.Product.Royalty;
                currentTransaction.Count = currentTransaction.Product.CurrentCount;
                currentTransaction.CustomerDiscount = currentTransaction.Product.CurrentCustomerDiscount;



                if (currentTransaction.Job != null && currentTransaction.JobID != CoreConstants.NA_ID && currentTransaction.Job.JobTonnesOrdered > 0 && sysConfig.TicketSettings.PrintJobTonnage)
                {
                    try
                    {
                        if (sysConfig.WeighBridgeSettings.OfflineMode.Value)
                        {
                            currentTransaction.Product.CurrentPrice = -1;
                            currentTransaction.Product.CurrentGST = -1;
                            currentTransaction.Product.CurrentEPA = -1;
                        }
                        else
                        {
                            JobTonnage jobTonnage = GetJobTonnage(currentTransaction.JobID);
                            if (jobTonnage != null)
                            {
                                currentTransaction.Product.CurrentGST = jobTonnage.TonnesOrdered;
                                currentTransaction.Product.CurrentPrice = jobTonnage.TonnesLeft - currentTransaction.Net;
                                currentTransaction.Product.CurrentEPA = jobTonnage.TonnesProcessed + currentTransaction.Net;
                            }
                            else
                            {
                                currentTransaction.Product.CurrentPrice = 0M;
                                currentTransaction.Product.CurrentGST = 0M;
                                currentTransaction.Product.CurrentEPA = 0M;
                            }
                        }
                    }
                    catch (Exception ecp)
                    {
                        currentTransaction.Product.CurrentPrice = -1;
                        currentTransaction.Product.CurrentGST = -1;
                        currentTransaction.Product.CurrentEPA = -1;
                        LogWMSSystemExceptionEvent(ecp);
                    }

                }

            }

            //   }

            generatedTicket.AddRange(currentTransaction.GenerateTicket(sysConfig, isReprint));
            return generatedTicket;
        }

        public void LogWMSSystemExceptionEvent(Exception ecp)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            string errMsg = ecp.Message.ToString();
            TempData["UserMessage"] = ComposeTempDisplayMessage(errMsg);

            WMSEventLog eventLog = new WMSEventLog
            {
                Name = "Web System Error",
                EventDateTime = DateTime.Now,
                DateStamp = DateTime.Now.ToString("dd/MM/yyyy"),
                WeighmanID = logOnWeighman.ID,
                SiteID = logOnSite.ID,
                Comment = errMsg + " from " + ecp.StackTrace,
                EventType = (int)WMSEventTypes.System,
                WeightPass = 0,
            };
            db.WMSEventLogs.Add(eventLog);
        }
        public JobTonnage GetJobTonnage(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            Job job = db.Jobs.Find(id);

            if (job == null)
            {
                return null;
            }

            JobTonnage jobTonnage = new JobTonnage()
            {
                TodayTotal = 0M,
                MonthlyTotal = 0M,
                RunningTotal = 0M,

                TonnesLeft = 0M,
                TonnesOrdered = 0M,
                TonnesProcessed = 0M
            };


            //old code end
            if (job != null)
            {
                jobTonnage.TonnesOrdered = job.JobTonnesOrdered;
                jobTonnage.TonnesProcessed = job.JobTonnesRunningTotal;
                jobTonnage.TonnesLeft = job.JobTonnesOrdered - job.JobTonnesRunningTotal;
            }

            return jobTonnage;
        }

        private void LoadTransaction(Transaction transaction)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            LoadData(transaction);
            if ((transaction.LoadType == CoreConstants.Load_Mixed) || (transaction.LoadType == CoreConstants.Load_Standard))
            {
                var multiTransactions = db.Transactions.Where(t => t.Docket == transaction.Docket).ToList();

                transaction.SelectedMixedProducts = new List<Product>();
                foreach (var tran in multiTransactions)
                {
                    var p = db.Products.FirstOrDefault(e => e.ID == tran.ProductID);
                    if (p != null)
                    {
                        p.CurrentAmount = tran.Net;

                        p.CurrentPrice = tran.Price;
                        p.CurrentGST = tran.GST;
                        p.CurrentEPA = tran.EPA;
                        p.CurrentTotalCost = tran.TotalCost;

                        transaction.SelectedMixedProducts.Add(p);
                    }

                }
            }
        }

        public void LoadData(Transaction transaction)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            if (transaction == null) return;

            var job = db.Jobs.FirstOrDefault(e => e.ID == transaction.JobID);
            if (job != null)
            {
                transaction.Job = job;
            }
            else
            {
                transaction.Job = db.Jobs.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Product = db.Products.FirstOrDefault(e => e.ID == transaction.ProductID);
            if (Product != null)
            {
                transaction.Product = Product;
            }
            else
            {
                transaction.Product = db.Products.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var ProductCategory = db.ProductCategories.FirstOrDefault(e => e.ID == transaction.ProductCategoryID);
            if (ProductCategory != null)
            {
                transaction.ProductCategory = ProductCategory;
            }
            else
            {
                transaction.ProductCategory = db.ProductCategories.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Customer = db.Customers.FirstOrDefault(e => e.ID == transaction.CustomerID);
            if (Customer != null)
            {
                transaction.Customer = Customer;
            }
            else
            {
                transaction.Customer = db.Customers.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Destination = db.Destinations.FirstOrDefault(e => e.ID == transaction.DestinationID);
            if (Destination != null)
            {
                transaction.Destination = Destination;
            }
            else
            {
                transaction.Destination = db.Destinations.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Source = db.Sources.FirstOrDefault(e => e.ID == transaction.SourceID);
            if (Source != null)
            {
                transaction.Source = Source;
            }
            else
            {
                transaction.Source = db.Sources.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Vehicle = db.Vehicles.FirstOrDefault(e => e.ID == transaction.VehicleID);
            if (Vehicle != null)
            {
                transaction.Vehicle = Vehicle;
            }
            else
            {
                transaction.Vehicle = db.Vehicles.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Site = db.Sites.FirstOrDefault(e => e.ID == transaction.SiteID);
            if (Site != null)
            {
                transaction.Site = Site;
            }
            else
            {
                transaction.Site = db.Sites.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var Weighman = db.Weighmen.FirstOrDefault(e => e.ID == transaction.WeighmanID);
            if (Weighman != null)
            {
                transaction.Weighman = Weighman;
            }
            else
            {
                transaction.Weighman = db.Weighmen.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }

            var driver = db.Drivers.FirstOrDefault(e => e.ID == transaction.DriverID);
            if (driver != null)
            {
                transaction.Driver = driver;
            }
            else
            {
                transaction.Driver = db.Drivers.FirstOrDefault(e => e.ID == CoreConstants.NA_ID);
            }
        }
        #endregion

        /// <summary>
        /// Get the details of the transaction - Navigate to the edit page from grid edit action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Transaction/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            if (Session["Role"] != null)
            {
                ViewBag.CanNew = (Session["Role"] as Role).CanNewTransaction;
                ViewBag.CanEdit = (Session["Role"] as Role).CanEditTransaction;
                ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTransaction;
            }
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Transactions.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPE_NO_FIRST, entity.LoadType);
            ViewBag.Payments = new SelectList(CoreConstants.PAYMENTS, entity.Payments);
            ViewBag.ChargeRate = new SelectList(CoreConstants.CHARGE_RATES, entity.ChargeRate);
            ViewBag.Direction = new SelectList(CoreConstants.DIRECTIONS, entity.Direction).Where(x => x.Text != CoreConstants.NA);
            ViewBag.VehicleOwner = new SelectList(CoreConstants.OWNERS, entity.VehicleOwner);

            ViewBag.DriverID = new SelectList(db.Drivers.OrderBy(e => e.Name), "ID", "Name", entity.DriverID);
            ViewBag.MarkID = new SelectList(db.Marks.OrderBy(e => e.Name), "ID", "Name", entity.MarkID);
            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories.OrderBy(e => e.Name), "ID", "Name", entity.ProductCategoryID);

            ViewBag.TruckID = new SelectList(db.Trucks.OrderBy(e => e.Name), "ID", "Name", entity.TruckID);
            ViewBag.VehicleID = new SelectList(db.Vehicles.OrderBy(e => e.Name), "ID", "Name", entity.VehicleID);
            ViewBag.VehicleConfigurationID = new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name", entity.VehicleConfigurationID);

            if (logOnSiteIsCentral)
            {
                ViewBag.CustomerID = new SelectList(db.Customers.OrderBy(e => e.Name), "ID", "Name", entity.CustomerID);
                ViewBag.DestinationID = new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name", entity.DestinationID);
                ViewBag.JobID = new SelectList(db.Jobs.OrderBy(e => e.Name), "ID", "Name", entity.JobID);
                ViewBag.ProductID = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name", entity.ProductID);
                ViewBag.SourceID = new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name", entity.SourceID);

                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name", entity.SiteID);
                ViewBag.WeighmanID = new SelectList(db.Weighmen.OrderBy(e => e.Name), "ID", "Name", entity.WeighmanID);
            }
            else
            {
                ViewBag.CustomerID = new SelectList(logOnSite.Customers.OrderBy(e => e.Name), "ID", "Name", entity.CustomerID);
                ViewBag.DestinationID = new SelectList(logOnSite.Destinations.OrderBy(e => e.Name), "ID", "Name", entity.DestinationID);
                ViewBag.JobID = new SelectList(logOnSite.Jobs.OrderBy(e => e.Name), "ID", "Name", entity.JobID);
                ViewBag.ProductID = new SelectList(logOnSite.Products.OrderBy(e => e.Name), "ID", "Name", entity.ProductID);
                ViewBag.SourceID = new SelectList(logOnSite.Sources.OrderBy(e => e.Name), "ID", "Name", entity.SourceID);

                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name", entity.SiteID);
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen.OrderBy(e => e.Name), "ID", "Name", entity.WeighmanID);
            }

            return View(entity);
        }

        // POST: Transaction/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditTransaction")]
        public ActionResult Edit([Bind(Include = "ID,Docket,TransactionDate,Comment,Payments,Direction,VehicleOwner,Registration1,Registration2,Registration3,LoadType,Gross1,Gross2,Gross3,Gross4,Gross5,Tare1,Tare2,Tare3,Tare4,Tare5,Net,OrderNumber,SiteID,WeighmanID,ProductCategoryID,ProductID,CustomerID,DestinationID,SourceID,JobID,TruckID,VehicleID,DriverID,VehicleConfigurationID,Price,EPARate,Haulage,VINNumber,IsManualEntry,CartageCharge,ChargeRate,TareInDate,MinimumCharge,DateStamp,ExportedToAccounting,DeliveryAddress,CustomerDiscount,Deleted")] Transaction updatedTransaction)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTransaction;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTransaction;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTransaction;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");
            string thisPayments = updatedTransaction.Payments;

            if (updatedTransaction.Registration1 == null || string.IsNullOrEmpty(updatedTransaction.Registration1.Trim()))
            {
                ModelState.AddModelError("Registration1", "The Registration1 field is required.");
            }

            if (updatedTransaction.Direction == null || updatedTransaction.Direction == "NA")
            {
                ModelState.AddModelError("Direction", "Please select Direction as IN/OUT.");
            }

            if (updatedTransaction.ProductID <= 1)
            {
                ModelState.AddModelError("ProductID", "Please select Product.");
            }

            if ((updatedTransaction.LoadType == CoreConstants.Load_Second) || (updatedTransaction.LoadType == CoreConstants.Load_StoredTare))
            {
                if (updatedTransaction.Gross <= 0)
                {
                    ModelState.AddModelError("Gross1", "Please enter Gross(t).");
                }
                if (updatedTransaction.Tare <= 0)
                {
                    ModelState.AddModelError("Tare1", "Please enter Tare(t).");
                }
            }

            if (updatedTransaction.LoadType == CoreConstants.Load_Counted)
            {
                if (updatedTransaction.Net <= 0)
                {
                    ModelState.AddModelError("Net", "Please enter counted number in Net(t) field.");
                }
            }

            if (updatedTransaction.LoadType == CoreConstants.Load_Standard)
            {
                if (updatedTransaction.VehicleID <= 1)
                {
                    ModelState.AddModelError("VehicleID", "Please select Vehicle Type.");
                }
            }

            if (ModelState.IsValid)
            {
                if ((updatedTransaction.LoadType == CoreConstants.Load_ManualTare) || (updatedTransaction.LoadType == CoreConstants.Load_Second) || (updatedTransaction.LoadType == CoreConstants.Load_StoredTare))
                {
                    updatedTransaction.Net = Math.Abs(updatedTransaction.Gross - updatedTransaction.Tare);
                }

                if (updatedTransaction.LoadType == CoreConstants.Load_Rego)
                {
                    if (updatedTransaction.Gross > 0 && updatedTransaction.Tare > 0)
                    {
                        updatedTransaction.Net = Math.Abs(updatedTransaction.Gross - updatedTransaction.Tare);
                    }

                    if (updatedTransaction.Gross > 0 && updatedTransaction.Tare == 0)
                    {
                        updatedTransaction.Net = Math.Abs(updatedTransaction.Gross);
                    }

                    if (updatedTransaction.Gross == 0 && updatedTransaction.Tare > 0)
                    {
                        updatedTransaction.Net = Math.Abs(updatedTransaction.Tare);
                    }
                }


                var existingTransactionInfo = (from t in db.Transactions
                                               where t.ID == updatedTransaction.ID
                                               select new { ProductID = t.ProductID, Net = t.Net, Direction = t.Direction, SiteID = t.SiteID, Price = t.Price, EPARate = t.EPARate, GST = t.GST, EPA = t.EPA, CartageCharge = t.CartageCharge, CartageCost = t.CartageCharge, TranCost = t.TranCost, TotalCost = t.TotalCost, Royalty = t.Royalty, Count = t.Count, Haulage = t.Haulage }).FirstOrDefault();

                //calculate prices
                //bool noPriceRecalculation = (updatedTransaction.ProductID == existingTransactionInfo.ProductID) && (updatedTransaction.Net == existingTransactionInfo.Net) && (updatedTransaction.Price == existingTransactionInfo.Price) && (updatedTransaction.EPARate == existingTransactionInfo.EPARate);
                //bool netChangedOnly = (updatedTransaction.LoadType != CoreConstants.Load_Standard) && (updatedTransaction.Net > 0) && (existingTransactionInfo.Net > 0) && (updatedTransaction.Net != existingTransactionInfo.Net) && (updatedTransaction.ProductID == existingTransactionInfo.ProductID) && (updatedTransaction.Price == existingTransactionInfo.Price) && (updatedTransaction.EPARate == existingTransactionInfo.EPARate);


                updatedTransaction.Customer = db.Customers.Find(updatedTransaction.CustomerID); //changes payments to customer lined
                updatedTransaction.Payments = thisPayments; // change it back to post value
                updatedTransaction.Destination = db.Destinations.Find(updatedTransaction.DestinationID);
                updatedTransaction.Source = db.Sources.Find(updatedTransaction.SourceID);
                updatedTransaction.Vehicle = db.Vehicles.Find(updatedTransaction.VehicleID);
                updatedTransaction.Product = db.Products.Find(updatedTransaction.ProductID);
                updatedTransaction.Site = db.Sites.Find(updatedTransaction.SiteID);

                updatedTransaction.Product = db.Products.Find(updatedTransaction.ProductID);
                updatedTransaction.Product.CurrentAmount = updatedTransaction.Net;
                updatedTransaction.Job = db.Jobs.Find(updatedTransaction.JobID);
                if (updatedTransaction.LoadType == CoreConstants.Load_Counted)
                {
                    updatedTransaction.Product.SetCurrentCharges(updatedTransaction, null, null, updatedTransaction.CartageCharge);
                }
                else
                {
                    //updatedTransaction.Product.SetCurrentCharges(updatedTransaction, db.JobProductPrices.ToList(), db.VehicleProductPrices.ToList(), 0, true);
                    updatedTransaction.Product.SetCurrentCharges(updatedTransaction, db.JobProductPrices.ToList(), db.VehicleProductPrices.ToList(), updatedTransaction.CartageCharge, false);
                }
                if (updatedTransaction.LoadType == CoreConstants.Load_Standard)
                {
                    updatedTransaction.Net = (updatedTransaction.Vehicle != null) ? updatedTransaction.Vehicle.NetWeight : 0;
                }
                updatedTransaction.Price = updatedTransaction.Product.CurrentPrice;
                updatedTransaction.EPARate = updatedTransaction.Product.EPALevy;
                updatedTransaction.GST = updatedTransaction.Product.CurrentGST;
                updatedTransaction.EPA = updatedTransaction.Product.CurrentEPA;
                updatedTransaction.CartageCharge = updatedTransaction.Product.CurrentCartage;
                updatedTransaction.CartageGST = updatedTransaction.Product.CurrentCartageGST;
                updatedTransaction.TranCost = updatedTransaction.Product.CurrentTranCost;
                updatedTransaction.TotalCost = updatedTransaction.Product.CurrentTotalCost;
                updatedTransaction.Royalty = updatedTransaction.Product.CurrentRoyalty;
                updatedTransaction.ProductRoyalty = updatedTransaction.Product.Royalty;
                updatedTransaction.Count = updatedTransaction.Product.CurrentCount;
                updatedTransaction.CustomerDiscount = updatedTransaction.Product.CurrentCustomerDiscount;
                updatedTransaction.MinimumCharge = updatedTransaction.Product.CurrentMinimumCharge;

                Truck truckExistsByRego1 = db.Trucks.Where(t => t.Name == updatedTransaction.Registration1).FirstOrDefault();
                updatedTransaction.MaxLoad = (truckExistsByRego1 != null) ? truckExistsByRego1.MaxLoad : 0;

                var existingStockActivation = db.ProductStockActivations.FirstOrDefault(s => s.ProductID == existingTransactionInfo.ProductID && s.SiteID == existingTransactionInfo.SiteID);
                var updateStockActivation = db.ProductStockActivations.FirstOrDefault(s => s.ProductID == updatedTransaction.ProductID && s.SiteID == updatedTransaction.SiteID);
                if (existingStockActivation != null)
                {
                    if ((updatedTransaction.Net != existingTransactionInfo.Net) || (updatedTransaction.Direction != existingTransactionInfo.Direction) || (updatedTransaction.ProductID != existingTransactionInfo.ProductID))
                    {
                        var existingTransaction = db.Transactions.FirstOrDefault(t => t.ID == updatedTransaction.ID);
                        var offsetStockMove = existingTransaction.GenerateOffsetProductStockMovement(existingStockActivation.STOCKLEVEL);
                        existingStockActivation.STOCKLEVEL = offsetStockMove.STOCKLEVEL;
                        existingStockActivation.WeighmanID = updatedTransaction.WeighmanID;
                        db.Entry(existingStockActivation).State = EntityState.Modified;
                        db.ProductStockMovements.Add(offsetStockMove);

                        if (updateStockActivation != null)
                        {
                            var newStockMove = updatedTransaction.GenerateProductStockMovement(updateStockActivation.STOCKLEVEL);
                            updateStockActivation.STOCKLEVEL = newStockMove.STOCKLEVEL;
                            updateStockActivation.WeighmanID = updatedTransaction.WeighmanID;
                            db.Entry(updateStockActivation).State = EntityState.Modified;
                            db.ProductStockMovements.Add(newStockMove);
                        }

                    }

                }

                db.Entry(updatedTransaction).State = EntityState.Modified;
                db.SaveChanges();

                if (updatedTransaction.JobID != CoreConstants.NA_ID)
                {
                    var job = db.Jobs.Find(updatedTransaction.JobID);
                    if (job != null && job.JobTonnesOrdered > 0)
                    {
                        var listOfTrans = db.Transactions.Where(t => t.Deleted == false && t.JobID == updatedTransaction.JobID).ToList();
                        if (listOfTrans != null)
                        {
                            job.JobTonnesRunningTotal = listOfTrans.Sum(t => t.Net);
                            db.Entry(job).State = EntityState.Modified;
                            db.SaveChanges();

                            foreach (var item in db.Sites.Where(s => s.ID > 1).ToList())
                            {
                                ReplicationLogItem logItem = new ReplicationLogItem
                                {
                                    DestinationSiteID = item.ID,
                                    EntityType = "Job",
                                    EntityID = job.ID,
                                    Operation = "U",
                                    SourceSiteID = 1,
                                    LogCreated = DateTime.UtcNow
                                };

                                db.ReplicationLogItems.Add(logItem);
                                db.SaveChanges();
                            }
                        }
                    }
                }

                // if storageconnectionstring is defined, only then generate PDF and upload it to azure storage account.
                string storageConnectionString = GetStorageConnectionString();
                if (storageConnectionString != "")
                {
                    SavePDF(updatedTransaction, storageConnectionString);
                }

                TempData["UserMessage"] = ComposeTempDisplayMessage("Transaction " + updatedTransaction.Docket + " edited successfully!");
                return RedirectToAction("Index");
            }
            ViewBag.LoadType = new SelectList(CoreConstants.LOADTYPE_NO_FIRST, updatedTransaction.LoadType);
            ViewBag.Payments = new SelectList(CoreConstants.PAYMENTS, updatedTransaction.Payments);
            ViewBag.ChargeRate = new SelectList(CoreConstants.CHARGE_RATES, updatedTransaction.ChargeRate);
            ViewBag.Direction = new SelectList(CoreConstants.DIRECTIONS, updatedTransaction.Direction).Where(x => x.Text != CoreConstants.NA);
            ViewBag.VehicleOwner = new SelectList(CoreConstants.OWNERS, updatedTransaction.VehicleOwner);

            ViewBag.DriverID = new SelectList(db.Drivers.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.DriverID);
            ViewBag.MarkID = new SelectList(db.Marks.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.MarkID);
            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.ProductCategoryID);
            ViewBag.TruckID = new SelectList(db.Trucks.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.TruckID);
            ViewBag.VehicleID = new SelectList(db.Vehicles.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.VehicleID);
            ViewBag.VehicleConfigurationID = new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.VehicleConfigurationID);

            if (logOnSiteIsCentral)
            {
                ViewBag.CustomerID = new SelectList(db.Customers.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.CustomerID);
                ViewBag.DestinationID = new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.DestinationID);
                ViewBag.JobID = new SelectList(db.Jobs.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.JobID);
                ViewBag.ProductID = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.ProductID);
                ViewBag.SourceID = new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.SourceID);

                ViewBag.SiteID = new SelectList(db.Sites, "ID", "Name", updatedTransaction.SiteID);
                ViewBag.WeighmanID = new SelectList(db.Weighmen.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.WeighmanID);
            }
            else
            {
                ViewBag.CustomerID = new SelectList(logOnSite.Customers.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.CustomerID);
                ViewBag.DestinationID = new SelectList(logOnSite.Destinations.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.DestinationID);
                ViewBag.JobID = new SelectList(logOnSite.Jobs.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.JobID);
                ViewBag.ProductID = new SelectList(logOnSite.Products.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.ProductID);
                ViewBag.SourceID = new SelectList(logOnSite.Sources.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.SourceID);

                ViewBag.SiteID = new SelectList(logOnSite.ToList(), "ID", "Name", updatedTransaction.SiteID);
                ViewBag.WeighmanID = new SelectList(logOnSite.Weighmen.OrderBy(e => e.Name), "ID", "Name", updatedTransaction.WeighmanID);
            }

            return View(updatedTransaction);
        }

        /// <summary>
        /// Navigate to the delete page by transaction id - from grid delete action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Transaction/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            if (Session["Role"] != null)
            {
                ViewBag.CanNew = (Session["Role"] as Role).CanNewTransaction;
                ViewBag.CanEdit = (Session["Role"] as Role).CanEditTransaction;
                ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTransaction;
            }
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Transactions.Find(id);
            entity.Comment = string.Empty;
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Remove the transaction from the transaction table
        /// </summary>
        /// <param name="id"></param>
        /// <param name="trnModel"></param>
        /// <returns></returns>
        // POST: Transaction/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteTransaction")]
        public ActionResult DeleteConfirmed(int id, Transaction trnModel)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTransaction;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTransaction;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTransaction;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (string.IsNullOrEmpty(trnModel.Comment))
            {
                ModelState.AddModelError("Comment", "Please enter comment.");
                return View(trnModel);
            }

            try
            {
                entity = db.Transactions.Find(id);
                entity.Deleted = true;
                entity.Comment = trnModel.Comment;
                db.Entry(entity).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage("Transaction " + entity.Docket + " deleted successfully!");
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This transaction " + entity.Docket + " is being referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Download transaction by the id and export type
        /// </summary>
        /// <param name="id"></param>
        /// <param name="exportType"></param>
        /// <returns></returns>
        public FileResult Download(string id, int exportType)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            int fid = Convert.ToInt32(id);
            string fileName, filePath;
            ExportFiles fileIndex = new ExportFiles();
            var files = fileIndex.GetFiles(exportType, DataBaseConnectionStringName);
            var aFile = (from f in files
                         where f.FileId == fid
                         select f).FirstOrDefault();

            filePath = aFile.FilePath;
            fileName = aFile.FileName;
            return File(filePath, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);

            //Parameters to file are
            //1. The File Path on the File Server
            //2. The connent type MIME type
            //3. The paraneter for the file save asked by the browser
        }

        /// <summary>
        /// Export transaction based on the date range
        /// </summary>
        /// <param name="dateRangeWithEntities"></param>
        /// <returns></returns>

        [HttpPost]
        [SessionAccess]
        [CheckForAccess("CanNewTransaction")]
        public ActionResult CreateExportFile(DateRangeWithEntities dateRangeWithEntities)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            string DataBaseConnectionStringName = (string)RouteData.Values["connStrName"];


            try
            {
                if (ModelState.IsValid)
                {
                    ExportTransactions(dateRangeWithEntities, DataBaseConnectionStringName);


                    return RedirectToAction("ExportFilesIndex", "Transaction");
                }
            }
            catch (DataException)
            {
                //Log the error (add a variable name after DataException)
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(dateRangeWithEntities);
        }

        /// <summary>
        /// Export files based on the export type
        /// </summary>
        /// <param name="exportType"></param>
        /// <returns></returns>
        // GET: Export Files
        [SessionAccess]
        [CheckForAccess("CanNewTransaction")]
        public ActionResult ExportFilesIndex(int exportType = 0)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            string DataBaseConnectionStringName = (string)RouteData.Values["connStrName"];


            ExportFiles fileIndex = new ExportFiles();
            var files = fileIndex.GetFiles(exportType, DataBaseConnectionStringName);
            ViewBag.IsTransaction = (exportType == 0);
            ViewBag.ExportType = exportType;
            return View(files);
        }

        /// <summary>
        /// Export the transaction to csv file based on the  current date
        /// </summary>
        /// <returns></returns>
        // GET: EPAExportWizard
        [SessionAccess]
        [CheckForAccess("CanNewTransaction")]
        public ActionResult EPAExportWizard()
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];


            DateRangeWithEntities dateRangeWithEntities = new DateRangeWithEntities
            {
                StartDate = DateTime.Today,
                EndDate = DateTime.Today,
                ReportName = "EPAExport_" + DateTime.Now.DateToStringYYYYMMDD() + ".CSV",  //reuse for export file name
            };

            try
            {
                return View(dateRangeWithEntities);
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Get the Transaction list based on the Date Range
        /// </summary>
        /// <param name="dateRangeWithEntities"></param>
        /// <param name="dbname"></param>

        private void ExportTransactions(DateRangeWithEntities dateRangeWithEntities, string dbname)
        {
            var transactions = db.Transactions.Where(e => e.TransactionDate >= dateRangeWithEntities.StartDate && e.TransactionDate <= dateRangeWithEntities.EndDate);
            var trans = transactions.ToList();

            var sites = db.Sites.ToList();
            var productCategories = db.ProductCategories.ToList();
            var customers = db.Customers.ToList();
            var products = db.Products.ToList();
            var destinations = db.Destinations.ToList();
            var sources = db.Sources.ToList();
            var vehicles = db.Vehicles.ToList();
            var trucks = db.Trucks.ToList();


            var entities = from t in trans
                           join s in sites on t.SiteID equals s.ID
                           join pc in productCategories on t.ProductCategoryID equals pc.ID
                           join c in customers on t.CustomerID equals c.ID
                           join p in products on t.ProductID equals p.ID
                           join d in destinations on t.DestinationID equals d.ID
                           join soc in sources on t.SourceID equals soc.ID
                           join tr in trucks on t.TruckID equals tr.ID

                           select new NSWEPAExport
                           {
                               TransactionNumber = t.ID.ToString(),
                               FacilityEPLNumber = s.Code, //use Site.Code to hold Facility EPL Number
                               DateIn = (t.TareInDate == null) ? string.Empty : t.TareInDate.Value.ToShortDateString(),
                               TimeIn = (t.TareInDate == null) ? string.Empty : t.TareInDate.Value.ToShortTimeString(),
                               DateOut = t.TransactionDate.ToShortDateString(),
                               TimeOut = t.TransactionDate.ToShortTimeString(),
                               VehicleRegistration = t.Registration1,
                               VehicleType = CoreConstants.NA,
                               CustomerName = c.Name,
                               CustomerAddress = c.Address1,
                               CustomerABN = c.ABN,
                               PurposeOfEntry = p.NGER_Code,
                               Direction = t.Direction,
                               Gross = (t.Gross1 + t.Gross2 + t.Gross3 + t.Gross4 + t.Gross5).ToString("0.##"),
                               Tare = (t.Tare1 + t.Tare2 + t.Tare3 + t.Tare4 + t.Tare5).ToString("0.##"),
                               Net = t.Net.ToString("0.##"),
                               StoredTare = (t.LoadType == CoreConstants.Load_StoredTare) ? "Yes" : "No",
                               StoredTareDateOfEffect = (tr.LastTareDate == null) ? CoreConstants.NA : tr.LastTareDate.Value.ToShortDateString(),
                               ProductDescription = p.Name,
                               MCC = pc.Name,
                               WasteStream = soc.Waste_Stream,
                               MunicipalSubStream = soc.Sub_Stream,
                               Destination = d.Name,
                               DestinationPurpose = d.EPA_Purpose,
                               Source = soc.OWF_Source,
                               OWP_EPL_Number = soc.OWF_EPL_Number,
                               CountedItem = (t.LoadType == CoreConstants.Load_Counted) ? t.Net.ToString() : CoreConstants.NA,
                               ManualEntry = (t.IsManualEntry) ? "Yes" : "No",
                               ManualEntryDateTime = (t.IsManualEntry) ? t.TransactionDate.ToString() : CoreConstants.NA,
                               ApprovalNumber = p.EPA_Din,
                               LevyStatus = p.EPA_Status,
                               Reportable = (p.Report_To_EPA) ? "Yes" : "No",
                               LevyAmount = t.EPA.ToString("0.##"),
                               EPALevyRate = t.EPARate.ToString("0.##"),
                               TransactionCompleted = "Yes",
                               DocketNumber = t.Docket,
                               Comment = t.Comment,

                           };

            List<string> recordList = new List<string> { NSWEPAExport.ExportHead };

            foreach (var r in entities)
            {
                recordList.Add(r.ToString());
            }

            string folderPath = (string.IsNullOrEmpty(dbname)) ? "~/ExportFiles/Transactions" : "~/ExportFiles/Transactions/" + dbname.ToLower();
            DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(folderPath));
            var pathName = dirInfo.FullName + @"\";

            System.IO.File.WriteAllLines(pathName + dateRangeWithEntities.ReportName, recordList);
        }

        /// <summary>
        /// Export the transaction based on the form values and page number
        /// </summary>
        /// <param name="formCollection"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        // GET: ExportWizard
        [SessionAccess]
        [CheckForAccess("CanNewTransaction")]
        public ActionResult ExportWizard(FormCollection formCollection, int? page)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            string DataBaseConnectionStringName = (string)RouteData.Values["connStrName"];

            SetViewBagValues();
            foreach (var key in formCollection.AllKeys)
            {
                var value = formCollection[key];
            }
            var UId = int.Parse(Session["CurrentWeighmanID"].ToString());
            var exportWiz = db.ExportWizard.SingleOrDefault(c => c.WeighmenID == UId) ?? new ExportWizard() { FromDate = DateTime.Now, ToDate = DateTime.Now, Range = true };

            FilterTransactions(exportWiz);

            var model = new ExportWizardViewModel()
            {
                ExportWizard = exportWiz,
                Transactions = entities.ToList()

            };
            ViewBag.SiteID = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", exportWiz.SiteID);
            ViewBag.IsEurobodallaClient = (DataBaseConnectionStringName == "Eurobodalla");

            pageNumber = (page ?? 1);

            try
            {
                return View(model);
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Here Transactions exported based on the WizardModel and page number
        /// </summary>
        /// <param name="model"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        // POST: ExportWizard/
        [HttpPost]
        [SessionAccess]
        [CheckForAccess("CanNewTransaction")]
        public ActionResult ExportWizard(ExportWizardViewModel model, int? page)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            string DataBaseConnectionStringName = (string)RouteData.Values["connStrName"];

            model.Transactions = TempData["Transactions"] as List<Transaction>;
            var UId = int.Parse(Session["CurrentWeighmanID"].ToString());
            var exportWiz = db.ExportWizard.SingleOrDefault(c => c.WeighmenID == UId) ?? new ExportWizard() { FromDate = DateTime.Now, ToDate = DateTime.Now, Range = true, Account = "1" };
            ViewBag.SiteID = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", model.ExportWizard.SiteID);
            if (exportWiz.WeighmenID > 0)
            {
                model.ExportWizard.WeighmenID = UId;
                model.ExportWizard.ID = exportWiz.ID;

                var exportwizardToUpdate = db.ExportWizard.Find(model.ExportWizard.ID);
                exportwizardToUpdate.Range = model.ExportWizard.Range;
                exportwizardToUpdate.FromDate = model.ExportWizard.FromDate;
                exportwizardToUpdate.ToDate = model.ExportWizard.ToDate;
                exportwizardToUpdate.FromInvoiceNumber = model.ExportWizard.FromInvoiceNumber;
                exportwizardToUpdate.ToInvoiceNumber = model.ExportWizard.ToInvoiceNumber;
                exportwizardToUpdate.OrderBy = model.ExportWizard.OrderBy;
                exportwizardToUpdate.Account = model.ExportWizard.Account;
                exportwizardToUpdate.CheckedList = model.ExportWizard.CheckedList;
                exportwizardToUpdate.TransColumnsList = model.ExportWizard.TransColumnsList;
                exportwizardToUpdate.SiteID = model.ExportWizard.SiteID;

                if (TryUpdateModel(exportwizardToUpdate, "",
                         new string[] { "Range", "FromDate", "ToDate", "FromInvoiceNumber", "ToInvoiceNumber", "Account", "OrderBy", "CheckedList", "TransColumnsList", "SiteID" }))

                    db.SaveChanges();
            }

            else
            {
                model.ExportWizard.WeighmenID = UId;
                db.ExportWizard.Add(model.ExportWizard);
                db.SaveChanges();
            }

            model.Transactions = FilterTransactions(model.ExportWizard);

            TempData["Transactions"] = model.Transactions;

            var vmmodel = new ExportWizardViewModel()
            {
                ExportWizard = model.ExportWizard,
                Transactions = model.Transactions

            };
            pageNumber = (page ?? 1);
            try
            {
                return View(vmmodel);
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Export the transactions to CSV
        /// based on the Transaction Ids, Name, Date Range and SiteId
        /// </summary>
        /// <param name="ids"></param>
        /// <param name="names"></param>
        /// <param name="orderby"></param>
        /// <param name="checkedlist"></param>
        /// <param name="trascolumnslist"></param>
        /// <param name="siteid"></param>
        /// <param name="fromdate"></param>
        /// <param name="todate"></param>
        /// <param name="account"></param>
        /// <returns></returns>

        [SessionAccess]
        public FileStreamResult ExportCSV_Transaction(string ids, string names, string orderby, string checkedlist, string trascolumnslist, int siteid, DateTime fromdate, DateTime todate, string account)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            //DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            //if (DataBaseConnectionStringName == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            //if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            //{
            //    RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            //}

            //logOnSite = GetSiteFromSession(db);
            //if (logOnSite == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            if (account == "2")
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid && e.Deleted == true);
            else if (account == "3")
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid);
            else if (account == "4")
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid && e.Deleted == false && e.ExportedToAccounting == true);
            else if (account == "5")
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid && e.Deleted == false && e.ExportedToAccounting == false);
            else
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid && e.Deleted == false);


            if (entities != null && entities.Count() > 0)
            {
                ids = string.Join(",", entities.Select(t => t.ID.ToString()));
            }

            if (!String.IsNullOrEmpty(ids) && !String.IsNullOrEmpty(names))
            {
                var UId = int.Parse(Session["CurrentWeighmanID"].ToString());
                var exportWiz = db.ExportWizard.SingleOrDefault(c => c.WeighmenID == UId) ?? new ExportWizard() { FromDate = DateTime.Now, ToDate = DateTime.Now };

                if (exportWiz.WeighmenID > 0)
                {
                    var exportwizardToUpdate = db.ExportWizard.Find(exportWiz.ID);

                    exportwizardToUpdate.OrderBy = orderby;
                    exportwizardToUpdate.CheckedList = checkedlist;
                    exportwizardToUpdate.TransColumnsList = trascolumnslist;
                    exportwizardToUpdate.SiteID = siteid;
                    exportwizardToUpdate.Account = account;
                    exportwizardToUpdate.FromDate = fromdate;
                    exportwizardToUpdate.ToDate = todate;

                    if (TryUpdateModel(exportwizardToUpdate, "",
                             new string[] { "OrderBy", "CheckedList", "TransColumnsList", "SiteID", "Account", "FromDate", "ToDate" }))

                        db.SaveChanges();
                }
                else
                {
                    var expWiz = new ExportWizard() { };

                    expWiz.WeighmenID = UId;
                    expWiz.CheckedList = checkedlist;
                    expWiz.TransColumnsList = trascolumnslist;
                    expWiz.Range = true;
                    expWiz.FromDate = fromdate;
                    expWiz.ToDate = todate;
                    expWiz.Account = account;
                    expWiz.OrderBy = orderby;
                    expWiz.SiteID = siteid;
                    db.ExportWizard.Add(expWiz);
                    db.SaveChanges();

                }

                string[] transactionIds = ids.Split(',');
                string[] expnames = names.Split(',');


                //below added to improve the performance                
                //db.Database.ExecuteSqlCommand("update transactions set ExportedToAccounting='true' where ID in (" + string.Join(", ", transactionIds.Select(int.Parse)) + ")");

                int[] myint = Array.ConvertAll<string, int>(transactionIds, int.Parse);
                var newListquery = from t in db.Transactions
                                   join s in db.Sites on t.SiteID equals s.ID
                                   join j in db.Jobs on t.JobID equals j.ID
                                   join p in db.Products on t.ProductID equals p.ID
                                   join d in db.Destinations on t.DestinationID equals d.ID
                                   join so in db.Sources on t.SourceID equals so.ID
                                   join w in db.Weighmen on t.WeighmanID equals w.ID
                                   join tr in db.Trucks on t.TruckID equals tr.ID
                                   join m in db.Marks on t.MarkID equals m.ID
                                   join dr in db.Drivers on t.DriverID equals dr.ID
                                   join vc in db.VehicleConfigurations on t.VehicleConfigurationID equals vc.ID
                                   join pc in db.ProductCategories on t.ProductCategoryID equals pc.ID
                                   join v in db.Vehicles on t.VehicleID equals v.ID
                                   join c in db.Customers on t.CustomerID equals c.ID
                                   where myint.Contains(t.ID)
                                   select new
                                   {
                                       ID = t.ID,
                                       Docket = t.Docket,
                                       SiteName = s.Name,
                                       CustomerName = c.Name,
                                       ProductName = p.Name,
                                       DestinationName = d.Name,
                                       SourceName = so.Name,
                                       JobName = j.Name,
                                       TruckName = t.Registration1,
                                       TruckName2 = t.Registration2,
                                       TruckName3 = t.Registration3,
                                       VehicleConfigurationName = vc.Name,
                                       TransactionDate = t.TransactionDate,
                                       SiteCode = s.Code,
                                       Direction = t.Direction,
                                       VehicleOwner = t.VehicleOwner,
                                       Payments = t.Payments,
                                       ProductCode = p.Code,
                                       ProductType = p.ProductType,
                                       ProductEPA_Din = p.EPA_Din,
                                       ProductNGER_Code = p.NGER_Code,
                                       ProductReport_To_EPA = p.Report_To_EPA,
                                       ProductEPA_Status = p.EPA_Status,
                                       ProductCategoryName = pc.Name,
                                       DestinationCode = d.Code,
                                       DestinationEPA_Purpose = d.EPA_Purpose,
                                       SourceCode = so.Code,
                                       SourceWaste_Stream = so.Waste_Stream,
                                       SourceSub_Stream = so.Sub_Stream,
                                       SourceOWF_Source = so.OWF_Source,
                                       SourceOWF_EPL_Number = so.OWF_EPL_Number,
                                       WeighmanName = w.Name,
                                       CustomerAccountNumber = c.AccountNumber,
                                       CustomerABN = c.ABN,
                                       CustomerComment = c.Comment,
                                       TruckIsStoredTare = tr.IsStoredTare,
                                       TruckLastTareDate = tr.LastTareDate,
                                       JobID = j.ID,
                                       JobOrderNumber = j.OrderNumber,
                                       DriverName = dr.Name,
                                       MarkName = m.Name,
                                       Gross1 = t.Gross1,
                                       Gross2 = t.Gross2,
                                       Gross3 = t.Gross3,
                                       Gross4 = t.Gross4,
                                       Tare1 = t.Tare1,
                                       Tare2 = t.Tare2,
                                       Tare3 = t.Tare3,
                                       Tare4 = t.Tare4,
                                       Net = t.Net,
                                       Price = t.Price,
                                       TranCost = t.TranCost,
                                       GST = t.GST,
                                       EPA = t.EPA,
                                       TotalCost = t.TotalCost,
                                       CartageCharge = t.CartageCharge,
                                       Comment = t.Comment,
                                       VehicleName = v.Name,
                                       ProductCurrentEPA = 0,//p.CurrentEPA,
                                       Net_Weighed = (t.LoadType != CoreConstants.Load_Counted) ? t.Net : 0,
                                       Net_Counted = (t.LoadType == CoreConstants.Load_Counted) ? t.Net : 0,
                                       LoadType = t.LoadType,
                                       ProductWeightPerItem = p.ToVolumeFactor,
                                       CartageGST = t.CartageGST,
                                       TranCustomerDiscount = t.CustomerDiscount
                                   };

                if (newListquery != null && newListquery.Count() > 0)
                {
                    if (orderby == "Docket")
                    {
                        newListquery = newListquery.OrderBy(o => o.Docket);
                    }
                    else if (orderby == "SiteName")
                    {
                        newListquery = newListquery.OrderBy(o => o.SiteName);
                    }
                    else if (orderby == "Customer")
                    {
                        newListquery = newListquery.OrderBy(o => o.CustomerName);
                    }
                    else if (orderby == "Product")
                    {
                        newListquery = newListquery.OrderBy(o => o.ProductName);
                    }
                    else if (orderby == "Destination")
                    {
                        newListquery = newListquery.OrderBy(o => o.DestinationName);
                    }
                    else if (orderby == "Source")
                    {
                        newListquery = newListquery.OrderBy(o => o.SourceName);
                    }
                    else if (orderby == "Job")
                    {
                        newListquery = newListquery.OrderBy(o => o.JobName);
                    }
                    else if (orderby == "Truck")
                    {
                        newListquery = newListquery.OrderBy(o => o.TruckName);
                    }
                    else
                    {
                        newListquery = newListquery.OrderBy(o => o.ID);
                    }


                    List<string> result = ids.Split(',').ToList();
                    List<string> Exportnames = names.Split(',').ToList();

                    var sb = new StringBuilder();
                    StringBuilder sbResult = new StringBuilder();
                    sbResult.Append(names);
                    char[] csvTokens = new[] { '\"', ',', '\n', '\r' };

                    foreach (var listItem in newListquery)
                    {
                        sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                        StringBuilder temp = new StringBuilder();
                        StringBuilder tempValue = new StringBuilder();
                        foreach (var item in expnames)
                        {
                            if (item == "TransactionDate")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TransactionDate.ToString("dd/MM/yyyy"))) : temp.Append(listItem.TransactionDate.ToString("dd/MM/yyyy"));
                            }
                            if (item == "TransactionTime")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TransactionDate.ToShortTimeString())) : temp.Append(listItem.TransactionDate.ToShortTimeString());
                            }
                            if (item == "SiteName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SiteName)) : temp.Append(listItem.SiteName);
                            }
                            if (item == "SiteCode")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SiteCode)) : temp.Append(listItem.SiteCode);
                            }
                            if (item == "Docket")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + string.Format("Docket #{0}", listItem.Docket))) : temp.Append(string.Format("Docket #{0}", listItem.Docket));
                            }
                            if (item == "RefDocket")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Docket)) : temp.Append(listItem.Docket);
                            }
                            if (item == "TruckName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckName)) : temp.Append(listItem.TruckName);
                            }
                            if (item == "VehicleConfigurationName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.VehicleConfigurationName)) : temp.Append(listItem.VehicleConfigurationName);
                            }
                            if (item == "Direction")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Direction)) : temp.Append(listItem.Direction);
                            }
                            if (item == "VehicleOwner")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.VehicleOwner)) : temp.Append(listItem.VehicleOwner);
                            }
                            if (item == "Payments")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Payments)) : temp.Append(listItem.Payments);
                            }
                            if (item == "ProductName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductName)) : temp.Append(listItem.ProductName);
                            }
                            if (item == "ProductCode")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductCode)) : temp.Append(listItem.ProductCode);
                            }
                            if (item == "ProductType")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductType)) : temp.Append(listItem.ProductType);
                            }
                            if (item == "Product_EPA_Din")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductEPA_Din)) : temp.Append(listItem.ProductEPA_Din);
                            }
                            if (item == "Product_NGER_Code")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductNGER_Code)) : temp.Append(listItem.ProductNGER_Code);
                            }
                            if (item == "Product_Report_To_EPA")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductReport_To_EPA)) : temp.Append(listItem.ProductReport_To_EPA);
                            }
                            if (item == "Product_EPA_Status")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductEPA_Status)) : temp.Append(listItem.ProductEPA_Status);
                            }
                            if (item == "Product_CurrentEPA")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductCurrentEPA)) : temp.Append(listItem.ProductCurrentEPA);
                            }

                            if (item == "ProductCategoryName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductCategoryName)) : temp.Append(listItem.ProductCategoryName);
                            }
                            if (item == "DestinationName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.DestinationName)) : temp.Append(listItem.DestinationName);
                            }
                            if (item == "DestinationCode")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.DestinationCode)) : temp.Append(listItem.DestinationCode);
                            }
                            if (item == "Destination_EPA_Purpose")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.DestinationEPA_Purpose)) : temp.Append(listItem.DestinationEPA_Purpose);
                            }
                            if (item == "SourceName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceName)) : temp.Append(listItem.SourceName);
                            }
                            if (item == "SourceCode")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceCode)) : temp.Append(listItem.SourceCode);
                            }
                            if (item == "Source_Waste_Stream")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceWaste_Stream)) : temp.Append(listItem.SourceWaste_Stream);
                            }
                            if (item == "Source_Sub_Stream")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceSub_Stream)) : temp.Append(listItem.SourceSub_Stream);
                            }
                            if (item == "Source_OWF_Source")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceOWF_Source)) : temp.Append(listItem.SourceOWF_Source);
                            }
                            if (item == "Source_OWF_EPL_Number")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceOWF_EPL_Number)) : temp.Append(listItem.SourceOWF_EPL_Number);
                            }
                            if (item == "WeighmanName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.WeighmanName)) : temp.Append(listItem.WeighmanName);
                            }
                            if (item == "CustomerName")
                            {
                                var customername = "";
                                if (listItem.CustomerName.Contains(","))
                                    customername = String.Format("\"{0}\"", listItem.CustomerName);
                                else
                                    customername = listItem.CustomerName;

                                temp = temp.Length > 0 ? (temp.Append("," + customername)) : temp.Append(customername);
                            }
                            if (item == "CustomerAccountNumber")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CustomerAccountNumber)) : temp.Append(listItem.CustomerAccountNumber);
                            }
                            if (item == "CustomerABN")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CustomerABN)) : temp.Append(listItem.CustomerABN);
                            }
                            if (item == "CustomerComment")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CustomerComment)) : temp.Append(listItem.CustomerComment);
                            }

                            if (item == "TruckIsStoredTare")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckIsStoredTare)) : temp.Append(listItem.TruckIsStoredTare);
                            }
                            if (item == "TruckLastTareDate")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckLastTareDate)) : temp.Append(listItem.TruckLastTareDate);
                            }
                            if (item == "JobName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.JobName)) : temp.Append(listItem.JobName);
                            }
                            if (item == "JobID")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.JobID)) : temp.Append(listItem.JobID);
                            }
                            if (item == "JobOrderNumber")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.JobOrderNumber)) : temp.Append(listItem.JobOrderNumber);
                            }
                            if (item == "DriverName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.DriverName)) : temp.Append(listItem.DriverName);
                            }
                            if (item == "MarkName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.MarkName)) : temp.Append(listItem.MarkName);
                            }
                            if (item == "Gross1")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Gross1)) : temp.Append(listItem.Gross1);
                            }
                            if (item == "Gross2")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Gross2)) : temp.Append(listItem.Gross2);
                            }
                            if (item == "Gross3")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Gross3)) : temp.Append(listItem.Gross3);
                            }
                            if (item == "Gross4")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Gross4)) : temp.Append(listItem.Gross4);
                            }
                            if (item == "Tare1")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Tare1)) : temp.Append(listItem.Tare1);
                            }
                            if (item == "Tare2")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Tare2)) : temp.Append(listItem.Tare2);
                            }
                            if (item == "Tare3")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Tare3)) : temp.Append(listItem.Tare3);
                            }
                            if (item == "Tare4")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Tare4)) : temp.Append(listItem.Tare4);
                            }
                            if (item == "Net")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Net)) : temp.Append(listItem.Net);
                            }

                            if (item == "JobProductPrices")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Price)) : temp.Append(listItem.Price);
                            }
                            if (item == "TranCost")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TranCost)) : temp.Append(listItem.TranCost);
                            }
                            if (item == "GST")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.GST)) : temp.Append(listItem.GST);
                            }
                            if (item == "EPA")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.EPA)) : temp.Append(listItem.EPA);
                            }
                            if (item == "CartageCharge")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CartageCharge)) : temp.Append(listItem.CartageCharge);
                            }
                            if (item == "TotalCost")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TotalCost)) : temp.Append(listItem.TotalCost);
                            }
                            if (item == "VehicleType_Name")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.VehicleName)) : temp.Append(listItem.VehicleName);
                            }
                            if (item == "Comment")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Comment)) : temp.Append(listItem.Comment);
                            }
                            if (item == "Net(Weighed)")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Net_Weighed)) : temp.Append(listItem.Net_Weighed);
                            }
                            if (item == "Net(Counted)")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Net_Counted)) : temp.Append(listItem.Net_Counted);
                            }
                            if (item == "TruckName2")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckName2)) : temp.Append(listItem.TruckName2);
                            }
                            if (item == "TruckName3")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckName3)) : temp.Append(listItem.TruckName3);
                            }
                            if (item == "LoadType")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.LoadType)) : temp.Append(listItem.LoadType);
                            }
                            if (item == "Product_WeightPerItem")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductWeightPerItem)) : temp.Append(listItem.ProductWeightPerItem);
                            }
                            if (item == "CartageGST")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CartageGST)) : temp.Append(listItem.CartageGST);
                            }
                            if (item == "TranCustomerDiscount")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TranCustomerDiscount)) : temp.Append(listItem.TranCustomerDiscount);
                            }
                            if (item == "TotalGST")
                            {
                                decimal totGst = listItem.GST + listItem.CartageGST;
                                temp = temp.Length > 0 ? (temp.Append("," + totGst)) : temp.Append(totGst);
                            }
                        }
                        sbResult.Append(temp.ToString());
                    }

                    var string_with_your_data = sbResult.ToString();
                    var byteArray1 = Encoding.ASCII.GetBytes(string_with_your_data);
                    var stream1 = new MemoryStream(byteArray1);
                    return File(stream1, "text/plain", "Exported_Transactions_" + DateTime.Now.ToString() + ".csv");
                }
                else
                {
                    var string_with_data2 = "no data avilable";
                    var byteArray2 = Encoding.ASCII.GetBytes(string_with_data2);
                    var stream2 = new MemoryStream(byteArray2);
                    return File(stream2, "text/plain", "Exported_Transactions_" + DateTime.Now.ToString() + ".csv");
                }
            }

            var string_with_data = "no data avilable";
            var byteArray = Encoding.ASCII.GetBytes(string_with_data);
            var stream = new MemoryStream(byteArray);
            return File(stream, "text/plain", "Exported_Transactions_" + DateTime.Now.ToString() + ".csv");
        }

        /// <summary>
        /// Export Transacions based on the Transaction ids, Name, Date Rane and Site Id
        /// </summary>
        /// <param name="ids"></param>
        /// <param name="names"></param>
        /// <param name="orderby"></param>
        /// <param name="checkedlist"></param>
        /// <param name="trascolumnslist"></param>
        /// <param name="siteid"></param>
        /// <param name="fromdate"></param>
        /// <param name="todate"></param>
        /// <param name="account"></param>
        /// <param name="isForNavSys"></param>
        /// <returns></returns>
        //[HttpPost]
        [SessionAccess]
        public FileStreamResult ExportText_Transaction(string ids, string names, string orderby, string checkedlist, string trascolumnslist, int siteid, DateTime fromdate, DateTime todate, string account, bool isForNavSys = false)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            //DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            //if (DataBaseConnectionStringName == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            //if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            //{
            //    RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            //}

            //logOnSite = GetSiteFromSession(db);
            //if (logOnSite == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            if (account == "2")
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid && e.Deleted == true);
            else if (account == "3")
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid);
            else if (account == "4")
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid && e.Deleted == false && e.ExportedToAccounting == true);
            else if (account == "5")
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid && e.Deleted == false && e.ExportedToAccounting == false);
            else
                entities = db.Transactions.Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(todate.Date)) && e.SiteID == siteid && e.Deleted == false);

            ids = string.Join(",", entities.Select(t => t.ID.ToString()));

            if (!String.IsNullOrEmpty(ids) && !String.IsNullOrEmpty(names))
            {
                var UId = int.Parse(Session["CurrentWeighmanID"].ToString());
                var exportWiz = db.ExportWizard.SingleOrDefault(c => c.WeighmenID == UId) ?? new ExportWizard() { FromDate = DateTime.Now, ToDate = DateTime.Now };

                if (exportWiz.WeighmenID > 0)
                {
                    var exportwizardToUpdate = db.ExportWizard.Find(exportWiz.ID);

                    exportwizardToUpdate.OrderBy = orderby;
                    exportwizardToUpdate.CheckedList = checkedlist;
                    exportwizardToUpdate.TransColumnsList = trascolumnslist;
                    exportwizardToUpdate.SiteID = siteid;
                    exportwizardToUpdate.Account = account;
                    exportwizardToUpdate.FromDate = fromdate;
                    exportwizardToUpdate.ToDate = todate;

                    if (TryUpdateModel(exportwizardToUpdate, "",
                             new string[] { "OrderBy", "CheckedList", "TransColumnsList", "SiteID", "Account", "FromDate", "ToDate" }))

                        db.SaveChanges();
                }
                else
                {
                    var expWiz = new ExportWizard() { };

                    expWiz.WeighmenID = UId;
                    expWiz.CheckedList = checkedlist;
                    expWiz.TransColumnsList = trascolumnslist;
                    expWiz.Range = true;
                    expWiz.FromDate = fromdate;
                    expWiz.ToDate = todate;
                    expWiz.Account = account;
                    expWiz.OrderBy = orderby;
                    expWiz.SiteID = siteid;
                    db.ExportWizard.Add(expWiz);
                    db.SaveChanges();

                }
                string[] transactionIds = ids.Split(',');
                string[] expnames = names.Split(',');

                //below added to improve the performance                
                //db.Database.ExecuteSqlCommand("update transactions set ExportedToAccounting='true' where ID in (" + string.Join(", ", transactionIds.Select(int.Parse)) + ")");

                int[] myint = Array.ConvertAll<string, int>(transactionIds, int.Parse);
                var newListquery = from t in db.Transactions
                                   join s in db.Sites on t.SiteID equals s.ID
                                   join j in db.Jobs on t.JobID equals j.ID
                                   join p in db.Products on t.ProductID equals p.ID
                                   join d in db.Destinations on t.DestinationID equals d.ID
                                   join so in db.Sources on t.SourceID equals so.ID
                                   join w in db.Weighmen on t.WeighmanID equals w.ID
                                   join tr in db.Trucks on t.TruckID equals tr.ID
                                   join m in db.Marks on t.MarkID equals m.ID
                                   join dr in db.Drivers on t.DriverID equals dr.ID
                                   join vc in db.VehicleConfigurations on t.VehicleConfigurationID equals vc.ID
                                   join pc in db.ProductCategories on t.ProductCategoryID equals pc.ID
                                   join v in db.Vehicles on t.VehicleID equals v.ID
                                   join c in db.Customers on t.CustomerID equals c.ID
                                   where myint.Contains(t.ID)
                                   select new
                                   {
                                       ID = t.ID,
                                       Docket = t.Docket,
                                       SiteName = s.Name,
                                       CustomerName = c.Name,
                                       ProductName = p.Name,
                                       DestinationName = d.Name,
                                       SourceName = so.Name,
                                       JobName = j.Name,
                                       TruckName = t.Registration1,
                                       TruckName2 = t.Registration2,
                                       TruckName3 = t.Registration3,
                                       VehicleConfigurationName = vc.Name,
                                       TransactionDate = t.TransactionDate,
                                       SiteCode = s.Code,
                                       Direction = t.Direction,
                                       VehicleOwner = t.VehicleOwner,
                                       Payments = t.Payments,
                                       ProductCode = p.Code,
                                       ProductType = p.ProductType,
                                       ProductEPA_Din = p.EPA_Din,
                                       ProductNGER_Code = p.NGER_Code,
                                       ProductReport_To_EPA = p.Report_To_EPA,
                                       ProductEPA_Status = p.EPA_Status,
                                       ProductCategoryName = pc.Name,
                                       DestinationCode = d.Code,
                                       DestinationEPA_Purpose = d.EPA_Purpose,
                                       SourceCode = so.Code,
                                       SourceWaste_Stream = so.Waste_Stream,
                                       SourceSub_Stream = so.Sub_Stream,
                                       SourceOWF_Source = so.OWF_Source,
                                       SourceOWF_EPL_Number = so.OWF_EPL_Number,
                                       WeighmanName = w.Name,
                                       CustomerAccountNumber = c.AccountNumber,
                                       CustomerABN = c.ABN,
                                       CustomerComment = c.Comment,
                                       TruckIsStoredTare = tr.IsStoredTare,
                                       TruckLastTareDate = tr.LastTareDate,
                                       JobID = j.ID,
                                       JobOrderNumber = j.OrderNumber,
                                       DriverName = dr.Name,
                                       MarkName = m.Name,
                                       Gross1 = t.Gross1,
                                       Gross2 = t.Gross2,
                                       Gross3 = t.Gross3,
                                       Gross4 = t.Gross4,
                                       Tare1 = t.Tare1,
                                       Tare2 = t.Tare2,
                                       Tare3 = t.Tare3,
                                       Tare4 = t.Tare4,
                                       Net = t.Net,
                                       Price = t.Price,
                                       TranCost = t.TranCost,
                                       GST = t.GST,
                                       EPA = t.EPA,
                                       TotalCost = t.TotalCost,
                                       CartageCharge = t.CartageCharge,
                                       Comment = t.Comment,
                                       VehicleName = v.Name,
                                       ProductCurrentEPA = 0,//p.CurrentEPA,
                                       Net_Weighed = (t.LoadType != CoreConstants.Load_Counted) ? t.Net : 0,
                                       Net_Counted = (t.LoadType == CoreConstants.Load_Counted) ? t.Net : 0,
                                       LoadType = t.LoadType,
                                       ProductWeightPerItem = p.ToVolumeFactor,
                                       CartageGST = t.CartageGST,
                                       TranCustomerDiscount = t.CustomerDiscount
                                   };

                if (newListquery != null && newListquery.Count() > 0)
                {
                    if (orderby == "Docket")
                    {
                        newListquery = newListquery.OrderBy(o => o.Docket);
                    }
                    else if (orderby == "SiteName")
                    {
                        newListquery = newListquery.OrderBy(o => o.SiteName);
                    }
                    else if (orderby == "Customer")
                    {
                        newListquery = newListquery.OrderBy(o => o.CustomerName);
                    }
                    else if (orderby == "Product")
                    {
                        newListquery = newListquery.OrderBy(o => o.ProductName);
                    }
                    else if (orderby == "Destination")
                    {
                        newListquery = newListquery.OrderBy(o => o.DestinationName);
                    }
                    else if (orderby == "Source")
                    {
                        newListquery = newListquery.OrderBy(o => o.SourceName);
                    }
                    else if (orderby == "Job")
                    {
                        newListquery = newListquery.OrderBy(o => o.JobName);
                    }
                    else if (orderby == "Truck")
                    {
                        newListquery = newListquery.OrderBy(o => o.TruckName);
                    }
                    else
                    {
                        newListquery = newListquery.OrderBy(o => o.ID);
                    }


                    List<string> result = ids.Split(',').ToList();
                    List<string> Exportnames = names.Split(',').ToList();

                    var sb = new StringBuilder();
                    StringBuilder sbResult = new StringBuilder();
                    sbResult.Append(names);
                    char[] csvTokens = new[] { '\"', ',', '\n', '\r' };

                    foreach (var listItem in newListquery)
                    {
                        sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                        StringBuilder temp = new StringBuilder();
                        StringBuilder tempValue = new StringBuilder();
                        foreach (var item in expnames)
                        {
                            if (item == "TransactionDate")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TransactionDate.ToString("dd/MM/yyyy"))) : temp.Append(listItem.TransactionDate.ToString("dd/MM/yyyy"));
                            }
                            if (item == "TransactionTime")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TransactionDate.ToShortTimeString())) : temp.Append(listItem.TransactionDate.ToShortTimeString());
                            }
                            if (item == "SiteName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SiteName)) : temp.Append(listItem.SiteName);
                            }
                            if (item == "SiteCode")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SiteCode)) : temp.Append(listItem.SiteCode);
                            }
                            if (item == "Docket")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + string.Format("Docket #{0}", listItem.Docket))) : temp.Append(string.Format("Docket #{0}", listItem.Docket));
                            }
                            if (item == "RefDocket")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Docket)) : temp.Append(listItem.Docket);
                            }
                            if (item == "TruckName")
                            {
                                if (isForNavSys)
                                {
                                    temp = temp.Length > 0 ? (temp.Append(" " + listItem.TruckName)) : temp.Append(listItem.TruckName);
                                }
                                else
                                {
                                    temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckName)) : temp.Append(listItem.TruckName);
                                }
                            }
                            if (item == "VehicleConfigurationName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.VehicleConfigurationName)) : temp.Append(listItem.VehicleConfigurationName);
                            }
                            if (item == "Direction")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Direction)) : temp.Append(listItem.Direction);
                            }
                            if (item == "VehicleOwner")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.VehicleOwner)) : temp.Append(listItem.VehicleOwner);
                            }
                            if (item == "Payments")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Payments)) : temp.Append(listItem.Payments);
                            }
                            if (item == "ProductName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductName)) : temp.Append(listItem.ProductName);
                            }
                            if (item == "ProductCode")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductCode)) : temp.Append(listItem.ProductCode);
                            }
                            if (item == "ProductType")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductType)) : temp.Append(listItem.ProductType);
                            }
                            if (item == "Product_EPA_Din")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductEPA_Din)) : temp.Append(listItem.ProductEPA_Din);
                            }
                            if (item == "Product_NGER_Code")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductNGER_Code)) : temp.Append(listItem.ProductNGER_Code);
                            }
                            if (item == "Product_Report_To_EPA")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductReport_To_EPA)) : temp.Append(listItem.ProductReport_To_EPA);
                            }
                            if (item == "Product_EPA_Status")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductEPA_Status)) : temp.Append(listItem.ProductEPA_Status);
                            }
                            if (item == "Product_CurrentEPA")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductCurrentEPA)) : temp.Append(listItem.ProductCurrentEPA);
                            }

                            if (item == "ProductCategoryName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductCategoryName)) : temp.Append(listItem.ProductCategoryName);
                            }
                            if (item == "DestinationName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.DestinationName)) : temp.Append(listItem.DestinationName);
                            }
                            if (item == "DestinationCode")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.DestinationCode)) : temp.Append(listItem.DestinationCode);
                            }
                            if (item == "Destination_EPA_Purpose")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.DestinationEPA_Purpose)) : temp.Append(listItem.DestinationEPA_Purpose);
                            }
                            if (item == "SourceName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceName)) : temp.Append(listItem.SourceName);
                            }
                            if (item == "SourceCode")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceCode)) : temp.Append(listItem.SourceCode);
                            }
                            if (item == "Source_Waste_Stream")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceWaste_Stream)) : temp.Append(listItem.SourceWaste_Stream);
                            }
                            if (item == "Source_Sub_Stream")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceSub_Stream)) : temp.Append(listItem.SourceSub_Stream);
                            }
                            if (item == "Source_OWF_Source")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceOWF_Source)) : temp.Append(listItem.SourceOWF_Source);
                            }
                            if (item == "Source_OWF_EPL_Number")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.SourceOWF_EPL_Number)) : temp.Append(listItem.SourceOWF_EPL_Number);
                            }
                            if (item == "WeighmanName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.WeighmanName)) : temp.Append(listItem.WeighmanName);
                            }
                            if (item == "CustomerName")
                            {
                                var customername = "";
                                if (listItem.CustomerName.Contains(","))
                                    customername = String.Format("\"{0}\"", listItem.CustomerName);
                                else
                                    customername = listItem.CustomerName;

                                temp = temp.Length > 0 ? (temp.Append("," + customername)) : temp.Append(customername);
                            }
                            if (item == "CustomerAccountNumber")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CustomerAccountNumber)) : temp.Append(listItem.CustomerAccountNumber);
                            }
                            if (item == "CustomerABN")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CustomerABN)) : temp.Append(listItem.CustomerABN);
                            }
                            if (item == "CustomerComment")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CustomerComment)) : temp.Append(listItem.CustomerComment);
                            }

                            if (item == "TruckIsStoredTare")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckIsStoredTare)) : temp.Append(listItem.TruckIsStoredTare);
                            }
                            if (item == "TruckLastTareDate")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckLastTareDate)) : temp.Append(listItem.TruckLastTareDate);
                            }
                            if (item == "JobName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.JobName)) : temp.Append(listItem.JobName);
                            }
                            if (item == "JobID")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.JobID)) : temp.Append(listItem.JobID);
                            }
                            if (item == "JobOrderNumber")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.JobOrderNumber)) : temp.Append(listItem.JobOrderNumber);
                            }
                            if (item == "DriverName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.DriverName)) : temp.Append(listItem.DriverName);
                            }
                            if (item == "MarkName")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.MarkName)) : temp.Append(listItem.MarkName);
                            }
                            if (item == "Gross1")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Gross1)) : temp.Append(listItem.Gross1);
                            }
                            if (item == "Gross2")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Gross2)) : temp.Append(listItem.Gross2);
                            }
                            if (item == "Gross3")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Gross3)) : temp.Append(listItem.Gross3);
                            }
                            if (item == "Gross4")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Gross4)) : temp.Append(listItem.Gross4);
                            }
                            if (item == "Tare1")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Tare1)) : temp.Append(listItem.Tare1);
                            }
                            if (item == "Tare2")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Tare2)) : temp.Append(listItem.Tare2);
                            }
                            if (item == "Tare3")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Tare3)) : temp.Append(listItem.Tare3);
                            }
                            if (item == "Tare4")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Tare4)) : temp.Append(listItem.Tare4);
                            }
                            if (item == "Net")
                            {
                                if (isForNavSys)
                                {
                                    temp = temp.Length > 0 ? (temp.Append(" " + listItem.Net + "T")) : temp.Append(listItem.Net);
                                }
                                else
                                {
                                    temp = temp.Length > 0 ? (temp.Append("," + listItem.Net)) : temp.Append(listItem.Net);
                                }
                            }

                            if (item == "JobProductPrices")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Price)) : temp.Append(listItem.Price);
                            }
                            if (item == "TranCost")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TranCost)) : temp.Append(listItem.TranCost);
                            }
                            if (item == "GST")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.GST)) : temp.Append(listItem.GST);
                            }
                            if (item == "EPA")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.EPA)) : temp.Append(listItem.EPA);
                            }
                            if (item == "CartageCharge")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CartageCharge)) : temp.Append(listItem.CartageCharge);
                            }
                            if (item == "TotalCost")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TotalCost)) : temp.Append(listItem.TotalCost);
                            }
                            if (item == "VehicleType_Name")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.VehicleName)) : temp.Append(listItem.VehicleName);
                            }
                            if (item == "Comment")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Comment)) : temp.Append(listItem.Comment);
                            }
                            if (item == "Net(Weighed)")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Net_Weighed)) : temp.Append(listItem.Net_Weighed);
                            }
                            if (item == "Net(Counted)")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.Net_Counted)) : temp.Append(listItem.Net_Counted);
                            }
                            if (item == "TruckName2")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckName2)) : temp.Append(listItem.TruckName2);
                            }
                            if (item == "TruckName3")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TruckName3)) : temp.Append(listItem.TruckName3);
                            }
                            if (item == "LoadType")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.LoadType)) : temp.Append(listItem.LoadType);
                            }
                            if (item == "Product_WeightPerItem")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductWeightPerItem)) : temp.Append(listItem.ProductWeightPerItem);
                            }
                            if (item == "CartageGST")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.CartageGST)) : temp.Append(listItem.CartageGST);
                            }
                            if (item == "TranCustomerDiscount")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + listItem.TranCustomerDiscount)) : temp.Append(listItem.TranCustomerDiscount);
                            }
                            if (item == "TotalGST")
                            {
                                decimal totGst = listItem.GST + listItem.CartageGST;
                                temp = temp.Length > 0 ? (temp.Append("," + totGst)) : temp.Append(totGst);
                            }
                        }
                        sbResult.Append(temp.ToString());
                    }

                    var string_with_your_data = sbResult.ToString();
                    var byteArray1 = Encoding.ASCII.GetBytes(string_with_your_data);
                    var stream1 = new MemoryStream(byteArray1);
                    return File(stream1, "text/plain", "Exported_Transactions_" + DateTime.Now.ToString() + ".txt");
                }
                else
                {
                    var string_with_data2 = "no data avilable";
                    var byteArray2 = Encoding.ASCII.GetBytes(string_with_data2);
                    var stream2 = new MemoryStream(byteArray2);
                    return File(stream2, "text/plain", "Exported_Transactions_" + DateTime.Now.ToString() + ".txt");
                }
            }

            var string_with_data = "no data avilable";
            var byteArray = Encoding.ASCII.GetBytes(string_with_data);
            var stream = new MemoryStream(byteArray);
            return File(stream, "text/plain", "Exported_Transactions_" + DateTime.Now.ToString() + ".txt");
        }

        [SessionAccess]
        [CheckForAccess("CanNewTransaction")]
        public ActionResult ExportAccountReports()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            string DataBaseConnectionStringName = (string)RouteData.Values["connStrName"];

            ViewBag.AllSites = db.Sites.Where(s => s.ID > 1).ToList();
            ViewBag.sDate = DateTime.Now.Date.ToString("yyyy-MM-dd");
            ViewBag.eDate = DateTime.Now.Date.ToString("yyyy-MM-dd");
            ViewBag.IsCHRCClient = DataBaseConnectionStringName.ToLower() == "chrc" ? true : false;
            return View();
        }

        /// <summary>
        /// Export Account CHRC Authority Report To CSV
        /// </summary>
        /// <param name="siteid">Site Id.</param>
        /// <param name="fromdate">From date.</param>
        /// <param name="todate">To date.</param>
        /// <returns>File stream.</returns>
        [SessionAccess]
        public FileStreamResult ExportAccountCHRCAuthorityReportToCSV(int siteid, DateTime fromdate, DateTime todate)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            //DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            //if (DataBaseConnectionStringName == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            //if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            //{
            //    RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            //}

            //logOnSite = GetSiteFromSession(db);
            //if (logOnSite == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            var newListquery = from t in db.Transactions
                               join s in db.Sites on t.SiteID equals s.ID
                               join j in db.Jobs on t.JobID equals j.ID
                               join p in db.Products on t.ProductID equals p.ID
                               join d in db.Destinations on t.DestinationID equals d.ID
                               join so in db.Sources on t.SourceID equals so.ID
                               join w in db.Weighmen on t.WeighmanID equals w.ID
                               join tr in db.Trucks on t.TruckID equals tr.ID
                               join m in db.Marks on t.MarkID equals m.ID
                               join dr in db.Drivers on t.DriverID equals dr.ID
                               join vc in db.VehicleConfigurations on t.VehicleConfigurationID equals vc.ID
                               join pc in db.ProductCategories on t.ProductCategoryID equals pc.ID
                               join v in db.Vehicles on t.VehicleID equals v.ID
                               join c in db.Customers on t.CustomerID equals c.ID
                               where t.SiteID == siteid && t.Deleted == false && (DbFunctions.TruncateTime(t.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(t.TransactionDate) <= DbFunctions.TruncateTime(todate.Date))
                               select new
                               {
                                   ID = t.ID,
                                   Docket = t.Docket,
                                   SiteName = s.Name,
                                   CustomerName = c.Name,
                                   ProductName = p.Name,
                                   DestinationName = d.Name,
                                   SourceName = so.Name,
                                   JobName = j.Name,
                                   TruckName = t.Registration1,
                                   TruckName2 = t.Registration2,
                                   TruckName3 = t.Registration3,
                                   VehicleConfigurationName = vc.Name,
                                   TransactionDate = t.TransactionDate,
                                   SiteCode = s.Code,
                                   Direction = t.Direction,
                                   VehicleOwner = t.VehicleOwner,
                                   Payments = t.Payments,
                                   ProductCode = p.Code,
                                   ProductType = p.ProductType,
                                   ProductEPA_Din = p.EPA_Din,
                                   ProductNGER_Code = p.NGER_Code,
                                   ProductReport_To_EPA = p.Report_To_EPA,
                                   ProductEPA_Status = p.EPA_Status,
                                   ProductCategoryName = pc.Name,
                                   DestinationCode = d.Code,
                                   DestinationEPA_Purpose = d.EPA_Purpose,
                                   SourceCode = so.Code,
                                   SourceWaste_Stream = so.Waste_Stream,
                                   SourceSub_Stream = so.Sub_Stream,
                                   SourceOWF_Source = so.OWF_Source,
                                   SourceOWF_EPL_Number = so.OWF_EPL_Number,
                                   WeighmanName = w.Name,
                                   CustomerAccountNumber = c.AccountNumber,
                                   CustomerABN = c.ABN,
                                   CustomerComment = c.Comment,
                                   TruckIsStoredTare = tr.IsStoredTare,
                                   TruckLastTareDate = tr.LastTareDate,
                                   JobID = j.ID,
                                   JobOrderNumber = j.OrderNumber,
                                   DriverName = dr.Name,
                                   MarkName = m.Name,
                                   Gross1 = t.Gross1,
                                   Gross2 = t.Gross2,
                                   Gross3 = t.Gross3,
                                   Gross4 = t.Gross4,
                                   Tare1 = t.Tare1,
                                   Tare2 = t.Tare2,
                                   Tare3 = t.Tare3,
                                   Tare4 = t.Tare4,
                                   Net = t.Net,
                                   Price = t.Price,
                                   TranCost = t.TranCost,
                                   GST = t.GST,
                                   EPA = t.EPA,
                                   TotalCost = t.TotalCost,
                                   CartageCharge = t.CartageCharge,
                                   Comment = t.Comment,
                                   VehicleName = v.Name,
                                   ProductCurrentEPA = 0,//p.CurrentEPA,
                                   Net_Weighed = (t.LoadType != CoreConstants.Load_Counted) ? t.Net : 0,
                                   Net_Counted = (t.LoadType == CoreConstants.Load_Counted) ? t.Net : 0,
                                   LoadType = t.LoadType,
                                   ProductWeightPerItem = p.ToVolumeFactor,
                                   CartageGST = t.CartageGST,
                                   TranCustomerDiscount = t.CustomerDiscount,
                                   ProductLedgerAccount = p.LedgerAccount,
                                   TranOrderNumber = t.OrderNumber
                               };

            if (newListquery != null && newListquery.Count() > 0)
            {
                List<string> expnames = new List<string>() { "Payments", "CustomerAccountNumber", "WONumber_ProductLedgerAccount","ProductLedgerAccount","SiteCode","TransactionDate",
                "TotalCost","GSTFreeOrNot","All","TranOrderNumber","NotinUseCartage","FromDate","ToDate"};
                var sb = new StringBuilder();
                StringBuilder sbResult = new StringBuilder();

                foreach (var listItem in newListquery)
                {
                    sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                    StringBuilder temp = new StringBuilder();

                    foreach (var item in expnames)
                    {
                        if (item == "Payments")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.Payments)) : temp.Append(listItem.Payments);
                        }
                        //Debtor number
                        if (item == "CustomerAccountNumber")
                        {
                            string dnumber = string.Format("{0}.0{1}", listItem.CustomerAccountNumber, listItem.SiteCode);
                            temp = temp.Length > 0 ? (temp.Append("," + dnumber)) : temp.Append(dnumber);
                        }
                        //WO number & Product code
                        if (item == "WONumber_ProductLedgerAccount")
                        {
                            var jobnameSplitArr = listItem.JobName.Split(' ').ToArray();
                            string formatedStr = string.Format("{0}.{1}", (jobnameSplitArr.Count() > 0) ? jobnameSplitArr[0] : "", listItem.ProductLedgerAccount);
                            temp = temp.Length > 0 ? (temp.Append("," + formatedStr)) : temp.Append(formatedStr);
                        }
                        //Product code
                        if (item == "ProductLedgerAccount")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductLedgerAccount)) : temp.Append(listItem.ProductLedgerAccount);
                        }

                        //SiteCode
                        if (item == "SiteCode")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.SiteCode)) : temp.Append(listItem.SiteCode);
                        }

                        //TransactionDate
                        if (item == "TransactionDate")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.TransactionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : temp.Append(listItem.TransactionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                        }

                        if (item == "TotalCost")
                        {
                            decimal totTranCost = listItem.TranCost + listItem.GST;
                            temp = temp.Length > 0 ? (temp.Append("," + totTranCost)) : temp.Append(totTranCost);
                        }

                        //GST or GST free
                        if (item == "GSTFreeOrNot")
                        {
                            //21 for including GST, 23 for excluding GST
                            int gstCode = listItem.GST > 0 ? 21 : 23;
                            temp = temp.Length > 0 ? (temp.Append("," + gstCode)) : temp.Append(gstCode);
                        }

                        //PONumber,DocketNumber,DatePurchased,Product,tonnage,amount per tonne excluding GST
                        if (item == "All")
                        {
                            string allformat = string.Empty;
                            allformat = string.Format("{0};{1};{2};{3};{4};{5}", listItem.TranOrderNumber, listItem.Docket, listItem.TransactionDate.ToString("dd/MM/yy", CultureInfo.InvariantCulture), listItem.ProductName, listItem.Net, listItem.Price);
                            temp = temp.Length > 0 ? (temp.Append("," + allformat)) : temp.Append(allformat);
                        }

                        //PO Number
                        if (item == "TranOrderNumber")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.TranOrderNumber)) : temp.Append(listItem.TranOrderNumber);
                        }

                        //NotinUseCartage
                        if (item == "NotinUseCartage")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + 0)) : temp.Append(0);
                        }

                        //Date from
                        if (item == "FromDate")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + fromdate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : temp.Append(fromdate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                        }

                        //Date to
                        if (item == "ToDate")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + todate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : temp.Append(todate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                        }

                    }

                    sbResult.Append(temp.ToString());

                    //for cartage row
                    if (listItem.CartageCharge > 0)
                    {
                        sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                        StringBuilder tempCartage = new StringBuilder();

                        foreach (var item in expnames)
                        {
                            if (item == "Payments")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.Payments)) : tempCartage.Append(listItem.Payments);
                            }
                            //Debtor number
                            if (item == "CustomerAccountNumber")
                            {
                                string dnumber = string.Format("{0}.0{1}", listItem.CustomerAccountNumber, listItem.SiteCode);
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + dnumber)) : tempCartage.Append(dnumber);
                            }
                            //WO number & Product code
                            if (item == "WONumber_ProductLedgerAccount")
                            {
                                var jobnameSplitArr = listItem.JobName.Split(' ').ToArray();
                                string formatedStr = string.Format("{0}.{1}", (jobnameSplitArr.Count() > 0) ? jobnameSplitArr[0] : "", 9118);//for cartage 9118 is the code
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + formatedStr)) : tempCartage.Append(formatedStr);
                            }
                            //Product code
                            if (item == "ProductLedgerAccount")
                            {
                                // tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.ProductLedgerAccount)) : tempCartage.Append(listItem.ProductLedgerAccount);
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + 9118)) : tempCartage.Append(9118);
                            }

                            //SiteCode
                            if (item == "SiteCode")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.SiteCode)) : tempCartage.Append(listItem.SiteCode);
                            }

                            //TransactionDate
                            if (item == "TransactionDate")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.TransactionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : tempCartage.Append(listItem.TransactionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                            }

                            if (item == "TotalCost")
                            {
                                //tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.TotalCost)) : tempCartage.Append(listItem.TotalCost);
                                decimal totCartageCost = listItem.CartageCharge + listItem.CartageGST;
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + totCartageCost)) : tempCartage.Append(totCartageCost);
                            }

                            //GST or GST free
                            if (item == "GSTFreeOrNot")
                            {
                                //21 for including GST, 23 for excluding GST
                                int gstCode = listItem.GST > 0 ? 21 : 23;
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + gstCode)) : tempCartage.Append(gstCode);
                            }

                            //PONumber,DocketNumber,DatePurchased,Product,tonnage
                            if (item == "All")
                            {
                                string allformat = string.Empty;
                                allformat = string.Format("{0};{1};{2};{3};{4}", "Cartage", listItem.Docket, listItem.TransactionDate.ToString("dd/MM/yy", CultureInfo.InvariantCulture), listItem.ProductName, listItem.Net);
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + allformat)) : tempCartage.Append(allformat);
                            }

                            //PO Number
                            if (item == "TranOrderNumber")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.TranOrderNumber)) : tempCartage.Append(listItem.TranOrderNumber);
                            }

                            //NotinUseCartage
                            if (item == "NotinUseCartage")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + 0)) : tempCartage.Append(0);
                            }

                            //Date from
                            if (item == "FromDate")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + fromdate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : tempCartage.Append(fromdate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                            }

                            //Date to
                            if (item == "ToDate")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + todate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : tempCartage.Append(todate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                            }

                        }

                        sbResult.Append(tempCartage.ToString());
                    }
                }

                var string_with_your_data = sbResult.ToString();
                var byteArray1 = Encoding.ASCII.GetBytes(string_with_your_data);
                var stream1 = new MemoryStream(byteArray1);
                return File(stream1, "text/plain", "Exported_Authority_Report_" + DateTime.Now.ToString() + ".csv");
            }
            else
            {
                var string_with_data2 = "no data avilable";
                var byteArray2 = Encoding.ASCII.GetBytes(string_with_data2);
                var stream2 = new MemoryStream(byteArray2);
                return File(stream2, "text/plain", "Exported_Authority_Report_" + DateTime.Now.ToString() + ".csv");
            }
        }

        /// <summary>
        /// Export Account CHRC Authority Report To TXT
        /// </summary>
        /// <param name="siteid">Site Id.</param>
        /// <param name="fromdate">From date.</param>
        /// <param name="todate">To date.</param>
        /// <returns>File stream.</returns>
        [SessionAccess]
        public FileStreamResult ExportAccountCHRCAuthorityReportToTXT(int siteid, DateTime fromdate, DateTime todate)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            //DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            //if (DataBaseConnectionStringName == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            //if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            //{
            //    RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            //}

            //logOnSite = GetSiteFromSession(db);
            //if (logOnSite == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            var newListquery = from t in db.Transactions
                               join s in db.Sites on t.SiteID equals s.ID
                               join j in db.Jobs on t.JobID equals j.ID
                               join p in db.Products on t.ProductID equals p.ID
                               join d in db.Destinations on t.DestinationID equals d.ID
                               join so in db.Sources on t.SourceID equals so.ID
                               join w in db.Weighmen on t.WeighmanID equals w.ID
                               join tr in db.Trucks on t.TruckID equals tr.ID
                               join m in db.Marks on t.MarkID equals m.ID
                               join dr in db.Drivers on t.DriverID equals dr.ID
                               join vc in db.VehicleConfigurations on t.VehicleConfigurationID equals vc.ID
                               join pc in db.ProductCategories on t.ProductCategoryID equals pc.ID
                               join v in db.Vehicles on t.VehicleID equals v.ID
                               join c in db.Customers on t.CustomerID equals c.ID
                               where t.SiteID == siteid && t.Deleted == false && (DbFunctions.TruncateTime(t.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(t.TransactionDate) <= DbFunctions.TruncateTime(todate.Date))
                               select new
                               {
                                   ID = t.ID,
                                   Docket = t.Docket,
                                   SiteName = s.Name,
                                   CustomerName = c.Name,
                                   ProductName = p.Name,
                                   DestinationName = d.Name,
                                   SourceName = so.Name,
                                   JobName = j.Name,
                                   TruckName = t.Registration1,
                                   TruckName2 = t.Registration2,
                                   TruckName3 = t.Registration3,
                                   VehicleConfigurationName = vc.Name,
                                   TransactionDate = t.TransactionDate,
                                   SiteCode = s.Code,
                                   Direction = t.Direction,
                                   VehicleOwner = t.VehicleOwner,
                                   Payments = t.Payments,
                                   ProductCode = p.Code,
                                   ProductType = p.ProductType,
                                   ProductEPA_Din = p.EPA_Din,
                                   ProductNGER_Code = p.NGER_Code,
                                   ProductReport_To_EPA = p.Report_To_EPA,
                                   ProductEPA_Status = p.EPA_Status,
                                   ProductCategoryName = pc.Name,
                                   DestinationCode = d.Code,
                                   DestinationEPA_Purpose = d.EPA_Purpose,
                                   SourceCode = so.Code,
                                   SourceWaste_Stream = so.Waste_Stream,
                                   SourceSub_Stream = so.Sub_Stream,
                                   SourceOWF_Source = so.OWF_Source,
                                   SourceOWF_EPL_Number = so.OWF_EPL_Number,
                                   WeighmanName = w.Name,
                                   CustomerAccountNumber = c.AccountNumber,
                                   CustomerABN = c.ABN,
                                   CustomerComment = c.Comment,
                                   TruckIsStoredTare = tr.IsStoredTare,
                                   TruckLastTareDate = tr.LastTareDate,
                                   JobID = j.ID,
                                   JobOrderNumber = j.OrderNumber,
                                   DriverName = dr.Name,
                                   MarkName = m.Name,
                                   Gross1 = t.Gross1,
                                   Gross2 = t.Gross2,
                                   Gross3 = t.Gross3,
                                   Gross4 = t.Gross4,
                                   Tare1 = t.Tare1,
                                   Tare2 = t.Tare2,
                                   Tare3 = t.Tare3,
                                   Tare4 = t.Tare4,
                                   Net = t.Net,
                                   Price = t.Price,
                                   TranCost = t.TranCost,
                                   GST = t.GST,
                                   EPA = t.EPA,
                                   TotalCost = t.TotalCost,
                                   CartageCharge = t.CartageCharge,
                                   Comment = t.Comment,
                                   VehicleName = v.Name,
                                   ProductCurrentEPA = 0,//p.CurrentEPA,
                                   Net_Weighed = (t.LoadType != CoreConstants.Load_Counted) ? t.Net : 0,
                                   Net_Counted = (t.LoadType == CoreConstants.Load_Counted) ? t.Net : 0,
                                   LoadType = t.LoadType,
                                   ProductWeightPerItem = p.ToVolumeFactor,
                                   CartageGST = t.CartageGST,
                                   TranCustomerDiscount = t.CustomerDiscount,
                                   ProductLedgerAccount = p.LedgerAccount,
                                   TranOrderNumber = t.OrderNumber
                               };

            if (newListquery != null && newListquery.Count() > 0)
            {
                List<string> expnames = new List<string>() { "Payments", "CustomerAccountNumber", "WONumber_ProductLedgerAccount","ProductLedgerAccount","SiteCode","TransactionDate",
                "TotalCost","GSTFreeOrNot","All","TranOrderNumber","NotinUseCartage","FromDate","ToDate"};
                var sb = new StringBuilder();
                StringBuilder sbResult = new StringBuilder();

                foreach (var listItem in newListquery)
                {
                    sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                    StringBuilder temp = new StringBuilder();

                    foreach (var item in expnames)
                    {
                        if (item == "Payments")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.Payments)) : temp.Append(listItem.Payments);
                        }
                        //Debtor number
                        if (item == "CustomerAccountNumber")
                        {
                            string dnumber = string.Format("{0}.0{1}", listItem.CustomerAccountNumber, listItem.SiteCode);
                            temp = temp.Length > 0 ? (temp.Append("," + dnumber)) : temp.Append(dnumber);
                        }
                        //WO number & Product code
                        if (item == "WONumber_ProductLedgerAccount")
                        {
                            var jobnameSplitArr = listItem.JobName.Split(' ').ToArray();
                            string formatedStr = string.Format("{0}.{1}", (jobnameSplitArr.Count() > 0) ? jobnameSplitArr[0] : "", listItem.ProductLedgerAccount);
                            temp = temp.Length > 0 ? (temp.Append("," + formatedStr)) : temp.Append(formatedStr);
                        }
                        //Product code
                        if (item == "ProductLedgerAccount")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductLedgerAccount)) : temp.Append(listItem.ProductLedgerAccount);
                        }

                        //SiteCode
                        if (item == "SiteCode")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.SiteCode)) : temp.Append(listItem.SiteCode);
                        }

                        //TransactionDate
                        if (item == "TransactionDate")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.TransactionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : temp.Append(listItem.TransactionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                        }

                        if (item == "TotalCost")
                        {
                            decimal totTranCost = listItem.TranCost + listItem.GST;
                            temp = temp.Length > 0 ? (temp.Append("," + totTranCost)) : temp.Append(totTranCost);
                        }

                        //GST or GST free
                        if (item == "GSTFreeOrNot")
                        {
                            //21 for including GST, 23 for excluding GST
                            int gstCode = listItem.GST > 0 ? 21 : 23;
                            temp = temp.Length > 0 ? (temp.Append("," + gstCode)) : temp.Append(gstCode);
                        }

                        //PONumber,DocketNumber,DatePurchased,Product,tonnage,amount per tonne excluding GST
                        if (item == "All")
                        {
                            string allformat = string.Empty;
                            allformat = string.Format("{0};{1};{2};{3};{4};{5}", listItem.TranOrderNumber, listItem.Docket, listItem.TransactionDate.ToString("dd/MM/yy", CultureInfo.InvariantCulture), listItem.ProductName, listItem.Net, listItem.Price);
                            temp = temp.Length > 0 ? (temp.Append("," + allformat)) : temp.Append(allformat);
                        }

                        //PO Number
                        if (item == "TranOrderNumber")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.TranOrderNumber)) : temp.Append(listItem.TranOrderNumber);
                        }

                        //NotinUseCartage
                        if (item == "NotinUseCartage")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + 0)) : temp.Append(0);
                        }

                        //Date from
                        if (item == "FromDate")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + fromdate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : temp.Append(fromdate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                        }

                        //Date to
                        if (item == "ToDate")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + todate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : temp.Append(todate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                        }

                    }

                    sbResult.Append(temp.ToString());

                    //for cartage row
                    if (listItem.CartageCharge > 0)
                    {
                        sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                        StringBuilder tempCartage = new StringBuilder();

                        foreach (var item in expnames)
                        {
                            if (item == "Payments")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.Payments)) : tempCartage.Append(listItem.Payments);
                            }
                            //Debtor number
                            if (item == "CustomerAccountNumber")
                            {
                                string dnumber = string.Format("{0}.0{1}", listItem.CustomerAccountNumber, listItem.SiteCode);
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + dnumber)) : tempCartage.Append(dnumber);
                            }
                            //WO number & Product code
                            if (item == "WONumber_ProductLedgerAccount")
                            {
                                var jobnameSplitArr = listItem.JobName.Split(' ').ToArray();
                                string formatedStr = string.Format("{0}.{1}", (jobnameSplitArr.Count() > 0) ? jobnameSplitArr[0] : "", 9118);//for cartage 9118 is the code
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + formatedStr)) : tempCartage.Append(formatedStr);
                            }
                            //Product code
                            if (item == "ProductLedgerAccount")
                            {
                                // tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.ProductLedgerAccount)) : tempCartage.Append(listItem.ProductLedgerAccount);
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + 9118)) : tempCartage.Append(9118);
                            }

                            //SiteCode
                            if (item == "SiteCode")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.SiteCode)) : tempCartage.Append(listItem.SiteCode);
                            }

                            //TransactionDate
                            if (item == "TransactionDate")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.TransactionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : tempCartage.Append(listItem.TransactionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                            }

                            if (item == "TotalCost")
                            {
                                //tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.TotalCost)) : tempCartage.Append(listItem.TotalCost);
                                decimal totCartageCost = listItem.CartageCharge + listItem.CartageGST;
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + totCartageCost)) : tempCartage.Append(totCartageCost);
                            }

                            //GST or GST free
                            if (item == "GSTFreeOrNot")
                            {
                                //21 for including GST, 23 for excluding GST
                                int gstCode = listItem.GST > 0 ? 21 : 23;
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + gstCode)) : tempCartage.Append(gstCode);
                            }

                            //PONumber,DocketNumber,DatePurchased,Product,tonnage,amount per tonne excluding GST
                            if (item == "All")
                            {
                                string allformat = string.Empty;
                                allformat = string.Format("{0};{1};{2};{3};{4}", "Cartage", listItem.Docket, listItem.TransactionDate.ToString("dd/MM/yy", CultureInfo.InvariantCulture), listItem.ProductName, listItem.Net);
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + allformat)) : tempCartage.Append(allformat);
                            }

                            //PO Number
                            if (item == "TranOrderNumber")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + listItem.TranOrderNumber)) : tempCartage.Append(listItem.TranOrderNumber);
                            }

                            //NotinUseCartage
                            if (item == "NotinUseCartage")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + 0)) : tempCartage.Append(0);
                            }

                            //Date from
                            if (item == "FromDate")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + fromdate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : tempCartage.Append(fromdate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                            }

                            //Date to
                            if (item == "ToDate")
                            {
                                tempCartage = tempCartage.Length > 0 ? (tempCartage.Append("," + todate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture))) : tempCartage.Append(todate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture));
                            }

                        }

                        sbResult.Append(tempCartage.ToString());
                    }
                }

                var string_with_your_data = sbResult.ToString();
                var byteArray1 = Encoding.ASCII.GetBytes(string_with_your_data);
                var stream1 = new MemoryStream(byteArray1);
                return File(stream1, "text/plain", "Exported_Authority_Report_" + DateTime.Now.ToString() + ".txt");
            }
            else
            {
                var string_with_data2 = "no data avilable";
                var byteArray2 = Encoding.ASCII.GetBytes(string_with_data2);
                var stream2 = new MemoryStream(byteArray2);
                return File(stream2, "text/plain", "Exported_Authority_Report_" + DateTime.Now.ToString() + ".txt");
            }
        }

        /// <summary>
        /// Export Account CHRC Stock Transaction Report To CSV
        /// </summary>
        /// <param name="siteid">Site Id.</param>
        /// <param name="fromdate">From date.</param>
        /// <param name="todate">To date.</param>
        /// <returns>file stream.</returns>
        [SessionAccess]
        public FileStreamResult ExportAccountCHRCStockTransactionReportToCSV(int siteid, DateTime fromdate, DateTime todate)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            //DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            //if (DataBaseConnectionStringName == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            //if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            //{
            //    RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            //}

            //logOnSite = GetSiteFromSession(db);
            //if (logOnSite == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            var newListquery = from t in db.Transactions
                               join s in db.Sites on t.SiteID equals s.ID
                               join j in db.Jobs on t.JobID equals j.ID
                               join p in db.Products on t.ProductID equals p.ID
                               join d in db.Destinations on t.DestinationID equals d.ID
                               join so in db.Sources on t.SourceID equals so.ID
                               join w in db.Weighmen on t.WeighmanID equals w.ID
                               join tr in db.Trucks on t.TruckID equals tr.ID
                               join m in db.Marks on t.MarkID equals m.ID
                               join dr in db.Drivers on t.DriverID equals dr.ID
                               join vc in db.VehicleConfigurations on t.VehicleConfigurationID equals vc.ID
                               join pc in db.ProductCategories on t.ProductCategoryID equals pc.ID
                               join v in db.Vehicles on t.VehicleID equals v.ID
                               join c in db.Customers on t.CustomerID equals c.ID
                               where t.SiteID == siteid && t.Deleted == false && (DbFunctions.TruncateTime(t.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(t.TransactionDate) <= DbFunctions.TruncateTime(todate.Date))
                               select new
                               {
                                   ID = t.ID,
                                   Docket = t.Docket,
                                   SiteName = s.Name,
                                   CustomerName = c.Name,
                                   ProductName = p.Name,
                                   DestinationName = d.Name,
                                   SourceName = so.Name,
                                   JobName = j.Name,
                                   TruckName = t.Registration1,
                                   TruckName2 = t.Registration2,
                                   TruckName3 = t.Registration3,
                                   VehicleConfigurationName = vc.Name,
                                   TransactionDate = t.TransactionDate,
                                   SiteCode = s.Code,
                                   Direction = t.Direction,
                                   VehicleOwner = t.VehicleOwner,
                                   Payments = t.Payments,
                                   ProductCode = p.Code,
                                   ProductType = p.ProductType,
                                   ProductEPA_Din = p.EPA_Din,
                                   ProductNGER_Code = p.NGER_Code,
                                   ProductReport_To_EPA = p.Report_To_EPA,
                                   ProductEPA_Status = p.EPA_Status,
                                   ProductCategoryName = pc.Name,
                                   DestinationCode = d.Code,
                                   DestinationEPA_Purpose = d.EPA_Purpose,
                                   SourceCode = so.Code,
                                   SourceWaste_Stream = so.Waste_Stream,
                                   SourceSub_Stream = so.Sub_Stream,
                                   SourceOWF_Source = so.OWF_Source,
                                   SourceOWF_EPL_Number = so.OWF_EPL_Number,
                                   WeighmanName = w.Name,
                                   CustomerAccountNumber = c.AccountNumber,
                                   CustomerABN = c.ABN,
                                   CustomerComment = c.Comment,
                                   TruckIsStoredTare = tr.IsStoredTare,
                                   TruckLastTareDate = tr.LastTareDate,
                                   JobID = j.ID,
                                   JobOrderNumber = j.OrderNumber,
                                   DriverName = dr.Name,
                                   MarkName = m.Name,
                                   Gross1 = t.Gross1,
                                   Gross2 = t.Gross2,
                                   Gross3 = t.Gross3,
                                   Gross4 = t.Gross4,
                                   Tare1 = t.Tare1,
                                   Tare2 = t.Tare2,
                                   Tare3 = t.Tare3,
                                   Tare4 = t.Tare4,
                                   Net = t.Net,
                                   Price = t.Price,
                                   TranCost = t.TranCost,
                                   GST = t.GST,
                                   EPA = t.EPA,
                                   TotalCost = t.TotalCost,
                                   CartageCharge = t.CartageCharge,
                                   Comment = t.Comment,
                                   VehicleName = v.Name,
                                   ProductCurrentEPA = 0,//p.CurrentEPA,
                                   Net_Weighed = (t.LoadType != CoreConstants.Load_Counted) ? t.Net : 0,
                                   Net_Counted = (t.LoadType == CoreConstants.Load_Counted) ? t.Net : 0,
                                   LoadType = t.LoadType,
                                   ProductWeightPerItem = p.ToVolumeFactor,
                                   CartageGST = t.CartageGST,
                                   TranCustomerDiscount = t.CustomerDiscount,
                                   ProductLedgerAccount = p.LedgerAccount,
                                   TranOrderNumber = t.OrderNumber,
                                   ProductID = t.ProductID
                               };

            if (newListquery != null && newListquery.Count() > 0)
            {
                List<string> expnames = new List<string>() { "InvName","LocnName","TransNbr","TransType","UserRef1","UserDate1","Descr","ProdNbr","BinCode",
                "TransUnitName","Qty","Val","ChrgCode","LdgCode","AccnBRI"};
                var sb = new StringBuilder();
                StringBuilder sbResult = new StringBuilder();

                int itemCount = 0;
                foreach (var listItem in newListquery)
                {
                    sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                    StringBuilder temp = new StringBuilder();
                    itemCount = itemCount + 1;
                    foreach (var item in expnames)
                    {
                        if (item == "InvName")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "MAIN")) : temp.Append("MAIN");
                        }

                        if (item == "LocnName")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "SHPQUA")) : temp.Append("SHPQUA");
                        }

                        if (item == "TransNbr")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + itemCount)) : temp.Append(itemCount);
                        }

                        if (item == "TransType")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "ISSUE")) : temp.Append("ISSUE");
                        }

                        if (item == "UserRef1")
                        {
                            string ref1format = string.Format("IS.{0}", todate.ToString("dd.MM.yyyy", CultureInfo.InvariantCulture));
                            temp = temp.Length > 0 ? (temp.Append("," + ref1format)) : temp.Append(ref1format);
                        }

                        if (item == "UserDate1")
                        {
                            string userDateformat = todate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                            temp = temp.Length > 0 ? (temp.Append("," + userDateformat)) : temp.Append(userDateformat);
                        }

                        if (item == "Descr")
                        {
                            string descformat = string.Format("Stock Issued {0}", todate.ToString("MMM yyyy", CultureInfo.InvariantCulture));
                            temp = temp.Length > 0 ? (temp.Append("," + descformat)) : temp.Append(descformat);
                        }

                        if (item == "ProdNbr")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductID)) : temp.Append(listItem.ProductID);
                        }

                        if (item == "BinCode")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "SQUARRY")) : temp.Append("SQUARRY");
                        }

                        if (item == "TransUnitName")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "TONN")) : temp.Append("TONN");
                        }

                        if (item == "Qty")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.Net)) : temp.Append(listItem.Net);
                        }

                        if (item == "Val")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }

                        if (item == "ChrgCode")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }

                        if (item == "LdgCode")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "PJ")) : temp.Append("PJ");
                        }

                        if (item == "AccnBRI")
                        {
                            var jobnameSplitArr = listItem.JobName.Split(' ').ToArray();
                            string formatedStr = string.Format("{0}", (jobnameSplitArr.Count() > 0) ? jobnameSplitArr[0] : "");
                            temp = temp.Length > 0 ? (temp.Append("," + formatedStr)) : temp.Append(formatedStr);
                        }
                    }

                    sbResult.Append(temp.ToString());
                }

                var string_with_your_data = sbResult.ToString();
                var byteArray1 = Encoding.ASCII.GetBytes(string_with_your_data);
                var stream1 = new MemoryStream(byteArray1);
                return File(stream1, "text/plain", "Exported_Stock_Transaction_Report_" + DateTime.Now.ToString() + ".csv");
            }
            else
            {
                var string_with_data2 = "no data avilable";
                var byteArray2 = Encoding.ASCII.GetBytes(string_with_data2);
                var stream2 = new MemoryStream(byteArray2);
                return File(stream2, "text/plain", "Exported_Stock_Transaction_Report_" + DateTime.Now.ToString() + ".csv");
            }
        }

        /// <summary>
        /// Export Account CHRC Summary Report per Job per Product Report To CSV
        /// </summary>
        /// <param name="siteid">Site Id.</param>
        /// <param name="fromdate">From date.</param>
        /// <param name="todate">To date.</param>
        /// <returns>file stream.</returns>
        [SessionAccess]
        public FileStreamResult ExportAccountCHRCSummaryReportperJobperProductReportToCSV(int siteid, DateTime fromdate, DateTime todate)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            //DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            //if (DataBaseConnectionStringName == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            //if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            //{
            //    RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            //}

            //logOnSite = GetSiteFromSession(db);
            //if (logOnSite == null)
            //{
            //    //return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            //}

            var newListquery1 = from t in db.Transactions
                                join j in db.Jobs on t.JobID equals j.ID
                                join p in db.Products on t.ProductID equals p.ID
                                where t.SiteID == siteid && t.Deleted == false && (DbFunctions.TruncateTime(t.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(t.TransactionDate) <= DbFunctions.TruncateTime(todate.Date))
                                select new
                                {
                                    JobName = j.Name,
                                    ProductName = p.Name,
                                    ProductID = p.ID,
                                    Net = t.Net
                                };

            List<JobReportParms> newJobReportParms = new List<JobReportParms>();
            foreach (var item in newListquery1)
            {
                string[] strName = item.JobName.Split(' ').ToArray();
                JobReportParms newJobInfo = new JobReportParms();
                newJobInfo.JobNumber = strName.Count() > 0 ? strName[0] : "";
                newJobInfo.ProductID = item.ProductID;
                newJobInfo.Net = item.Net;
                newJobReportParms.Add(newJobInfo);
            }

            var newListquery = from t in newJobReportParms
                               group t by new { JobNumber = t.JobNumber, ProductID = t.ProductID } into g
                               select new
                               {
                                   JobNumber = g.Key.JobNumber,
                                   ProductID = g.Key.ProductID,
                                   Net = g.Sum(x => x.Net)
                               };

            if (newListquery != null && newListquery.Count() > 0)
            {
                //List<string> expnames = new List<string>() { "JobNumber","ProductID","Net"};
                //var sb = new StringBuilder();
                //StringBuilder sbResult = new StringBuilder();

                //int itemCount = 0;
                //foreach (var listItem in newListquery)
                //{
                //    sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                //    StringBuilder temp = new StringBuilder();
                //    itemCount = itemCount + 1;
                //    foreach (var item in expnames)
                //    {                        

                //        if (item == "JobNumber")
                //        {                           
                //            temp = temp.Length > 0 ? (temp.Append("," + listItem.JobNumber)) : temp.Append(listItem.JobNumber);
                //        }

                //        if (item == "ProductID")
                //        {
                //            temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductID)) : temp.Append(listItem.ProductID);
                //        }                      

                //        if (item == "Net")
                //        {
                //            temp = temp.Length > 0 ? (temp.Append("," + listItem.Net)) : temp.Append(listItem.Net);
                //        }
                //    }

                //    sbResult.Append(temp.ToString());
                //}

                List<string> expnames = new List<string>() { "InvName","LocnName","TransNbr","TransType","UserRef1","UserDate1","Descr","ProdNbr","BinCode",
                "TransUnitName","Qty","Val","ChrgCode","LdgCode","AccnBRI"};
                var sb = new StringBuilder();
                StringBuilder sbResult = new StringBuilder();

                int itemCount = 0;
                foreach (var listItem in newListquery)
                {
                    sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                    StringBuilder temp = new StringBuilder();
                    itemCount = itemCount + 1;
                    foreach (var item in expnames)
                    {
                        if (item == "InvName")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "MAIN")) : temp.Append("MAIN");
                        }

                        if (item == "LocnName")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "SHPQUA")) : temp.Append("SHPQUA");
                        }

                        if (item == "TransNbr")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + itemCount)) : temp.Append(itemCount);
                        }

                        if (item == "TransType")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "ISSUE")) : temp.Append("ISSUE");
                        }

                        if (item == "UserRef1")
                        {
                            string ref1format = string.Format("IS.{0}", todate.ToString("dd.MM.yyyy", CultureInfo.InvariantCulture));
                            temp = temp.Length > 0 ? (temp.Append("," + ref1format)) : temp.Append(ref1format);
                        }

                        if (item == "UserDate1")
                        {
                            string userDateformat = todate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                            temp = temp.Length > 0 ? (temp.Append("," + userDateformat)) : temp.Append(userDateformat);
                        }

                        if (item == "Descr")
                        {
                            string descformat = string.Format("Stock Issued {0}", todate.ToString("MMM yyyy", CultureInfo.InvariantCulture));
                            temp = temp.Length > 0 ? (temp.Append("," + descformat)) : temp.Append(descformat);
                        }

                        if (item == "ProdNbr")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.ProductID)) : temp.Append(listItem.ProductID);
                        }

                        if (item == "BinCode")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "SQUARRY")) : temp.Append("SQUARRY");
                        }

                        if (item == "TransUnitName")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "TONN")) : temp.Append("TONN");
                        }

                        if (item == "Qty")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.Net)) : temp.Append(listItem.Net);
                        }

                        if (item == "Val")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }

                        if (item == "ChrgCode")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }

                        if (item == "LdgCode")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "PJ")) : temp.Append("PJ");
                        }

                        if (item == "AccnBRI")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.JobNumber)) : temp.Append(listItem.JobNumber);
                        }
                    }

                    sbResult.Append(temp.ToString());
                }

                var string_with_your_data = sbResult.ToString();
                var byteArray1 = Encoding.ASCII.GetBytes(string_with_your_data);
                var stream1 = new MemoryStream(byteArray1);
                return File(stream1, "text/plain", "Exported_Summary_Per_Job_Per_Product_Report_" + DateTime.Now.ToString() + ".csv");
            }
            else
            {
                var string_with_data2 = "no data avilable";
                var byteArray2 = Encoding.ASCII.GetBytes(string_with_data2);
                var stream2 = new MemoryStream(byteArray2);
                return File(stream2, "text/plain", "Exported_Summary_Per_Job_Per_Product_Report_" + DateTime.Now.ToString() + ".csv");
            }
        }

        /// <summary>
        /// Export Account CHRC Stock Transaction Report To CSV
        /// </summary>
        /// <param name="siteid">Site Id.</param>
        /// <param name="fromdate">From date.</param>
        /// <param name="todate">To date.</param>
        /// <returns>file stream.</returns>
        [SessionAccess]
        public FileStreamResult ExportAccountCHRCInvoiceTransactionImportReportToCSV(int siteid, DateTime fromdate, DateTime todate)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];

            var newListquery = from t in db.Transactions
                               join s in db.Sites on t.SiteID equals s.ID
                               join j in db.Jobs on t.JobID equals j.ID
                               join p in db.Products on t.ProductID equals p.ID
                               join d in db.Destinations on t.DestinationID equals d.ID
                               join so in db.Sources on t.SourceID equals so.ID
                               join w in db.Weighmen on t.WeighmanID equals w.ID
                               join tr in db.Trucks on t.TruckID equals tr.ID
                               join m in db.Marks on t.MarkID equals m.ID
                               join dr in db.Drivers on t.DriverID equals dr.ID
                               join vc in db.VehicleConfigurations on t.VehicleConfigurationID equals vc.ID
                               join pc in db.ProductCategories on t.ProductCategoryID equals pc.ID
                               join v in db.Vehicles on t.VehicleID equals v.ID
                               join c in db.Customers on t.CustomerID equals c.ID
                               where t.SiteID == siteid && t.Deleted == false && (DbFunctions.TruncateTime(t.TransactionDate) >= DbFunctions.TruncateTime(fromdate.Date) && DbFunctions.TruncateTime(t.TransactionDate) <= DbFunctions.TruncateTime(todate.Date))
                               select new
                               {
                                   ID = t.ID,
                                   Docket = t.Docket,
                                   SiteName = s.Name,
                                   CustomerName = c.Name,
                                   ProductName = p.Name,
                                   DestinationName = d.Name,
                                   SourceName = so.Name,
                                   JobName = j.Name,
                                   TruckName = t.Registration1,
                                   TruckName2 = t.Registration2,
                                   TruckName3 = t.Registration3,
                                   VehicleConfigurationName = vc.Name,
                                   TransactionDate = t.TransactionDate,
                                   SiteCode = s.Code,
                                   Direction = t.Direction,
                                   VehicleOwner = t.VehicleOwner,
                                   Payments = t.Payments,
                                   ProductCode = p.Code,
                                   ProductType = p.ProductType,
                                   ProductEPA_Din = p.EPA_Din,
                                   ProductNGER_Code = p.NGER_Code,
                                   ProductReport_To_EPA = p.Report_To_EPA,
                                   ProductEPA_Status = p.EPA_Status,
                                   ProductCategoryName = pc.Name,
                                   DestinationCode = d.Code,
                                   DestinationEPA_Purpose = d.EPA_Purpose,
                                   SourceCode = so.Code,
                                   SourceWaste_Stream = so.Waste_Stream,
                                   SourceSub_Stream = so.Sub_Stream,
                                   SourceOWF_Source = so.OWF_Source,
                                   SourceOWF_EPL_Number = so.OWF_EPL_Number,
                                   WeighmanName = w.Name,
                                   CustomerAccountNumber = c.AccountNumber,
                                   CustomerABN = c.ABN,
                                   CustomerComment = c.Comment,
                                   TruckIsStoredTare = tr.IsStoredTare,
                                   TruckLastTareDate = tr.LastTareDate,
                                   JobID = j.ID,
                                   JobOrderNumber = j.OrderNumber,
                                   DriverName = dr.Name,
                                   MarkName = m.Name,
                                   Gross1 = t.Gross1,
                                   Gross2 = t.Gross2,
                                   Gross3 = t.Gross3,
                                   Gross4 = t.Gross4,
                                   Tare1 = t.Tare1,
                                   Tare2 = t.Tare2,
                                   Tare3 = t.Tare3,
                                   Tare4 = t.Tare4,
                                   Net = t.Net,
                                   Price = t.Price,
                                   TranCost = t.TranCost,
                                   GST = t.GST,
                                   EPA = t.EPA,
                                   TotalCost = t.TotalCost,
                                   CartageCharge = t.CartageCharge,
                                   Comment = t.Comment,
                                   VehicleName = v.Name,
                                   ProductCurrentEPA = 0,//p.CurrentEPA,
                                   Net_Weighed = (t.LoadType != CoreConstants.Load_Counted) ? t.Net : 0,
                                   Net_Counted = (t.LoadType == CoreConstants.Load_Counted) ? t.Net : 0,
                                   LoadType = t.LoadType,
                                   ProductWeightPerItem = p.ToVolumeFactor,
                                   CartageGST = t.CartageGST,
                                   TranCustomerDiscount = t.CustomerDiscount,
                                   ProductLedgerAccount = p.LedgerAccount,
                                   TranOrderNumber = t.OrderNumber,
                                   ProductID = t.ProductID,
                                   WorkOrderSystemCode = j.WorkOrderSystemCode,
                                   ResourceCode = p.ResourceCode,
                                   CustomerID = t.CustomerID
                               };

            if (newListquery != null && newListquery.Count() > 0)
            {
                newListquery = newListquery.OrderBy(t => t.CustomerID).ThenBy(t => t.TranOrderNumber).ThenBy(t => t.ProductID);

                List<string> expnames = new List<string>() { "LineType","AccountId","ExistingAccount","AccountName","NameType","NameTitle","GivenName","Name","AddressLine1",
                    "AddressLine2","AddressLine3","PrintIndicator","Email","EmailAddress","PhoneNumber","DocumentId_Doc","InvoiceIssued_Doc","DocumentReference_Doc",
                "DocumentDate_Doc","DueDate_Doc","DocumentDescription_Doc","TaxType_Doc","TransactionId_Trans","TransactionDate_Trans","TransactionDescription_Trans","Amount_Trans",
                    "TaxRateCode_Trans","LedgerCode_Trans","AccountNumber_Trans","PropSystem_Trans","PropId_Trans",
                "IsWorkSystem_Trans","WorkSystemName_Trans","ResGroupCode_Trans","ResCode_Trans","Units_Trans","Unit_Price","Cartage"};
                var sb = new StringBuilder();
                StringBuilder sbResult = new StringBuilder();
                StringBuilder tempColumnNames = new StringBuilder();
                foreach (var item in expnames)
                {
                    tempColumnNames = tempColumnNames.Length > 0 ? (tempColumnNames.Append("," + item)) : tempColumnNames.Append(item);
                }
                sbResult.Append(tempColumnNames.ToString());

                int chkCustomerId = 0;
                string chkTrOrderNumber = string.Empty;
                bool addAandDLine = false;

                int cntDocumentId = 0;
                int cntTranId = 0;

                //int itemCount = 0;
                foreach (var listItem in newListquery)
                {
                    if (chkCustomerId == listItem.CustomerID && chkTrOrderNumber == listItem.TranOrderNumber)
                    {
                        chkCustomerId = listItem.CustomerID;
                        chkTrOrderNumber = listItem.TranOrderNumber;
                        addAandDLine = false;
                        cntTranId = cntTranId + 1;
                    }
                    else
                    {
                        chkCustomerId = listItem.CustomerID;
                        chkTrOrderNumber = listItem.TranOrderNumber;
                        addAandDLine = true;
                        cntDocumentId = cntDocumentId + 1;
                        cntTranId = 1;
                    }

                    //check for A and D Lines
                    if (addAandDLine)
                    {
                        //for A line
                        sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                        StringBuilder tempA2 = new StringBuilder();
                        //itemCount = itemCount + 1;
                        foreach (var item in expnames)
                        {
                            if (item == "LineType")
                            {
                                //'A' Line Type -Describes the Debtor Account
                                //'D' Line Type -Represents the Debtor Transaction(aka Invoice)
                                //'T' Line Type -Represents the line items on that invoice
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "A")) : tempA2.Append("A");
                            }
                            if (item == "AccountId")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + listItem.CustomerAccountNumber)) : tempA2.Append(listItem.CustomerAccountNumber);
                            }
                            if (item == "ExistingAccount")
                            {
                                if (string.IsNullOrEmpty(listItem.CustomerAccountNumber) || listItem.CustomerAccountNumber == "NA")
                                {
                                    tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "N")) : tempA2.Append("N");
                                }
                                else
                                {
                                    tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "Y")) : tempA2.Append("Y");
                                }
                            }

                            if (item == "AccountName")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "NameType")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "NameTitle")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "GivenName")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "Name")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "AddressLine1")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "AddressLine2")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "AddressLine3")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "PrintIndicator")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "Email")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "EmailAddress")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "PhoneNumber")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }


                            if (item == "DocumentId_Doc")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "InvoiceIssued_Doc")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "DocumentReference_Doc")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "DocumentDate_Doc")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "DueDate_Doc")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "DocumentDescription_Doc")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "TaxType_Doc")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }

                            if (item == "TransactionId_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "TransactionDate_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "TransactionDescription_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "Amount_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "TaxRateCode_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "LedgerCode_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "AccountNumber_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }

                            if (item == "PropSystem_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "PropId_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }


                            if (item == "IsWorkSystem_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "WorkSystemName_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "ResGroupCode_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "ResCode_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "Units_Trans")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "Unit_Price")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                            if (item == "Cartage")
                            {
                                tempA2 = tempA2.Length > 0 ? (tempA2.Append("," + "")) : tempA2.Append("");
                            }
                        }

                        sbResult.Append(tempA2.ToString());

                        //for D line
                        sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                        StringBuilder temp1 = new StringBuilder();
                        //itemCount = itemCount + 1;
                        foreach (var item in expnames)
                        {
                            if (item == "LineType")
                            {
                                //'A' Line Type -Describes the Debtor Account
                                //'D' Line Type -Represents the Debtor Transaction(aka Invoice)
                                //'T' Line Type -Represents the line items on that invoice
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "D")) : temp1.Append("D");
                            }
                            if (item == "AccountId")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + listItem.CustomerAccountNumber)) : temp1.Append(listItem.CustomerAccountNumber);
                            }
                            if (item == "ExistingAccount")
                            {
                                if (string.IsNullOrEmpty(listItem.CustomerAccountNumber) || listItem.CustomerAccountNumber == "NA")
                                {
                                    temp1 = temp1.Length > 0 ? (temp1.Append("," + "N")) : temp1.Append("N");
                                }
                                else
                                {
                                    temp1 = temp1.Length > 0 ? (temp1.Append("," + "Y")) : temp1.Append("Y");
                                }
                            }

                            if (item == "AccountName")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "NameType")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "NameTitle")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "GivenName")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "Name")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "AddressLine1")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "AddressLine2")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "AddressLine3")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "PrintIndicator")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "Email")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "EmailAddress")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "PhoneNumber")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }


                            if (item == "DocumentId_Doc")
                            {
                                //temp = temp.Length > 0 ? (temp.Append("," + itemCount)) : temp.Append(itemCount);                              
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + cntDocumentId)) : temp1.Append(cntDocumentId);
                            }
                            if (item == "InvoiceIssued_Doc")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "Y")) : temp1.Append("Y");
                            }
                            if (item == "DocumentReference_Doc")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + listItem.TranOrderNumber)) : temp1.Append(listItem.TranOrderNumber);
                            }
                            if (item == "DocumentDate_Doc")
                            {
                                //date of import
                                string importDate = DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + importDate)) : temp1.Append(importDate);
                            }
                            if (item == "DueDate_Doc")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "DocumentDescription_Doc")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + listItem.ProductName)) : temp1.Append(listItem.ProductName);
                            }
                            if (item == "TaxType_Doc")
                            {
                                string gstCode = (listItem.GST > 0 || listItem.CartageGST > 0) ? "I" : "E";
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + gstCode)) : temp1.Append(gstCode);
                            }

                            if (item == "TransactionId_Trans")
                            {
                                //temp = temp.Length > 0 ? (temp.Append("," +listItem.Docket)) : temp.Append(listItem.Docket);
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "TransactionDate_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "TransactionDescription_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "Amount_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "TaxRateCode_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "LedgerCode_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "AccountNumber_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }

                            if (item == "PropSystem_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "PropId_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }


                            if (item == "IsWorkSystem_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "WorkSystemName_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "ResGroupCode_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "ResCode_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "Units_Trans")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "Unit_Price")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                            if (item == "Cartage")
                            {
                                temp1 = temp1.Length > 0 ? (temp1.Append("," + "")) : temp1.Append("");
                            }
                        }

                        sbResult.Append(temp1.ToString());
                    }

                    sbResult = sbResult.Length > 0 ? sbResult.AppendLine() : sbResult;
                    StringBuilder temp = new StringBuilder();
                    //itemCount = itemCount + 1;
                    foreach (var item in expnames)
                    {
                        if (item == "LineType")
                        {
                            //'A' Line Type -Describes the Debtor Account
                            //'D' Line Type -Represents the Debtor Transaction(aka Invoice)
                            //'T' Line Type -Represents the line items on that invoice
                            temp = temp.Length > 0 ? (temp.Append("," + "T")) : temp.Append("T");
                        }
                        if (item == "AccountId")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.CustomerAccountNumber)) : temp.Append(listItem.CustomerAccountNumber);
                        }
                        if (item == "ExistingAccount")
                        {
                            if (string.IsNullOrEmpty(listItem.CustomerAccountNumber) || listItem.CustomerAccountNumber == "NA")
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + "N")) : temp.Append("N");
                            }
                            else
                            {
                                temp = temp.Length > 0 ? (temp.Append("," + "Y")) : temp.Append("Y");
                            }
                        }

                        if (item == "AccountName")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "NameType")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "NameTitle")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "GivenName")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "Name")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "AddressLine1")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "AddressLine2")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "AddressLine3")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "PrintIndicator")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "Email")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "EmailAddress")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "PhoneNumber")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }


                        if (item == "DocumentId_Doc")
                        {
                            //temp = temp.Length > 0 ? (temp.Append("," + itemCount)) : temp.Append(itemCount);
                            temp = temp.Length > 0 ? (temp.Append("," + cntDocumentId)) : temp.Append(cntDocumentId);
                        }
                        if (item == "InvoiceIssued_Doc")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "Y")) : temp.Append("Y");
                        }
                        if (item == "DocumentReference_Doc")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.TranOrderNumber)) : temp.Append(listItem.TranOrderNumber);
                        }
                        if (item == "DocumentDate_Doc")
                        {
                            //date of import
                            string importDate = DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                            temp = temp.Length > 0 ? (temp.Append("," + importDate)) : temp.Append(importDate);
                        }
                        if (item == "DueDate_Doc")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "DocumentDescription_Doc")
                        {
                            //temp = temp.Length > 0 ? (temp.Append("," + "Supply of quarry materials")) : temp.Append("Supply of quarry materials");
                            //added with unit price
                            temp = temp.Length > 0 ? (temp.Append("," + string.Format("{0} @ ${1}", listItem.ProductName, listItem.Price))) : temp.Append(string.Format("{0} @ ${1}", listItem.ProductName, listItem.Price));
                        }
                        if (item == "TaxType_Doc")
                        {
                            string gstCode = (listItem.GST > 0 || listItem.CartageGST > 0) ? "I" : "E";
                            temp = temp.Length > 0 ? (temp.Append("," + gstCode)) : temp.Append(gstCode);
                        }

                        if (item == "TransactionId_Trans")
                        {
                            //temp = temp.Length > 0 ? (temp.Append("," +listItem.Docket)) : temp.Append(listItem.Docket);
                            temp = temp.Length > 0 ? (temp.Append("," + cntTranId)) : temp.Append(cntTranId);
                        }
                        if (item == "TransactionDate_Trans")
                        {
                            string tranDate = listItem.TransactionDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                            temp = temp.Length > 0 ? (temp.Append("," + tranDate)) : temp.Append(tranDate);
                        }
                        if (item == "TransactionDescription_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "Amount_Trans")
                        {
                            decimal diTransAmount = listItem.TranCost + listItem.CartageCharge;
                            temp = temp.Length > 0 ? (temp.Append("," + diTransAmount)) : temp.Append(diTransAmount);
                        }
                        if (item == "TaxRateCode_Trans")
                        {
                            //temp = temp.Length > 0 ? (temp.Append("," + "C")) : temp.Append("C");
                            string gstCode = (listItem.GST > 0 || listItem.CartageGST > 0) ? "C" : "NA";
                            temp = temp.Length > 0 ? (temp.Append("," + gstCode)) : temp.Append(gstCode);
                        }
                        if (item == "LedgerCode_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "PJ")) : temp.Append("PJ");
                        }
                        if (item == "AccountNumber_Trans")
                        {
                            //temp = temp.Length > 0 ? (temp.Append("," + listItem.JobOrderNumber)) : temp.Append(listItem.JobOrderNumber);
                            string[] strName = listItem.JobName.Split(' ').ToArray();
                            string jobNameStr = strName.Count() > 0 ? strName[0] : "";
                            temp = temp.Length > 0 ? (temp.Append("," + jobNameStr)) : temp.Append(jobNameStr);
                        }

                        if (item == "PropSystem_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }
                        if (item == "PropId_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "")) : temp.Append("");
                        }

                        if (item == "IsWorkSystem_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "Y")) : temp.Append("Y");
                        }
                        if (item == "WorkSystemName_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.WorkOrderSystemCode)) : temp.Append(listItem.WorkOrderSystemCode);
                        }
                        if (item == "ResGroupCode_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + "REVENUE")) : temp.Append("REVENUE");
                        }
                        if (item == "ResCode_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.ResourceCode)) : temp.Append(listItem.ResourceCode);
                        }
                        if (item == "Units_Trans")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.Net)) : temp.Append(listItem.Net);
                        }
                        if (item == "Unit_Price")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.Price)) : temp.Append(listItem.Price);
                        }
                        if (item == "Cartage")
                        {
                            temp = temp.Length > 0 ? (temp.Append("," + listItem.CartageCharge)) : temp.Append(listItem.CartageCharge);
                        }
                    }

                    sbResult.Append(temp.ToString());
                }

                var string_with_your_data = sbResult.ToString();
                var byteArray1 = Encoding.ASCII.GetBytes(string_with_your_data);
                var stream1 = new MemoryStream(byteArray1);
                return File(stream1, "text/plain", "Exported_Invoice_Transaction_Import_Report_" + DateTime.Now.ToString() + ".csv");
            }
            else
            {
                var string_with_data2 = "no data avilable";
                var byteArray2 = Encoding.ASCII.GetBytes(string_with_data2);
                var stream2 = new MemoryStream(byteArray2);
                return File(stream2, "text/plain", "Exported_Invoice_Transaction_Import_Report_" + DateTime.Now.ToString() + ".csv");
            }
        }

        /// <summary>
        /// Filter the transaction based on the ExportWizard model -Date Range, WeighmanId, SiteId, Transaction Number 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>

        private List<Transaction> FilterTransactions(ExportWizard model)
        {

            entities = db.Transactions.Include(t => t.Customer).Include(t => t.Product).Include(t => t.Site).Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(DateTime.Now) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(DateTime.Now)));

            if (model.ID > 0)
            {
                if (model.Range)
                {
                    if (model.Account == "2")
                        entities = db.Transactions.Include(t => t.Customer).Include(t => t.Product).Include(t => t.Site).Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(model.FromDate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(model.ToDate.Date)) && e.SiteID == model.SiteID && e.Deleted == true);
                    else if (model.Account == "3")
                        entities = db.Transactions.Include(t => t.Customer).Include(t => t.Product).Include(t => t.Site).Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(model.FromDate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(model.ToDate.Date)) && e.SiteID == model.SiteID);
                    else if (model.Account == "4")
                        entities = db.Transactions.Include(t => t.Customer).Include(t => t.Product).Include(t => t.Site).Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(model.FromDate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(model.ToDate.Date)) && e.SiteID == model.SiteID && e.Deleted == false && e.ExportedToAccounting == true);
                    else if (model.Account == "5")
                        entities = db.Transactions.Include(t => t.Customer).Include(t => t.Product).Include(t => t.Site).Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(model.FromDate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(model.ToDate.Date)) && e.SiteID == model.SiteID && e.Deleted == false && e.ExportedToAccounting == false);
                    else
                        entities = db.Transactions.Include(t => t.Customer).Include(t => t.Product).Include(t => t.Site).Where(e => (DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(model.FromDate.Date) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(model.ToDate.Date)) && e.SiteID == model.SiteID && e.Deleted == false);



                    if (model.OrderBy == "Docket")
                    {
                        entities = entities.OrderBy(o => o.Docket);
                    }
                    else if (model.OrderBy == "SiteName")
                    {
                        entities = entities.OrderBy(o => o.Site.Name);
                    }
                    else if (model.OrderBy == "Customer")
                    {
                        entities = entities.OrderBy(o => o.Customer.Name);
                    }
                    else if (model.OrderBy == "Product")
                    {
                        entities = entities.OrderBy(o => o.Product.Name);
                    }
                    else if (model.OrderBy == "Destination")
                    {
                        entities = entities.OrderBy(o => o.Destination.Name);
                    }
                    else if (model.OrderBy == "Source")
                    {
                        entities = entities.OrderBy(o => o.Source.Name);
                    }
                    else if (model.OrderBy == "Job")
                    {
                        entities = entities.OrderBy(o => o.Job.Name);
                    }
                    else if (model.OrderBy == "Truck")
                    {
                        entities = entities.OrderBy(o => o.Registration1);
                    }
                    else
                    {
                        entities = entities.OrderBy(o => o.ID);
                    }

                }
            }

            return entities.ToList();
        }

        private static char[] quotedCharacters = { ',', '"', '\n' };
        private const string quote = "\"";
        private const string escapedQuote = "\"\"";

        private static string Escape(string value)
        {
            if (value == null) return "";
            if (value.Contains(quote)) value = value.Replace(quote, escapedQuote);
            if (value.IndexOfAny(quotedCharacters) > 1)
                value = quote + value + quote;
            return value;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }

    public class JobReportParms
    {
        public string JobNumber { get; set; }
        public int ProductID { get; set; }
        public decimal Net { get; set; }
    }
}
