﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using PagedList;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class DriverController : EntityController<Driver>
    {
        /// <summary>
        /// Get the Drivers list based on the filters - Renders index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <param name="state"></param>
        /// <param name="suburb"></param>
        /// <param name="mobile"></param>
        /// <returns></returns>

        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string code, string state, string suburb, string mobile)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDriver;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDriver;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDriver;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Drivers");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");

            ViewBag.SuburbSortParm = (sortOrder == "Suburb" ? "Suburb_Desc" : "Suburb");
            ViewBag.StateSortParm = (sortOrder == "State" ? "State_Desc" : "State");
            ViewBag.PostcodeSortParm = (sortOrder == "Postcode" ? "Postcode_Desc" : "Postcode");
            ViewBag.CountrySortParm = (sortOrder == "Country" ? "Country_Desc" : "Country");
            ViewBag.PhoneSortParm = (sortOrder == "Phone" ? "Phone_Desc" : "Phone");
            ViewBag.MobileSortParm = (sortOrder == "Mobile" ? "Mobile_Desc" : "Mobile");
            ViewBag.EmailSortParm = (sortOrder == "Email" ? "Email_Desc" : "Email");

            entities = from e in db.Drivers select e;

            entities = entities.Where(e => e.ID > CoreConstants.NA_ID);



            //Filters

            ViewBag.States = Constants.AUS_STATES.ToList();
            ViewBag.Suburbs = db.Drivers.Where(e => e.Suburb != null).GroupBy(r => r.Suburb).Select(group => group.Key).ToList();

            ViewBag.name = name;
            ViewBag.code = code;
            ViewBag.state = state;
            ViewBag.suburb = suburb;
            ViewBag.mobile = mobile;


            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));

            }

            if (!String.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));

            }

            if (!String.IsNullOrEmpty(suburb) && suburb != "All")
            {
                entities = entities.Where(e => e.Suburb.ToUpper() == suburb.ToUpper());
            }

            if (!String.IsNullOrEmpty(state) && state != "All")
            {
                entities = entities.Where(e => e.State.ToUpper() == state.ToUpper());
            }


            if (!String.IsNullOrEmpty(mobile))
            {
                entities = entities.Where(e => e.Mobile == mobile);
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;

                case "Suburb":
                    entities = entities.OrderBy(e => e.Suburb);
                    break;
                case "Suburb_Desc":
                    entities = entities.OrderByDescending(e => e.Suburb);
                    break;
                case "State":
                    entities = entities.OrderBy(e => e.State);
                    break;
                case "State_Desc":
                    entities = entities.OrderByDescending(e => e.State);
                    break;
                case "Postcode":
                    entities = entities.OrderBy(e => e.Postcode);
                    break;
                case "Postcode_Desc":
                    entities = entities.OrderByDescending(e => e.Postcode);
                    break;
                case "Country":
                    entities = entities.OrderBy(e => e.Country);
                    break;
                case "Country_Desc":
                    entities = entities.OrderByDescending(e => e.Country);
                    break;
                case "Phone":
                    entities = entities.OrderBy(e => e.Phone);
                    break;
                case "Phone_Desc":
                    entities = entities.OrderByDescending(e => e.Phone);
                    break;
                case "Mobile":
                    entities = entities.OrderBy(e => e.Mobile);
                    break;
                case "Mobile_Desc":
                    entities = entities.OrderByDescending(e => e.Mobile);
                    break;
                case "Email":
                    entities = entities.OrderBy(e => e.Email);
                    break;
                case "Email_Desc":
                    entities = entities.OrderByDescending(e => e.Email);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);

            pageSize = filterPageSize ?? pageSize;

            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Get the Driver details from the index grid, it navigates to the details page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Driver/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDriver;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDriver;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDriver;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Drivers.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// It navigates to the create a driver page
        /// </summary>
        /// <returns></returns>
        // GET: Driver/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDriver;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDriver;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDriver;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, CoreConstants.NSW);

            return View();
        }

        /// <summary>
        /// Create a new driver and store the details in the DB
        /// </summary>
        /// <param name="driver"></param>
        /// <returns></returns>
        // POST: Driver/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewDriver")]
        public ActionResult Create([Bind(Include = "ID,Name,Code,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Email")] Driver driver)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDriver;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDriver;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDriver;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, driver.State);

            var nameExist = db.Drivers.FirstOrDefault(e => e.Name == driver.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "Driver already exists");
                return View(driver);
            }

            if (ModelState.IsValid)
            {
                driver.Name = driver.Name.ToUpper();
                db.Drivers.Add(driver);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(driver.Name + " created successfully!");
                return RedirectToAction("Edit/" + driver.ID.ToString());
            }

            return View(driver);
        }

        /// <summary>
        /// It navigates the edit screen from the grid edit action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Driver/Edit/5

        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDriver;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDriver;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDriver;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Drivers.Find(id);
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, entity.State);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Update the Driver and stored in the DB
        /// </summary>
        /// <param name="driver"></param>
        /// <returns></returns>

        // POST: Driver/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditDriver")]
        public ActionResult Edit([Bind(Include = "ID,Name,Code,Description,Address1,Address2,Suburb,State,Postcode,Country,Phone,Mobile,Email")] Driver driver)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDriver;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDriver;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDriver;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");
            ViewBag.State = new SelectList(CoreConstants.AUS_STATES, driver.State);

            var driverExist = db.Drivers.FirstOrDefault(m => m.Name == driver.Name);
            if (driverExist != null)
            {
                if (driverExist.ID == driver.ID)
                {
                    if (ModelState.IsValid)
                    {
                        var entityUpdate = db.Drivers.Find(driver.ID);
                        entityUpdate.Name = driver.Name.ToUpper();
                        entityUpdate.Description = driver.Description;
                        entityUpdate.Code = driver.Code;
                        entityUpdate.Address1 = driver.Address1;
                        entityUpdate.Address2 = driver.Address2;
                        entityUpdate.Suburb = driver.Suburb;
                        entityUpdate.State = driver.State;
                        entityUpdate.Postcode = driver.Postcode;
                        entityUpdate.Country = driver.Country;
                        entityUpdate.Phone = driver.Phone;
                        entityUpdate.Mobile = driver.Mobile;
                        entityUpdate.Email = driver.Email;

                        if (TryUpdateModel(entityUpdate, "",
                                 new string[] { "Name", "Description", "Code", "Address1", "Address2", "Suburb", "State", "Postcode", "Country", "Phone", "Mobile", "Email" }))

                            db.SaveChanges();


                        TempData["UserMessage"] = ComposeTempDisplayMessage(driver.Name + " edited successfully!");
                        //                        return RedirectToAction("Index");
                        return RedirectToAction("Edit/" + driver.ID.ToString());
                    }
                }
                else
                {
                    ModelState.AddModelError("Name", "Driver already exists");
                    return View(driver);
                }
            }


            if (ModelState.IsValid)
            {
                driver.Name = driver.Name.ToUpper();
                db.Entry(driver).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(driver.Name + " edited successfully!");
                //                return RedirectToAction("Index");
                return RedirectToAction("Edit/" + driver.ID.ToString());
            }
            return View(driver);
        }


        /// <summary>
        /// Delted the driver based on the driver id- it navigates to the details page before you delete
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Driver/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDriver;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDriver;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDriver;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Drivers.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Remove the driver from the DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Driver/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteDriver")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewDriver;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditDriver;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteDriver;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");
            try
            {
                entity = db.Drivers.Find(id);
                db.Drivers.Remove(entity);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This driver " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db!=null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
