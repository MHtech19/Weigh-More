﻿using AWSWeighingService.Models;
using ChartJs.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class HomeController : EntityController<Weighman>
    {
        [SessionAccess]
        public ActionResult Index()
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (DataBaseConnectionStringName == null)
            {
                return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            }

            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }
            var sessionCurrentSiteID = Session["CurrentSiteID"];
            var sessionLogonWeighMan = Session["CurrentWeighmanID"];

            if (sessionCurrentSiteID == null)
            {
                ViewBag.IsAdmin = false;
            }
            else
            {
                int logOnWeighManIDFromSession = (int)sessionLogonWeighMan;
                logOnWeighman = db.Weighmen.Where(w => w.ID == logOnWeighManIDFromSession).FirstOrDefault();
                var logOnSite = db.Sites.FirstOrDefault(s => s.ID == (int)sessionCurrentSiteID);
                ViewBag.IsAdmin = logOnWeighman.IsAdmin;
                string url = Request.Url.AbsoluteUri;
                ViewBag.ReportWizardUrl = ReportLink + "?SiteID=" + logOnSite.ID.ToString() + "&SiteName=" + logOnSite.Name + "&ReturnUrl=" + url; ;
            }
            return View();
        }


        /// <summary>
        /// Navigate to the About page
        /// </summary>
        /// <returns></returns>
        public ActionResult About()
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }

            ViewBag.IsAdmin = false;
            ViewBag.Message = "WMS - Scales & Weighing Systems.";

            var sessionCurrentSiteID = Session["CurrentSiteID"];
            var sessionLogonWeighMan = Session["CurrentWeighmanID"];

            if (sessionCurrentSiteID == null)
            {
                ViewBag.IsAdmin = false;
            }
            else
            {
                int logOnWeighManIDFromSession = (int)sessionLogonWeighMan;
                logOnWeighman = db.Weighmen.Where(w => w.ID == logOnWeighManIDFromSession).FirstOrDefault();
                ViewBag.IsAdmin = logOnWeighman.IsAdmin;
                var logOnSite = db.Sites.FirstOrDefault(s => s.ID == (int)sessionCurrentSiteID);
                string url = Request.Url.AbsoluteUri;
                ViewBag.ReportWizardUrl = ReportLink + "?SiteID=" + logOnSite.ID.ToString() + "&SiteName=" + logOnSite.Name + "&ReturnUrl=" + url; ;

            }
            return View();
        }

        /// <summary>
        /// Navigate to the Contact Us page
        /// </summary>
        /// <returns></returns>
        public ActionResult Contact()
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }

            ViewBag.IsAdmin = false;
            ViewBag.Message = CoreConstants.WeighMoreSolutions;

            var sessionCurrentSiteID = Session["CurrentSiteID"];
            var sessionLogonWeighMan = Session["CurrentWeighmanID"];

            if (sessionCurrentSiteID == null)
            {
                ViewBag.IsAdmin = false;
            }
            else
            {
                int logOnWeighManIDFromSession = (int)sessionLogonWeighMan;
                logOnWeighman = db.Weighmen.Where(w => w.ID == logOnWeighManIDFromSession).FirstOrDefault();
                ViewBag.IsAdmin = logOnWeighman.IsAdmin;
                var logOnSite = db.Sites.FirstOrDefault(s => s.ID == (int)sessionCurrentSiteID);
                string url = Request.Url.AbsoluteUri;
                ViewBag.ReportWizardUrl = ReportLink + "?SiteID=" + logOnSite.ID.ToString() + "&SiteName=" + logOnSite.Name + "&ReturnUrl=" + url;

            }

            return View();
        }


        public ActionResult BarChartData()
        {

            Chart _chart = new Chart() { };
            _chart.labels = new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "Novemeber", "December" };
            _chart.datasets = new List<Datasets>();
            List<Datasets> _dataSet = new List<Datasets>() { };
            _dataSet.Add(new Datasets()
            {
                label = "Current Year",
                data = new decimal[] { 28, 48, 40, 19, 86, 27, 90, 20, 45, 65, 34, 22 },
                backgroundColor = new string[] { "#FF0000", "#800000", "#808000", "#008080", "#800080", "#0000FF", "#000080", "#999999", "#E9967A", "#CD5C5C", "#1A5276", "#27AE60" },
                borderColor = new string[] { "#FF0000", "#800000", "#808000", "#008080", "#800080", "#0000FF", "#000080", "#999999", "#E9967A", "#CD5C5C", "#1A5276", "#27AE60" },
                borderWidth = "1"
            });
            _chart.datasets = _dataSet;
            return Json(_chart, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BarChartForTransactionsByDates()
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (DataBaseConnectionStringName == null)
            {
                return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            }

            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }
            logOnSite = GetSiteFromSession(db);
            if (logOnSite == null)
            {
                return RedirectToAction("Login", "Logon", new { returnUrl = Request.RawUrl });
            }

            SetViewBagValues();
            DateTime endDate = DateTime.Now;
            DateTime startDate = endDate.AddDays(-4);
            string[] labelsInfo = new string[] { startDate.Date.ToString("dd/MM/yyyy"), startDate.AddDays(1).ToString("dd/MM/yyyy"), startDate.AddDays(2).ToString("dd/MM/yyyy")
            ,startDate.AddDays(3).ToString("dd/MM/yyyy"),endDate.Date.ToString("dd/MM/yyyy")};


            var transactions = db.Transactions.Where(e => DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(startDate) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(endDate));

            var entities = from t in transactions.ToList()
                           select new
                           {
                               Docket = t.Docket,
                               TransactionDate = t.TransactionDate,
                               LoadType = t.LoadType,
                               Payments = t.Payments,
                               Direction = t.Direction,
                               VehicleOwner = t.VehicleOwner,
                               ChargeRate = t.ChargeRate,
                               OrderNumber = t.OrderNumber,
                               Comment = t.Comment,
                               Registration1 = t.Registration1,
                               Gross1 = t.Gross1 + t.Gross2 + t.Gross3 + t.Gross4 + t.Gross5,
                               Tare1 = t.Tare1 + t.Tare2 + t.Tare3 + t.Tare4 + t.Tare5,
                               Net = t.Net,
                               Price = t.Price,
                               TranCost = t.TranCost,
                               TotalCost = t.TotalCost,
                               CartageCharge = t.CartageCharge,
                               CartageCost = t.CartageCost,
                               GST = t.GST,
                               EPA = t.EPA,
                               DateStamp = t.DateStamp,
                               Royalty = t.Royalty,
                               Count = t.Count,
                           };

            var entitiySummary = entities.OrderBy(e => e.TransactionDate).GroupBy(e => e.TransactionDate.ToString("dd/MM/yyyy")).Select(sumary => new
            {
                Date = sumary.Key,
                TotalCost = sumary.Sum(e => e.TotalCost),
            }).ToList();

            decimal day1 = 0;
            decimal day2 = 0;
            decimal day3 = 0;
            decimal day4 = 0;
            decimal day5 = 0;
            if (entitiySummary != null)
            {
                var day1Info = entitiySummary.Where(e => e.Date == labelsInfo[0]).FirstOrDefault();
                day1 = day1Info != null ? day1Info.TotalCost : 0;

                var day2Info = entitiySummary.Where(e => e.Date == labelsInfo[1]).FirstOrDefault();
                day2 = day2Info != null ? day2Info.TotalCost : 0;

                var day3Info = entitiySummary.Where(e => e.Date == labelsInfo[2]).FirstOrDefault();
                day3 = day3Info != null ? day3Info.TotalCost : 0;

                var day4Info = entitiySummary.Where(e => e.Date == labelsInfo[3]).FirstOrDefault();
                day4 = day4Info != null ? day4Info.TotalCost : 0;

                var day5Info = entitiySummary.Where(e => e.Date == labelsInfo[4]).FirstOrDefault();
                day5 = day5Info != null ? day5Info.TotalCost : 0;
            }

            decimal[] dataInfo = new decimal[] { day1, day2, day3, day4, day5 };

            Chart _chart = new Chart() { };
            //_chart.labels = new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "Novemeber", "December" };
            _chart.labels = labelsInfo;
            _chart.datasets = new List<Datasets>();
            List<Datasets> _dataSet = new List<Datasets>() { };
            _dataSet.Add(new Datasets()
            {
                label = "Total Cost",
                data = dataInfo,
                backgroundColor = new string[] { "#FF0000", "#800000", "#808000", "#008080", "#800080" },
                borderColor = new string[] { "#FF0000", "#800000", "#808000", "#008080", "#800080" },
                borderWidth = "1"
            });
            _chart.datasets = _dataSet;
            return Json(_chart, JsonRequestBehavior.AllowGet);
        }
    }
}