﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using PagedList;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class ProductController : EntityController<Product>
    {
        /// <summary>
        /// Get the Product Category list - Navigate to index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="productType"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <param name="direction"></param>
        /// <param name="productCategory"></param>
        /// <param name="site"></param>
        /// <param name="source"></param>
        /// <param name="destination"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        // GET: Product
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string productType, string name, string code, string direction, string productCategory,
                                  string site, string source, string destination, string status)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProduct;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProduct;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProduct;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView(GetDisplayTitle(productType, true));

            if (productType == null)
            {
                productType = CoreConstants.ProductType_Weighed;
            }

            ViewBag.ProductType = productType;

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");
            ViewBag.DescriptionSortParm = (sortOrder == "Description" ? "Description_Desc" : "Description");
            ViewBag.ProductCategorySortParm = (sortOrder == "ProductCategory" ? "ProductCategory_Desc" : "ProductCategory");
            ViewBag.IsActiveSortParm = (sortOrder == "IsActive" ? "IsActive_Desc" : "IsActive");

            entities = from e in db.Products where e.ProductType == productType select e;

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.Products == null)
                {
                    entities = from e in db.Products where e.Name == CoreConstants.NA select e;
                }
                else
                {
                    entities = logOnSite.Products.AsQueryable<Product>();
                }
            }

            entities = entities.Include(e => e.ProductCategory).Where(e => ((e.ID > CoreConstants.NA_ID) && (e.ProductType == productType)));

            //Filters

            ViewBag.Directions = CoreConstants.DIRECTIONS.Where(x => x != "NA");
            ViewBag.ProductCategories = db.ProductCategories.Select(e => new { ID = e.ID, Name = e.Name }).ToList();
            ViewBag.Sources = db.Sources.Select(e => new { ID = e.ID, Name = e.Name }).ToList();
            ViewBag.Destinations = db.Destinations.Select(e => new { ID = e.ID, Name = e.Name }).ToList();
            ViewBag.Sites = db.Sites.Where(s => s.ID > 1).ToList();

            status = status ?? "true";

            ViewBag.name = name;
            ViewBag.code = code;
            ViewBag.direction = direction;
            ViewBag.productType = productType;
            ViewBag.productCategory = productCategory;
            ViewBag.site = site;
            ViewBag.source = source;
            ViewBag.destination = destination;
            ViewBag.status = status;


            if (!string.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!string.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));
            }

            if (!string.IsNullOrEmpty(direction) && direction != null)
            {
                entities = entities.Where(e => e.Direction.ToUpper().Contains(direction.ToUpper()));
            }

            if (!string.IsNullOrEmpty(productType) && productType != null)
            {
                entities = entities.Where(e => e.ProductType.ToUpper().Contains(productType.ToUpper()));
            }

            if (!string.IsNullOrEmpty(productCategory) && productCategory != "All")
            {
                int productCategoryId = int.Parse(productCategory);
                entities = entities.Where(e => e.ProductCategoryID == productCategoryId);
            }

            if (!string.IsNullOrEmpty(site) && site != "All")
            {
                int siteId = int.Parse(site);
                entities = entities.Where(s => s.Sites.Any(st => st.ID == siteId));
            }

            if (!string.IsNullOrEmpty(source) && source != "All")
            {
                int sourceId = int.Parse(source);
                entities = entities.Where(e => e.SourceID == sourceId);
            }

            if (!string.IsNullOrEmpty(destination) && destination != "All")
            {
                int destinationId = int.Parse(destination);
                entities = entities.Where(e => e.DestinationID == destinationId);
            }

            if (!string.IsNullOrEmpty(status) && status != "All")
            {
                bool statusId = bool.Parse(status);
                entities = entities.Where(e => e.IsActive == statusId);
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;
                case "Description":
                    entities = entities.OrderBy(e => e.Description);
                    break;
                case "Description_Desc":
                    entities = entities.OrderByDescending(e => e.Description);
                    break;
                case "ProductCategory":
                    entities = entities.OrderBy(e => e.ProductCategory.Name);
                    break;
                case "ProductCategory_Desc":
                    entities = entities.OrderByDescending(e => e.ProductCategory.Name);
                    break;
                case "IsActive_Desc":
                    entities = entities.OrderByDescending(e => e.IsActive);
                    break;
                case "IsActive":
                    entities = entities.OrderBy(e => e.IsActive);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }
            pageNumber = (page ?? 1);

            pageSize = filterPageSize ?? pageSize;

            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        // GET: Product/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProduct;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProduct;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProduct;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Products.Include(e => e.ProductCategory).Include(e => e.Sites).Single(e => e.ID == id);
            if (entity == null)
            {
                return HttpNotFound();
            }

            ViewBag.ProductOrItem = GetDisplayTitle(entity.ProductType, false);

            return View(entity);
        }

        /// <summary>
        /// Navigate to create a new product from index page
        /// </summary>
        /// <param name="productType"></param>
        /// <returns></returns>
        // GET: Product/Create
        [SessionAccess]
        public ActionResult Create(string productType)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            ViewBag.CanNew = (Session["Role"] as Role).CanNewProduct;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProduct;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProduct;

            logOnSiteIsCentral = (logOnSite.ID == CoreConstants.NA_ID);
            ViewBag.IsCentralSite = logOnSiteIsCentral;
            ViewBag.LongonSiteID = logOnSite.ID;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            if (productType == null)
            {
                productType = CoreConstants.ProductType_Weighed;
            }

            ViewBag.ProductType = productType;
            ViewBag.ProductOrItem = GetDisplayTitle(productType, false);

            entity = new Product();
            entity.Sites = new List<Site>();

            ViewBag.Direction = new SelectList(CoreConstants.DIRECTIONS, CoreConstants.NA);
            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories, "ID", "Name");
            if (!logOnSiteIsCentral)
            {
                ViewBag.Sites = new List<AssignedSiteData>();
                ViewBag.DestinationID = new SelectList(logOnSite.Destinations.OrderBy(d => d.Name), "ID", "Name");
                ViewBag.SourceID = new SelectList(logOnSite.Sources.OrderBy(s => s.Name), "ID", "Name");
                ViewBag.EPAStatus = new SelectList(new List<string> { "", "Leviable", "Exempt", "Non-Waste", "Under Contract", "Other" });
            }
            else
            {
                ViewBag.Sites = GetEntityAssignedSiteData(db, entity.Sites);
                ViewBag.DestinationID = new SelectList(db.Destinations.Where(d => d.SiteCreated == false).OrderBy(d => d.Name), "ID", "Name");
                ViewBag.SourceID = new SelectList(db.Sources.Where(s => s.SiteCreated == false).OrderBy(s => s.Name), "ID", "Name");
                ViewBag.EPAStatus = new SelectList(new List<string> { "", "Leviable", "Exempt", "Non-Waste", "Under Contract", "Other" });
            }


            return View(entity);
        }

        /// <summary>
        /// Saved new Product in the DB
        /// </summary>
        /// <param name="product"></param>
        /// <param name="productType"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>
        // POST: Product/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewProduct")]
        public ActionResult Create([Bind(Include = "ID,Name,Code,Description,ProductType,InLocalDiscount,InLocalDiscountGST,OutLocalDiscount,OutLocalDiscountGST,MinLocalDiscount,InVisitStandard,InVisitStandardGST,OutVisitStandard,OutVisitStandardGST,MinVisitStandard,EPALevy,MinEPALevy,CreationDate,ProductCategoryID,DestinationID,SourceID,Direction,IsActive,LiftBoomGate,Report_To_EPA,EPA_Status,NoOfDockets,LedgerAccount,SchedulePriceDate,StockLevel,Royalty,ToVolumeFactor,MinWeight,InLocalDiscount_S,OutLocalDiscount_S,MinLocalDiscount_S,InVisitStandard_S,OutVisitStandard_S,MinVisitStandard_S,EPALevy_S,MinEPALevy_S,ResourceCode")] Product product, string productType, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProduct;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProduct;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProduct;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.ProductOrItem = GetDisplayTitle(productType, false);

            entity = new Product();
            entity.Sites = new List<Site>();
            ViewBag.Sites = (logOnSiteIsCentral) ? GetEntityAssignedSiteData(db, entity.Sites) : new List<AssignedSiteData>();

            ViewBag.EPAStatus = new SelectList(new List<string> { "", "Leviable", "Exempt", "Non-Waste", "Under Contract", "Other" });
            if (!logOnSiteIsCentral) // not central site
            {
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
                product.SiteCreated = true;
                product.Name = logOnSite.PrefixEntityName(product.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
            }

            if (selectedSites != null)
            {
                product.Sites = new List<Site>();
                foreach (var site in selectedSites)
                {
                    var siteToAdd = db.Sites.Find(int.Parse(site));
                    product.Sites.Add(siteToAdd);
                }
                List<AssignedSiteData> siteData = GetEntityAssignedSiteData(db, product.Sites);
                ViewBag.Sites = siteData;

            }
            ViewBag.Direction = new SelectList(CoreConstants.DIRECTIONS, product.Direction);
            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories, "ID", "Name", product.ProductCategoryID);
            if (!logOnSiteIsCentral)
            {
                ViewBag.DestinationID = new SelectList(logOnSite.Destinations.OrderBy(d => d.Name), "ID", "Name", product.DestinationID);
                ViewBag.SourceID = new SelectList(logOnSite.Sources.OrderBy(d => d.Name), "ID", "Name", product.SourceID);
            }
            else
            {
                ViewBag.DestinationID = new SelectList(db.Destinations.Where(d => d.SiteCreated == false).OrderBy(d => d.Name), "ID", "Name", product.DestinationID);
                ViewBag.SourceID = new SelectList(db.Sources.Where(d => d.SiteCreated == false).OrderBy(d => d.Name), "ID", "Name", product.SourceID);
            }
            var nameExist = db.Products.FirstOrDefault(e => e.Name == product.Name);
            if (nameExist != null)
            {
                var prodType = nameExist.ProductType == "W" ? "Product" : "CountedItem";
                ModelState.AddModelError("Name", prodType + " already exists");
                return View(product);
            }
            if (ModelState.IsValid)
            {
                product.Name = product.Name.ToUpper();
                db.Products.Add(product);
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (selectedSites != null)
                {
                    foreach (var site in selectedSites)
                    {
                        var siteToAdd = db.Sites.Find(int.Parse(site));
                        if (siteToAdd != null)
                        {
                            WriteReplicationLog(siteToAdd.ID, product.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                        }

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(product.Name + " created successfully! ", logOnSite);
                return RedirectToAction("Edit/" + product.ID.ToString());
            }


            return View(product);
        }

        /// <summary>
        /// Navigate to edit page from the grid edit action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Product/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProduct;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProduct;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProduct;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");


            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = new Product { Name = "Connection Failed! Retry later." };

            try
            {
                entity = db.Products.Include(e => e.Sites).Where(e => e.ID == id).Single();

                if (entity == null)
                {
                    return HttpNotFound();
                }

                ViewBag.ProductOrItem = GetDisplayTitle(entity.ProductType, false);


                ViewBag.ProductOrItem = GetDisplayTitle(entity.ProductType, false);
                ViewBag.Direction = new SelectList(CoreConstants.DIRECTIONS, entity.Direction);
                ViewBag.ProductCategoryID = new SelectList(db.ProductCategories.OrderBy(d => d.Name), "ID", "Name", entity.ProductCategoryID);

                if (!logOnSiteIsCentral)
                {
                    ViewBag.Sites = new List<AssignedSiteData>();
                    ViewBag.DestinationID = new SelectList(logOnSite.Destinations.OrderBy(d => d.Name), "ID", "Name", entity.DestinationID);
                    ViewBag.SourceID = new SelectList(logOnSite.Sources.OrderBy(d => d.Name), "ID", "Name", entity.SourceID);
                    ViewBag.EPAStatus = new SelectList(new List<string> { "", "Leviable", "Exempt", "Non-Waste", "Under Contract", "Other" }, entity.EPA_Status);
                }
                else
                {
                    ViewBag.Sites = GetEntityAssignedSiteData(db, entity.Sites);
                    ViewBag.DestinationID = new SelectList(db.Destinations.Where(d => d.SiteCreated == false).OrderBy(d => d.Name), "ID", "Name", entity.DestinationID);
                    ViewBag.SourceID = new SelectList(db.Sources.Where(d => d.SiteCreated == false).OrderBy(d => d.Name), "ID", "Name", entity.SourceID);
                    ViewBag.EPAStatus = new SelectList(new List<string> { "", "Leviable", "Exempt", "Non-Waste", "Under Contract", "Other" }, entity.EPA_Status);
                }


            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }


            return View(entity);
        }

        /// <summary>
        /// Updated Product data in the DB
        /// </summary>
        /// <param name="id"></param>
        /// <param name="selectedSites"></param>
        /// <returns></returns>

        // POST: Product/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditProduct")]
        //public ActionResult Edit([Bind(Include = "ID,Name,Code,Description,InLocalDiscount,InLocalDiscountGST,OutLocalDiscount,OutLocalDiscountGST,MinLocalDiscount,InVisitStandard,InVisitStandardGST,OutVisitStandard,OutVisitStandardGST,MinVisitStandard,EPALevy,MinEPALevy,ProductCategoryID")] Product product)
        public ActionResult Edit(int? id, string[] selectedSites)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProduct;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProduct;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProduct;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            if (!logOnSiteIsCentral) // not central site
            {
                ViewBag.IsCentralSite = false;
                selectedSites = new string[1];
                selectedSites[0] = logOnSite.ID.ToString();
            }

            entity = db.Products.Include(e => e.Sites).Where(e => e.ID == id).Single();
            ViewBag.ProductOrItem = GetDisplayTitle(entity.ProductType, false);

            ViewBag.ProductCategoryID = new SelectList(db.ProductCategories, "ID", "Name", entity.ProductCategoryID);
            ViewBag.Direction = new SelectList(CoreConstants.DIRECTIONS, entity.Direction);

            if (!logOnSiteIsCentral)
            {
                ViewBag.Sites = new List<AssignedSiteData>();
                ViewBag.DestinationID = new SelectList(logOnSite.Destinations.OrderBy(d => d.Name), "ID", "Name", entity.DestinationID);
                ViewBag.SourceID = new SelectList(logOnSite.Sources.OrderBy(d => d.Name), "ID", "Name", entity.SourceID);
                ViewBag.EPAStatus = new SelectList(new List<string> { "", "Leviable", "Exempt", "Non-Waste", "Under Contract", "Other" }, entity.EPA_Status);
            }
            else
            {
                ViewBag.Sites = GetEntityAssignedSiteData(db, entity.Sites);
                ViewBag.DestinationID = new SelectList(db.Destinations.Where(d => d.SiteCreated == false).OrderBy(d => d.Name), "ID", "Name", entity.DestinationID);
                ViewBag.SourceID = new SelectList(db.Sources.Where(d => d.SiteCreated == false).OrderBy(d => d.Name), "ID", "Name", entity.SourceID);
                ViewBag.EPAStatus = new SelectList(new List<string> { "", "Leviable", "Exempt", "Non-Waste", "Under Contract", "Other" }, entity.EPA_Status);
            }


            if (TryUpdateModel(entity, "", new string[] { "Name", "Description", "Code", "InLocalDiscount", "InLocalDiscountGST", "OutLocalDiscount", "OutLocalDiscountGST",
                "MinLocalDiscount", "InVisitStandard", "InVisitStandardGST", "OutVisitStandard", "OutVisitStandardGST", "MinVisitStandard", "EPALevy",
                "ProductCategoryID", "DestinationID", "SourceID", "Direction", "IsActive", "LiftBoomGate", "Report_To_EPA", "EPA_Status", "NoOfDockets",
                "LedgerAccount", "SchedulePriceDate", "StockLevel","Royalty", "ToVolumeFactor","MinWeight","InLocalDiscount_S","OutLocalDiscount_S","MinLocalDiscount_S",
            "InVisitStandard_S","OutVisitStandard_S","MinVisitStandard_S","EPALevy_S","MinEPALevy_S","ResourceCode"}))
            {
                try
                {
                    var productExist = db.Products.FirstOrDefault(e => e.Name == entity.Name);
                    if (productExist != null)
                    {
                        if (productExist.ID == entity.ID)
                        {
                            if (ModelState.IsValid)
                            {
                                var entityUpdate = db.Products.Find(entity.ID);
                                entityUpdate.Name = entity.Name.ToUpper();
                                entityUpdate.Description = entity.Description;
                                entityUpdate.Code = entity.Code;
                                entityUpdate.InLocalDiscount = entity.InLocalDiscount;
                                entityUpdate.InLocalDiscountGST = entity.InLocalDiscountGST;
                                entityUpdate.OutLocalDiscount = entity.OutLocalDiscount;
                                entityUpdate.OutLocalDiscountGST = entity.OutLocalDiscountGST;
                                entityUpdate.MinLocalDiscount = entity.MinLocalDiscount;
                                entityUpdate.InVisitStandard = entity.InVisitStandard;
                                entityUpdate.InVisitStandardGST = entity.InVisitStandardGST;
                                entityUpdate.OutVisitStandard = entity.OutVisitStandard;
                                entityUpdate.OutVisitStandardGST = entity.OutVisitStandardGST;
                                entityUpdate.MinVisitStandard = entity.MinVisitStandard;
                                entityUpdate.EPALevy = entity.EPALevy;
                                entityUpdate.ProductCategoryID = entity.ProductCategoryID;
                                entityUpdate.DestinationID = entity.DestinationID;
                                entityUpdate.SourceID = entity.SourceID;
                                entityUpdate.Direction = entity.Direction;
                                entityUpdate.IsActive = entity.IsActive;
                                entityUpdate.LiftBoomGate = entity.LiftBoomGate;
                                entityUpdate.EPA = entity.EPA;
                                entityUpdate.EPA_Status = entity.EPA_Status;
                                entityUpdate.NoOfDockets = entity.NoOfDockets;
                                entityUpdate.LedgerAccount = entity.LedgerAccount;
                                entityUpdate.SchedulePriceDate = entity.SchedulePriceDate;
                                entityUpdate.StockLevel = entity.StockLevel;
                                entityUpdate.Royalty = entity.Royalty;
                                entityUpdate.MinWeight = entity.MinWeight;
                                entityUpdate.InLocalDiscount_S = entity.InLocalDiscount_S;
                                entityUpdate.OutLocalDiscount_S = entity.OutLocalDiscount_S;
                                entityUpdate.MinLocalDiscount_S = entity.MinLocalDiscount_S;
                                entityUpdate.InVisitStandard_S = entity.InVisitStandard_S;
                                entityUpdate.OutVisitStandard_S = entity.OutVisitStandard_S;
                                entityUpdate.MinVisitStandard_S = entity.MinVisitStandard_S;
                                entityUpdate.EPALevy_S = entity.EPALevy_S;
                                entityUpdate.MinEPALevy_S = entity.MinEPALevy_S;
                                entityUpdate.ResourceCode = entity.ResourceCode;

                                UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);

                                if (TryUpdateModel(entityUpdate, "",
                                         new string[]  { "Name", "Description", "Code", "InLocalDiscount", "InLocalDiscountGST", "OutLocalDiscount", "OutLocalDiscountGST",
                                                        "MinLocalDiscount", "InVisitStandard", "InVisitStandardGST", "OutVisitStandard", "OutVisitStandardGST", "MinVisitStandard", "EPALevy",
                                                        "ProductCategoryID", "DestinationID", "SourceID", "Direction", "IsActive", "LiftBoomGate", "Report_To_EPA", "EPA_Status", "NoOfDockets",
                                                        "LedgerAccount", "SchedulePriceDate", "StockLevel","Royalty", "ToVolumeFactor","MinWeight","InLocalDiscount_S","OutLocalDiscount_S","MinLocalDiscount_S",
            "InVisitStandard_S","OutVisitStandard_S","MinVisitStandard_S","EPALevy_S","MinEPALevy_S","ResourceCode"}))

                                    db.SaveChanges();



                                //Adding to the ReplicationLogItem for data sync
                                if (selectedSites != null)
                                {
                                    foreach (var site in selectedSites)
                                    {
                                        var siteToAdd = db.Sites.Find(int.Parse(site));
                                        if (siteToAdd != null)
                                        {
                                            WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                        }

                                    }

                                }

                                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ");
                                return RedirectToAction("Edit/" + entity.ID.ToString());
                            }
                        }
                        else
                        {
                            var prodType = entity.ProductType == "W" ? "Product" : "CountedItem";
                            ModelState.AddModelError("Name", prodType + " already exists");
                            return View(entity);
                        }
                    }
                    if (ModelState.IsValid)
                    {

                        entity.Name = entity.Name.ToUpper();
                        UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);
                        if (!logOnSiteIsCentral) // not central site
                        {
                            entity.Name = logOnSite.PrefixEntityName(entity.Name, SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix);
                        }
                        db.Entry(entity).State = EntityState.Modified;
                        db.SaveChanges();

                        //Adding to the ReplicationLogItem for data sync
                        if (selectedSites != null)
                        {
                            foreach (var site in selectedSites)
                            {
                                var siteToAdd = db.Sites.Find(int.Parse(site));
                                if (siteToAdd != null)
                                {
                                    WriteReplicationLog(siteToAdd.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                                }

                            }

                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " edited successfully! ", logOnSite);
                        return RedirectToAction("Edit/" + entity.ID.ToString());
                    }

                }
                catch (RetryLimitExceededException)
                {
                    //Log the error (uncomment dex variable name and add a line here to write a log.
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }
            UpdateEntitySiteAssignments(db, selectedSites, entity.Sites);

            return View(entity);
        }

        /// <summary>
        /// Navigate to the Delete page from the grid delete action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Product/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProduct;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProduct;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProduct;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Products.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }

            ViewBag.ProductOrItem = GetDisplayTitle(entity.ProductType, false);
            return View(entity);
        }

        /// <summary>
        /// Removed Product from the Product table
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteProduct")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProduct;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProduct;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProduct;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            try
            {
                entity = db.Products.Find(id);
                if (entity != null)
                {
                    ViewBag.ProductOrItem = GetDisplayTitle(entity.ProductType, false);
                    entity.IsActive = false;
                    db.Entry(entity).State = EntityState.Modified;
                    db.SaveChanges();
                    TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");

                    var siteList = db.Sites.Where(s => s.ID > 1).ToList();
                    foreach (var siteItem in siteList)
                    {
                        WriteReplicationLog(siteItem.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                    }
                }

            }
            catch (Exception)
            {
                var prodType = entity.ProductType == "W" ? "Product" : "CountedItem";
                TempData["UserMessage"] = ComposeTempDisplayMessage("This " + prodType + " " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }
            return RedirectToAction("Index", new { productType = entity.ProductType });
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
