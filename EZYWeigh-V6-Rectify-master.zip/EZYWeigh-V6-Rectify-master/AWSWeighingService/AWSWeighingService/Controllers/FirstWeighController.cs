﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using PagedList;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace AWSWeighingService.Controllers
{
    public class FirstWeighController : EntityController<FirstWeigh>
    {
        // GET: FirstWeigh

        [SessionAccess]      
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page, string sDate, string eDate, int? sId, string rego, int? filterPageSize)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();

            //ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;           
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteFirstWeigh;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("FirstWeigh");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.DateTimeInSortParm = (sortOrder == "DateTimeIn" ? "DateTimeIn_Desc" : "DateTimeIn");
            ViewBag.SiteSortParm = (sortOrder == "Site" ? "Site_Desc" : "Site");
            ViewBag.WeighmanSortParm = (sortOrder == "Weighman" ? "Weighman_Desc" : "Weighman");

            ViewBag.sDate = sDate;
            ViewBag.eDate = eDate;
            ViewBag.AllSites = db.Sites.Where(s => s.ID > 1).ToList();
            sId = sId ?? db.Sites.Where(s => s.ID > 1).FirstOrDefault().ID;
            ViewBag.sId = sId;            
            ViewBag.rego = rego;

            //if (searchString != null)
            //{
            //    page = 1;
            //}
            //else
            //{
            //    searchString = currentFilter;
            //}

            //ViewBag.CurrentFilter = searchString;

            DateTime? paramStartDate = null;
            DateTime? paramEndDate = null;
            if (!string.IsNullOrEmpty(sDate))
            {

                paramStartDate = Convert.ToDateTime(sDate);
            }
            else
            {
                paramStartDate = DateTime.Now;
                //ViewBag.sDate = paramStartDate.Value.ToShortDateString();
                ViewBag.sDate = paramStartDate.Value.Date.ToString("yyyy-MM-dd");
            }

            if (!string.IsNullOrEmpty(eDate))
            {

                paramEndDate = Convert.ToDateTime(eDate);

            }
            else
            {
                paramEndDate = DateTime.Now;
                //ViewBag.eDate = paramEndDate.Value.ToShortDateString();
                ViewBag.eDate = paramEndDate.Value.Date.ToString("yyyy-MM-dd"); ;
            }

            entities = db.FirstWeighs.Include(o => o.Site).Include(o => o.Weighman);

            entities = entities.Where(e => e.SiteID == sId && (DbFunctions.TruncateTime(e.TareInDate) >= DbFunctions.TruncateTime(paramStartDate.Value) && DbFunctions.TruncateTime(e.TareInDate) <= DbFunctions.TruncateTime(paramEndDate.Value)));

            if (!string.IsNullOrEmpty(rego))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(rego.ToUpper()));
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "DateTimeIn":
                    entities = entities.OrderBy(e => e.TareInDate);
                    break;
                case "DateTimeIn_Desc":
                    entities = entities.OrderByDescending(e => e.TareInDate);
                    break;
                case "Site":
                    entities = entities.OrderBy(e => e.Site.Name);
                    break;
                case "Site_Desc":
                    entities = entities.OrderByDescending(e => e.Site.Name);
                    break;
                case "Weighman":
                    entities = entities.OrderBy(e => e.Weighman.Name);
                    break;
                case "Weighman_Desc":
                    entities = entities.OrderByDescending(e => e.Weighman.Name);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        // GET: FirstWeigh/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            //ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;            
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteFirstWeigh;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.FirstWeighs.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        // POST: FirstWeigh/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteFirstWeigh")]

        public ActionResult DeleteConfirmed(int id)
        {

            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();
            //ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;            
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteFirstWeigh;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            entity = db.FirstWeighs.Find(id);
            db.FirstWeighs.Remove(entity);
            db.SaveChanges();
            TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}