﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using PagedList;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{    
    public class VehicleConfigurationController : EntityController<VehicleConfiguration>
    {
        /// <summary>
        /// Here get the list of vehicle configurations based on the filters
        /// Navigate to the index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <param name="tareMin"></param>
        /// <param name="tareMax"></param>
        /// <param name="maxLoadMin"></param>
        /// <param name="maxLoadMax"></param>
        /// <returns></returns>
        // GET: VehicleConfiguration
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string code, decimal? tareMin, decimal? tareMax, decimal? maxLoadMin, decimal? maxLoadMax)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruckConfiguration;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruckConfiguration;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruckConfiguration;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Truck Configurations");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");
            ViewBag.DescriptionSortParm = (sortOrder == "Description" ? "Description_Desc" : "Description");
            ViewBag.TareSortParm = (sortOrder == "Tare" ? "Tare_Desc" : "Tare");
            ViewBag.MaxLoadSortParm = (sortOrder == "MaxLoad" ? "MaxLoad_Desc" : "MaxLoad");
          
            entities = from e in db.VehicleConfigurations where e.ID > CoreConstants.NA_ID select e;

            //Filters

            ViewBag.name = name;
            ViewBag.code = code;
            ViewBag.tareMin = tareMin;
            ViewBag.tareMax = tareMax;
            ViewBag.maxLoadMin = maxLoadMin;
            ViewBag.maxLoadMax = maxLoadMax;


            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!String.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));
            }

            if (tareMin != null || tareMax != null)
            {
                if (!String.IsNullOrEmpty(tareMin.ToString()) && tareMin != 0 && !String.IsNullOrEmpty(tareMax.ToString()) && tareMax != 0)
                    entities = entities.Where(e => e.Tare >= tareMin && e.Tare <= tareMax);
                else
                if (!String.IsNullOrEmpty(tareMin.ToString()) && tareMin != 0) entities = entities.Where(e => e.Tare >= tareMin);
                else
                if (!String.IsNullOrEmpty(tareMax.ToString()) && tareMax != 0) entities = entities.Where(e => e.Tare <= tareMax);
            }

            if (maxLoadMin != null || maxLoadMax != null)
            {
                if (!String.IsNullOrEmpty(maxLoadMin.ToString()) && maxLoadMin != 0 && !String.IsNullOrEmpty(maxLoadMax.ToString()) && maxLoadMax != 0)
                    entities = entities.Where(e => e.MaxLoad >= maxLoadMin && e.MaxLoad <= maxLoadMax);
                else
                if (!String.IsNullOrEmpty(maxLoadMin.ToString()) && maxLoadMin != 0) entities = entities.Where(e => e.MaxLoad >= maxLoadMin);
                else
                if (!String.IsNullOrEmpty(maxLoadMax.ToString()) && maxLoadMax != 0) entities = entities.Where(e => e.MaxLoad <= maxLoadMax);
            }
            
            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;
                case "Description":
                    entities = entities.OrderBy(e => e.Description);
                    break;
                case "Description_Desc":
                    entities = entities.OrderByDescending(e => e.Description);
                    break;
                case "Tare":
                    entities = entities.OrderBy(e => e.Tare);
                    break;
                case "Tare_Desc":
                    entities = entities.OrderByDescending(e => e.Tare);
                    break;
                case "MaxLoad":
                    entities = entities.OrderBy(e => e.MaxLoad);
                    break;
                case "MaxLoad_Desc":
                    entities = entities.OrderByDescending(e => e.MaxLoad);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Here get the details of the vechileConfiguration based on the id
        /// Navigates to the deatils page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        // GET: VehicleConfiguration/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruckConfiguration;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.VehicleConfigurations.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Here it renders the create a vehicle configuration page with the default values
        /// </summary>
        /// <returns></returns>
        // GET: VehicleConfiguration/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruckConfiguration;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruckConfiguration;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruckConfiguration;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            return View();
        }

        /// <summary>
        /// Here it stores the vehicle configuration data to the VehicleConfigurations table
        /// Renders the edit vehicleConfiguration edit page
        /// </summary>
        /// <param name="vehicleConfiguration"></param>
        /// <returns></returns>
        // POST: VehicleConfiguration/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewTruckConfiguration")]
        public ActionResult Create([Bind(Include = "ID,Name,Code,Description,Tare,MaxLoad")] VehicleConfiguration vehicleConfiguration)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruckConfiguration;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruckConfiguration;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruckConfiguration;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            var allSiteIDs = db.Sites.Where(t => t.ID > CoreConstants.NA_ID).Select(t => t.ID).ToList();


            var nameExist = db.VehicleConfigurations.FirstOrDefault(e => e.Name == vehicleConfiguration.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "TruckConfiguration already exists");
                return View(vehicleConfiguration);
            }
            if (ModelState.IsValid)
            {
                vehicleConfiguration.Name = vehicleConfiguration.Name.ToUpper();
                db.VehicleConfigurations.Add(vehicleConfiguration);
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (allSiteIDs != null)
                {
                    foreach (var siteID in allSiteIDs)
                    {
                        WriteReplicationLog(siteID, vehicleConfiguration.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(vehicleConfiguration.Name + " created successfully!");     
                return RedirectToAction("Edit/" + vehicleConfiguration.ID.ToString());
            }

            return View(vehicleConfiguration);
        }

        /// <summary>
        /// Here get the details of the vehicle configuration based on the id
        /// Renders the edit page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: VehicleConfiguration/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruckConfiguration;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruckConfiguration;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruckConfiguration;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.VehicleConfigurations.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Here update the details of the config in the VehicleConfiguration table
        /// </summary>
        /// <param name="vehicleConfiguration"></param>
        /// <returns></returns>

        // POST: VehicleConfiguration/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditTruckConfiguration")]
        public ActionResult Edit([Bind(Include = "ID,Name,Code,Description,Tare,MaxLoad")] VehicleConfiguration vehicleConfiguration)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruckConfiguration;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruckConfiguration;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruckConfiguration;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            var allSiteIDs = db.Sites.Where(t => t.ID > CoreConstants.NA_ID).Select(t => t.ID).ToList();


            var vehicleConfigurationExist = db.VehicleConfigurations.FirstOrDefault(m => m.Name == vehicleConfiguration.Name);
            if (vehicleConfigurationExist != null)
            {
                if (vehicleConfigurationExist.ID == vehicleConfiguration.ID)
                {
                    if (ModelState.IsValid)
                    {
                        var entityUpdate = db.VehicleConfigurations.Find(vehicleConfiguration.ID);
                        entityUpdate.Name = vehicleConfiguration.Name.ToUpper();
                        entityUpdate.Description = vehicleConfiguration.Description;
                        entityUpdate.Code = vehicleConfiguration.Code;
                        entityUpdate.Tare = vehicleConfiguration.Tare;
                        entityUpdate.MaxLoad = vehicleConfiguration.MaxLoad;

                        if (TryUpdateModel(entityUpdate, "",
                                 new string[] { "Name", "Description", "Code", "Tare", "MaxLoad" }))

                            db.SaveChanges();


                        //Adding to the ReplicationLogItem for data sync
                        if (allSiteIDs != null)
                        {
                            foreach (var siteID in allSiteIDs)
                            {
                                WriteReplicationLog(siteID, vehicleConfiguration.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                            }

                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(vehicleConfiguration.Name + " edited successfully!");                 
                        return RedirectToAction("Edit/" + vehicleConfiguration.ID.ToString());
                    }
                }
                else
                {
                    ModelState.AddModelError("Name", "TruckConfiguration already exists");
                    return View(vehicleConfiguration);
                }
            }

            if (ModelState.IsValid)
            {
                vehicleConfiguration.Name = vehicleConfiguration.Name.ToUpper();
                db.Entry(vehicleConfiguration).State = EntityState.Modified;
                TempData["UserMessage"] = ComposeTempDisplayMessage(vehicleConfiguration.Name + " edited successfully!");
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (allSiteIDs != null)
                {
                    foreach (var siteID in allSiteIDs)
                    {
                        WriteReplicationLog(siteID, vehicleConfiguration.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                    }

                }
                return RedirectToAction("Edit/" + vehicleConfiguration.ID.ToString());
            }
            return View(vehicleConfiguration);
        }

        /// <summary>
        /// Here get the details of the configuration based on the id
        /// Navigates to the delete config page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: VehicleConfiguration/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruckConfiguration;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruckConfiguration;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruckConfiguration;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.VehicleConfigurations.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Here remove the VehicleConfiguration record from the table based on the id
        /// Navigates to the index page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: VehicleConfiguration/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteTruckConfiguration")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewTruckConfiguration;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditTruckConfiguration;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteTruckConfiguration;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            try
            {
                entity = db.VehicleConfigurations.Find(id);
                db.VehicleConfigurations.Remove(entity);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
            }
            catch
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This truckconfiguration " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }
                
        protected override void Dispose(bool disposing)
        {
            if (disposing && db!=null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
