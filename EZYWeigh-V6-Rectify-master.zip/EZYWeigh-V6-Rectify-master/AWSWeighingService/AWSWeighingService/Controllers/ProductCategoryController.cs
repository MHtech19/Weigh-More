﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using PagedList;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class ProductCategoryController : EntityController<ProductCategory>
    {
        /// <summary>
        /// Get the Product Category list - navigate to index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <returns></returns>
        // GET: ProductCategory
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string code)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewProductCategory;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProductCategory;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProductCategory;

            logOnSiteIsCentral = (logOnSite.ID == CoreConstants.NA_ID);
            ViewBag.IsCentralSite = logOnSiteIsCentral;
            ViewBag.LongonSiteID = logOnSite.ID;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Product Categories");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");
            ViewBag.DescriptionSortParm = (sortOrder == "Description" ? "Description_Desc" : "Description");

            entities = from e in db.ProductCategories where e.ID > CoreConstants.NA_ID select e;

            //Filters

            ViewBag.Name = name;
            ViewBag.Code = code;

            if (!string.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!string.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;
                case "Description":
                    entities = entities.OrderBy(e => e.Description);
                    break;
                case "Description_Desc":
                    entities = entities.OrderByDescending(e => e.Description);
                    break;


                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Get the details of the Product Category from the grid Details action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: ProductCategory/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProductCategory;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProductCategory;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProductCategory;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.ProductCategories.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Navigate to the the Create Product Category page from the index page
        /// </summary>
        /// <returns></returns>
        // GET: ProductCategory/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProductCategory;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProductCategory;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProductCategory;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            return View();
        }

        /// <summary>
        ///  Save new product cateory into the DB
        /// </summary>
        /// <param name="productCategory"></param>
        /// <returns></returns>

        // POST: ProductCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.

        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewProductCategory")]
        public ActionResult Create([Bind(Include = "ID,Name,Description,Code,CreationDate")] ProductCategory productCategory)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProductCategory;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProductCategory;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProductCategory;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            var allSiteIDs = db.Sites.Where(t => t.ID > CoreConstants.NA_ID).Select(t => t.ID).ToList();
            //bool IsProductCategoryExist = IsProductNameExist(productCategory.Name);
            var IsProductCategoryExist = db.ProductCategories.FirstOrDefault(m => m.Name == productCategory.Name);
            if (IsProductCategoryExist != null)
            {
                ModelState.AddModelError("Name", "ProductCategory already exists");
                return View(productCategory);
            }

            if (ModelState.IsValid)
            {
                productCategory.Name = productCategory.Name.ToUpper();
                db.ProductCategories.Add(productCategory);
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (allSiteIDs != null)
                {
                    foreach (var siteID in allSiteIDs)
                    {
                        WriteReplicationLog(siteID, productCategory.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(productCategory.Name + " created successfully!");                
                return RedirectToAction("Edit/" + productCategory.ID.ToString());
            }

            return View(productCategory);
        }

        /// <summary>
        /// Navigate to the edit page from the grid edit action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        // GET: ProductCategory/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProductCategory;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProductCategory;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProductCategory;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.ProductCategories.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Update product category details to the DB
        /// </summary>
        /// <param name="productCategory"></param>
        /// <returns></returns>
        // POST: ProductCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditProductCategory")]
        public ActionResult Edit([Bind(Include = "ID,Name,Description,Code,CreationDate")] ProductCategory productCategory)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProductCategory;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProductCategory;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProductCategory;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            var allSiteIDs = db.Sites.Where(t => t.ID > CoreConstants.NA_ID).Select(t => t.ID).ToList();

            var IsProductCategoryExist = db.ProductCategories.FirstOrDefault(m => m.Name == productCategory.Name);
            if (IsProductCategoryExist != null)
            {
                if (IsProductCategoryExist.ID == productCategory.ID)
                {
                    if (ModelState.IsValid)
                    {
                        var entityUpdate = db.ProductCategories.Find(productCategory.ID);
                        entityUpdate.Name = productCategory.Name.ToUpper();
                        entityUpdate.Description = productCategory.Description;
                        entityUpdate.Code = productCategory.Code;

                        if (TryUpdateModel(entityUpdate, "",
                                 new string[] { "Name", "Description", "Code" }))

                            db.SaveChanges();


                        //Adding to the ReplicationLogItem for data sync
                        if (allSiteIDs != null)
                        {
                            foreach (var siteID in allSiteIDs)
                            {
                                WriteReplicationLog(siteID, productCategory.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                            }

                        }

                        TempData["UserMessage"] = ComposeTempDisplayMessage(productCategory.Name + " edited successfully!");
                        return RedirectToAction("Edit/" + productCategory.ID.ToString());
                    }
                }
                else
                {
                    ModelState.AddModelError("Name", "ProductCategory already exists");
                    return View(productCategory);
                }
            }

            if (ModelState.IsValid)
            {
                productCategory.Name = productCategory.Name.ToUpper();
                db.Entry(productCategory).State = EntityState.Modified;
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (allSiteIDs != null)
                {
                    foreach (var siteID in allSiteIDs)
                    {
                        WriteReplicationLog(siteID, productCategory.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(productCategory.Name + " edited successfully!");                
                return RedirectToAction("Edit/" + productCategory.ID.ToString());
            }
            return View(productCategory);
        }

        /// <summary>
        /// Navigate to the delete page from the grid delete action based on the product category id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: ProductCategory/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProductCategory;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProductCategory;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProductCategory;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.ProductCategories.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Removed Product Category from the DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: ProductCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteProductCategory")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewProductCategory;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditProductCategory;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteProductCategory;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            try
            {
                entity = db.ProductCategories.Find(id);
                db.ProductCategories.Remove(entity);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");
            }
            catch (Exception)
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This productcategory " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }

        public bool IsProductNameExist(string Name)
        {
            var validateName = db.ProductCategories.FirstOrDefault(m => m.Name == Name);
            if (validateName != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
