﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using PagedList;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class OffenceController : EntityController<Offence>
    {
        /// <summary>
        /// Get the List of Offences - navigate to index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="weighman"></param>
        /// <param name="site"></param>
        /// <param name="rDate"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        // GET: Offence
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string weighman, string site, string rDate, string status)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditOffence;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteOffence;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Offences");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.DescriptionSortParm = (sortOrder == "Description" ? "Description_Desc" : "Description");
            ViewBag.DateTimeInSortParm = (sortOrder == "DateTimeIn" ? "DateTimeIn_Desc" : "DateTimeIn");
            ViewBag.SiteSortParm = (sortOrder == "Site" ? "Site_Desc" : "Site");
            ViewBag.WeighmanSortParm = (sortOrder == "Weighman" ? "Weighman_Desc" : "Weighman");

            entities = db.Offences.Include(o => o.Site).Include(o => o.Weighman);

            if (!logOnSiteIsCentral) // not CENTRAL site
            {
                if (logOnSite.Offences == null)
                {
                    entities = from e in db.Offences where e.ID == Constants.NAEntityID select e;
                }
                else
                {
                    entities = logOnSite.Offences.AsQueryable<Offence>();
                }
            }


            //Filters

            ViewBag.Sites = db.Sites.Select(e => new { Id = e.ID, Name = e.Name }).OrderBy(e => e.Name).ToList();
            ViewBag.Weighmans = db.Weighmen.Where(w => w.IsAWSSupportUser == false).Select(e => new { Id = e.ID, Name = e.Name }).OrderBy(e => e.Name).ToList();

            //By default load active offences
            status = status ?? "true";

            ViewBag.name = name;
            ViewBag.weighman = weighman;
            ViewBag.site = site;
            ViewBag.rDate = rDate;
            ViewBag.status = status;

            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!String.IsNullOrEmpty(weighman) && weighman != "All")
            {
                int weighmanId = int.Parse(weighman);
                entities = entities.Where(e => e.WeighmanID == weighmanId);
            }

            if (!String.IsNullOrEmpty(site) && site != "All")
            {
                int siteId = int.Parse(site);
                entities = entities.Where(e => e.SiteID == siteId);
            }

            if (!String.IsNullOrEmpty(status) && status != "All")
            {
                bool statusId = bool.Parse(status);
                entities = entities.Where(e => e.IsActive == statusId);
            }

            DateTime? paramInDate = null;

            if (!String.IsNullOrEmpty(rDate))
            {
                paramInDate = Convert.ToDateTime(rDate);
                entities = entities.Where(e => DbFunctions.TruncateTime(e.DateTimeIn) == DbFunctions.TruncateTime(paramInDate.Value));
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Description":
                    entities = entities.OrderBy(e => e.Description);
                    break;
                case "Description_Desc":
                    entities = entities.OrderByDescending(e => e.Description);
                    break;
                case "DateTimeIn":
                    entities = entities.OrderBy(e => e.DateTimeIn);
                    break;
                case "DateTimeIn_Desc":
                    entities = entities.OrderByDescending(e => e.DateTimeIn);
                    break;
                case "Site":
                    entities = entities.OrderBy(e => e.Site.Name);
                    break;
                case "Site_Desc":
                    entities = entities.OrderByDescending(e => e.Site.Name);
                    break;
                case "Weighman":
                    entities = entities.OrderBy(e => e.Weighman.Name);
                    break;
                case "Weighman_Desc":
                    entities = entities.OrderByDescending(e => e.Weighman.Name);
                    break;
                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }

            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;
            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Get the detailsof the offence from the grid action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Offence/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditOffence;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteOffence;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Offences.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            entity.InTime = entity.DateTimeIn;
            return View(entity);
        }
        /// <summary>
        /// Create a new offence - navigate to the create a newgrid page
        /// </summary>
        /// <returns></returns>
        // GET: Offence/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditOffence;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteOffence;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            ViewBag.SiteID = new SelectList(db.Sites.Where(s => s.ID > 1), "ID", "Name");
            ViewBag.WeighmanID = new SelectList(db.Weighmen.Where(w => w.IsAWSSupportUser == false), "ID", "Name");


            Offence entity = new Offence() { };
            entity.DateTimeIn = DateTime.Now;
            entity.InTime = DateTime.Now;
            entity.IsActive = true;
            return View(entity);
        }


        /// <summary>
        /// Save the new offence to the DB
        /// </summary>
        /// <param name="offence"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewOffence")]
        public ActionResult Create(Offence offence)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditOffence;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteOffence;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");

            if (ModelState.IsValid)
            {
                offence.DateTimeIn = new DateTime(offence.DateTimeIn.Year, offence.DateTimeIn.Month, offence.DateTimeIn.Day, offence.InTime.Hour, offence.InTime.Minute, 0);
                db.Offences.Add(offence);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(offence.Name + " created successfully!");

                //Adding to the ReplicationLogItem for data sync
                foreach (var site in db.Sites.Where(s => s.ID > 1).ToList())
                {
                    WriteReplicationLog(site.ID, offence.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                }

                return RedirectToAction("Index");
            }

            ViewBag.SiteID = new SelectList(db.Sites.Where(s => s.ID > 1), "ID", "Name");
            ViewBag.WeighmanID = new SelectList(db.Weighmen.Where(w => w.IsAWSSupportUser == false), "ID", "Name");

            return View(offence);
        }

        /// <summary>
        /// Navigate to the edit offence page from the grid edit action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Offence/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditOffence;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteOffence;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Offences.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }

            ViewBag.SiteID = new SelectList(db.Sites.Where(s => s.ID > 1), "ID", "Name", entity.SiteID);
            ViewBag.WeighmanID = new SelectList(db.Weighmen.Where(w => w.IsAWSSupportUser == false), "ID", "Name", entity.WeighmanID);

            entity.InTime = entity.DateTimeIn;
            return View(entity);
        }

        /// <summary>
        /// Update the offence details
        /// </summary>
        /// <param name="offence"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditOffence")]
        public ActionResult Edit(Offence offence)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];
            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditOffence;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteOffence;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (ModelState.IsValid)
            {
                offence.DateTimeIn = new DateTime(offence.DateTimeIn.Year, offence.DateTimeIn.Month, offence.DateTimeIn.Day, offence.InTime.Hour, offence.InTime.Minute, 0);
                db.Entry(offence).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(offence.Name + " edited successfully!");

                //Adding to the ReplicationLogItem for data sync
                foreach (var site in db.Sites.Where(s => s.ID > 1).ToList())
                {
                    WriteReplicationLog(site.ID, offence.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                }
                return RedirectToAction("Index");
            }

            ViewBag.SiteID = new SelectList(db.Sites.Where(s => s.ID > 1), "ID", "Name");
            ViewBag.WeighmanID = new SelectList(db.Weighmen.Where(w => w.IsAWSSupportUser == false), "ID", "Name");

            return View(offence);
        }

        /// <summary>
        /// Delete the offence - navigate to the details page before delete offence
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Offence/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditOffence;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteOffence;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Offences.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            entity.InTime = entity.DateTimeIn;
            return View(entity);
        }

        /// <summary>
        /// Removed offence from the DB
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Offence/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteOffence")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewOffence;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditOffence;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteOffence;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            entity = db.Offences.Find(id);
            //db.Offences.Remove(entity);
            entity.IsActive = false;
            db.Entry(entity).State = EntityState.Modified;
            db.SaveChanges();
            TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");

            //Adding to the ReplicationLogItem for data sync
            foreach (var site in db.Sites.Where(s => s.ID > 1).ToList())
            {
                WriteReplicationLog(site.ID, entity.ID, CoreConstants.InsertOp, logOnSite.ID, db);
            }

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db!=null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
