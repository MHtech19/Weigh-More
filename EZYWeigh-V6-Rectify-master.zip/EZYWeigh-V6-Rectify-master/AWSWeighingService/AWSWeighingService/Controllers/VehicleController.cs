﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using PagedList;
using System.Data.Entity.Infrastructure;
using AWSWeighingService.ViewModels;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    
    public class VehicleController : EntityController<Vehicle>
    {
        /// <summary>
        /// Here get the list of vehicles based on the filters
        /// Renders the index page
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="page"></param>
        /// <param name="filterPageSize"></param>
        /// <param name="name"></param>
        /// <param name="code"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        // GET: Vehicle
        [SessionAccess]
        public ActionResult Index(string sortOrder, int? page, int? filterPageSize, string name, string code, string status)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Vehicle Types");

            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = (String.IsNullOrEmpty(sortOrder) ? "Name_Desc" : "");
            ViewBag.CodeSortParm = (sortOrder == "Code" ? "Code_Desc" : "Code");
            ViewBag.DescriptionSortParm = (sortOrder == "Description" ? "Description_Desc" : "Description");

            entities = from e in db.Vehicles select e;

            entities = entities.Where(e => e.ID > CoreConstants.NA_ID);

            //Filters

            status = status ?? "true";
            ViewBag.name = name;
            ViewBag.code = code;
            ViewBag.status = status;

            if (!String.IsNullOrEmpty(name))
            {
                entities = entities.Where(e => e.Name.ToUpper().Contains(name.ToUpper()));
            }

            if (!String.IsNullOrEmpty(code))
            {
                entities = entities.Where(e => e.Code.ToUpper().Contains(code.ToUpper()));
            }

            if (!String.IsNullOrEmpty(status) && status != "All")
            {
                bool statusId = bool.Parse(status);
                entities = entities.Where(e => e.IsActive == statusId);
            }

            switch (sortOrder)
            {
                case "Name_Desc":
                    entities = entities.OrderByDescending(e => e.Name);
                    break;
                case "Code":
                    entities = entities.OrderBy(e => e.Code);
                    break;
                case "Code_Desc":
                    entities = entities.OrderByDescending(e => e.Code);
                    break;
                case "Description":
                    entities = entities.OrderBy(e => e.Description);
                    break;
                case "Description_Desc":
                    entities = entities.OrderByDescending(e => e.Description);
                    break;

                default:
                    entities = entities.OrderBy(e => e.Name);
                    break;
            }
            pageNumber = (page ?? 1);
            pageSize = filterPageSize ?? pageSize;

            ViewBag.filterPageSize = pageSize;

            try
            {
                return View(entities.ToPagedList(pageNumber, pageSize));
            }
            catch (RetryLimitExceededException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                return HttpNotFound();
            }
        }

        /// <summary>
        /// Here get the details of the Vehicle based on the vehicle id
        /// Renders the details page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Vehicle/Details/5
        [SessionAccess]
        public ActionResult Details(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;

            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Details");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Vehicles.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        /// Here it creates a new vehicle and reders the create page
        /// </summary>
        /// <returns></returns>
        // GET: Vehicle/Create
        [SessionAccess]
        public ActionResult Create()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.InOut = new SelectList(new List<string> { "", "In", "Out" });
            Vehicle entity = new Vehicle() { };
            entity.IsActive = true;
            return View(entity);
        }

        /// <summary>
        /// Here insert the new vehilce in the Vehicle table
        /// </summary>
        /// <param name="vehicle"></param>
        /// <returns></returns>
        // POST: Vehicle/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanNewVehicleType")]
        public ActionResult Create([Bind(Include = "ID,Name,Code,Description,NetWeight,InLocalDiscount,InLocalDiscountGST,InVisitStandard,InVisitStandardGST,IsActive,InLocalDiscount_S,InVisitStandard_S,SchedulePriceDate")] Vehicle vehicle)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Create");
            ViewBag.InOrOut = new SelectList(new List<string> { "", "In", "Out" });

            var allSiteIDs = db.Sites.Where(t => t.ID > CoreConstants.NA_ID).Select(t => t.ID).ToList();

            var productNA = db.Products.Single(e => e.ID == 1 && e.IsActive);

            var nameExist = db.Vehicles.FirstOrDefault(e => e.Name == vehicle.Name);
            if (nameExist != null)
            {
                ModelState.AddModelError("Name", "VehicleType already exists");
                return View(vehicle);
            }

            if (ModelState.IsValid)
            {
                vehicle.Name = vehicle.Name.ToUpper();
                vehicle.Product = productNA;
                db.Vehicles.Add(vehicle);
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (allSiteIDs != null)
                {
                    foreach (var siteID in allSiteIDs)
                    {
                        WriteReplicationLog(siteID, vehicle.ID, CoreConstants.InsertOp, logOnSite.ID, db);
                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(vehicle.Name + " created successfully!");
                return RedirectToAction("Edit/" + vehicle.ID.ToString());
            }

            return View(vehicle);
        }

        /// <summary>
        /// Here get the details of the vehicle based on the id
        /// Renders the edit page 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Vehicle/Edit/5
        [SessionAccess]
        public ActionResult Edit(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Vehicles.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            var vehicleProdPricelist = from vProdPrice in db.VehicleProductPrices
                                       join allProduct in db.Products on vProdPrice.ProductID equals allProduct.ID
                                       where vProdPrice.VehicleID == entity.ID
                                       select new { ID = vProdPrice.ProductID, Name = allProduct.Name };

            if (vehicleProdPricelist.IsEmpty())
            {
                var linkedProduct = db.Products.FirstOrDefault(e => e.ID == entity.ProductID);
                var prodList = new List<Product> { linkedProduct };
                ViewBag.ProductID = new SelectList(prodList, "ID", "Name", CoreConstants.NA_ID);
            }
            else
            {
                ViewBag.ProductID = new SelectList(vehicleProdPricelist.OrderBy(e => e.Name), "ID", "Name", entity.ProductID);
            }

            return View(entity);
        }

        /// <summary>
        /// Here update the details of the vehicle in the vehicle table
        /// Renders edit page
        /// </summary>
        /// <param name="vehicle"></param>
        /// <returns></returns>
        // POST: Vehicle/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanEditVehicleType")]
        public ActionResult Edit([Bind(Include = "ID,Name,Code,Description,ProductID,InLocalDiscount,InLocalDiscountGST,InVisitStandard,InVisitStandardGST,NetWeight,IsActive,InLocalDiscount_S,InVisitStandard_S,SchedulePriceDate")] Vehicle vehicle)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Edit");

            var linkedProduct = db.Products.FirstOrDefault(e => e.ID == vehicle.ProductID);
            var prodList = new List<Product> { linkedProduct };
            ViewBag.ProductID = new SelectList(prodList, "ID", "Name", CoreConstants.NA_ID);

            var allSiteIDs = db.Sites.Where(t => t.ID > CoreConstants.NA_ID).Select(t => t.ID).ToList();

            var vehicleExist = db.Vehicles.FirstOrDefault(m => m.Name == vehicle.Name);
            if (vehicleExist != null)
            {
                if (vehicleExist.ID == vehicle.ID)
                {
                    if (ModelState.IsValid)
                    {
                        var entityUpdate = db.Vehicles.Find(vehicle.ID);
                        entityUpdate.Name = vehicle.Name.ToUpper();
                        entityUpdate.Description = vehicle.Description;
                        entityUpdate.Code = vehicle.Code;
                        entityUpdate.ProductID = vehicle.ProductID;
                        entityUpdate.InLocalDiscount = vehicle.InLocalDiscount;
                        entityUpdate.InLocalDiscountGST = vehicle.InLocalDiscountGST;
                        entityUpdate.InVisitStandard = vehicle.InVisitStandard;
                        entityUpdate.InVisitStandardGST = vehicle.InVisitStandardGST;
                        entityUpdate.NetWeight = vehicle.NetWeight;
                        entityUpdate.IsActive = vehicle.IsActive;
                        entityUpdate.InLocalDiscount_S = vehicle.InLocalDiscount_S;
                        entityUpdate.InVisitStandard_S = vehicle.InVisitStandard_S;
                        entityUpdate.SchedulePriceDate = vehicle.SchedulePriceDate;

                        if (TryUpdateModel(entityUpdate, "",
                                 new string[] { "Name", "Description", "Code", "ProductID", "InLocalDiscount", "InLocalDiscountGST", "InVisitStandard", "InVisitStandardGST", "NetWeight", "IsActive","InLocalDiscount_S","InVisitStandard_S","SchedulePriceDate" }))

                            db.SaveChanges();

                        //Adding to the ReplicationLogItem for data sync
                        if (allSiteIDs != null)
                        {
                            foreach (var siteID in allSiteIDs)
                            {
                                WriteReplicationLog(siteID, vehicle.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                            }

                        }
                        TempData["UserMessage"] = ComposeTempDisplayMessage(vehicle.Name + " edited successfully!");
                        return RedirectToAction("Edit/" + vehicle.ID.ToString());
                    }
                }
                else
                {
                    ModelState.AddModelError("Name", "VehicleType already exists");
                    return View(vehicle);
                }
            }

            if (ModelState.IsValid)
            {
                vehicle.Name = vehicle.Name.ToUpper();
                db.Entry(vehicle).State = EntityState.Modified;
                db.SaveChanges();

                //Adding to the ReplicationLogItem for data sync
                if (allSiteIDs != null)
                {
                    foreach (var siteID in allSiteIDs)
                    {
                        WriteReplicationLog(siteID, vehicle.ID, CoreConstants.InsertOp, logOnSite.ID, db);

                    }

                }

                TempData["UserMessage"] = ComposeTempDisplayMessage(vehicle.Name + " edited successfully!");
                return RedirectToAction("Edit/" + vehicle.ID.ToString());
            }
            return View(vehicle);
        }

        /// <summary>
        /// Here get the details of the Vehicle based on the id
        /// Renders delete page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        // GET: Vehicle/Delete/5
        [SessionAccess]
        public ActionResult Delete(int? id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            entity = db.Vehicles.Find(id);
            if (entity == null)
            {
                return HttpNotFound();
            }
            return View(entity);
        }

        /// <summary>
        ///Here remove the vehicle from the vehicle talbe
        ///Renders index page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // POST: Vehicle/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteVehicleType")]
        public ActionResult DeleteConfirmed(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = logOnSite.ComposeDisplayTitleForView("Delete");

            try
            {
                entity = db.Vehicles.Find(id);
                //db.Vehicles.Remove(entity);
                entity.IsActive = false;
                db.Entry(entity).State = EntityState.Modified;
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(entity.Name + " deleted successfully!");

                var siteList = db.Sites.Where(s => s.ID > 1).ToList();
                foreach (var siteItem in siteList)
                {
                    WriteReplicationLog(siteItem.ID, entity.ID, CoreConstants.UpdateOp, logOnSite.ID, db);
                }
            }
            catch
            {
                TempData["UserMessage"] = ComposeTempDisplayMessage("This vehicle " + entity.Name + " is being used in transaction or referred elsewhere and hence cannot be deleted.");
            }

            return RedirectToAction("Index");
        }

        [SessionAccess]
        public ActionResult AddProduct(int productId, int id = 1)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            Vehicle currentVehicle = db.Vehicles.FirstOrDefault(e => e.ID == id);
            VehicleProductPrice vehicleProductPrice = new VehicleProductPrice();

            List<Product> AllProductsExceptLinked = null;

            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;

            try
            {
                if (!logOnSiteIsCentral)
                {
                    AllProductsExceptLinked = logOnSite.Products.OrderBy(e => e.Name).ToList();

                }
                else
                {
                    AllProductsExceptLinked = db.Products.Where(e => e.SiteCreated == false).OrderBy(e => e.Name).ToList();

                }

                vehicleProductPrice = db.VehicleProductPrices.Include(e => e.Vehicle).FirstOrDefault(e => e.VehicleID == id && e.ProductID == productId);

                if (vehicleProductPrice == null)
                {
                    vehicleProductPrice = new VehicleProductPrice
                    {
                        VehicleID = id,
                        ProductID = productId
                    };
                    db.VehicleProductPrices.Add(vehicleProductPrice);
                    db.SaveChanges();

                };

                var vehicleProdPricelist = from vehicleProdPrice in db.VehicleProductPrices
                                           join allProduct in db.Products on vehicleProdPrice.ProductID equals allProduct.ID
                                           where vehicleProdPrice.VehicleID == id
                                           select new { ID = vehicleProdPrice.ProductID, Name = allProduct.Name };
                ViewBag.ProductID = new SelectList(vehicleProdPricelist.OrderBy(e => e.Name), "ID", "Name", vehicleProductPrice.ProductID);



                foreach (var jplist in vehicleProdPricelist.ToList())
                {
                    Product deleProduct = db.Products.FirstOrDefault(e => e.ID == jplist.ID);
                    AllProductsExceptLinked.Remove(deleProduct);
                }

                ViewBag.DisplayTitle = "Add Products to Vehicle: " + currentVehicle.Name;
                ViewBag.AllProductID = new SelectList(AllProductsExceptLinked, "ID", "Name", 1);
                ViewBag.SelectedVehicleID = currentVehicle.ID;


                ViewBag.ShowDropButton = (vehicleProdPricelist.Count() > 1);

            }
            catch (RetryLimitExceededException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(vehicleProductPrice);

        }

        /// <summary>
        /// Here add a product to the vehicle
        /// </summary>
        /// <param name="allProductID"></param>
        /// <param name="linkedVehicleID"></param>
        /// <param name="inLocalDiscount"></param>
        /// <param name="inVisitStandard"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        public ActionResult AddProduct(int allProductID, int linkedVehicleID, decimal inLocalDiscount, decimal inVisitStandard)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            VehicleProductPrice vehicleProductPrice = new VehicleProductPrice { VehicleID = linkedVehicleID, ProductID = allProductID, InLocalDiscount = inLocalDiscount, InVisitStandard = inVisitStandard };
            List<Product> AllProductsExceptLinked = null;

            Product newlyLinkedProduct = db.Products.FirstOrDefault(e => e.ID == allProductID);


            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = "Add Product";

            if (ModelState.IsValid)
            {
                db.VehicleProductPrices.Add(vehicleProductPrice);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(newlyLinkedProduct.Name + " linked successfully! ", logOnSite);
            }

            var vehiProdPricelist = from vProdPrice in db.VehicleProductPrices
                                    join allProduct in db.Products on vProdPrice.ProductID equals allProduct.ID
                                    where vProdPrice.VehicleID == vehicleProductPrice.VehicleID
                                    select new { ID = vProdPrice.ProductID, Name = allProduct.Name };

            if (!vehiProdPricelist.IsEmpty())
            {

                ViewBag.ProductID = new SelectList(vehiProdPricelist.OrderBy(e => e.Name), "ID", "Name", vehicleProductPrice.ProductID);
            }

            if (!logOnSiteIsCentral)
            {
                AllProductsExceptLinked = logOnSite.Products.OrderBy(e => e.Name).ToList();

            }
            else
            {
                AllProductsExceptLinked = db.Products.Where(e => e.SiteCreated == false).OrderBy(e => e.Name).ToList();

            }

            foreach (var vjplist in vehiProdPricelist.ToList())
            {
                Product deleProduct = db.Products.FirstOrDefault(e => e.ID == vjplist.ID);
                AllProductsExceptLinked.Remove(deleProduct);
            }

            ViewBag.AllProductID = new SelectList(AllProductsExceptLinked, "ID", "Name", 1);

            ViewBag.ShowDropButton = (vehiProdPricelist.Count() > 1);


            return View(vehicleProductPrice);

        }

        /// <summary>
        /// Here drop link of the product from the vehicle
        /// </summary>
        /// <param name="productID"></param>
        /// <param name="vehicleLinkedID"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        [CheckForAccess("CanDeleteVehicleType")]
        public ActionResult DropProduct(int productID, int vehicleLinkedID)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            VehicleProductPrice vehicleProductPriceDropped = db.VehicleProductPrices.Include(e => e.Product).FirstOrDefault(e => e.VehicleID == vehicleLinkedID && e.ProductID == productID);
            Vehicle hostVehicle = db.Vehicles.FirstOrDefault(e => e.ID == vehicleLinkedID);

            bool defaultLinkedProductDropped = (hostVehicle.ProductID == vehicleProductPriceDropped.ProductID);

            List<Product> AllProductsExceptLinked = null;


            SetViewBagValues();
            ViewBag.CanNew = (Session["Role"] as Role).CanNewVehicleType;
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditVehicleType;
            ViewBag.CanDelete = (Session["Role"] as Role).CanDeleteVehicleType;
            ViewBag.DisplayTitle = "Add Product";

            string prodName = vehicleProductPriceDropped.Product.Name;

            if (ModelState.IsValid)
            {
                db.VehicleProductPrices.Remove(vehicleProductPriceDropped);
                db.SaveChanges();
                TempData["UserMessage"] = ComposeTempDisplayMessage(prodName + " droped successfully! ", logOnSite);
            }

            var vehiProdPricelist = from vProdPrice in db.VehicleProductPrices
                                    join allProduct in db.Products on vProdPrice.ProductID equals allProduct.ID
                                    where vProdPrice.VehicleID == vehicleProductPriceDropped.VehicleID
                                    select new { ID = vProdPrice.ProductID, Name = allProduct.Name };

            if (!vehiProdPricelist.IsEmpty())
            {
                ViewBag.ProductID = new SelectList(vehiProdPricelist.OrderBy(e => e.Name), "ID", "Name", vehicleProductPriceDropped.ProductID);
            }

            if (!logOnSiteIsCentral)
            {
                AllProductsExceptLinked = logOnSite.Products.OrderBy(e => e.Name).ToList();

            }
            else
            {
                AllProductsExceptLinked = db.Products.Where(e => e.SiteCreated == false).OrderBy(e => e.Name).ToList();

            }

            foreach (var vjplist in vehiProdPricelist.ToList())
            {
                Product deleProduct = db.Products.FirstOrDefault(e => e.ID == vjplist.ID);
                AllProductsExceptLinked.Remove(deleProduct);
            }

            ViewBag.AllProductID = new SelectList(AllProductsExceptLinked, "ID", "Name", 1);


            var vPPList = db.VehicleProductPrices.Where(e => e.VehicleID == vehicleLinkedID).OrderBy(e => e.Product.Name);

            ViewBag.ShowDropButton = (vPPList.Count() > 1);

            VehicleProductPrice vPP = vPPList.ToArray().ElementAt<VehicleProductPrice>(0);

            if (defaultLinkedProductDropped)
            {
                hostVehicle.ProductID = vPP.ProductID;
                db.Entry(hostVehicle).State = EntityState.Modified;
                db.SaveChanges();
            }
            return View("AddProduct", vPP);

        }

        /// <summary>
        /// Get the price based on teh product and vehicle ids
        /// </summary>
        /// <param name="productID"></param>
        /// <param name="vehicleID"></param>
        /// <returns></returns>
        
        public JsonResult GetVehicleProductPriceShownJson(int productID, int vehicleID)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }


            var vpprice = db.VehicleProductPrices.Include(e => e.Vehicle).Include(e => e.Product).Single(e => e.ProductID == productID && e.VehicleID == vehicleID);
            var vppriceJson = new VehicleProductPriceViewModel { Vehicle = vpprice.Vehicle.Name, VehicleID = vpprice.VehicleID, Product = vpprice.Product.Name, ProductID = vpprice.ProductID, InLocalDiscount = vpprice.InLocalDiscount, InVisitStandard = vpprice.InVisitStandard };
            return Json(vppriceJson, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Here update the price based on the product and vehicle ids
        /// </summary>
        /// <param name="vehicleProductPrice"></param>
        /// <returns></returns>
        
        public JsonResult UpdateVehicleProductPriceShownJson(VehicleProductPrice vehicleProductPrice)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }

            var vpprice = db.VehicleProductPrices.Include(e => e.Vehicle).Include(e => e.Product).Single(e => e.ProductID == vehicleProductPrice.ProductID && e.VehicleID == vehicleProductPrice.VehicleID);
            if (TryUpdateModel(vpprice, "", new string[] { "InLocalDiscount", "InVisitStandard" }))
            {
                try
                {
                    if (ModelState.IsValid)
                    {

                        db.Entry(vpprice).State = EntityState.Modified;
                        db.SaveChanges();

                    }
                }
                catch (RetryLimitExceededException)
                {

                }
            }

            var vppriceJson = new VehicleProductPriceViewModel { Vehicle = vpprice.Vehicle.Name, VehicleID = vpprice.VehicleID, Product = vpprice.Product.Name, ProductID = vpprice.ProductID, InLocalDiscount = vpprice.InLocalDiscount, InVisitStandard = vpprice.InVisitStandard };
            return Json(vppriceJson, JsonRequestBehavior.AllowGet);
        }

        public PartialViewResult GetVehicleProductPriceShown([Bind(Include = "ProductID,VehicleID,InLocalDiscount,InVisitStandard")] VehicleProductPrice vehicleProductPrice)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            if (!String.IsNullOrEmpty(DataBaseConnectionStringName))
            {
                RecreatDbContextByConnStringName(DataBaseConnectionStringName);
            }
            var vpprice = db.VehicleProductPrices.Include(e => e.Product).Single(e => e.ProductID == vehicleProductPrice.ProductID && e.VehicleID == vehicleProductPrice.VehicleID);
            return PartialView(vpprice);
        }


        
        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
