﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AWSWeighingService.Infrastructure;
using System.Data.Entity;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using AWSWeighingService.DAL;

namespace AWSWeighingService.Controllers
{
    [SessionAccess]
    public class SettingsController : EntityController<Site>
    {
        // GET: Settings
        [CheckForAccess("CanEditAppSettings")]
        public ActionResult Index()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditAppSettings;
            List<Site> listOfSites = (from s in db.Sites select s).OrderBy(s=>s.ID).ToList();

            return View(listOfSites);
        }

        [CheckForAccess("CanEditAppSettings")]
        public ActionResult EditOrganization(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditAppSettings;
            Site selectedSite = db.Sites.Where(s=>s.ID==id).FirstOrDefault();
            if(selectedSite!=null && !string.IsNullOrEmpty(selectedSite.SiteCount))
            {
                string siteCount = selectedSite.SiteCount.Decrypt();                
                selectedSite.NoOfSites =siteCount;
            }
            else
            {
                selectedSite.NoOfSites = "0";
            }

            return View(selectedSite);
        }

        [HttpPost]
        [CheckForAccess("CanEditAppSettings")]
        public ActionResult EditOrganization(Site siteModel)
        {
            DataBaseConnectionStringName = GetConnectionStringNameFromSession();
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditAppSettings;
            Site selectedSite = db.Sites.Where(s => s.ID == siteModel.ID).FirstOrDefault();
            int noOfsitesAlreadyExists = db.Sites.Where(s => s.ID != 1).Count();
            int noOfCount = Convert.ToInt32(siteModel.NoOfSites);
            if (noOfCount < noOfsitesAlreadyExists)
            {
                ModelState.AddModelError("", string.Format("Please enter valid site number. Already {0} site(s) exists.", noOfsitesAlreadyExists));
                return View(selectedSite);
            }

            //update site count
            selectedSite.SiteCount = siteModel.NoOfSites.Encrypt();
            selectedSite.NoOfUsersAllowed = siteModel.NoOfUsersAllowed;

            db.Entry(selectedSite).State = EntityState.Modified;
            db.SaveChanges();
            TempData["UserMessage"] = ComposeTempDisplayMessage("Organization edited successfully.");
            return View(selectedSite);
        }

        [CheckForAccess("CanEditAppSettings")]
        public ActionResult EditSite(int id)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditAppSettings;
            Site selectedSites = db.Sites.Where(s => s.ID == id).FirstOrDefault();            
            return View(selectedSites);
        }

        [HttpPost]
        [CheckForAccess("CanEditAppSettings")]
        public ActionResult EditSite(Site siteModel)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            ViewBag.CanEdit = (Session["Role"] as Role).CanEditAppSettings;
            Site selectedSites = db.Sites.Where(s => s.ID == siteModel.ID).FirstOrDefault();
            //update site
            selectedSites.IsProductPricesIncludingGST = siteModel.IsProductPricesIncludingGST;
            selectedSites.IsVehicleTypePricesIncludingGST = siteModel.IsVehicleTypePricesIncludingGST;
            selectedSites.IsJobCartagePricesIncludingGST = siteModel.IsJobCartagePricesIncludingGST;

            db.Entry(selectedSites).State = EntityState.Modified;
            db.SaveChanges();

            //Adding to the ReplicationLogItem for data sync
            WriteReplicationLog(siteModel.ID, siteModel.ID, CoreConstants.UpdateOp, logOnSite.ID, db);

            TempData["UserMessage"] = ComposeTempDisplayMessage("Site edited successfully.");
            return View(selectedSites);
        }
    }
}