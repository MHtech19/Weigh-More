﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace AWSWeighingService.Controllers
{
    public class UpdateController : EntityController<Weighman>
    {
        [SessionAccess]
        // GET: Update
        public ActionResult Index()
        {
            logOnRole = (Role)RouteData.Values["logOnRole"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            ViewBag.ShowEdit = logOnRole.IsAWSSupportRole;
            SetViewBagValues();
            UpdateInfo info = new UpdateInfo();          

            var file = Server.MapPath("~/ApplicationUpdates.html");            
            if (!System.IO.File.Exists(file))
            {
                return HttpNotFound();
            }
            info.UpdateDetails = System.IO.File.ReadAllText(file);            

            return View(info);
        }

        [HttpGet]
        public JsonResult GetNotifications()
        {
            //List<UpdateInfo> lstDataSubmit = new List<UpdateInfo>();
            UpdateInfo info = new UpdateInfo();

            var file = Server.MapPath("~/ApplicationUpdates.html");
            info.UpdateDetails = System.IO.File.ReadAllText(file);

            if (!string.IsNullOrEmpty(info.UpdateDetails))
            {
                string[] noTags = info.UpdateDetails.Split(new[] { "<p>" }, StringSplitOptions.RemoveEmptyEntries);
                info.LinksCount = noTags.Count();
            }
            else
            {
                info.LinksCount = 0;
            }
            
            return Json(info, JsonRequestBehavior.AllowGet);
        }

        [SessionAccess]
        public ActionResult Edit()
        {
            logOnRole = (Role)RouteData.Values["logOnRole"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];            
            SetViewBagValues();
            UpdateInfo info = new UpdateInfo();          

            var file = Server.MapPath("~/ApplicationUpdates.html");
            if (!System.IO.File.Exists(file))
            {
                return HttpNotFound();
            }
            info.UpdateDetails = System.IO.File.ReadAllText(file);           

            return View(info);
        }

        [SessionAccess]
        [HttpPost]
        public ActionResult Edit(UpdateInfo info)
        {
            logOnRole = (Role)RouteData.Values["logOnRole"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];            
            SetViewBagValues();

            var file = Server.MapPath("~/ApplicationUpdates.html");
            if (!System.IO.File.Exists(file))
            {
                return HttpNotFound();
            }           
            System.IO.File.WriteAllText(file, info.UpdateDetails);
           
            return RedirectToAction("Index");
        }
    }
}