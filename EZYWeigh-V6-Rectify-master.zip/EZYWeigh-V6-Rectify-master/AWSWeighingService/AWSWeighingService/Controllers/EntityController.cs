﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using System.Data.Entity.Infrastructure;
using PagedList;
using AWSWeighingService.ViewModels;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Abstract;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using WeighBridge.Core.Device;

namespace AWSWeighingService.Controllers
{
    [Authorize]
    public class EntityController<TEntity> : Controller where TEntity : IEntityID
    {
        //protected AWSWeighingServiceContext clientDb = new AWSWeighingServiceContext();
        protected AWSWeighingServiceContext db = new AWSWeighingServiceContext();

        protected IQueryable<TEntity> entities;
        protected TEntity entity;
        protected Site logOnSite;
        protected Weighman logOnWeighman;
        protected string DataBaseConnectionStringName;
        protected bool logOnSiteIsCentral;
        protected int pageSize = SingletonWebConfigAppSetttings.Instance.PageSize;
        protected string ReportLink = SingletonWebConfigAppSetttings.Instance.ReportLink;
        protected Role logOnRole;
        protected int pageNumber;

        protected string GetConnectionStringNameFromSession()
        {
            string connStrName = null;
            var sessionLogonWeighManName = Session["CurrentWeighmanName"];
            if (sessionLogonWeighManName == null) return connStrName;

            string logonWeighManNameFromSession = (string)sessionLogonWeighManName;
            string[] splitLogonName = logonWeighManNameFromSession.Split(DeviceConstants.CHAR_DOT);
            if (splitLogonName.Length > 1)
            {
                connStrName = splitLogonName[0];
            }
            else
            {
                connStrName = string.Empty;
            }
            return connStrName;
        }

        protected void RecreatDbContextByConnStringName(string connStringName)
        {
            db = new AWSWeighingServiceContext(connStringName);
        }

        

        protected Site GetSiteFromSession(AWSWeighingServiceContext db)
        {
            Site currentSite = null;
            var sessionCurrentSiteID = Session["CurrentSiteID"];
            var sessionLogonWeighMan = Session["CurrentWeighmanID"];
            var sessionLogonWeighManName = Session["CurrentSiteName"];
            var sessionRole = Session["Role"] ;

            if ((sessionCurrentSiteID == null) || (sessionLogonWeighManName == null))
            {

                return currentSite;
            }
            else
            {
                int logOnSiteIDFromSession = (int)sessionCurrentSiteID;
                currentSite = db.Sites.Where(s => s.ID == logOnSiteIDFromSession).FirstOrDefault();
                int logOnWeighManIDFromSession = (int)sessionLogonWeighMan;
                logOnWeighman = db.Weighmen.Where(w => w.ID == logOnWeighManIDFromSession).FirstOrDefault();
                logOnRole = sessionRole as Role;
                

                return currentSite;
            }
        }       

        protected void SetViewBagValues()
        {
            logOnSiteIsCentral = (logOnSite.ID == CoreConstants.NA_ID);
            ViewBag.IsCentralSite = logOnSiteIsCentral;
            ViewBag.LongonSiteID = logOnSite.ID;
            ViewBag.IsAdmin = logOnWeighman.IsAdmin;
            string url = Request.Url.AbsoluteUri;
            ViewBag.ReportWizardUrl = ReportLink + "?SiteID=" + logOnSite.ID.ToString() + "&SiteName=" + logOnSite.Name + "&ReturnUrl=" + url;
        }

        protected string GetDisplayTitle(string entityType, bool isPlural)
        {
            string displayTitle;
            switch (entityType)
            {
                case "C": displayTitle = "Customer";
                    break;
                case "S": displayTitle = "Supplier";
                    break;
                case "W": displayTitle = "Product";
                    break;
                case "I": displayTitle = "Counted Item";
                    break;
                default: displayTitle = "Customer";
                    break;
            }

            if (isPlural)
            {
                displayTitle = displayTitle + "s";
            }

            return displayTitle;
        }

        protected string ComposeTempDisplayMessage(string message, Site currentSite = null)
        {
            string displayMessage = message;

            if (currentSite != null)
            {
                if (currentSite.ID != CoreConstants.NA_ID) //
                {
                    if (!SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix)
                    {
                        displayMessage = message + Environment.NewLine + "Note: the site name prefix " + currentSite.Name + ". is for avoiding name confilct!";
                    }
                    else
                    {
                        displayMessage = message + Environment.NewLine + "Note: the site code prefix " + currentSite.Code + ". is for avoiding name confilct!";
                    }

                }
            }

            return displayMessage;
        }


        protected List<AssignedSiteData> GetEntityAssignedSiteData(AWSWeighingServiceContext dbContext, ICollection<Site> assignedSites)
        {
            var allSites = dbContext.Sites.Where(s => s.ID > CoreConstants.NA_ID);


            var customerSites = new HashSet<int>(assignedSites.Select(s => s.ID));
            var viewModel = new List<AssignedSiteData>();
            foreach (var site in allSites)
            {
                viewModel.Add(new AssignedSiteData
                {
                    SiteID = site.ID,
                    Name = site.Name,
                    Assigned = customerSites.Contains(site.ID)
                });
            }

            return viewModel;
        }

        protected void UpdateEntitySiteAssignments(AWSWeighingServiceContext dbContext, string[] selectedSites, ICollection<Site> assignedSites)
        {

            if (selectedSites == null)
            {
                assignedSites = new List<Site>();
                return;
            }


            var selectedSitesHS = new HashSet<string>(selectedSites);
            var assignedSitesHS = new HashSet<int>(assignedSites.Select(s => s.ID));

            foreach (var site in dbContext.Sites)
            {
                if (selectedSitesHS.Contains(site.ID.ToString()))
                {
                    if (!assignedSitesHS.Contains(site.ID))
                    {
                        assignedSites.Add(site);
                    }
                }
                else
                {
                    if (assignedSitesHS.Contains(site.ID))
                    {
                        assignedSites.Remove(site);
                    }
                }
            }
        }

        protected void CreateSingleLogTargetingSingleSite(int destinationSiteID, string entityTypeName, int entityID,  string OperationType, int sourceSiteID, AWSWeighingServiceContext dbContext)
        {
            ReplicationLogItem logItem = new ReplicationLogItem
            {
                DestinationSiteID = destinationSiteID,
                EntityType = entityTypeName,
                EntityID = entityID,
                
                Operation = OperationType,
                SourceSiteID = sourceSiteID,
                LogCreated=DateTime.UtcNow                
            };

            dbContext.ReplicationLogItems.Add(logItem);
            dbContext.SaveChanges();
            //Logger.LogActivity("tran  repl log inserted");
        }

        protected void WriteReplicationLog(int destinationID, int entityID, string operationType, int loginSiteID, AWSWeighingServiceContext dbContext)
        {

            string entityTypeName = typeof(TEntity).Name.ToString();
            CreateSingleLogTargetingSingleSite(destinationID, entityTypeName, entityID, operationType, loginSiteID, dbContext);


        }

    }
}