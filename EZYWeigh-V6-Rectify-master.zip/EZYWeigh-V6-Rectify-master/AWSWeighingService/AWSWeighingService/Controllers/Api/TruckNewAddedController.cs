﻿using AWSWeighingService.Controllers.Api;
using AWSWeighingService.DAL;
using AWSWeighingService.Logging;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace PublicWeigh.Web.api
{
    public class TruckNewAddedController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        public IEnumerable<Truck> Get(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            try
            {
                var trucks = db.Trucks.Where(c => c.ID >= id).OrderBy(c => c.ID).ToList(); // uow.JobRepo.GetAll();
                return trucks;

            }
            catch
            {
                //Logger.LogActivity("exception down loading customers: " + ex.InnerException);
                return new List<Truck>();
            }

        }
    }
}
