﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class VehicleConfigurationController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;
        
        /// <summary>
        /// Here get the list of vehicle configuration details from db 
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/VehicleConfiguration
        public IQueryable<VehicleConfiguration> GetVehicleConfigurations(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.VehicleConfigurations.Where(e => e.ID > 1).OrderBy(e => e.Name);
        }

        /// <summary>
        /// Here get the vehicle configuration details based on the vehicle configuration id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/VehicleConfiguration/5
        [ResponseType(typeof(VehicleConfiguration))]
        public async Task<IHttpActionResult> GetVehicleConfigurations(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            VehicleConfiguration vehicleConfiguration = await db.VehicleConfigurations.FindAsync(id);
            if (vehicleConfiguration == null)
            {
                return NotFound();
            }

            return Ok(vehicleConfiguration);
        }

        /// <summary>
        /// Here update the vehicle configuration details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="vehicleConfiguration"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/VehicleConfiguration/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutVehicleConfiguration(int id, VehicleConfiguration vehicleConfiguration, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != vehicleConfiguration.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(vehicleConfiguration).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VehicleConfigurationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Here create a new vehicle configuration based on the model
        /// </summary>
        /// <param name="vehicleConfiguration"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>

        // POST: api/VehicleConfiguration
        [ResponseType(typeof(VehicleConfiguration))]
        public async Task<IHttpActionResult> PostVehicleConfiguration(VehicleConfiguration vehicleConfiguration, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.VehicleConfigurations.Add(vehicleConfiguration);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = vehicleConfiguration.ID }, vehicleConfiguration);
        }


        /// <summary>
        /// Here delete the vehicle configuration based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/VehicleConfiguration/5
        [ResponseType(typeof(VehicleConfiguration))]
        public async Task<IHttpActionResult> DeleteVehicleConfiguration(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            VehicleConfiguration vehicleConfiguration = await db.VehicleConfigurations.FindAsync(id);
            if (vehicleConfiguration == null)
            {
                return NotFound();
            }

            db.VehicleConfigurations.Remove(vehicleConfiguration);
            await db.SaveChangesAsync();

            return Ok(vehicleConfiguration);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool VehicleConfigurationExists(int id)
        {
            return db.VehicleConfigurations.Count(e => e.ID == id) > 0;
        }

    }
}
