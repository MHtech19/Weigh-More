﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class VehicleProductPriceController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Here get the vehicle product prices based on the vehicle id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/VehicleProductPrice/2
        public IList<VehicleProductPrice> GetVehicleProductPrices(int id = -1, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            if (id == -1)
            {
                return db.VehicleProductPrices.ToList();
            }
            return db.VehicleProductPrices.Where(e => e.VehicleID == id).ToList(); 
        }

        /// <summary>
        /// Here update the product and price of the vehicle based on the vehicle id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="vehicleProductPrice"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        
        // PUT: api/VehicleProductPrice/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutVehicleProductPrice(int id, VehicleProductPrice vehicleProductPrice, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != vehicleProductPrice.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(vehicleProductPrice).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VehicleProductPriceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Here create a new VehicleProductPrice based on the model
        /// </summary>
        /// <param name="vehicleProductPrice"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/VehicleProductPrice
        [ResponseType(typeof(VehicleProductPrice))]
        public IHttpActionResult PostVehicleProductPrice(VehicleProductPrice vehicleProductPrice, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.VehicleProductPrices.Add(vehicleProductPrice);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = vehicleProductPrice.ID }, vehicleProductPrice);
        }

        /// <summary>
        /// Here delete the product and price of the vehicle based on the vehicle id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/VehicleProductPrice/5
        [ResponseType(typeof(VehicleProductPrice))]
        public IHttpActionResult DeleteVehicleProductPrice(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            VehicleProductPrice vehicleProductPrice = db.VehicleProductPrices.Find(id);
            if (vehicleProductPrice == null)
            {
                return NotFound();
            }

            db.VehicleProductPrices.Remove(vehicleProductPrice);
            db.SaveChanges();

            return Ok(vehicleProductPrice);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool VehicleProductPriceExists(int id)
        {
            return db.VehicleProductPrices.Count(e => e.ID == id) > 0;
        }
    }
}