﻿using AWSWeighingService.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class DocketController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the docket details based on the site id
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET api/docket/5
        public string Get(int ID, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            var site = db.Sites.FirstOrDefault(s => s.ID == ID);
            if (site != null)
            {
                return site.DocketHead + (site.CurrentDocket + 1).ToString();
            }
            else
            {
                return "1";
            }

            //return new int[] {db.Transactions.Where(t => t.SiteID == SiteID).Max(t => t.Docket) + 1};


        }

    }
}
