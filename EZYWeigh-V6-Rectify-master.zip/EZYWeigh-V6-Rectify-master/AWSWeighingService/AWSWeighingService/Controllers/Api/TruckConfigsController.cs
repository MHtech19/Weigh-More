﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TruckConfigsController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the list of truck-vehicleConfiguration details from DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<TruckConfigs> GetTruckConfigs(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.TruckConfigs.ToList();
        }

        /// <summary>
        /// Get the truck-vehicleConfiguration details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/TruckConfigss/186
        public IList<TruckConfigs> GetTruckConfigs(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is truckID
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            //IList<Product> productListWithNewPrice = new List<Product>();
            return db.TruckConfigs.Where(e => e.TruckID == id).ToList();
        }

        /// <summary>
        /// Update the truck-vehicleConfiguration details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="truckConfigs"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/TruckConfigss/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTruckConfigs(int id, TruckConfigs truckConfigs, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != truckConfigs.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(truckConfigs).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TruckConfigsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new truck-vehicleConfiguration based on the model
        /// </summary>
        /// <param name="truckConfigs"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/TruckConfigss
        [ResponseType(typeof(TruckConfigs))]
        public IHttpActionResult PostTruckConfigs(TruckConfigs truckConfigs, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.TruckConfigs.Add(truckConfigs);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = truckConfigs.ID }, truckConfigs);
        }

        /// <summary>
        /// Delete the truck-vehicleConfiguration based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/TruckConfigss/5
        [ResponseType(typeof(TruckConfigs))]
        public IHttpActionResult DeleteTruckConfigs(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            TruckConfigs truckConfigs = db.TruckConfigs.Find(id);
            if (truckConfigs == null)
            {
                return NotFound();
            }

            db.TruckConfigs.Remove(truckConfigs);
            db.SaveChanges();

            return Ok(truckConfigs);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TruckConfigsExists(int id)
        {
            return db.TruckConfigs.Count(e => e.ID == id) > 0;
        }
    }
}