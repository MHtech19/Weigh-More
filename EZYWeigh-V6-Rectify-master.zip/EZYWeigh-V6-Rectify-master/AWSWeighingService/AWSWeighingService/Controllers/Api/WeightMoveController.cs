﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class WeightMoveController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Here return the list of weightmoves from the db
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/WeightMove
        public IQueryable<WeightMove> GetWeightMoves(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.WeightMoves;
        }

        /// <summary>
        /// Here fetch and return the weightmove details from db based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/WeightMove/5
        [ResponseType(typeof(WeightMove))]
        public IHttpActionResult GetWeightMove(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            WeightMove weightMove = db.WeightMoves.Find(id);
            if (weightMove == null)
            {
                return NotFound();
            }

            return Ok(weightMove);
        }

        /// <summary>
        /// Here update the weightmove details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="weightMove"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/WeightMove/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWeightMove(int id, WeightMove weightMove, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (weightMove != null)
            {
                if (id != weightMove.ID)
                {
                    return BadRequest();
                }
            }
            else
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(weightMove).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WeightMoveExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Here create a new weightmove based on the model
        /// </summary>
        /// <param name="weightMove"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/WeightMove
        [ResponseType(typeof(WeightMove))]
        public IHttpActionResult PostWeightMove(WeightMove weightMove, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            var weighman = db.Weighmen.FirstOrDefault(w => w.Name == weightMove.WeighmanName);
            if (weighman != null)
            {
                weightMove.WeighmanID = weighman.ID;
            }

            var site = db.Sites.FirstOrDefault(s => s.Name == weightMove.SiteName);
            if (site != null)
            {
                weightMove.SiteID = site.ID;
            }


            db.WeightMoves.Add(weightMove);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = weightMove.ID }, weightMove);
        }

        /// <summary>
        /// Here delete the weightmove from the db based on the weightmove id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/WeightMove/5
        [ResponseType(typeof(WeightMove))]
        public IHttpActionResult DeleteWeightMove(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            WeightMove weightMove = db.WeightMoves.Find(id);
            if (weightMove == null)
            {
                return NotFound();
            }

            db.WeightMoves.Remove(weightMove);
            db.SaveChanges();

            return Ok(weightMove);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool WeightMoveExists(int id)
        {
            return db.WeightMoves.Count(e => e.ID == id) > 0;
        }
    }
}