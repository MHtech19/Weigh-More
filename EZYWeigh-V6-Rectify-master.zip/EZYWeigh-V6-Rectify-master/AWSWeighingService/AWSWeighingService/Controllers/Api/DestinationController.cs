﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class DestinationController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Here return the list of destinations from db
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Customer
        public IQueryable<Destination> GetDestinations(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Destinations.Where(e => e.ID > 1 && e.IsActive);
        }

        /// <summary>
        /// Here get the destination details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Customer/5
        [ResponseType(typeof(Destination))]
        public IHttpActionResult GetDestination(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Destination destination = db.Destinations.Find(id);
            if (destination == null)
            {
                return NotFound();
            }

            return Ok(destination);
        }

        /// <summary>
        /// Update the destination details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="destination"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/Destination/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDestination(int id, Destination destination, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != destination.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);

            db.Entry(destination).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Here create a new destination based on the model
        /// </summary>
        /// <param name="destination"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/Destination
        [ResponseType(typeof(Destination))]
        public IHttpActionResult PostDestination(Destination destination, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            destination.Sites = new List<Site>();
            var siteToAdd = db.Sites.Find(destination.ID);  //here ID is reused to hold site ID of which site the destination is created
            if (siteToAdd != null)
            {
                destination.Sites.Add(siteToAdd);
            }
            destination.ID = 0;
            destination.Name = destination.Name.ToUpper();


            db.Destinations.Add(destination);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = destination.ID }, destination);
        }

        /// <summary>
        /// Delete the destination based on the destination id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/Destination/5
        [ResponseType(typeof(Destination))]
        public IHttpActionResult DeleteDestination(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Destination destination = db.Destinations.Find(id);
            if (destination == null)
            {
                return NotFound();
            }

            db.Destinations.Remove(destination);
            db.SaveChanges();

            return Ok(destination);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CustomerExists(int id)
        {
            return db.Destinations.Count(e => e.ID == id) > 0;
        }


    }
}
