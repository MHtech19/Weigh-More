﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class VehicleController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;
    
        /// <summary>
        /// Here return the list of vehicle details  
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/VehicleConfiguration
        public IQueryable<Vehicle> GetVehicles(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Vehicles.Where(e => e.ID > 1 && e.IsActive).OrderBy(e => e.Name);
        }

        //for scheduled price update
        public IHttpActionResult GetVehicles(string date, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            // var selecteddate = Convert.ToDateTime(date);
            var selecteddate = DateTime.ParseExact(date, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            db = new AWSWeighingServiceContext(connectionStringName);
            List<Vehicle> scheduledPriceEnabledVehicles = db.Vehicles.Where(p => p.SchedulePriceDate.HasValue && p.SchedulePriceDate != null && DbFunctions.TruncateTime(p.SchedulePriceDate) <= DbFunctions.TruncateTime(selecteddate)).ToList();
            if (scheduledPriceEnabledVehicles != null && scheduledPriceEnabledVehicles.Count > 0)
            {
                foreach (var vehicleItem in scheduledPriceEnabledVehicles)
                {
                    vehicleItem.InLocalDiscount = vehicleItem.InLocalDiscount_S;
                    vehicleItem.InVisitStandard = vehicleItem.InVisitStandard_S;                   
                    db.Entry(vehicleItem).State = EntityState.Modified;
                }

                db.SaveChanges();

                foreach (var vehicleItem in scheduledPriceEnabledVehicles)
                {
                    vehicleItem.InLocalDiscount_S = 0;
                    vehicleItem.InVisitStandard_S = 0;
                    vehicleItem.SchedulePriceDate = null;
                    db.Entry(vehicleItem).State = EntityState.Modified;
                }

                db.SaveChanges();

                foreach (var vehicleItem in scheduledPriceEnabledVehicles)
                {
                    List<Site> siteList = db.Sites.Where(s => s.ID > 1).ToList();
                    foreach (var siteItem in siteList)
                    {
                        ReplicationLogItem logItem = new ReplicationLogItem
                        {
                            DestinationSiteID = siteItem.ID,
                            EntityType = "Vehicle",
                            EntityID = vehicleItem.ID,

                            Operation = "U",
                            SourceSiteID = 1,
                            LogCreated = DateTime.UtcNow
                        };

                        db.ReplicationLogItems.Add(logItem);
                    }

                    db.SaveChanges();
                }
            }
            return StatusCode(HttpStatusCode.OK);
        }

        /// <summary>
        /// Here get the vehicle details of the based on the vehicle id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Vehicle/5
        [ResponseType(typeof(Vehicle))]
        public async Task<IHttpActionResult> GetVehicle(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Vehicle vehicle = await db.Vehicles.FindAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }

            return Ok(vehicle);
        }

        /// <summary>
        /// Here update the vehicle details based on the vehicle id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="vehicle"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/Vehicle/5
        [ResponseType(typeof(Vehicle))]
        public async Task<IHttpActionResult> PutVehicle(int id, Vehicle vehicle, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != vehicle.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(vehicle).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VehicleExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Here create a new vehicle based on the model
        /// </summary>
        /// <param name="vehicle"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/Vehicle
        [ResponseType(typeof(Vehicle))]
        public async Task<IHttpActionResult> PostVehicle(Vehicle vehicle, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            var productNA = db.Products.Single(e => e.ID == 1 && e.IsActive).ID;
            vehicle.ProductID = productNA;
            db.Vehicles.Add(vehicle);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = vehicle.ID }, vehicle);
        }

        /// <summary>
        /// Here delete the vehicle from the Db based on the vehicle id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/Vehicle/5
        [ResponseType(typeof(Vehicle))]
        public async Task<IHttpActionResult> DeleteVehicle(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Vehicle vehicle = await db.Vehicles.FindAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }

            db.Vehicles.Remove(vehicle);
            await db.SaveChangesAsync();

            return Ok(vehicle);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool VehicleExists(int id)
        {
            return db.Vehicles.Count(e => e.ID == id) > 0;
        }
    }
}
