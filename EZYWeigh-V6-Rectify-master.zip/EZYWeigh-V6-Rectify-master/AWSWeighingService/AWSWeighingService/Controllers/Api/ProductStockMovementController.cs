﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class ProductStockMovementController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        // GET: api/ProductStockActivation/id 
        // the latest ProductStockMovement which reflects the current stock level
        // int productID : id1 , int siteID :id2
        public ProductStockMovement GetLatestProductStockMovement(int id1, int id2, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.ProductStockMovements.Where(m => m.ProductID == id1 && m.SiteID == id2).OrderByDescending(item => item.ID).First();
        }

        // POST: api/ProductStockMovement
        [ResponseType(typeof(ProductStockMovement))]
        public IHttpActionResult PostProductStockMovement(ProductStockMovement productStockMovement, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            ProductStockActivation existingProductStockActivation = db.ProductStockActivations.FirstOrDefault(e => e.ProductID == productStockMovement.ProductID && e.SiteID == productStockMovement.SiteID);

            if (existingProductStockActivation == null)
            {
                return BadRequest(ModelState);
            }

            existingProductStockActivation.STOCKLEVEL = productStockMovement.STOCKLEVEL;
            existingProductStockActivation.WeighmanID = productStockMovement.WeighmanID;
            db.Entry(existingProductStockActivation).State = EntityState.Modified;

            db.ProductStockMovements.Add(productStockMovement);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = productStockMovement.ID }, productStockMovement);
        }
    }
}
