﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TruckController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the list of trucks from DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Truck
        public IQueryable<Truck> GetTrucks(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Trucks.Where(e => e.ID > 1 && e.IsActive);
        }

        /// <summary>
        /// Get the truck details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Truck/5
        [ResponseType(typeof(Truck))]
        public IHttpActionResult GetTruck(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Truck truck = db.Trucks.Find(id);
            if (truck == null)
            {
                return NotFound();
            }

            return Ok(truck);
        }

        /// <summary>
        /// Update the truck details based on the model and id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="truck"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/truck/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTruck(int id, Truck truck, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != truck.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(truck).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TruckExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new truck based on the model
        /// </summary>
        /// <param name="truck"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/Truck
        [ResponseType(typeof(Truck))]
        public IHttpActionResult PostTruck(Truck truck, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            truck.ID = 0;
            truck.Name = truck.Name.ToUpper();

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Trucks.Add(truck);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = truck.ID }, truck);
        }

        /// <summary>
        /// Delete the truck based on the truck id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/Truck/5
        [ResponseType(typeof(Truck))]
        public IHttpActionResult DeleteTruck(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Truck truck = db.Trucks.Find(id);
            if (truck == null)
            {
                return NotFound();
            }

            db.Trucks.Remove(truck);
            db.SaveChanges();

            return Ok(truck);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TruckExists(int id)
        {
            return db.Trucks.Count(e => e.ID == id) > 0;
        }
    }
}
