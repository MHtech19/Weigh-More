﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class SiteWeighmanController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;
        
        /// <summary>
        /// Get the sit-weighman details based on the site id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/SiteWeighman/5
        [AllowAnonymous]
        public IQueryable<Weighman> GetWeighmen(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is SiteID
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            var site = db.Sites.FirstOrDefault(s => s.ID == id);
            if (site == null)
            {
                return db.Weighmen.Where(s => s.Name == Constants.NAEntityName).OrderBy(e => e.Name);
            }

            var allocatedWeighmen =  site.Weighmen;

            var awsWeighmen = db.Weighmen.Where(s=> s.ID == 1).FirstOrDefault();
            var masterWeighmen = db.Weighmen.Where(s => s.ID == 2).FirstOrDefault();
            if (awsWeighmen != null) allocatedWeighmen.Add(awsWeighmen);
            if (masterWeighmen != null) allocatedWeighmen.Add(masterWeighmen);
            return allocatedWeighmen.OrderBy(e => e.Name).AsQueryable<Weighman>();
        }

    }
}
