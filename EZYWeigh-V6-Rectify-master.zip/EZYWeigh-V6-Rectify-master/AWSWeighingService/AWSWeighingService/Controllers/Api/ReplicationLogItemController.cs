﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class ReplicationLogItemController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;
        
        /// <summary>
        /// Get the list of RelicationLog items
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/ReplicationLogItem/5
        public IQueryable<ReplicationLogItem> GetReplicationLogItems(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.ReplicationLogItems.Where(e => e.DestinationSiteID == id);
        }

        //// GET: api/ReplicationLogItem/5
        //[ResponseType(typeof(ReplicationLogItem))]
        //public IHttpActionResult GetReplicationLogItem(int id)
        //{
        //    ReplicationLogItem replicationLogItem = db.ReplicationLogItems.Find(id);
        //    if (replicationLogItem == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(replicationLogItem);
        //}

            /// <summary>
            /// Update the replicationlog item based on the id
            /// </summary>
            /// <param name="id"></param>
            /// <param name="replicationLogItem"></param>
            /// <param name="connectionStringName"></param>
            /// <returns></returns>
        // PUT: api/ReplicationLogItem/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutReplicationLogItem(int id, ReplicationLogItem replicationLogItem, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != replicationLogItem.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(replicationLogItem).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ReplicationLogItemExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new relplication log item based on the model
        /// </summary>
        /// <param name="replicationLogItem"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/ReplicationLogItem
        [ResponseType(typeof(ReplicationLogItem))]
        public IHttpActionResult PostReplicationLogItem(ReplicationLogItem replicationLogItem, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.ReplicationLogItems.Add(replicationLogItem);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = replicationLogItem.ID }, replicationLogItem);
        }

        /// <summary>
        /// Delete the replication log item based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/ReplicationLogItem/5
        [ResponseType(typeof(ReplicationLogItem))]
        public IHttpActionResult DeleteReplicationLogItem(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            ReplicationLogItem replicationLogItem = db.ReplicationLogItems.Find(id);
            if (replicationLogItem == null)
            {
                return NotFound();
            }
            if (DateTime.UtcNow.Subtract(replicationLogItem.LogCreated).TotalMinutes > 60)
            {
                db.ReplicationLogItems.Remove(replicationLogItem);
                db.SaveChanges();
            }

            return Ok(replicationLogItem);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ReplicationLogItemExists(int id)
        {
            return db.ReplicationLogItems.Count(e => e.ID == id) > 0;
        }
    }
}