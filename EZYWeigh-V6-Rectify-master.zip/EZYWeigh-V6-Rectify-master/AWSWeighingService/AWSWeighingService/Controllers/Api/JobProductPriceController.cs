﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class JobProductPriceController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the list of job-product-prices from the db
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<JobProductPrice> GetJobProductPrices(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.JobProductPrices.ToList();
        }
        
        /// <summary>
        /// Get the job-product-price details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/JobProductPrice/186
        public IList<JobProductPrice> GetJobProductPrice(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is jobID
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            //IList<Product> productListWithNewPrice = new List<Product>();
            return db.JobProductPrices.Where(e => e.JobID == id).ToList();
            
            /*
            foreach (var jpp in jobProductPriceList)
            {
                var linkedProduct = db.Products.FirstOrDefault(e => e.ID == jpp.ProductID);
                linkedProduct.InLocalDiscount = jpp.Price;
                linkedProduct.InVisitStandard = jpp.Price;
                linkedProduct.OutLocalDiscount = jpp.Price;
                linkedProduct.OutVisitStandard = jpp.Price;
                productListWithNewPrice.Add(linkedProduct);
            }
            

            return productListWithNewPrice;
             */ 
        }

        /// <summary>
        /// Update the job-product-price details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="jobProductPrice"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/JobProductPrices/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutJobProductPrice(int id, JobProductPrice jobProductPrice, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != jobProductPrice.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(jobProductPrice).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!JobProductPriceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new job-product-price based on the model
        /// </summary>
        /// <param name="jobProductPrice"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/JobProductPrices
        [ResponseType(typeof(JobProductPrice))]
        public IHttpActionResult PostJobProductPrice(JobProductPrice jobProductPrice, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.JobProductPrices.Add(jobProductPrice);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = jobProductPrice.ID }, jobProductPrice);
        }

        /// <summary>
        /// Delete the job-product-price from the db based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>

        // DELETE: api/JobProductPrices/5
        [ResponseType(typeof(JobProductPrice))]
        [HttpDelete]
        public IHttpActionResult DeleteJobProductPrice(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            JobProductPrice jobProductPrice = db.JobProductPrices.Find(id);
            if (jobProductPrice == null)
            {
                return NotFound();
            }

            db.JobProductPrices.Remove(jobProductPrice);
            db.SaveChanges();

            return Ok(jobProductPrice);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool JobProductPriceExists(int id)
        {
            return db.JobProductPrices.Count(e => e.ID == id) > 0;
        }
    }
}