﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TransactionController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the transaction details based on the transaction id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        [ResponseType(typeof(Transaction))]
        public IHttpActionResult GetTransaction(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Transaction tran = db.Transactions.Find(id);
            if (tran == null)
            {
                return NotFound();
            }

            return Ok(tran);
        }

        /// <summary>
        /// Get list of transactions based on the date range and site id
        /// </summary>
        /// <param name="startingDate"></param>
        /// <param name="endingDate"></param>
        /// <param name="siteID"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IEnumerable<Transaction> GetTransactions(string startingDate, string endingDate, string siteID, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            DateTime startD = DateTime.ParseExact(startingDate, "s", CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal); //DateTime.Parse(startingDate);
            DateTime endD = DateTime.ParseExact(endingDate, "s", CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal);   //DateTime.Parse(endingDate);
            int intSiteID = int.Parse(siteID);

            return db.Transactions.Where(t => t.TransactionDate >= startD && t.TransactionDate <= endD && t.SiteID == intSiteID && t.Deleted == false).ToList();
        }

        /// <summary>
        /// Get list of transactions for given site id and whether exported to accounts or not exported
        /// </summary>
        /// <param name="exportedToAccounts"></param>
        /// <param name="siteID"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IEnumerable<Transaction> GetTransactions(string exportedToAccounts, string siteID, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            int intSiteID = int.Parse(siteID);
            switch (exportedToAccounts.ToUpper())
            {
                case "ALL":
                    {
                        return db.Transactions.Where(t => t.SiteID == intSiteID && t.Deleted == false).ToList();
                        break;
                    }
                case "EXPORTED":
                    {
                        return db.Transactions.Where(t => t.ExportedToAccounting == true && t.SiteID == intSiteID && t.Deleted == false).ToList();
                        break;
                    }
                case "NOTEXPORTED":
                    {
                        return db.Transactions.Where(t => t.ExportedToAccounting == false && t.SiteID == intSiteID && t.Deleted == false).ToList();
                        break;
                    }
                default:
                    {
                        return null;
                        break;
                    }
            }

        }

        /// <summary>
        /// Create a new transaction based on the model
        /// </summary>
        /// <param name="transaction"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/Transaction
        //[ResponseType(typeof(string))]
        [ResponseType(typeof(Transaction))]
        public IHttpActionResult PostTransaction(Transaction transaction, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            string _Docket = transaction.Docket;

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            Site site = db.Sites.Find(transaction.SiteID);
            if (!(!String.IsNullOrEmpty(_Docket) && Char.IsLetter(_Docket[0])))
            {
                if (transaction.Docket == CoreConstants.IncreaseDocketByOne)
                {
                    site.CurrentDocket++;
                    transaction.Docket = site.DocketHead + site.CurrentDocket.ToString();
                }
                else if (transaction.Docket == CoreConstants.NotIncreaseDocketByOne)
                {
                    transaction.Docket = site.DocketHead + site.CurrentDocket.ToString();
                }
            }

            // update DocketInitials implicitly.
            if ((!String.IsNullOrEmpty(_Docket) && Char.IsLetter(_Docket[0])))
            {
                Customer customerDocketInitials = db.Customers.Find(transaction.CustomerID);
                customerDocketInitials.DocketInitials = _Docket.Substring(0, 3);

                db.Customers.Attach(customerDocketInitials);
                db.Entry(customerDocketInitials).State = EntityState.Modified;
            }

            db.Transactions.Add(transaction); 
            db.SaveChanges();

            if (transaction.JobID != CoreConstants.NA_ID)
            {
                var job = db.Jobs.Find(transaction.JobID);
                if (job != null && job.JobTonnesOrdered > 0)
                {
                    var listOfTrans = db.Transactions.Where(t => t.Deleted == false && t.JobID == transaction.JobID).ToList();
                    if (listOfTrans != null)
                    {
                        job.JobTonnesRunningTotal = listOfTrans.Sum(t => t.Net);
                        db.Entry(job).State = EntityState.Modified;
                        db.SaveChanges();

                        foreach (var item in db.Sites.Where(s=>s.ID>1).ToList())
                        {
                            ReplicationLogItem logItem = new ReplicationLogItem
                            {
                                DestinationSiteID = item.ID,
                                EntityType = "Job",
                                EntityID = job.ID,
                                Operation = "U",
                                SourceSiteID = 1,
                                LogCreated = DateTime.UtcNow
                            };

                            db.ReplicationLogItems.Add(logItem);
                            db.SaveChanges();
                        }
                       
                    }
                }
            }

            return Ok(transaction);
        }

        /// <summary>
        /// Update the transaction based on the model
        /// </summary>
        /// <param name="transaction"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/transaction
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTransaction(Transaction transaction, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            //transaction.Net = Math.Abs(transaction.Gross - transaction.Tare);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(transaction).State = EntityState.Modified;

            try
            {
                db.SaveChanges();

                if (transaction.JobID != CoreConstants.NA_ID)
                {
                    var job = db.Jobs.Find(transaction.JobID);
                    if (job != null && job.JobTonnesOrdered > 0)
                    {
                        var listOfTrans = db.Transactions.Where(t => t.Deleted == false && t.JobID == transaction.JobID).ToList();
                        if (listOfTrans != null)
                        {
                            job.JobTonnesRunningTotal = listOfTrans.Sum(t => t.Net);                            
                            db.Entry(job).State = EntityState.Modified;
                            db.SaveChanges();

                            foreach (var item in db.Sites.Where(s => s.ID > 1).ToList())
                            {
                                ReplicationLogItem logItem = new ReplicationLogItem
                                {
                                    DestinationSiteID = item.ID,
                                    EntityType = "Job",
                                    EntityID = job.ID,
                                    Operation = "U",
                                    SourceSiteID = 1,
                                    LogCreated = DateTime.UtcNow
                                };

                                db.ReplicationLogItems.Add(logItem);
                                db.SaveChanges();
                            }
                        }
                    }
                }
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }

            return StatusCode(HttpStatusCode.NoContent);
        }


    }
}
