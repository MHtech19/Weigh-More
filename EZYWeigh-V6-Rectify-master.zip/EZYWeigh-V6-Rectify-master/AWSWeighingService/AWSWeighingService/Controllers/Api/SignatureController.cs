﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class SignatureController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the signature based on the transaction id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        //[ResponseType(typeof(Signature))]
        public HttpResponseMessage GetSignature(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK);
            Signature signature = db.Signatures.FirstOrDefault(s => s.TransactionID == id);
            if (signature != null)
            {
                
                byte[] imgData = signature.Content;
                MemoryStream ms = new MemoryStream(imgData);
                
                response.Content = new StreamContent(ms);
                response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("image/jpeg");
               
               // return Ok(signature);

            }
            else
            {
                //return NotFound();
                
                response = new HttpResponseMessage(HttpStatusCode.NotFound);
                 
            }

            return response;
        }

        public HttpResponseMessage GetSignature(int id, string OnlyCheckIfExists, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK);
            db = new AWSWeighingServiceContext(connectionStringName);
            Signature signature = db.Signatures.FirstOrDefault(s => s.TransactionID == id);
            if (signature == null)
            {
                response = new HttpResponseMessage(HttpStatusCode.NotFound);
            }

            return response;
        }

        /// <summary>
        /// Create a new signature for transaction
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public HttpResponseMessage Post(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            var httpRequest = HttpContext.Current.Request;
            if (httpRequest.Files.Count < 1)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            /*
            if (httpPostedFile != null) {  
            FileUpload imgupload = new FileUpload();  
            int length = httpPostedFile.ContentLength;  
            imgupload.imagedata = new byte[length]; //get imagedata  
            httpPostedFile.InputStream.Read(imgupload.imagedata, 0, length);  
            imgupload.imagename = Path.GetFileName(httpPostedFile.FileName);  
            db.fileUpload.Add(imgupload);  
            db.SaveChanges();  
            var fileSavePath = Path.Combine(HttpContext.Current.Server.MapPath("~/UploadedFiles"), httpPostedFile.FileName);  
            // Save the uploaded file to "UploadedFiles" folder  
            httpPostedFile.SaveAs(fileSavePath);  
            return Ok("Image Uploaded"); 
            
            

            //HttpClient side sample
            var url = "http://localhost/api/v1/yourendpointhere";
            var filePath = @"C:\path\to\image.jpg";

            HttpClient httpClient = new HttpClient();
            MultipartFormDataContent form = new MultipartFormDataContent();

            FileStream fs = File.OpenRead(filePath);
            var streamContent = new StreamContent(fs);

            var imageContent = new ByteArrayContent(streamContent.ReadAsByteArrayAsync().Result);
            imageContent.Headers.ContentType = MediaTypeHeaderValue.Parse("multipart/form-data");

            form.Add(imageContent, "image", Path.GetFileName(filePath));
            var response = httpClient.PostAsync(url, form).Result;

            */

            foreach (string file in httpRequest.Files)
            {
                var httpPostedFile = httpRequest.Files[file];
                //var filePath = HttpContext.Current.Server.MapPath("~/UploadedImages/" + httpPostedFile.FileName);
                //httpPostedFile.SaveAs(filePath);
                
                if (httpPostedFile != null)
                {
                    Signature signature = new Signature();
                    signature.TransactionID = id;
                    int length = httpPostedFile.ContentLength;
                    signature.Content = new byte[length]; //get imagedata  
                    httpPostedFile.InputStream.Read(signature.Content, 0, length);
                    
                    db.Signatures.Add(signature);
                    db.SaveChanges();
                    
                   // return Ok("Image Uploaded");
                    
                }


                
            }

            return Request.CreateResponse(HttpStatusCode.Created);
        }
    }
}
