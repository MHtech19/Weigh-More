﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TruckDestinationController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        private void SetDB(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
        }

        /// <summary>
        /// Get the list of truck-destination details from DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<TruckDestination> GetTruckDestination(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            return db.TruckDestination.ToList();
        }

        /// <summary>
        /// Get the truck-destination details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/TruckDestinations/186
        public IList<TruckDestination> GetTruckDestination(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is truckID
        {
            SetDB(connectionStringName);
            //IList<Product> productListWithNewPrice = new List<Product>();
            return db.TruckDestination.Where(e => e.TruckID == id).ToList();
        }

        /// <summary>
        /// Update the truck-destination details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="truckDestination"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/TruckDestinations/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTruckDestination(int id, TruckDestination truckDestination, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != truckDestination.ID)
            {
                return BadRequest();
            }

            SetDB(connectionStringName);
            db.Entry(truckDestination).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TruckDestinationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new truck-destination based on the model
        /// </summary>
        /// <param name="truckDestination"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/TruckDestinations
        [ResponseType(typeof(TruckDestination))]
        public IHttpActionResult PostTruckDestination(TruckDestination truckDestination, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SetDB(connectionStringName);
            db.TruckDestination.Add(truckDestination);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = truckDestination.ID }, truckDestination);
        }

        /// <summary>
        /// Delete truck-destination details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/TruckDestinations/5
        [ResponseType(typeof(TruckDestination))]
        public IHttpActionResult DeleteTruckDestination(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            TruckDestination truckDestination = db.TruckDestination.Find(id);
            if (truckDestination == null)
            {
                return NotFound();
            }

            db.TruckDestination.Remove(truckDestination);
            db.SaveChanges();

            return Ok(truckDestination);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TruckDestinationExists(int id)
        {
            return db.TruckDestination.Count(e => e.ID == id) > 0;
        }
    }
}