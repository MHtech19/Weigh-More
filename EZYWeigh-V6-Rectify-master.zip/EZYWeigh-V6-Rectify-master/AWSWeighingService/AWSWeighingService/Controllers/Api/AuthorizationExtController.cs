﻿using System.Web.Http;

namespace AWSWeighingService.Controllers.Api
{
    /// <summary>
    /// Decorate ClientAuthorizationFilter to check Client-Secret key for api requests

    /// </summary>
    [ClientAuthorizationFilter]
    public class AuthorizationExtController : ApiController { }
}
