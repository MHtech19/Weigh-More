﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class RealTimeWeightController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the realtime weights from the DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/RealTimeWeight
        public IQueryable<RealTimeWeight> GetRealTimeWeights(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.RealTimeWeights;
        }

        /// <summary>
        /// Get the details Realtime weight based on the site id and platform 
        /// </summary>
        /// <param name="id1"></param>
        /// <param name="id2"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/RealTimeWeight/5
        [ResponseType(typeof(RealTimeWeight))]
        public IHttpActionResult GetRealTimeWeight(int id1, int id2, string connectionStringName = CoreConstants.AWSConnectionStringName) // id1:SiteID, id2:
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            var realTimeWeight = db.RealTimeWeights.FirstOrDefault(m => m.SiteID == id1 && m.PlatformID == id2.ToString());
            if (realTimeWeight == null)
            {
                return NotFound();
            }

            return Ok(realTimeWeight);
        }
       
        /// <summary>
        /// Update the realtime weight based on the model
        /// </summary>
        /// <param name="putRealTimeWeight"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/RealTimeWeight/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutRealTimeWeight(RealTimeWeight putRealTimeWeight, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);

            int id = putRealTimeWeight.ID;

            RealTimeWeight realTimeWeight = db.RealTimeWeights.Find(id);

            if (!RealTimeWeightExists(id))
            {
                return NotFound();
            }

            realTimeWeight.CurrentWeight = putRealTimeWeight.CurrentWeight;
            db.Entry(realTimeWeight).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                
                
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new realtime weight based on the model
        /// </summary>
        /// <param name="realTimeWeight"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/RealTimeWeight
        [ResponseType(typeof(RealTimeWeight))]
        public IHttpActionResult PostRealTimeWeight(RealTimeWeight realTimeWeight, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            //db.RealTimeWeights.Add(realTimeWeight);
            db.Entry(realTimeWeight).State = EntityState.Modified;
            db.SaveChanges();

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Delete the realtime weight based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/RealTimeWeight/5
        [ResponseType(typeof(RealTimeWeight))]
        public IHttpActionResult DeleteRealTimeWeight(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            RealTimeWeight realTimeWeight = db.RealTimeWeights.Find(id);
            if (realTimeWeight == null)
            {
                return NotFound();
            }

            db.RealTimeWeights.Remove(realTimeWeight);
            db.SaveChanges();

            return Ok(realTimeWeight);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RealTimeWeightExists(int id)
        {
            return db.RealTimeWeights.Count(e => e.ID == id) > 0;
        }
    }
}