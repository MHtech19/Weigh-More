﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class ProductStockActivationController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        // GET: api/ProductStockActivation/?id1=id1&id2=id2
        public ProductStockActivation GetProductStockActivation(int id1, int id2, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.ProductStockActivations.FirstOrDefault(m => m.ProductID == id1 && m.SiteID == id2);
        }

        

        // POST: api/ProductStockActivation
        [ResponseType(typeof(ProductStockActivation))]
        public ProductStockActivation PostProductStockActivation(ProductStockActivation postedProductStockActivation, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            /*
            db.ProductStockActivations.Add(productStockActivation);
            db.SaveChanges();
            */
            db = new AWSWeighingServiceContext(connectionStringName);

            ProductStockActivation existingProductStockActivation = db.ProductStockActivations.FirstOrDefault(e => e.ProductID == postedProductStockActivation.ProductID && e.SiteID == postedProductStockActivation.SiteID);
            if (existingProductStockActivation == null)
            {
                ProductStockMovement stockMove = postedProductStockActivation.GenerateProductStockMovement(0); // 0 for new 
                db.ProductStockMovements.Add(stockMove);
                db.ProductStockActivations.Add(postedProductStockActivation);
                db.SaveChanges();
            }
            else
            {
                try
                {
                    decimal currentStockLevel = existingProductStockActivation.STOCKLEVEL;
                    ProductStockMovement stockMove = postedProductStockActivation.GenerateProductStockMovement(currentStockLevel);
                    //postedProductStockActivation.STOCKLEVEL = stockMove.STOCKLEVEL; // to reflect the newly added or subtracted amount

                    db.ProductStockMovements.Add(stockMove);
                    //db.SaveChanges();
                    //db.Entry(existingProductStockActivation).CurrentValues.SetValues(productStockActivation);
                    existingProductStockActivation.STOCKLEVEL = stockMove.STOCKLEVEL; // to reflect the newly added or subtracted amount
                    existingProductStockActivation.WeighmanID = postedProductStockActivation.WeighmanID;
                    db.Entry(existingProductStockActivation).State = EntityState.Modified;
                    db.SaveChanges();

                    return existingProductStockActivation;
                }
                catch (Exception)
                {

                    //Logger.LogActivity(theExe.Message);
                    //Logger.LogActivity(theExe.InnerException.Message);
                    return null;
                }

            }
            

            

            return  postedProductStockActivation;
        }


        // PUT: api/ProductStockActivation
        [ResponseType(typeof(ProductStockActivation))]
        public ProductStockActivation PutProductStockActivation(ProductStockActivation putProductStockActivation, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            ProductStockActivation existingProductStockActivation = db.ProductStockActivations.FirstOrDefault(e => e.ProductID == putProductStockActivation.ProductID && e.SiteID == putProductStockActivation.SiteID);

            //db.Entry(existingProductStockActivation).CurrentValues.SetValues(putProductStockActivation);
            existingProductStockActivation.STOCKLEVEL = putProductStockActivation.STOCKLEVEL;
            db.Entry(existingProductStockActivation).State = EntityState.Modified;
            db.SaveChanges();

            return  existingProductStockActivation ;

            /*
            if (localProductStockActivation == null)
            {
                return PostProductStockActivation(putProductStockActivation); //  does not exist, change update to insert 

            }
            else
            {
                try
                {
                    decimal currentStockLevel = localProductStockActivation.STOCKLEVEL;
                    ProductStockMovement stockMove = putProductStockActivation.GenerateProductStockMovement(currentStockLevel);
                    putProductStockActivation.STOCKLEVEL = stockMove.STOCKLEVEL; // to reflect the newly added or subtracted amount

                    db.ProductStockMovements.Add(stockMove);
                    db.Entry(localProductStockActivation).CurrentValues.SetValues(putProductStockActivation);
                    db.Entry(existingProductStockActivation).State = EntityState.Modified;
                    db.SaveChanges();

                    return  putProductStockActivation ;
                }
                catch (Exception theExe)
                {

                    //Logger.LogActivity(theExe.Message);
                    //Logger.LogActivity(theExe.InnerException.Message);
                    return null;
                }
             

            }*/
        }

        // DELETE: api/ProductStockActivation/5
        [ResponseType(typeof(ProductStockActivation))]
        public IHttpActionResult DeleteProductStockActivation(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            ProductStockActivation stockActivation = db.ProductStockActivations.Find(id);

            if (stockActivation == null)
            {
                return NotFound();
            }

            db.ProductStockActivations.Remove(stockActivation);
            db.SaveChanges();

            return Ok(stockActivation);
        }
    }
}
