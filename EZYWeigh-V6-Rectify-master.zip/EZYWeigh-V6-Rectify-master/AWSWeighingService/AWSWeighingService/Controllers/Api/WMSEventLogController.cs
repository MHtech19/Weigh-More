﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class WMSEventLogController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Herer return the list of all event logs from the db based on the connectionstring name
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/EventLog
        public IQueryable<WMSEventLog> GetEventLogs(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.WMSEventLogs;
        }

        /// <summary>
        /// Here return the event log details from the db based on the event log id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/EventLog/5
        [ResponseType(typeof(WMSEventLog))]
        public IHttpActionResult GetEventLog(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            WMSEventLog eventLog = db.WMSEventLogs.Find(id);
            if (eventLog == null)
            {
                return NotFound();
            }

            return Ok(eventLog);
        }

        /// <summary>
        /// Here update the event log details to the db based on the event log id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="eventLog"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/EventLog/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutEventLog(int id, WMSEventLog eventLog, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (eventLog != null)
            {
                if (id != eventLog.ID)
                {
                    return BadRequest();
                }
            }
            else { return BadRequest(); }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(eventLog).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventLogExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Here create a new event log and added to the eventlog table
        /// </summary>
        /// <param name="eventLog"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/EventLog
        [ResponseType(typeof(WMSEventLog))]
        public IHttpActionResult PostEventLog(WMSEventLog eventLog, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.WMSEventLogs.Add(eventLog);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = eventLog.ID }, eventLog);
        }

        /// <summary>
        /// Delete the event log from the eventlog table based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/EventLog/5
        [ResponseType(typeof(WMSEventLog))]
        public IHttpActionResult DeleteEventLog(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            WMSEventLog eventLog = db.WMSEventLogs.Find(id);
            if (eventLog == null)
            {
                return NotFound();
            }

            db.WMSEventLogs.Remove(eventLog);
            db.SaveChanges();

            return Ok(eventLog);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool EventLogExists(int id)
        {
            return db.WMSEventLogs.Count(e => e.ID == id) > 0;
        }
    }
}