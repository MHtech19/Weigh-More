﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class WeighmanController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the list of Weighman from DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Weighman
        public IQueryable<Weighman> GetWeighmen(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Weighmen.Where(e => e.ID != Constants.NAEntityID).OrderBy(e => e.Name);
        }

        /// <summary>
        /// Get the weighman details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Weighman/5
        [ResponseType(typeof(Weighman))]
        public IHttpActionResult GetWeighman(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Weighman weighman = db.Weighmen.Find(id);
            if (weighman == null)
            {
                return NotFound();
            }

            return Ok(weighman);
        }

        /// <summary>
        /// Update the weighman details based on id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="weighman"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/Weighman/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutWeighman(int id, Weighman weighman, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != weighman.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(weighman).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WeighmanExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new weighman based on the model
        /// </summary>
        /// <param name="weighman"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/Weighman
        [ResponseType(typeof(Weighman))]
        public IHttpActionResult PostWeighman(Weighman weighman, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Weighmen.Add(weighman);

            weighman.Sites = new List<Site>();
            var siteToAdd = db.Sites.Find(weighman.ID);  //here ID is reused to hold site ID of which site the destination is created
            if (siteToAdd != null)
            {
                weighman.Sites.Add(siteToAdd);
            }

            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = weighman.ID }, weighman);
        }

        /// <summary>
        /// Delete weighman based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/Weighman/5
        [ResponseType(typeof(Weighman))]
        public IHttpActionResult DeleteWeighman(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Weighman weighman = db.Weighmen.Find(id);
            if (weighman == null)
            {
                return NotFound();
            }

            db.Weighmen.Remove(weighman);
            db.SaveChanges();

            return Ok(weighman);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool WeighmanExists(int id)
        {
            return db.Weighmen.Count(e => e.ID == id) > 0;
        }
    }
}