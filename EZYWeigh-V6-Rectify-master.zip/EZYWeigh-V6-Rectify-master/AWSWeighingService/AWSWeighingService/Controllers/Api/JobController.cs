﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class JobController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Here get the list of jobs from the db
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Job
        public IQueryable<Job> GetJobs(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Jobs.Where(e => e.ID > 1 && e.IsActive);
        }

        /// <summary>
        /// Get the job details based on the job id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Job/5
        [ResponseType(typeof(Job))]
        public IHttpActionResult GetJob(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Job job = db.Jobs.Find(id);
            if (job == null)
            {
                return NotFound();
            }

            return Ok(job);
        }

        /// <summary>
        /// Update the job details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="job"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/Job/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutJob(int id, Job job, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != job.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(job).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!JobExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new job based on the job model
        /// </summary>
        /// <param name="job"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/Job
        [ResponseType(typeof(Job))]
        public IHttpActionResult PostJob(Job job, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            job.Sites = new List<Site>();
            var siteToAdd = db.Sites.Find(job.ID);  //here ID is reused to hold site ID of which site the job is created
            if (siteToAdd != null)
            {
                job.Sites.Add(siteToAdd);
            }
            job.ID = 0;
            job.Name = job.Name.ToUpper();


            db.Jobs.Add(job);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = job.ID }, job);
        }

        /// <summary>
        /// Delete the job based on the job id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/Job/5
        [ResponseType(typeof(Job))]
        public IHttpActionResult DeleteJob(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Job job = db.Jobs.Find(id);
            if (job == null)
            {
                return NotFound();
            }

            db.Jobs.Remove(job);
            db.SaveChanges();

            return Ok(job);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool JobExists(int id)
        {
            return db.Jobs.Count(e => e.ID == id) > 0;
        }
    }
}
