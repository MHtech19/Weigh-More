﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class RoleController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the list of roles from DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Role
        [AllowAnonymous]
        public IQueryable<Role> GetRoles(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Roles.OrderBy(e => e.Name);
        }

    }
}
