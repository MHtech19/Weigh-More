﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace AWSWeighingService.Controllers.Api
{
    public class OffenceController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the list of Offences from db
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IQueryable<Offence> GetOffence(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Offences.Where(e => e.IsActive);
        }

        /// <summary>
        /// Get the offence details based on the name(rego)
        /// </summary>
        /// <param name="rego"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IQueryable<Offence> GetOffence(string rego, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Offences.Where(o => o.Name == rego && o.IsActive);
        }

        /// <summary>
        /// Get the offence details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IHttpActionResult GetOffence(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Offence selectedOffence = db.Offences.Find(id);
            if (selectedOffence == null)
            {
                return NotFound();
            }

            return Ok(selectedOffence);
        }

        /// <summary>
        /// Create a new offence based on the offence model
        /// </summary>
        /// <param name="offence"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IHttpActionResult PostOffence(Offence offence, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);

            db.Offences.Add(offence);
            db.SaveChanges();

            return Ok(offence);
        }

        /// <summary>
        /// Update the offence details based on the offences model
        /// </summary>
        /// <param name="offence"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IHttpActionResult PutOffence(Offence offence, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);

            db.Entry(offence).State = EntityState.Modified;
            db.SaveChanges();

            return Ok(offence);
        }

        //Delete the offence based on the id
        public IHttpActionResult DeleteOffence(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Offence selectedOffence = db.Offences.Find(id);
            if (selectedOffence == null)
            {
                return NotFound();
            }

            //db.Offences.Remove(selectedOffence);
            selectedOffence.IsActive = false;
            db.Entry(selectedOffence).State = EntityState.Modified;
            db.SaveChanges();

            return Ok(selectedOffence);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}
