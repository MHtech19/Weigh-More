﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class EPASourceController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        // GET: api/EPASource
        public IQueryable<EPASource> GetEPASources(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);

            return db.EPASources;
        }

        // GET: api/EPASource/5
        [ResponseType(typeof(EPASource))]
        public IHttpActionResult GetEPASource(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);

            EPASource ePASource = db.EPASources.Find(id);
            if (ePASource == null)
            {
                return NotFound();
            }

            return Ok(ePASource);
        }

        // PUT: api/EPASource/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutEPASource(int id, EPASource ePASource, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != ePASource.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(ePASource).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EPASourceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/EPASource
        [ResponseType(typeof(EPASource))]
        public IHttpActionResult PostEPASource(EPASource ePASource, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);

            db.EPASources.Add(ePASource);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = ePASource.ID }, ePASource);
        }

        // DELETE: api/EPASource/5
        [ResponseType(typeof(EPASource))]
        public IHttpActionResult DeleteEPASource(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);

            EPASource ePASource = db.EPASources.Find(id);
            if (ePASource == null)
            {
                return NotFound();
            }

            db.EPASources.Remove(ePASource);
            db.SaveChanges();

            return Ok(ePASource);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool EPASourceExists(int id)
        {
            return db.EPASources.Count(e => e.ID == id) > 0;
        }
    }
}