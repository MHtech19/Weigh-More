﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Hosting;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using Newtonsoft.Json;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using Xero.Api;
using Xero.Api.Core;
using Xero.Api.Example.Applications.Private;
using Xero.Api.Infrastructure.OAuth;
using Xero.Api.Serialization;
using Xero.Api.Core.Model;
using XeroIntegration;
using AWSWeighingService.ViewModels;

namespace AWSWeighingService.Controllers.Api
{
    class XeroAuths
    {
        public XeroAuth[] xeroAuth { get; set; }
    }

    class XeroAuth
    {
        public string Company { get; set; }
        public int SiteID { get; set; }
        public string SiteName { get; set; }
        public string AppKey { get; set; }
        public string CertificateFile { get; set; }
        public string Password { get; set; }
        public string ConsumerKey { get; set; }
        public string ConsumerSecret { get; set; }
        public string RunType { get; set; }
    }

    public class XeroCustomerController : ApiController
    {
        private AWSWeighingServiceContext db;
        private string xeroCompany = "";
        private string xeroSiteName = "";
        private string xeroAuthKey = "";
        private string xeroCertificateFile = "";
        private string xeroCertificatePassword = "";
        private string xeroConsumerKey = "";
        private string xeroConsumerSecret = "";
        private string xeroRunType = "";

        // POST: api/XeroCustomer
        [HttpPost]
        public IHttpActionResult Post(string siteID, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            try
            {
                // Read Xero authentication file.
                LogInfo("Getting Xero authentication details.", true);
                GetXeroAuthenticationDetails(siteID, connectionStringName);

                LogInfo("Reading Payload. SiteID = " + siteID + ", SiteName = " + xeroSiteName + ", CS = " + connectionStringName);

                var payLoad = ReadPayLoad();

                LogInfo("Saving payload.");
                SavePayload(payLoad);

                LogInfo("Reading signature.");
                var signatureHeader = HttpContext.Current.Request.Headers["x-xero-signature"].ToString();
                LogInfo("Signature = " + signatureHeader);

                LogInfo("Validating signature.");
                var isValid = VerifySignature(payLoad, signatureHeader);

                if (!isValid)
                {
                    LogInfo("Returning unauthorized.");
                    return Unauthorized();
                }

                dynamic json = JsonConvert.DeserializeObject(payLoad);
                SavePayload(json.ToString());
                string url = json.events[0].resourceUrl;
                string operation = json.events[0].eventType;
                string resourceId = json.events[0].resourceId;
                LogInfo("Resource URL is: " + url);

                LogInfo("Getting customer from Xero.");
                Contact contact = GetCustomer_FromXero(url, resourceId);
                LogInfo("Customer name: " + contact.Name);

                LogInfo("Adding/updating in V6.");
                AddOrUpdateCustomers(contact, operation, siteID, connectionStringName);
                LogInfo("Added/updated in V6.");

                LogInfo("Returning Ok.");
                return Ok();
            }
            catch (Exception ex)
            {
                LogInfo("Exception: " + ex.Message + " | " + ex.StackTrace);
                return Ok();
            }
        }

        private string ReadPayLoad()
        {
            var bodyStream = new StreamReader(HttpContext.Current.Request.InputStream);
            bodyStream.BaseStream.Seek(0, SeekOrigin.Begin);
            var bodyText = bodyStream.ReadToEnd();
            return bodyText;
        }

        public bool VerifySignature(string payload, string signatureHeader)
        {
            var generatedSignature = GenerateSignature(payload);

            return generatedSignature == signatureHeader;
        }

        public string GenerateSignature(string dataToHash)
        {
 //           string key = "cVE7uetHHZXpquePjVT9Vi1dSWCrragwgEP2kGgjx4cwp9AVeGcp2VOLV0jIElx0PStzm7XTQ97RDKBjyZ3c7w==";
            using (var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(xeroAuthKey)))
            {
                var messageBytes = Encoding.UTF8.GetBytes(dataToHash);
                var hash = hmac.ComputeHash(messageBytes);
                return Convert.ToBase64String(hash);
            }
        }

        #region Get customers from Xero
        private Contact GetCustomer_FromXero(string XeroContactAPI, string resourceId)
        {
            string certPath = "~/XeroCertificates";
            LogInfo("In GetCustomer_FromXero, certPath = " + certPath);
            DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(certPath));
            var certFile = dirInfo.FullName + @"\" + xeroCertificateFile;
            LogInfo("In GetCustomer_FromXero, certFile = " + certFile);

            XeroStaticUtilities.CertificateFile = certFile;

            //// ebh details for demo company
            //XeroStaticUtilities.CertificatePassword = "P@ssw0rd";
            //XeroStaticUtilities.ConsumerKey = "BZGDKY7SMDLZCYALJNTKNTINMZDWED";
            //XeroStaticUtilities.ConsumerSecret = "QPGZB1QYKKPQWL4HKQDYACCMC2JKKS";

            // test company
            //XeroStaticUtilities.CertificatePassword = "aj@12345";
            //XeroStaticUtilities.ConsumerKey = "IJZDQ9ZWCINGN7BVPBUW97C1NRW0KR";
            //XeroStaticUtilities.ConsumerSecret = "JSQX5FKPVLDOAL7CPGYMZWZ2WL4YLN";

            XeroStaticUtilities.CertificatePassword = xeroCertificatePassword;
            XeroStaticUtilities.ConsumerKey = xeroConsumerKey;
            XeroStaticUtilities.ConsumerSecret = xeroConsumerSecret;

            XeroStaticUtilities.ResourceID = resourceId;
            XeroStaticUtilities.XeroContactAPI = XeroContactAPI;
            LogInfo("In GetCustomer_FromXero, calling GetCustomer().");
            Contact _contact = XeroStaticUtilities.GetCustomer();
            LogInfo("In GetCustomer_FromXero, called GetCustomer().");
            return _contact;
        }
        #endregion

        private void AddOrUpdateCustomers(Contact _contact, string operation, string siteID, string connectionStringName)
        {
            try
            {
                db = new AWSWeighingServiceContext(connectionStringName);
                int? termDays = 0;
                if ((_contact.PaymentTerms != null) && (_contact.PaymentTerms.Sales != null))
                {
                    termDays = _contact.PaymentTerms.Sales.Day;
                }
                LogInfo("In AddOrUpdateCustomers. _contact.AccountNumber=" + _contact.AccountNumber);
                string _operation = operation;
                Customer customer = new Customer();
                var nameExist = db.Customers.Where(e => e.AccountNumber.ToLower() == _contact.AccountNumber.ToLower()).FirstOrDefault();
                if (nameExist != null)
                {
                    customer = nameExist;
                }

                if ((_operation == "UPDATE") && (nameExist == null))
                {
                    _operation = "CREATE";
                }
                customer.Sites = new List<Site>();
                var siteToAdd = db.Sites.Find(Convert.ToInt32(siteID));
                if (siteToAdd != null)
                {
                    customer.Sites.Add(siteToAdd);
                }

                LogInfo("_contact.AN=" + _contact.AccountNumber + " | " + "customer.AN=" + customer.AccountNumber);
                SetCustomerObject(customer, _contact, termDays);

                customer.Name = customer.Name.ToUpper();

                if (_operation.ToUpper() == "CREATE")
                {
                    LogInfo("Customer is creating...");
                    customer.ID = 0;
                    db.Customers.Add(customer);
                    WriteReplicationLog(siteToAdd.ID, customer.ID, CoreConstants.InsertOp, Convert.ToInt32(siteID), db);
                }
                if (_operation.ToUpper() == "UPDATE")
                {
                    LogInfo("Customer is updating...");
                    db.Entry(customer).State = EntityState.Modified;
                    WriteReplicationLog(siteToAdd.ID, customer.ID, CoreConstants.UpdateOp, customer.ID, db);
                }

                string[] addSites = new string[1];
                addSites[0] = siteID;

                AddCustomerToSite(db, addSites, customer.Sites);

                db.SaveChanges();
            }
            catch (Exception ex)
            {
                LogInfo(ex.Message + " | " + ex.StackTrace);
            }
        }

        protected void AddCustomerToSite(AWSWeighingServiceContext dbContext, string[] selectedSites, ICollection<Site> assignedSites)
        {

            if (selectedSites == null)
            {
                assignedSites = new List<Site>();
                return;
            }


            var selectedSitesHS = new HashSet<string>(selectedSites);
            var assignedSitesHS = new HashSet<int>(assignedSites.Select(s => s.ID));

            foreach (var site in dbContext.Sites)
            {
                if (selectedSitesHS.Contains(site.ID.ToString()))
                {
                    if (!assignedSitesHS.Contains(site.ID))
                    {
                        assignedSites.Add(site);
                    }
                }
            }

        }

        private void SetCustomerObject(Customer customer, Contact contact, int? termDays)
        {
            try
            {
                customer.Name = contact.Name;
                customer.AccountNumber = contact.AccountNumber;
                customer.CustomerType = "C";
                customer.Active = true;
                customer.TicketCopies = 1;
                customer.ABN = contact.TaxNumber;
                customer.Email = contact.EmailAddress;
                customer.Contact = contact.FirstName + " " + contact.LastName;

                LogInfo("Payment Terms: " + termDays.ToString());
                if (termDays > 0)
                {
                    customer.PaymentMethod = CoreConstants.PAYMENT_ACCOUNT;
                }
                else
                {
                    customer.PaymentMethod = CoreConstants.PAYMENT_CASH;
                }

                //if (contact.ContactPersons.Count > 0)
                //{
                //    customer.Contact = contact.ContactPersons[0].FirstName + contact.ContactPersons[0].LastName;

                //}
                if (contact.Addresses[1] != null)
                {
                    customer.Address1 = contact.Addresses[1].AddressLine1;
                    customer.Address2 = contact.Addresses[1].AddressLine2;
                    customer.Suburb = contact.Addresses[1].City;
                    customer.State = contact.Addresses[1].Region;
                    customer.Postcode = contact.Addresses[1].PostalCode;
                    customer.Country = contact.Addresses[1].Country;

                }

                if (contact.Addresses[0] != null)
                {
                    customer.DeliveryAddress1 = contact.Addresses[0].AddressLine1;
                    customer.DeliveryAddress2 = contact.Addresses[0].AddressLine2;
                    customer.DeliverySuburb = contact.Addresses[0].City;
                    customer.DeliveryState = contact.Addresses[0].Region;
                    customer.DeliveryPostcode = contact.Addresses[0].PostalCode;
                }

                foreach (Phone phone in contact.Phones)
                {
                    if (phone.PhoneType == Xero.Api.Core.Model.Types.PhoneType.Default)
                    {
                        customer.Phone = phone.PhoneCountryCode + phone.PhoneAreaCode + phone.PhoneNumber;
                    }
                    if (phone.PhoneType == Xero.Api.Core.Model.Types.PhoneType.Fax)
                    {
                        customer.Fax = phone.PhoneCountryCode + phone.PhoneAreaCode + phone.PhoneNumber;
                    }
                    if (phone.PhoneType == Xero.Api.Core.Model.Types.PhoneType.Mobile)
                    {
                        customer.Mobile = phone.PhoneCountryCode + phone.PhoneAreaCode + phone.PhoneNumber;
                    }
                }
            }
            catch (Exception ex)
            {
                // to log...
            }
        }

        private void GetXeroAuthenticationDetails(string siteID, string company)
        {
            string authPath = "~/XeroCertificates";
            DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(authPath));
            var authFile = dirInfo.FullName + @"\XeroAuthentication.JSON";
            string authData = System.IO.File.ReadAllText(authFile);
            LogInfo("Reading " + authFile, true);
            XeroAuths xeroAuths = JsonConvert.DeserializeObject<XeroAuths>(authData);
            LogInfo("Read " + xeroAuths.xeroAuth.Count().ToString() + " records.", true);

            foreach (XeroAuth xeroAuth in xeroAuths.xeroAuth)
            {
                if ((xeroAuth.Company.ToLower() == company.ToLower()) && (xeroAuth.SiteID == Convert.ToInt32(siteID)))
                {
                    xeroAuthKey = xeroAuth.AppKey;
                    xeroCertificateFile = xeroAuth.CertificateFile;
                    xeroCompany = xeroAuth.Company;
                    xeroCertificatePassword = xeroAuth.Password;
                    xeroConsumerKey = xeroAuth.ConsumerKey;
                    xeroConsumerSecret = xeroAuth.ConsumerSecret;
                    xeroSiteName = xeroAuth.SiteName;
                    xeroRunType = xeroAuth.RunType;
                }
            }
        }

        public void SavePayload(string data, bool overrideRunType = false)
        {
            if ((xeroRunType.ToLower() == "test") || (overrideRunType))
            {
                    string payloadPath = "~/XeroCertificates/logs";
                DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(payloadPath));
                var payloadFile = dirInfo.FullName + @"\PayloadReceived.txt";
                System.IO.File.WriteAllLines(payloadFile, new[] { data }, Encoding.UTF8);
            }
        }

        public void LogInfo(string message, bool overrideRunType = false)
        {
            if ((xeroRunType.ToLower() == "test") || (overrideRunType))
            {
                string logPath = "~/XeroCertificates/logs";
                DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(logPath));
                var logFile = dirInfo.FullName + @"\XeroCustomerLog.txt";
                //            System.IO.File.WriteAllLines(logFile, new[] { message }, Encoding.UTF8);

                if (!System.IO.File.Exists(logFile))
                {
                    System.IO.File.WriteAllLines(logFile, new[] { message }, Encoding.UTF8);
                }
                else
                {
                    System.IO.File.AppendAllLines(logFile, new[] { message }, Encoding.UTF8);
                }
            }
        }

        protected void WriteReplicationLog(int destinationID, int entityID, string operationType, int loginSiteID, AWSWeighingServiceContext dbContext)
        {
            string entityTypeName = typeof(Customer).Name.ToString();
            CreateSingleLogTargetingSingleSite(destinationID, entityTypeName, entityID, operationType, loginSiteID, dbContext);
        }

        protected void CreateSingleLogTargetingSingleSite(int destinationSiteID, string entityTypeName, int entityID, string OperationType, int sourceSiteID, AWSWeighingServiceContext dbContext)
        {
            ReplicationLogItem logItem = new ReplicationLogItem
            {
                DestinationSiteID = destinationSiteID,
                EntityType = entityTypeName,
                EntityID = entityID,

                Operation = OperationType,
                SourceSiteID = sourceSiteID,
                LogCreated = DateTime.UtcNow
            };

            dbContext.ReplicationLogItems.Add(logItem);
            dbContext.SaveChanges();
        }

    }
}