﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TruckProductsController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        private void SetDB(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
        }

        /// <summary>
        /// Get the list of truck-product details from the DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<TruckProducts> GetTruckProducts(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            return db.TruckProducts.ToList();
        }

        //Get the truck-product details based on the id
        // GET: api/TruckProductss/186
        public IList<TruckProducts> GetTruckProducts(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is truckID
        {
            SetDB(connectionStringName);
            //IList<Product> productListWithNewPrice = new List<Product>();
            return db.TruckProducts.Where(e => e.TruckID == id).ToList();
        }

        /// <summary>
        /// Update the truck-product details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="truckProducts"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/TruckProductss/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTruckProducts(int id, TruckProducts truckProducts, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != truckProducts.ID)
            {
                return BadRequest();
            }

            SetDB(connectionStringName);
            db.Entry(truckProducts).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TruckProductsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new truck-product details based on the model
        /// </summary>
        /// <param name="truckProducts"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/TruckProductss
        [ResponseType(typeof(TruckProducts))]
        public IHttpActionResult PostTruckProducts(TruckProducts truckProducts, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SetDB(connectionStringName);
            db.TruckProducts.Add(truckProducts);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = truckProducts.ID }, truckProducts);
        }


        /// <summary>
        /// Delete the truck-product based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/TruckProductss/5
        [ResponseType(typeof(TruckProducts))]
        public IHttpActionResult DeleteTruckProducts(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            TruckProducts truckProducts = db.TruckProducts.Find(id);
            if (truckProducts == null)
            {
                return NotFound();
            }

            db.TruckProducts.Remove(truckProducts);
            db.SaveChanges();

            return Ok(truckProducts);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TruckProductsExists(int id)
        {
            return db.TruckProducts.Count(e => e.ID == id) > 0;
        }
    }
}