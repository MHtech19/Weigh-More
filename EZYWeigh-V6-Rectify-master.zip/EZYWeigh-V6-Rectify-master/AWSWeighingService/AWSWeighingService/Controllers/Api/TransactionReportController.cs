﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CoreConstants = WeighBridge.Core.Utils.Constants;
namespace AWSWeighingService.Controllers.Api
{
    public class TransactionReportController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;
        [ResponseType(typeof(string))]

        public string GetPDF(int customerID,int siteID,string startDate,string endDate, string reportName, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            DateRangeWithEntities dateRangeWithEntities = new DateRangeWithEntities();
            dateRangeWithEntities.EntityIDs = new List<int> { customerID };
            dateRangeWithEntities.EntityIDs2 = new List<int> { siteID };
            dateRangeWithEntities.StartDate = Convert.ToDateTime(startDate);
            dateRangeWithEntities.EndDate = Convert.ToDateTime(endDate);
            dateRangeWithEntities.ReportName = reportName;
  
            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            var transactions = db.Transactions.Where(e => DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(dateRangeWithEntities.StartDate) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(dateRangeWithEntities.EndDate)); //.ToList();
            //Direction Filter
            if ((dateRangeWithEntities.IsInDirection ^ dateRangeWithEntities.IsOutDirection)) // xor
            {
                if (dateRangeWithEntities.IsInDirection)
                {
                    transactions = transactions.Where(t => t.Direction == CoreConstants.DIRECTION_IN);
                }
                else if (dateRangeWithEntities.IsOutDirection)
                {
                    transactions = transactions.Where(t => t.Direction == CoreConstants.DIRECTION_OUT);
                }
            }

            //Owner Filter
            if ((dateRangeWithEntities.IsSiteOwned ^ dateRangeWithEntities.IsCustomerOwned)) // xor
            {
                if (dateRangeWithEntities.IsSiteOwned)
                {
                    transactions = transactions.Where(t => t.VehicleOwner == CoreConstants.OWNER_SITE);
                }
                else if (dateRangeWithEntities.IsCustomerOwned)
                {
                    transactions = transactions.Where(t => t.VehicleOwner == CoreConstants.OWNER_PRIVATE);
                }
            }

            //Charge Rate Filter
            if ((dateRangeWithEntities.IsLocalChargeRate ^ dateRangeWithEntities.IsVisitorChargeRate)) // xor
            {
                if (dateRangeWithEntities.IsLocalChargeRate)
                {
                    transactions = transactions.Where(t => t.ChargeRate == CoreConstants.RATE_LOCAL);
                }
                else if (dateRangeWithEntities.IsVisitorChargeRate)
                {
                    transactions = transactions.Where(t => t.ChargeRate == CoreConstants.RATE_VISITOR);
                }
            }

            //Payment Filter
            List<string> paymentsList = new List<string>();
            string[] paymentsArray = null;
            if (!(dateRangeWithEntities.IsCashPayment && dateRangeWithEntities.IsAccountPayment && dateRangeWithEntities.IsChequePayment && dateRangeWithEntities.IsEFTPOSPayment && dateRangeWithEntities.IsCreditCardPayment) && !(!dateRangeWithEntities.IsCashPayment && !dateRangeWithEntities.IsAccountPayment && !dateRangeWithEntities.IsChequePayment && !dateRangeWithEntities.IsEFTPOSPayment && !dateRangeWithEntities.IsCreditCardPayment))
            {
                if (dateRangeWithEntities.IsCashPayment) paymentsList.Add(CoreConstants.PAYMENT_CASH);
                if (dateRangeWithEntities.IsAccountPayment) paymentsList.Add(CoreConstants.PAYMENT_ACCOUNT);
                if (dateRangeWithEntities.IsChequePayment) paymentsList.Add(CoreConstants.PAYMENT_CHEQUE);
                if (dateRangeWithEntities.IsEFTPOSPayment) paymentsList.Add(CoreConstants.PAYMENT_EFTPOS);
                if (dateRangeWithEntities.IsCreditCardPayment) paymentsList.Add(CoreConstants.PAYMENT_CREDIT);
                paymentsArray = paymentsList.ToArray();
            }

            // Load Type Filter
            List<string> loadTypesList = new List<string>();
            string[] loadTypesArray = null;
            if (!(dateRangeWithEntities.IsStandardLoadType && dateRangeWithEntities.IsCountedLoadType && dateRangeWithEntities.IsSecondLoadType && dateRangeWithEntities.IsMixedLoadType && dateRangeWithEntities.IsCreditCardPayment) && !(!dateRangeWithEntities.IsStandardLoadType && !dateRangeWithEntities.IsCountedLoadType && !dateRangeWithEntities.IsSecondLoadType && !dateRangeWithEntities.IsMixedLoadType && !dateRangeWithEntities.IsRegoLoadType))
            {
                if (dateRangeWithEntities.IsStandardLoadType) loadTypesList.Add(CoreConstants.Load_Standard);
                if (dateRangeWithEntities.IsCountedLoadType) loadTypesList.Add(CoreConstants.Load_Counted);
                if (dateRangeWithEntities.IsSecondLoadType)
                {
                    loadTypesList.Add(CoreConstants.Load_Second);
                    loadTypesList.Add(CoreConstants.Load_StoredTare);
                }
                if (dateRangeWithEntities.IsMixedLoadType) loadTypesList.Add(CoreConstants.Load_Mixed);
                if (dateRangeWithEntities.IsRegoLoadType) loadTypesList.Add(CoreConstants.Load_Rego);
                loadTypesArray = loadTypesList.ToArray();
            }

            if ((paymentsArray != null) && (paymentsArray.Count() >= 1))
            {
                transactions = transactions.Where(t => paymentsArray.Contains(t.Payments));
            }

            if ((loadTypesArray != null) && (loadTypesArray.Count() >= 1))
            {
                transactions = transactions.Where(t => loadTypesArray.Contains(t.LoadType));
            }

            var trans = transactions.Where(t => t.Deleted == false).ToList();




            switch (dateRangeWithEntities.ReportName)
            {
                case "SummaryBySiteTransactionReport":
                case "BySiteTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Site";
                    break;
                case "SummaryByCustomerTransactionReport":
                case "ByCustomerTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.CustomerID)).ToList();
                    }
                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Customer";
                    break;
                //case "SummaryByPaymentTransactionReport":
                //case "ByPaymentTransactionReport":
                //    transactions = transactions.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.CustomerID)).ToList();
                //    break;
                case "SummaryBySupplierTransactionReport":
                case "BySupplierTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.CustomerID)).ToList();
                    }
                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Supplier";
                    break;
                case "SummaryByProductCategoryTransactionReport":
                case "ByProductCategoryTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductCategoryID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Product Category";
                    break;
                case "SummaryBySourceTransactionReport":
                case "BySourceTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.SourceID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Source";
                    break;
                case "SummaryByDestinationTransactionReport":
                case "ByDestinationTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.DestinationID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Destination";
                    break;
                case "SummaryByProductTransactionReport":
                case "SummaryByCountedItemTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    break;
                case "ByProductTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Product";
                    break;
                case "ByCountedItemTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Counted Item";
                    break;
                case "ByPruductTransactionWithEPASourceReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Pruduct with EPS Source";
                    break;
                case "SummaryByTruckConfigurationTransactionReport":
                case "ByTruckConfigurationTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.VehicleConfigurationID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }

                    reportTitle = "Transaction Report By Truck Configuration";
                    break;
                case "SummaryByVehicleTypeTransactionReport":
                case "ByVehicleTypeTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.VehicleID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Vehicle Type";
                    break;
                case "SummaryByVehicleTransactionReport":
                case "ByVehicleTransactionReport":
                    if (dateRangeWithEntities.Registrations != null && dateRangeWithEntities.Registrations.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.Registrations.Contains(e.Registration1)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Vehicle";
                    break;
                case "SummaryByJobTransactionReport":
                case "ByJobTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.JobID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Job";
                    break;
                case "SummaryByWeighmanTransactionReport":
                case "ByWeighmanTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.WeighmanID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Operator";
                    break;
                case "SummaryByJobByProductTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.JobID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs3 != null && dateRangeWithEntities.EntityIDs3.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs3.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Job By Product";
                    break;
                default:
                    break;
            }

            if (dateRangeWithEntities.ReportName == "SummaryBySiteTransactionReport" || dateRangeWithEntities.ReportName == "BySiteTransactionReport")
            {
                if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0 && dateRangeWithEntities.EntityIDs.Count == 1)
                {
                    int selectedSiteID = Convert.ToInt32(siteID);
                    Site selectedSite = db.Sites.FirstOrDefault(s => s.ID == selectedSiteID);
                    if (selectedSiteID > 1)
                    {
                        organisation = selectedSite.Name;
                        address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                            + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                            + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));
                    }
                    else
                    {
                        organisation = string.IsNullOrEmpty(selectedSite.Address1) ? "Organisation" : selectedSite.Address1;
                        address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                            + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                            + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));

                        address = string.IsNullOrEmpty(address) ? "Address" : address;
                    }
                }
                else
                {
                    Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
                    organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
                    address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                        + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                        + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

                    address = string.IsNullOrEmpty(address) ? "Address" : address;
                }
            }
            else
            {
                if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0 && dateRangeWithEntities.EntityIDs2.Count == 1)
                {
                    int selectedSiteID = Convert.ToInt32(dateRangeWithEntities.EntityIDs2[0]);
                    Site selectedSite = db.Sites.FirstOrDefault(s => s.ID == selectedSiteID);
                    if (selectedSiteID > 1)
                    {
                        organisation = selectedSite.Name;
                        address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                            + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                            + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));
                    }
                    else
                    {
                        organisation = string.IsNullOrEmpty(selectedSite.Address1) ? "Organisation" : selectedSite.Address1;
                        address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                            + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                            + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));

                        address = string.IsNullOrEmpty(address) ? "Address" : address;
                    }
                }
                else
                {
                    Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
                    organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
                    address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                        + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                        + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

                    address = string.IsNullOrEmpty(address) ? "Address" : address;
                }
            }



            var sites = db.Sites.ToList();
            var weighmen = db.Weighmen.ToList();
            var productCategories = db.ProductCategories.ToList();
            var customers = db.Customers.ToList();
            var products = db.Products.ToList();
            var destinations = db.Destinations.ToList();
            var sources = db.Sources.ToList();
            var jobs = db.Jobs.ToList();
            var vehicleTypes = db.Vehicles.ToList();
            var drivers = db.Drivers.ToList();
            var truckconfig = db.VehicleConfigurations.ToList();
            var epaSources = db.EPASources.ToList();

            var entities = from t in trans
                           join s in sites on t.SiteID equals s.ID
                           join w in weighmen on t.WeighmanID equals w.ID
                           join pc in productCategories on t.ProductCategoryID equals pc.ID
                           join c in customers on t.CustomerID equals c.ID
                           join p in products on t.ProductID equals p.ID
                           join d in destinations on t.DestinationID equals d.ID
                           join soc in sources on t.SourceID equals soc.ID
                           join j in jobs on t.JobID equals j.ID
                           join vt in vehicleTypes on t.VehicleID equals vt.ID
                           join dr in drivers on t.DriverID equals dr.ID
                           join tcf in truckconfig on t.VehicleConfigurationID equals tcf.ID
                           //join epas in epaSources on t.ID equals epas.TransactionID
                           select new
                           {
                               ID = t.ID,
                               Docket = t.Docket,
                               TransactionDate = t.TransactionDate,
                               LoadType = t.LoadType,
                               Payments = t.Payments,
                               Direction = t.Direction,
                               VehicleOwner = t.VehicleOwner,
                               ChargeRate = t.ChargeRate,
                               OrderNumber = t.OrderNumber,
                               Comment = t.Comment,
                               Registration1 = t.Registration1,
                               Gross1 = t.Gross1 + t.Gross2 + t.Gross3 + t.Gross4 + t.Gross5,
                               Tare1 = t.Tare1 + t.Tare2 + t.Tare3 + t.Tare4 + t.Tare5,
                               Net = t.Net,
                               Price = t.Price,
                               TranCost = t.TranCost,
                               TotalCost = t.TotalCost,
                               CartageCharge = t.CartageCharge,
                               CartageCost = t.CartageCost,
                               GST = t.GST,
                               EPA = t.EPA,
                               DateStamp = t.DateStamp,
                               Royalty = t.Royalty,
                               Count = t.Count,
                               CartageGST = t.CartageGST,
                               Site = s.Name,
                               Weighman = w.Name,
                               ProductCategory = pc.Name,
                               Customer = c.Name,
                               Product = p.Name,
                               Destination = d.Name,
                               Source = soc.Name,
                               Job = j.Name,
                               VehicleType = vt.Name,
                               Driver = dr.Name,
                               VehicleConfiguration = tcf.Name,

                               //SourceBlock = epas.SourceBlock,
                               //SourceSection = epas.SourceSection,
                               //SourceAddress = epas.SourceAddress,

                               //CatId = c.CatId
                               // other assignments
                           };

            if (entities.Count() == 0)
            {
                return "No data.";
            }

            ReportDataSource rd = new ReportDataSource("Entities", entities);

            List<TransactionSummary> entitiySummary = new List<TransactionSummary>();
            bool isSummaryReport = false;

            switch (dateRangeWithEntities.ReportName)
            {
                case "ByPruductTransactionWithEPASourceReport":
                    var epaSourceTran = from t in entities
                                        join epas in epaSources on t.ID equals epas.TransactionID
                                        select new
                                        {
                                            ID = t.ID,
                                            Docket = t.Docket,
                                            TransactionDate = t.TransactionDate,
                                            LoadType = t.LoadType,
                                            Payments = t.Payments,
                                            Direction = t.Direction,
                                            VehicleOwner = t.VehicleOwner,
                                            ChargeRate = t.ChargeRate,
                                            OrderNumber = t.OrderNumber,
                                            Comment = t.Comment,
                                            Registration1 = t.Registration1,
                                            Gross1 = t.Gross1,
                                            Tare1 = t.Tare1,
                                            Net = t.Net,
                                            Price = t.Price,
                                            TranCost = t.TranCost,
                                            TotalCost = t.TotalCost,
                                            CartageCharge = t.CartageCharge,
                                            CartageCost = t.CartageCost,
                                            GST = t.GST,
                                            EPA = t.EPA,
                                            DateStamp = t.DateStamp,

                                            Site = t.Site,
                                            Weighman = t.Weighman,
                                            ProductCategory = t.ProductCategory,
                                            Customer = t.Customer,
                                            Product = t.Product,
                                            Destination = t.Destination,
                                            Source = t.Source,
                                            Job = t.Job,
                                            VehicleType = t.VehicleType,
                                            Driver = t.Driver,
                                            VehicleConfiguration = t.VehicleConfiguration,

                                            SourceBlock = epas.SourceBlock,
                                            SourceSection = epas.SourceSection,
                                            SourceAddress = epas.SourceAddress,
                                            CartageGST = t.CartageGST
                                            //CatId = c.CatId
                                            // other assignments
                                        };
                    if (epaSourceTran.Count() == 0)
                    {
                        return "fail";
                    }
                    rd = new ReportDataSource("Entities", epaSourceTran);
                    break;
                case "SummaryBySiteTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Site).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Site,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Site";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByCustomerTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Customer).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Customer,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Customer";
                    break;
                case "SummaryByPaymentTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Payments).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Payments,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Payment";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryBySupplierTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Customer).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Customer,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Supplier";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByProductCategoryTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.ProductCategory).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().ProductCategory,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Product Category";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryBySourceTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Source).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Source,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Source";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByDestinationTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Destination).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Destination,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Destination";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByProductTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Product).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Product,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Product";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByCountedItemTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Product).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Product,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Counted Item";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByTruckConfigurationTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.VehicleConfiguration).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().VehicleConfiguration,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Vehicle Configuration";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByVehicleTypeTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.VehicleType).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().VehicleType,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Vehicle Type";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByVehicleTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Registration1).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Registration1,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Vehicle Registration";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByJobTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Job).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Job,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Job";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByWeighmanTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Weighman).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Weighman,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Operator";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;

                case "SummaryByJobByProductTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => new { Job = e.Job, Product = e.Product }).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Job,
                        EntityName2 = sumary.First().Product,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Job and by Product";
                    dateRangeWithEntities.ReportName = "SummaryByJobByProductTransactionReport";//use the same report rdlc
                    break;

                default:
                    break;
            }

            if (isSummaryReport)
            {
                rd = new ReportDataSource("Entities", entitiySummary);
            }


            rd.Name = "Entities";

            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Local;
            reportViewer.SizeToReportContent = true;
            reportViewer.LocalReport.DataSources.Clear();
            reportViewer.LocalReport.DataSources.Add(rd);
            reportViewer.LocalReport.ReportPath = System.Web.Hosting.HostingEnvironment.MapPath("~/Reports/" + dateRangeWithEntities.ReportName + ".rdlc");

            ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);
            ReportParameter reportSubTitle_DateRange_Param = new ReportParameter("DateRangeParameter", "From " + dateRangeWithEntities.StartDate.ToString("dd/MM/yyyy") + " to " + dateRangeWithEntities.EndDate.ToString("dd/MM/yyyy"));
            transactions.FirstOrDefault();
            reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param, reportSubTitle_DateRange_Param });
            string path = System.Web.Hosting.HostingEnvironment.MapPath("~/DocketPDFS/TransactionReport_" + DateTime.Now.ToString("dd-MM-yyyy hh mm ss tt") + ".pdf");
            SavePDF(reportViewer, path);
            return path;
        }


        public void SavePDF(ReportViewer viewer, string savePath)

        {
            byte[] Bytes = viewer.LocalReport.Render(format: "PDF", deviceInfo: "");

            using (FileStream stream = new FileStream(savePath, FileMode.Create))
            {
                stream.Write(Bytes, 0, Bytes.Length);
            }
        }

    }

}
