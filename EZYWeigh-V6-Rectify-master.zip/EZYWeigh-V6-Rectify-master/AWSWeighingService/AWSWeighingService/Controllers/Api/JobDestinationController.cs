﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class JobDestinationController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        private void SetDB(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
        }

        /// <summary>
        /// Get the list of job destinations from the db
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<JobDestination> GetJobDestination(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            return db.JobDestination.ToList();
        }

        /// <summary>
        /// Get the job destinations details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/JobDestinations/186
        public IList<JobDestination> GetJobDestination(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is truckID
        {
            SetDB(connectionStringName);
            //IList<Product> productListWithNewPrice = new List<Product>();
            return db.JobDestination.Where(e => e.JobID == id).ToList();
        }

        /// <summary>
        /// Update the job destination based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="JobDestination"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/JobDestinations/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutJobDestination(int id, JobDestination JobDestination, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != JobDestination.ID)
            {
                return BadRequest();
            }

            SetDB(connectionStringName);
            db.Entry(JobDestination).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!JobDestinationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new job destination based on the model
        /// </summary>
        /// <param name="JobDestination"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/JobDestinations
        [ResponseType(typeof(JobDestination))]
        public IHttpActionResult PostJobDestination(JobDestination JobDestination, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SetDB(connectionStringName);
            db.JobDestination.Add(JobDestination);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = JobDestination.ID }, JobDestination);
        }

        /// <summary>
        /// Delete the job destination based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/JobDestinations/5
        [ResponseType(typeof(JobDestination))]
        public IHttpActionResult DeleteJobDestination(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            JobDestination JobDestination = db.JobDestination.Find(id);
            if (JobDestination == null)
            {
                return NotFound();
            }

            db.JobDestination.Remove(JobDestination);
            db.SaveChanges();

            return Ok(JobDestination);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db!=null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool JobDestinationExists(int id)
        {
            return db.JobDestination.Count(e => e.ID == id) > 0;
        }
    }
}