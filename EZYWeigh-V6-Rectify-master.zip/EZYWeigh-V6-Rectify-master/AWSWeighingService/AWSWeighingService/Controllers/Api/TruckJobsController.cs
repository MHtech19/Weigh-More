﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TruckJobsController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        private void SetDB(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
        }

        /// <summary>
        /// Get the list of truck-job details from DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<TruckJobs> GetTruckJobs(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            return db.TruckJobs.ToList();
        }

        /// <summary>
        /// Get the truck-job details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/TruckJobss/186
        public IList<TruckJobs> GetTruckJobs(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is truckID
        {
            //IList<Product> productListWithNewPrice = new List<Product>();
            SetDB(connectionStringName);
            return db.TruckJobs.Where(e => e.TruckID == id).ToList();
        }

        /// <summary>
        /// Update truck-job details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="truckJobs"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/TruckJobss/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTruckJobs(int id, TruckJobs truckJobs, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != truckJobs.ID)
            {
                return BadRequest();
            }

            SetDB(connectionStringName);
            db.Entry(truckJobs).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TruckJobsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new truck-job based on the model
        /// </summary>
        /// <param name="truckJobs"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/TruckJobss
        [ResponseType(typeof(TruckJobs))]
        public IHttpActionResult PostTruckJobs(TruckJobs truckJobs, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SetDB(connectionStringName);
            db.TruckJobs.Add(truckJobs);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = truckJobs.ID }, truckJobs);
        }

        /// <summary>
        /// Delete truck-job details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/TruckJobss/5
        [ResponseType(typeof(TruckJobs))]
        public IHttpActionResult DeleteTruckJobs(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            TruckJobs truckJobs = db.TruckJobs.Find(id);
            if (truckJobs == null)
            {
                return NotFound();
            }

            db.TruckJobs.Remove(truckJobs);
            db.SaveChanges();

            return Ok(truckJobs);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TruckJobsExists(int id)
        {
            return db.TruckJobs.Count(e => e.ID == id) > 0;
        }
    }
}