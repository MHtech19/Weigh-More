﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class JobTonnageController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;



        // GET: api/JobTonnage/5
        [ResponseType(typeof(JobTonnage))]
        public IHttpActionResult GetJobTonnage(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Job job = db.Jobs.Find(id);

            if (job == null)
            {
                return NotFound();
            }

            JobTonnage jobTonnage = new JobTonnage()
            {
                TodayTotal = 0M,
                MonthlyTotal = 0M,
                RunningTotal = 0M,

                TonnesLeft = 0M,
                TonnesOrdered = 0M,
                TonnesProcessed = 0M
            };

            //old code start
            //DateTime toDay = DateTime.Today;
            //DateTime beforeDay = toDay.AddDays(-1);
            //DateTime afterDay = toDay.AddDays(1);
            //DateTime firstDayOfMonth = new DateTime(toDay.Year, toDay.Month, 1).AddDays(-1);

            //var transToday = db.Transactions.Where(t => (t.TransactionDate > beforeDay) && (t.TransactionDate < afterDay));
            //var TransThisMonth = db.Transactions.Where(t => (t.TransactionDate > firstDayOfMonth) && (t.TransactionDate < afterDay));
            //if (transToday != null && transToday.Count() > 0)
            //{
            //    decimal todayTotal = transToday.Where(t => t.JobID == id && t.ProductID == job.ProductID).Sum(t => t.Net);
            //    decimal monthlyTotal = TransThisMonth.Where(t => t.JobID == id && t.ProductID == job.ProductID).Sum(t => t.Net);

            //    jobTonnage.TodayTotal = todayTotal;
            //    jobTonnage.MonthlyTotal = monthlyTotal;
            //    jobTonnage.RunningTotal = job.JobTonnesRunningTotal;

            //}
            //old code end
            if (job != null)
            {
                jobTonnage.TonnesOrdered = job.JobTonnesOrdered;
                jobTonnage.TonnesProcessed = job.JobTonnesRunningTotal;
                jobTonnage.TonnesLeft = job.JobTonnesOrdered - job.JobTonnesRunningTotal;
            }

            return Ok(jobTonnage);
        }





        // DELETE: api/JobTonnage/5

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


    }
}