﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class DriverController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Here return the list of drivers from the db
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Driver
        public IQueryable<Driver> GetDrivers(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Drivers;
        }

        /// <summary>
        /// Get the driver details based on the driver id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Driver/5
        [ResponseType(typeof(Driver))]
        public async Task<IHttpActionResult> GetDriver(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Driver driver = await db.Drivers.FindAsync(id);
            if (driver == null)
            {
                return NotFound();
            }

            return Ok(driver);
        }

        /// <summary>
        /// Update the driver details based on the  driver id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="driver"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/Driver/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutDriver(int id, Driver driver, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != driver.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(driver).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DriverExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new driver based on the model
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/Driver
        [ResponseType(typeof(Driver))]
        public async Task<IHttpActionResult> PostDriver(Driver driver, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Drivers.Add(driver);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = driver.ID }, driver);
        }
        
        /// <summary>
        /// Delete the driver based on the driver id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/Driver/5
        [ResponseType(typeof(Driver))]
        public async Task<IHttpActionResult> DeleteDriver(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Driver driver = await db.Drivers.FindAsync(id);
            if (driver == null)
            {
                return NotFound();
            }

            db.Drivers.Remove(driver);
            await db.SaveChangesAsync();

            return Ok(driver);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool DriverExists(int id)
        {
            return db.Drivers.Count(e => e.ID == id) > 0;
        }
    }
}