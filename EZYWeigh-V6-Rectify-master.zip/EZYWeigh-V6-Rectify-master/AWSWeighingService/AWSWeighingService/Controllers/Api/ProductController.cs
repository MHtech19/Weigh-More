﻿using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Hosting;
using System.Web.Http;
using System.Web.Http.Description;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class ProductController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the list of products from the DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Product
        public IQueryable<Product> GetProducts(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Products.Where(e => e.ID >= 1 && e.IsActive);
        }

        //for scheduled price update
        public IHttpActionResult GetProducts(string date, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            //var selecteddate = Convert.ToDateTime(date);
            var selecteddate = DateTime.ParseExact(date, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            db = new AWSWeighingServiceContext(connectionStringName);
            List<Product> scheduledPriceEnabledProducts = db.Products.Where(p => p.SchedulePriceDate.HasValue && p.SchedulePriceDate != null && DbFunctions.TruncateTime(p.SchedulePriceDate) <= DbFunctions.TruncateTime(selecteddate)).ToList();
            if (scheduledPriceEnabledProducts != null && scheduledPriceEnabledProducts.Count > 0)
            {
                foreach (var productItem in scheduledPriceEnabledProducts)
                {
                    productItem.InLocalDiscount = productItem.InLocalDiscount_S;
                    productItem.OutLocalDiscount = productItem.OutLocalDiscount_S;
                    productItem.MinLocalDiscount = productItem.MinLocalDiscount_S;
                    productItem.InVisitStandard = productItem.InVisitStandard_S;
                    productItem.OutVisitStandard = productItem.OutVisitStandard_S;
                    productItem.MinVisitStandard = productItem.MinVisitStandard_S;
                    productItem.EPALevy = productItem.EPALevy_S;
                    productItem.MinEPALevy = productItem.MinEPALevy_S;
                    db.Entry(productItem).State = EntityState.Modified;
                }

                db.SaveChanges();

                foreach (var productItem in scheduledPriceEnabledProducts)
                {
                    productItem.InLocalDiscount_S = 0;
                    productItem.OutLocalDiscount_S = 0;
                    productItem.MinLocalDiscount_S = 0;
                    productItem.InVisitStandard_S = 0;
                    productItem.OutVisitStandard_S = 0;
                    productItem.MinVisitStandard_S = 0;
                    productItem.EPALevy_S = 0;
                    productItem.MinEPALevy_S = 0;
                    productItem.SchedulePriceDate = null;
                    db.Entry(productItem).State = EntityState.Modified;
                }

                db.SaveChanges();

                foreach (var productItem in scheduledPriceEnabledProducts)
                {
                    List<Site> siteList = db.Sites.Where(s => s.ID > 1).ToList();
                    foreach (var siteItem in siteList)
                    {
                        ReplicationLogItem logItem = new ReplicationLogItem
                        {
                            DestinationSiteID = siteItem.ID,
                            EntityType = "Product",
                            EntityID = productItem.ID,

                            Operation = "U",
                            SourceSiteID = 1,
                            LogCreated = DateTime.UtcNow
                        };

                        db.ReplicationLogItems.Add(logItem);
                    }

                    db.SaveChanges();
                }
            }
            return StatusCode(HttpStatusCode.OK);
        }

        /// <summary>
        /// Get the product details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Product/5
        [ResponseType(typeof(Product))]
        public IHttpActionResult GetProduct(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        /// <summary>
        /// Update product details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="product"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/Product/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutProduct(int id, Product product, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != product.ID)
            {
                return BadRequest();
            }

            product.Name = product.Name.ToUpper();
            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(product).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // PUT: api/Product/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutProduct(int id, Product _product, int siteID, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                if (id != _product.ID)
                {
                    return BadRequest();
                }

                db = new AWSWeighingServiceContext(connectionStringName);

                Product product = new Product();
                var productExist = db.Products.Where(e => e.Code.ToLower() == _product.Code.ToLower()).FirstOrDefault();
                if (productExist != null)
                {
                    product = productExist;
                    product.Name = _product.Name;
                    product.InLocalDiscount = _product.InLocalDiscount;
                    product.OutLocalDiscount = _product.OutLocalDiscount;
                }
                else product = _product;

                product.Name = product.Name.ToUpper();
                db.Entry(product).State = EntityState.Modified;
                product.Sites = new List<Site>();
                var siteToAdd = db.Sites.Find(Convert.ToInt32(siteID));
                if (siteToAdd != null)
                {
                    product.Sites.Add(siteToAdd);
                }

                LogInfo("Updating for: " + product.Name + " at site " + siteID.ToString());
                string[] addSites = new string[1];
                addSites[0] = siteID.ToString();

                AddProductToSite(db, addSites, product.Sites);

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                LogInfo("Exception: " + ex.Message + " | " + ex.InnerException.Message + " | " + ex.StackTrace);
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Creat a new product based on the model
        /// </summary>
        /// <param name="product"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/Product
        [ResponseType(typeof(Product))]
        public IHttpActionResult PostProduct(Product product, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            product.Sites = new List<Site>();
            var siteToAdd = db.Sites.Find(product.ID);  //here ID is reused to hold site ID of which site the destination is created
            if (siteToAdd != null)
            {
                product.Sites.Add(siteToAdd);
            }
            product.ID = 0;
            product.Name = product.Name.ToUpper();


            db.Products.Add(product);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = product.ID }, product);
        }

        //Delete the product based on the id
        // DELETE: api/Product/5
        [ResponseType(typeof(Product))]
        public IHttpActionResult DeleteProduct(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return NotFound();
            }

            db.Products.Remove(product);
            db.SaveChanges();

            return Ok(product);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ProductExists(int id)
        {
            return db.Products.Count(e => e.ID == id) > 0;
        }

        protected void AddProductToSite(AWSWeighingServiceContext dbContext, string[] selectedSites, ICollection<Site> assignedSites)
        {

            if (selectedSites == null)
            {
                assignedSites = new List<Site>();
                return;
            }


            var selectedSitesHS = new HashSet<string>(selectedSites);
            var assignedSitesHS = new HashSet<int>(assignedSites.Select(s => s.ID));

            foreach (var site in dbContext.Sites)
            {
                if (selectedSitesHS.Contains(site.ID.ToString()))
                {
                    if (!assignedSitesHS.Contains(site.ID))
                    {
                        assignedSites.Add(site);
                    }
                }
            }
        }

        public void LogInfo(string message)
        {
            string logPath = "~/XeroCertificates/logs";
            DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(logPath));
            var logFile = dirInfo.FullName + @"\ProductUpdateLog.txt";
            //            System.IO.File.WriteAllLines(logFile, new[] { message }, Encoding.UTF8);

            if (!System.IO.File.Exists(logFile))
            {
                System.IO.File.WriteAllLines(logFile, new[] { message }, Encoding.UTF8);
            }
            else
            {
                System.IO.File.AppendAllLines(logFile, new[] { message }, Encoding.UTF8);
            }
        }

    }
}
