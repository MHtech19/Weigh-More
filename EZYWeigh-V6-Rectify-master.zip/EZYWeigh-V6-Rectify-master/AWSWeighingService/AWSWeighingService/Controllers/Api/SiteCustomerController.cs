﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class SiteCustomerController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db ;

        /// <summary>
        /// Get the list os site-customer details from DB
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/SiteCustomer/5
        public IQueryable<Customer> GetCustomers(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is SiteID
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            var site = db.Sites.FirstOrDefault(s => s.ID == id);
            if (site == null)
            {
                return db.Customers.Where(s => s.Name == Constants.NAEntityName).OrderBy(e => e.Name);
            }

            return site.Customers.Where(c => c.Active).OrderBy(e => e.Name).AsQueryable<Customer>();
        }

    }
}
