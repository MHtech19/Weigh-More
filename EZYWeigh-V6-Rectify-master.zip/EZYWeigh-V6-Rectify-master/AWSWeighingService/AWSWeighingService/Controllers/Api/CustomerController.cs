﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class CustomerController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Here return the list of customers from db
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Customer
        public IQueryable<Customer> GetCustomers(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.Customers.Where(e => e.ID >= 1 && e.Active && (e.CustomerType == CoreConstants.CustomerType));
        }

        // GET: api/Customer
        public IQueryable<Customer> GetCustomers(string activeInactiveAll, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            switch (activeInactiveAll.ToUpper())
            {
                case "ALL":
                    {
                        return db.Customers.Where(e => e.ID >= 1 && (e.CustomerType == CoreConstants.CustomerType));
                        break;
                    }
                case "ACTIVE":
                    {
                        return db.Customers.Where(e => e.ID >= 1 && e.Active && (e.CustomerType == CoreConstants.CustomerType));
                        break;
                    }
                case "INACTIVE":
                    {
                        return db.Customers.Where(e => e.ID >= 1 && !e.Active && (e.CustomerType == CoreConstants.CustomerType));
                        break;
                    }
                default:
                    {
                        return null;
                        break;
                    }
            }

        }

        /// <summary>
        /// Here get the customer details based on the cusotmer id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/Customer/5
        [ResponseType(typeof(Customer))]
        public IHttpActionResult GetCustomer(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return NotFound();
            }

            return Ok(customer);
        }

        /// <summary>
        /// Here update the customer details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="customer"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/Customer/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCustomer(int id, Customer customer, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != customer.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);

            db.Entry(customer).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Here create a new customer based on the model
        /// </summary>
        /// <param name="customer"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>

        // POST: api/Customer
        [ResponseType(typeof(Customer))]
        public IHttpActionResult PostCustomer(Customer customer, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            customer.Sites = new List<Site>();
            var siteToAdd = db.Sites.Find(customer.ID);  //here ID is reused to hold site ID of which site the customer is created
            if (siteToAdd != null)
            {
                customer.Sites.Add(siteToAdd);
            }
            customer.ID = 0;
            customer.Name = customer.Name.ToUpper();

            db.Customers.Add(customer);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = customer.ID }, customer);
        }

        /// <summary>
        /// Delete the customer based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/Customer/5
        [ResponseType(typeof(Customer))]
        public IHttpActionResult DeleteCustomer(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return NotFound();
            }

            db.Customers.Remove(customer);
            db.SaveChanges();

            return Ok(customer);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CustomerExists(int id)
        {
            return db.Customers.Count(e => e.ID == id) > 0;
        }
    }
}