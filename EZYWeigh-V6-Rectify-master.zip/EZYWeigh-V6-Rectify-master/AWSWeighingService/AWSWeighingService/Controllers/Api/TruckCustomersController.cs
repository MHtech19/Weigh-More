﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TruckCustomersController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        private void SetDB(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
        }

        /// <summary>
        /// Get the list of truck-customer details from DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<TruckCustomers> GetTruckCustomers(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            return db.TruckCustomers.Where(e => e.CustomerType == "C").ToList();
        }

        /// <summary>
        /// Get the truck-customer details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/TruckCustomers/186
        public IList<TruckCustomers> GetTruckCustomers(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is truckID
        {
            SetDB(connectionStringName);
            //IList<Product> productListWithNewPrice = new List<Product>();
            return db.TruckCustomers.Where(e => e.TruckID == id && e.CustomerType == "C").ToList();
        }

        //Update truck-customer details based on the id and model
        // PUT: api/TruckCustomers/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTruckCustomers(int id, TruckCustomers truckCustomers, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != truckCustomers.ID)
            {
                return BadRequest();
            }

            SetDB(connectionStringName);
            db.Entry(truckCustomers).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TruckCustomerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new truck-customer based on the model
        /// </summary>
        /// <param name="truckCustomers"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/TruckCustomers
        [ResponseType(typeof(TruckCustomers))]
        public IHttpActionResult PostTruckCustomers(TruckCustomers truckCustomers, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SetDB(connectionStringName);
            db.TruckCustomers.Add(truckCustomers);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = truckCustomers.ID }, truckCustomers);
        }

        /// <summary>
        /// Delete the truck-customer details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/TruckCustomers/5
        [ResponseType(typeof(TruckCustomers))]
        public IHttpActionResult DeleteTruckCustomers(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            TruckCustomers truckCustomers = db.TruckCustomers.Find(id);
            if (truckCustomers == null)
            {
                return NotFound();
            }

            db.TruckCustomers.Remove(truckCustomers);
            db.SaveChanges();

            return Ok(truckCustomers);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TruckCustomerExists(int id)
        {
            return db.TruckCustomers.Count(e => e.ID == id) > 0;
        }
    }
}