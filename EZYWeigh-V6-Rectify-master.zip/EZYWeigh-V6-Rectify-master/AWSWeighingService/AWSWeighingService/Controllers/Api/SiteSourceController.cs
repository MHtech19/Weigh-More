﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class SiteSourceController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Get the Site-Source details from DB based on the site id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/SiteSource/5
        public IQueryable<Source> GetSources(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is SiteID
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            var site = db.Sites.FirstOrDefault(s => s.ID == id);
            if (site == null)
            {
                return db.Sources.Where(s => s.Name == Constants.NAEntityName).OrderBy(e => e.Name);
            }

            return site.Sources.Where(p => p.IsActive).OrderBy(e => e.Name).AsQueryable<Source>();
        }

    }
}
