﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
//using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class FirstWeighController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        // GET: api/FirstWeigh
        public IQueryable<FirstWeigh> GetFirstWeighs(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.FirstWeighs.Where(e => e.SiteID == id).OrderByDescending(f=>f.TareInDate);
        }

        // GET: api/FirstWeigh
        public IQueryable<FirstWeigh> GetFirstWeighs(int id,string date, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            var selecteddate = DateTime.ParseExact(date, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);

            db = new AWSWeighingServiceContext(connectionStringName);
            return db.FirstWeighs.Where(e => e.SiteID == id && DbFunctions.TruncateTime(e.TareInDate) == DbFunctions.TruncateTime(selecteddate)).OrderByDescending(f => f.TareInDate);
        }

        // GET: api/FirstWeigh/5
        [ResponseType(typeof(FirstWeigh))]
        public IHttpActionResult GetFirstWeigh(int id, string name, string connectionStringName = CoreConstants.AWSConnectionStringName) 
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            FirstWeigh firstWeigh = db.FirstWeighs.FirstOrDefault(e => (e.Name == name) && (e.SiteID == id));
            if (firstWeigh == null)
            {
                return NotFound();
            }

            return Ok(firstWeigh);
        }

        // PUT: api/FirstWeigh/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutFirstWeigh(int id, FirstWeigh firstWeigh, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != firstWeigh.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(firstWeigh).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FirstWeighExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/FirstWeigh
        [ResponseType(typeof(FirstWeigh))]
        public IHttpActionResult PostFirstWeigh(FirstWeigh firstWeigh, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.FirstWeighs.Add(firstWeigh);
            db.SaveChanges();

            return Ok(firstWeigh);
        }

        // DELETE: api/FirstWeigh/5
        [ResponseType(typeof(FirstWeigh))]
        public IHttpActionResult DeleteFirstWeigh(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            FirstWeigh firstWeigh = db.FirstWeighs.Find(id);
            if (firstWeigh != null)
            {
                db.FirstWeighs.Remove(firstWeigh);
                db.SaveChanges();
            }

            return Ok(firstWeigh);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool FirstWeighExists(int id)
        {
            return db.FirstWeighs.Count(e => e.ID == id) > 0;
        }
    }
}