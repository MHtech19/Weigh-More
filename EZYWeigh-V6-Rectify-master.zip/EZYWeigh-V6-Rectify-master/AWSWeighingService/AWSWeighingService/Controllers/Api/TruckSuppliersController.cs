﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TruckSuppliersController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        private void SetDB(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
        }

        /// <summary>
        /// Get the list of truck-supplier details
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<TruckCustomers> GetTruckSuppliers(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            return db.TruckCustomers.Where(e => e.CustomerType == "S").ToList();
        }

        /// <summary>
        /// Get the truck-supplier based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/TruckSuppliers/186
        public IList<TruckCustomers> GetTruckSuppliers(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is truckID
        {
            SetDB(connectionStringName);
            //IList<Product> productListWithNewPrice = new List<Product>();
            return db.TruckCustomers.Where(e => e.TruckID == id && e.CustomerType == "S").ToList();
        }

        /// <summary>
        /// Update truck-supplier details based on the id and model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="truckCustomers"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/TruckSuppliers/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTruckSuppliers(int id, TruckCustomers truckCustomers, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != truckCustomers.ID)
            {
                return BadRequest();
            }

            SetDB(connectionStringName);
            db.Entry(truckCustomers).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TruckSupplierExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        //Create a new truck-supplier based on the model
        // POST: api/TruckSuppliers
        [ResponseType(typeof(TruckCustomers))]
        public IHttpActionResult PostTruckSuppliers(TruckCustomers truckCustomers, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SetDB(connectionStringName);
            db.TruckCustomers.Add(truckCustomers);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = truckCustomers.ID }, truckCustomers);
        }

        /// <summary>
        /// Delete the truck-supplier details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/TruckSuppliers/5
        [ResponseType(typeof(TruckCustomers))]
        public IHttpActionResult DeleteTruckSuppliers(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            TruckCustomers truckCustomers = db.TruckCustomers.Find(id);
            if (truckCustomers == null)
            {
                return NotFound();
            }

            db.TruckCustomers.Remove(truckCustomers);
            db.SaveChanges();

            return Ok(truckCustomers);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TruckSupplierExists(int id)
        {
            return db.TruckCustomers.Count(e => e.ID == id) > 0;
        }
    }
}