﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class CameraSnapshotController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        /// <summary>
        /// Here get the list of camera snapshots bases on the connection string
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/CameraSnapshot
        public IQueryable<CameraSnapshot> GetCameraSnapshots(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.CameraSnapshots;
        }
  
        /// <summary>
        /// Here get the snapshot details based on the snapshot id 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/CameraSnapshot/5
        [ResponseType(typeof(CameraSnapshot))]
        public IHttpActionResult GetCameraSnapshot(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)  //here ID is actually TransactionID
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            CameraSnapshot cameraSnapshot = db.CameraSnapshots.FirstOrDefault(s => s.TransactionID == id);
            if (cameraSnapshot == null)
            {
                return NotFound();
            }

            return Ok(cameraSnapshot);
        }

        /// <summary>
        /// Here Modify the snapshot details based on the snapshot id and the model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="cameraSnapshot"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/CameraSnapshot/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCameraSnapshot(int id, CameraSnapshot cameraSnapshot, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != cameraSnapshot.ID)
            {
                return BadRequest();
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(cameraSnapshot).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CameraSnapshotExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }
        /// <summary>
        /// Here create a new snapshot based on the snapshot model
        /// </summary>
        /// <param name="cameraSnapshot"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>

        // POST: api/CameraSnapshot
        [ResponseType(typeof(CameraSnapshot))]
        public IHttpActionResult PostCameraSnapshot(CameraSnapshot cameraSnapshot, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);

            db.CameraSnapshots.Add(cameraSnapshot);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = cameraSnapshot.ID }, cameraSnapshot);
        }

        /// <summary>
        /// Here Delete the snapshot basedon the snapshot id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // DELETE: api/CameraSnapshot/5
        [ResponseType(typeof(CameraSnapshot))]
        public IHttpActionResult DeleteCameraSnapshot(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            CameraSnapshot cameraSnapshot = db.CameraSnapshots.Find(id);
            if (cameraSnapshot == null)
            {
                return NotFound();
            }

            db.CameraSnapshots.Remove(cameraSnapshot);
            db.SaveChanges();

            return Ok(cameraSnapshot);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CameraSnapshotExists(int id)
        {
            return db.CameraSnapshots.Count(e => e.ID == id) > 0;
        }
    }
}