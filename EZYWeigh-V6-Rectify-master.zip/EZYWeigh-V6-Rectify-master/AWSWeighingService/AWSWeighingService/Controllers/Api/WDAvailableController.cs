﻿using AWSWeighingService.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AWSWeighingService.Controllers.Api
{
    public class WDAvailableController : AuthorizationExtController
    {

        // GET: api/wdavailable
        public string GetWDAvailable()
        {
            WebRequest request = WebRequest.Create("http://61.16.135.140:988/");
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                if (response == null || response.StatusCode != HttpStatusCode.OK)
                {
                    response.Close();
                    return "Not Available";
                }
                else
                {
                    response.Close();
                    return "Available";
                }

            }
            catch
            {
                return "Not Available";
            }
           
        }
    }
}
