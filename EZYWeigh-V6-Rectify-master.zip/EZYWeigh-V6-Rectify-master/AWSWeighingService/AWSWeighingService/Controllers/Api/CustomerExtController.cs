﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class CustomerExtController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        // GET: api/CustomerExt
        public IQueryable<CustomerExt> GetCustomerExt(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            return db.CustomerExt.Where(e => e.ID >= 1);
        }
        
        // GET: api/CustomerExt/5
        [ResponseType(typeof(CustomerExt))]
        public IHttpActionResult GetCustomerExt(int customerID, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            CustomerExt customerExt = db.CustomerExt.FirstOrDefault(s => s.CustomerID == customerID);
            if (customerExt == null)
            {
                return NotFound();
            }

            return Ok(customerExt);
        }

        // POST: api/CustomerExt
        [ResponseType(typeof(CustomerExt))]
        public IHttpActionResult PostCustomerExt(CustomerExt customerExt, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {  
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            customerExt.ID = 0;
            db.CustomerExt.Add(customerExt);

            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = customerExt.ID }, customerExt);
        }

        // PUT: api/CustomerExt
        [ResponseType(typeof(CustomerExt))]
        public IHttpActionResult PutCustomerExt(CustomerExt customerExt, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db = new AWSWeighingServiceContext(connectionStringName);
            db.Entry(customerExt).State = EntityState.Modified;
            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerExtExists(customerExt.ID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // DELETE: api/CustomerExt/5
        [ResponseType(typeof(Customer))]
        public IHttpActionResult DeleteCustomerExt(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
            CustomerExt customerExt = db.CustomerExt.Find(id);
            if (customerExt == null)
            {
                return NotFound();
            }

            db.CustomerExt.Remove(customerExt);
            db.SaveChanges();

            return Ok(customerExt);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db!=null)
            {
               if (db != null) db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CustomerExtExists(int id)
        {
            return db.Customers.Count(e => e.ID == id) > 0;
        }
    }
}