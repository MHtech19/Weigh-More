﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers.Api
{
    public class TruckSourceController : AuthorizationExtController
    {
        private AWSWeighingServiceContext db;

        private void SetDB(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            db = new AWSWeighingServiceContext(connectionStringName);
        }

        /// <summary>
        /// Get the list of truck-source details from DB
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        public IList<TruckSource> GetTruckSource(string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            return db.TruckSource.ToList();
        }

        /// <summary>
        /// Get the truck-source details based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // GET: api/TruckSources/186
        public IList<TruckSource> GetTruckSource(int id, string connectionStringName = CoreConstants.AWSConnectionStringName) // id is truckID
        {
            SetDB(connectionStringName);
            //IList<Product> productListWithNewPrice = new List<Product>();
            return db.TruckSource.Where(e => e.TruckID == id).ToList();
        }

        /// <summary>
        /// Update truck-source details based on the idand model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="truckSource"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // PUT: api/TruckSources/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTruckSource(int id, TruckSource truckSource, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != truckSource.ID)
            {
                return BadRequest();
            }

            SetDB(connectionStringName);
            db.Entry(truckSource).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TruckSourceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new truck-source based on the model
        /// </summary>
        /// <param name="truckSource"></param>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        // POST: api/TruckSources
        [ResponseType(typeof(TruckSource))]
        public IHttpActionResult PostTruckSource(TruckSource truckSource, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SetDB(connectionStringName);
            db.TruckSource.Add(truckSource);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = truckSource.ID }, truckSource);
        }

        //Delete truck-source based on the id
        // DELETE: api/TruckSources/5
        [ResponseType(typeof(TruckSource))]
        public IHttpActionResult DeleteTruckSource(int id, string connectionStringName = CoreConstants.AWSConnectionStringName)
        {
            SetDB(connectionStringName);
            TruckSource truckSource = db.TruckSource.Find(id);
            if (truckSource == null)
            {
                return NotFound();
            }

            db.TruckSource.Remove(truckSource);
            db.SaveChanges();

            return Ok(truckSource);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && db != null)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TruckSourceExists(int id)
        {
            return db.TruckSource.Count(e => e.ID == id) > 0;
        }
    }
}