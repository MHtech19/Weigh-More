﻿using AWSWeighingService.DAL;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using AWSWeighingService.ViewModels;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Controllers
{
    public class ReportController : EntityController<Customer>
    {
        /// <summary>
        /// Get the reports list - Renders report index page
        /// </summary>
        /// <returns></returns>
        // GET: Report List
        [SessionAccess]
        public ActionResult Index()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();

            return View(logOnRole);
        }

        /// <summary>
        /// Get the reports list - navigate to report index page
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportIndex()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            SetViewBagValues();
            return View();
        }

        /// <summary>
        /// Navigate to the specific report index page based on the selected report
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="reportDescription"></param>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportTemplate(string reportName, string reportDescription)
        {
            var rptInfo = new ReportInfo
            {
                ReportName = reportName,
                ReportDescription = reportDescription,
                ReportPath = SingletonWebConfigAppSetttings.Instance.ReportLink,
                ReportCommand = "&rs:Command=Render",
            };
            SetViewBagValues();
            return Redirect(rptInfo.ReportURL); // redirects to external url
        }

        /// <summary>
        /// Navigate to Customer report page
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportCustomer()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Customers.Where(e => e.ID > CoreConstants.NA_ID && e.CustomerType == CoreConstants.CustomerType).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no customer data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Customer Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Customers", entities);
            //rd.Name = "Customers";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\CustomerReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();

            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Customers";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/CustomerReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};
            
            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Site repost page
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportSite()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Sites.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no site data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;


            ViewBag.Title = "Site Report";
            reportTitle = ViewBag.Title;            

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\SiteReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();
            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;

            newReportViewerInfo.ReportPath = "Reports/SiteReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Supplier report page
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportSupplier()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Customers.Where(e => e.ID > CoreConstants.NA_ID && e.CustomerType == CoreConstants.SupplierType).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no supplier data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Supplier Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Customers", entities);
            //rd.Name = "Customers";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\CustomerReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();

            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Customers";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/CustomerReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};
            
            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Product Category report
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportProductCategory()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.ProductCategories.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no product category data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Product Category Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\ProductCategoryReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();

            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/ProductCategoryReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};
            
            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Source Report page
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportSource()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Sources.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no source data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Source Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\SourceReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();

            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/SourceReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Destination report page
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportDestination()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Destinations.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no destination data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Destination Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\DestinationReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();

            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/DestinationReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Product report page
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportProduct()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Products.Where(e => e.ID > CoreConstants.NA_ID && e.ProductType == CoreConstants.ProductType_Weighed).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no product data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Product Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\ProductReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();
            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/ProductReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Counted Item report
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportCountedItem()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Products.Where(e => e.ID > CoreConstants.NA_ID && e.ProductType == CoreConstants.ProductType_Counted).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no counted item data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Counted Item Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\ProductReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();
            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/ProductReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to truck Configuration report
        /// </summary>
        /// <returns></returns>
        [SessionAccess]
        public ActionResult ReportTruckConfiguration()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.VehicleConfigurations.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no truck configuration data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Truck Configuration Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\TruckConfigurationReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();
            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/TruckConfigurationReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Driver Report
        /// </summary>
        /// <returns></returns>
        /// 
        [SessionAccess]
        public ActionResult ReportDriver()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Drivers.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no driver data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Driver Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\DriverReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();
            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/DriverReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to VehicleType report
        /// </summary>
        /// <returns></returns>
        /// 
        [SessionAccess]
        public ActionResult ReportVehicleType()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Vehicles.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no vehicle type data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Vehicle Type Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\VehicleTypeReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();
            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/VehicleTypeReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Navigate to Vehicle Report
        /// </summary>
        /// <returns></returns>
        /// 
        [SessionAccess]
        public ActionResult ReportVehicle()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Trucks.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no vehicle data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Vehicle Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\VehicleReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();

            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/VehicleReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};
            
            return View("ReportContainer", newReportViewerInfo);
        }


        /// <summary>
        /// Navigate to Job report
        /// </summary>
        /// <returns></returns>
        /// 
        [SessionAccess]
        public ActionResult ReportJob()
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            var entities = db.Jobs.Where(e => e.ID > CoreConstants.NA_ID).ToList();
            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no job data to report.";
                return RedirectToAction("Index");
            }

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
            organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
            address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

            address = string.IsNullOrEmpty(address) ? "Address" : address;

            ViewBag.Title = "Job Report";
            reportTitle = ViewBag.Title;

            //ReportDataSource rd = new ReportDataSource("Entities", entities);
            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\JobReport.rdlc";

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();
            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            newReportViewerInfo.ReportPath = "Reports/JobReport.rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address};

            return View("ReportContainer", newReportViewerInfo);
        }


        /// <summary>
        ///  Navigate to CreateDateSelection page based on the report name and by date
        /// </summary>
        /// <param name="reportName"></param>
        /// <returns></returns>
        // GET: ReportTransaction
        [SessionAccess]
        public ActionResult CreateDateSelection(string reportName)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            DateRangeWithEntities dateRangeWithEntities = new DateRangeWithEntities
            {
                StartDate = DateTime.Today,
                EndDate = DateTime.Today,
                ReportName = reportName,
                Entities = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID),
            };
            ViewBag.SelectTitle = "Select Sites";

            SetViewBagValues();
            return View(dateRangeWithEntities);
        }

        /// <summary>
        /// Get report based on the report name and start and end dates
        /// </summary>
        /// <param name="dateRangeWithEntities"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        public ActionResult CreateDateSelection(DateRangeWithEntities dateRangeWithEntities)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            List<Signature> signatures = db.Signatures.ToList();

            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            if ((dateRangeWithEntities.ReportName == "ByVehicleTransactionReport") || (dateRangeWithEntities.ReportName == "SummaryByVehicleTransactionReport"))
            {
                var regos = db.Transactions.Where(e => DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(dateRangeWithEntities.StartDate) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(dateRangeWithEntities.EndDate)).GroupBy(e => e.Registration1).Select(grp => grp.FirstOrDefault().Registration1).ToList();
                dateRangeWithEntities.Entities = new SelectList(regos, regos[0]);
                dateRangeWithEntities.EntityIDs2 = dateRangeWithEntities.EntityIDs;
                ViewBag.SelectTitle = "Select Vehicles";
                return View("CreateVehicleSelection", dateRangeWithEntities);
            }

            var transactions = db.Transactions.Where(e => DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(dateRangeWithEntities.StartDate) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(dateRangeWithEntities.EndDate)); //.ToList();


            //if site selected
            if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
            {
                transactions = transactions.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.SiteID));
            }

            if (dateRangeWithEntities.ReportName == "ManualTransactionReport")
            {
                transactions = transactions.Where(e => e.IsManualEntry == true);
            }

            //Direction Filter
            if ((dateRangeWithEntities.IsInDirection ^ dateRangeWithEntities.IsOutDirection)) // xor
            {
                if (dateRangeWithEntities.IsInDirection)
                {
                    transactions = transactions.Where(t => t.Direction == CoreConstants.DIRECTION_IN);
                }
                else if (dateRangeWithEntities.IsOutDirection)
                {
                    transactions = transactions.Where(t => t.Direction == CoreConstants.DIRECTION_OUT);
                }
            }

            //Owner Filter
            if ((dateRangeWithEntities.IsSiteOwned ^ dateRangeWithEntities.IsCustomerOwned)) // xor
            {
                if (dateRangeWithEntities.IsSiteOwned)
                {
                    transactions = transactions.Where(t => t.VehicleOwner == CoreConstants.OWNER_SITE);
                }
                else if (dateRangeWithEntities.IsCustomerOwned)
                {
                    transactions = transactions.Where(t => t.VehicleOwner == CoreConstants.OWNER_PRIVATE);
                }
            }

            //Charge Rate Filter
            if ((dateRangeWithEntities.IsLocalChargeRate ^ dateRangeWithEntities.IsVisitorChargeRate)) // xor
            {
                if (dateRangeWithEntities.IsLocalChargeRate)
                {
                    transactions = transactions.Where(t => t.ChargeRate == CoreConstants.RATE_LOCAL);
                }
                else if (dateRangeWithEntities.IsVisitorChargeRate)
                {
                    transactions = transactions.Where(t => t.ChargeRate == CoreConstants.RATE_VISITOR);
                }
            }

            //Payment Filter
            List<string> paymentsList = new List<string>();
            string[] paymentsArray = null;
            if (!(dateRangeWithEntities.IsCashPayment && dateRangeWithEntities.IsAccountPayment && dateRangeWithEntities.IsChequePayment && dateRangeWithEntities.IsEFTPOSPayment && dateRangeWithEntities.IsCreditCardPayment) && !(!dateRangeWithEntities.IsCashPayment && !dateRangeWithEntities.IsAccountPayment && !dateRangeWithEntities.IsChequePayment && !dateRangeWithEntities.IsEFTPOSPayment && !dateRangeWithEntities.IsCreditCardPayment))
            {
                if (dateRangeWithEntities.IsCashPayment) paymentsList.Add(CoreConstants.PAYMENT_CASH);
                if (dateRangeWithEntities.IsAccountPayment) paymentsList.Add(CoreConstants.PAYMENT_ACCOUNT);
                if (dateRangeWithEntities.IsChequePayment) paymentsList.Add(CoreConstants.PAYMENT_CHEQUE);
                if (dateRangeWithEntities.IsEFTPOSPayment) paymentsList.Add(CoreConstants.PAYMENT_EFTPOS);
                if (dateRangeWithEntities.IsCreditCardPayment) paymentsList.Add(CoreConstants.PAYMENT_CREDIT);
                paymentsArray = paymentsList.ToArray();
            }

            // Load Type Filter
            List<string> loadTypesList = new List<string>();
            string[] loadTypesArray = null;
            if (!(dateRangeWithEntities.IsStandardLoadType && dateRangeWithEntities.IsCountedLoadType && dateRangeWithEntities.IsSecondLoadType && dateRangeWithEntities.IsMixedLoadType && dateRangeWithEntities.IsCreditCardPayment) && !(!dateRangeWithEntities.IsStandardLoadType && !dateRangeWithEntities.IsCountedLoadType && !dateRangeWithEntities.IsSecondLoadType && !dateRangeWithEntities.IsMixedLoadType && !dateRangeWithEntities.IsRegoLoadType))
            {
                if (dateRangeWithEntities.IsStandardLoadType) loadTypesList.Add(CoreConstants.Load_Standard);
                if (dateRangeWithEntities.IsCountedLoadType) loadTypesList.Add(CoreConstants.Load_Counted);
                if (dateRangeWithEntities.IsSecondLoadType)
                {
                    loadTypesList.Add(CoreConstants.Load_Second);
                    loadTypesList.Add(CoreConstants.Load_StoredTare);
                }
                if (dateRangeWithEntities.IsMixedLoadType) loadTypesList.Add(CoreConstants.Load_Mixed);
                if (dateRangeWithEntities.IsRegoLoadType) loadTypesList.Add(CoreConstants.Load_Rego);
                loadTypesArray = loadTypesList.ToArray();
            }

            if ((paymentsArray != null) && (paymentsArray.Count() >= 1))
            {
                transactions = transactions.Where(t => paymentsArray.Contains(t.Payments));
            }

            if ((loadTypesArray != null) && (loadTypesArray.Count() >= 1))
            {
                transactions = transactions.Where(t => loadTypesArray.Contains(t.LoadType));
            }

            if (dateRangeWithEntities.ReportName == "DeletedTransactionReport")
            {
                transactions = transactions.Where(e => e.Deleted == true);
            }
            else
            {
                transactions = transactions.Where(t => t.Deleted == false);
            }

            var jobs = db.Jobs.ToList();
            // for un-signed dockets.
            var _transT = transactions.ToList();

            if (dateRangeWithEntities.IsUnsignedDockets)
            {
                var _trans = transactions;
                foreach(Transaction tr in transactions)
                {
                    Job job = jobs.Find(x => x.ID == tr.JobID);
                    if ((job != null) && (job.DocketsShouldBeSigned))
                    {
                        if (DocketIsSigned(tr.ID, signatures))
                        {
                            _trans = _trans.Where(t => t.ID != tr.ID);
                        }
                    }
                    else
                    {
                        _trans = _trans.Where(t => t.ID != tr.ID);
                    }
                }
                transactions = _trans;
            }

            var trans = transactions.ToList();


            var sites = db.Sites.ToList();
            var weighmen = db.Weighmen.ToList();
            var productCategories = db.ProductCategories.ToList();
            var customers = db.Customers.ToList();
            var products = db.Products.ToList();
            var destinations = db.Destinations.ToList();
            var sources = db.Sources.ToList();
//            var jobs = db.Jobs.ToList();
            var vehicles = db.Vehicles.ToList();
            var drivers = db.Drivers.ToList();
            var truckconfig = db.VehicleConfigurations.ToList();


            var entities = from t in trans
                           join s in sites on t.SiteID equals s.ID
                           join w in weighmen on t.WeighmanID equals w.ID
                           join pc in productCategories on t.ProductCategoryID equals pc.ID
                           join c in customers on t.CustomerID equals c.ID
                           join p in products on t.ProductID equals p.ID
                           join d in destinations on t.DestinationID equals d.ID
                           join soc in sources on t.SourceID equals soc.ID
                           join j in jobs on t.JobID equals j.ID
                           join v in vehicles on t.VehicleID equals v.ID
                           join dr in drivers on t.DriverID equals dr.ID
                           join tcf in truckconfig on t.VehicleConfigurationID equals tcf.ID
                           select new
                           {
                               Docket = t.Docket,
                               TransactionDate = t.TransactionDate,
                               LoadType = t.LoadType,
                               Payments = t.Payments,
                               Direction = t.Direction,
                               VehicleOwner = t.VehicleOwner,
                               ChargeRate = t.ChargeRate,
                               OrderNumber = t.OrderNumber,
                               Comment = t.Comment,
                               Registration1 = t.Registration1,
                               Gross1 = t.Gross1 + t.Gross2 + t.Gross3 + t.Gross4 + t.Gross5,
                               Tare1 = t.Tare1 + t.Tare2 + t.Tare3 + t.Tare4 + t.Tare5,
                               Net = t.Net,
                               Price = t.Price,
                               TranCost = t.TranCost,
                               TotalCost = t.TotalCost,
                               CartageCharge = t.CartageCharge,
                               CartageCost = t.CartageCost,
                               GST = t.GST,
                               EPA = t.EPA,
                               DateStamp = t.DateStamp,
                               Royalty = t.Royalty,
                               Count = t.Count,

                               Site = s.Name,
                               Weighman = w.Name,
                               ProductCategory = pc.Name,
                               Customer = c.Name,
                               Product = p.Name,
                               Destination = d.Name,
                               Source = soc.Name,
                               Job = j.Name,
                               Vehicle = v.Name,
                               Driver = dr.Name,
                               VehicleConfiguration = tcf.Name,
                               CartageGST = t.CartageGST
                               //CatId = c.CatId
                               // other assignments
                           };

            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no transaction data to report.";
                return RedirectToAction("Index");
            }

            List<TransactionSummary> entitiySummary = new List<TransactionSummary>();
            bool isSummaryReport = false;
            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            //get report title subtitles
            if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0 && dateRangeWithEntities.EntityIDs.Count == 1)
            {
                int selectedSiteID = Convert.ToInt32(dateRangeWithEntities.EntityIDs[0]);
                Site selectedSite = db.Sites.FirstOrDefault(s => s.ID == selectedSiteID);
                if (selectedSiteID > 1)
                {
                    organisation = selectedSite.Name;
                    address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                        + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                        + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));
                }
                else
                {
                    organisation = string.IsNullOrEmpty(selectedSite.Address1) ? "Organisation" : selectedSite.Address1;
                    address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                        + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                        + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));

                    address = string.IsNullOrEmpty(address) ? "Address" : address;
                }
            }
            else
            {
                Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
                organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
                address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                    + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                    + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

                address = string.IsNullOrEmpty(address) ? "Address" : address;
            }

            reportTitle = "Transaction Report";

            switch (dateRangeWithEntities.ReportName)
            {
                case "SummaryTransactionReport":
                    isSummaryReport = true;
                    //entitiySummary = entities.GroupBy(e => e.DateStamp).Select(sumary => new TransactionSummary
                    entitiySummary = entities.GroupBy(e => e.TransactionDate.ToString("dd/MM/yyyy")).Select(sumary => new TransactionSummary
                    {
                        //EntityName = sumary.First().DateStamp,
                        EntityName = sumary.First().TransactionDate.ToString("dd/MM/yyyy"),
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)

                    }).ToList();
                    reportTitle = "Transaction Summary Report by Date";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByPaymentTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Payments).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Payments,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Payment";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "TransactionReport":
                    isSummaryReport = false;
                    reportTitle = "Transaction Report by Date";
                    break;
                case "AllTransactionListReport":
                    isSummaryReport = false;
                    reportTitle = "Transactions Report";
                    entities = entities.OrderBy(c => c.TransactionDate).ToList();
                    break;
                case "ManualTransactionReport":
                    isSummaryReport = false;
                    reportTitle = "Manual Transaction Report";
                    break;
                case "DeletedTransactionReport":
                    isSummaryReport = false;
                    reportTitle = "Deleted Transaction Report";
                    break;
                case "ByPaymentTransactionReport":
                    isSummaryReport = false;
                    reportTitle = "Transaction Report by Payment";
                    break;
                default: break;
            }

            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            //ReportDataSource rd = new ReportDataSource("Entities", entities);

            if (isSummaryReport)
            {
                //rd = new ReportDataSource("Entities", entitiySummary);
                newReportViewerInfo.ReportDataSourceKey = "Entities";
                newReportViewerInfo.ReportDataSource = entitiySummary;
            }

            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\" + dateRangeWithEntities.ReportName + ".rdlc";// @"Reports\TransactionReport.rdlc";

            ViewBag.Title = "Transaction Report";

            if (isSummaryReport)
            {               
                ViewBag.Title = "Transaction Summary Report";
            }

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);
            //ReportParameter reportSubTitle_DateRange_Param = new ReportParameter("DateRangeParameter", "From " + dateRangeWithEntities.StartDate.ToString("dd/MM/yyyy") + " to " + dateRangeWithEntities.EndDate.ToString("dd/MM/yyyy"));

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param, reportSubTitle_DateRange_Param });
            
            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();

            newReportViewerInfo.ReportPath = "Reports/" + dateRangeWithEntities.ReportName + ".rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address, DateRangeParameter = "From " + dateRangeWithEntities.StartDate.ToString("dd/MM/yyyy") + " to " + dateRangeWithEntities.EndDate.ToString("dd/MM/yyyy") };

            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// Get report based on the report name
        /// </summary>
        /// <param name="reportName"></param>
        /// <returns></returns>
        // GET: ReportTransaction
        [SessionAccess]
        public ActionResult CreateEntitiesSelection(string reportName, string listItemStatus = "")
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            DateRangeWithEntities dateRangeWithEntities = new DateRangeWithEntities
            {
                StartDate = DateTime.Today,
                EndDate = DateTime.Today,
                ReportName = reportName,
            };

            switch (dateRangeWithEntities.ReportName)
            {
                case "SummaryBySiteTransactionReport":
                case "BySiteTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Sites";
                    break;
                case "SummaryByCustomerTransactionReport":
                case "ByCustomerTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Customers.Where(e => e.CustomerType == "C").OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Customers";
                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                //case "SummaryByPaymentTransactionReport":
                //case "ByPaymentTransactionReport":
                //    dateRangeWithEntities.Entities = new SelectList(db.Customers.Where(e => e.CustomerType == "C").OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                //    ViewBag.SelectTitle = "Select Customers";
                //    break;
                case "SummaryBySupplierTransactionReport":
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    dateRangeWithEntities.Entities = new SelectList(db.Customers.Where(e => e.CustomerType == "S").OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Suppliers";
                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "BySupplierTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Customers.Where(e => e.CustomerType == "S").OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Suppliers";
                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";

                    break;
                case "SummaryByProductCategoryTransactionReport":
                case "ByProductCategoryTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.ProductCategories.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Product Categories";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "DocketSummaryListByProductCategoryandByAllVehicleTypes":
                    dateRangeWithEntities.Entities = new SelectList(db.ProductCategories.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Product Categories";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryBySourceTransactionReport":
                case "BySourceTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Sources.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Sources";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByDestinationTransactionReport":
                case "ByDestinationTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Destinations.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Destinations";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByProductTransactionReport":
                case "ByProductTransactionReport":
                    if (listItemStatus == "active")
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Products.Where(e => e.IsActive && e.ProductType == "W").OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Products(Active List)";
                    }
                    else if (listItemStatus == "inactive")
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Products.Where(e => e.IsActive == false && e.ProductType == "W").OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Products(InActive List)";
                    }
                    else
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Products.Where(e => e.ProductType == "W").OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Products(All Active/InActive)";
                    }

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByCountedItemTransactionReport":
                case "ByCountedItemTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Products.Where(e => e.ProductType == "I").OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Counted Items";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "ByPruductTransactionWithEPASourceReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Products";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByTruckConfigurationTransactionReport":
                case "ByTruckConfigurationTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.VehicleConfigurations.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Truck Configurations";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByVehicleTypeTransactionReport":
                case "ByVehicleTypeTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Vehicles.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Vehicles Types";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByVehicleTransactionReport":
                case "ByVehicleTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Trucks.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Vehicles";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByJobTransactionReport":
                case "ByJobTransactionReport":
                    if (listItemStatus == "active")
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Jobs.Where(j => j.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Jobs(Active List)";
                    }
                    else if (listItemStatus == "inactive")
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Jobs.Where(j => j.IsActive == false).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Jobs(InActive List)";
                    }
                    else
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Jobs.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Jobs(All Active/InActive)";
                    }

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByWeighmanTransactionReport":
                case "ByWeighmanTransactionReport":
                    dateRangeWithEntities.Entities = new SelectList(db.Weighmen.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle = "Select Operators";

                    dateRangeWithEntities.Entities2 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Sites";
                    break;
                case "SummaryByJobByProductTransactionReport":
                    if (listItemStatus == "active")
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Jobs.Where(j => j.IsActive).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Jobs(Active List)";
                    }
                    else if (listItemStatus == "inactive")
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Jobs.Where(j => j.IsActive == false).OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Jobs(InActive List)";
                    }
                    else
                    {
                        dateRangeWithEntities.Entities = new SelectList(db.Jobs.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                        ViewBag.SelectTitle = "Select Jobs(All Active/InActive)";
                    }

                    dateRangeWithEntities.Entities2 = new SelectList(db.Products.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle2 = "Select Products(All Active/InActive)";

                    dateRangeWithEntities.Entities3 = new SelectList(db.Sites.OrderBy(e => e.Name), "ID", "Name", CoreConstants.NA_ID);
                    ViewBag.SelectTitle3 = "Select Sites";
                    break;
                default:
                    break;
            }
            SetViewBagValues();
            return View(dateRangeWithEntities);
        }

        /// <summary>
        ///  Get transaction report based on date range
        /// </summary>
        /// <param name="dateRangeWithEntities"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [SessionAccess]
        public ActionResult CreateEntitiesSelection(DateRangeWithEntities dateRangeWithEntities)
        {
            db = (AWSWeighingServiceContext)RouteData.Values["db"];
            logOnSite = (Site)RouteData.Values["logOnSite"];
            logOnWeighman = (Weighman)RouteData.Values["logOnWeighman"];
            logOnRole = (Role)RouteData.Values["logOnRole"];

            string reportTitle = string.Empty;
            string organisation = string.Empty;
            string address = string.Empty;

            var transactions = db.Transactions.Where(e => DbFunctions.TruncateTime(e.TransactionDate) >= DbFunctions.TruncateTime(dateRangeWithEntities.StartDate) && DbFunctions.TruncateTime(e.TransactionDate) <= DbFunctions.TruncateTime(dateRangeWithEntities.EndDate)); //.ToList();
            //Direction Filter
            if ((dateRangeWithEntities.IsInDirection ^ dateRangeWithEntities.IsOutDirection)) // xor
            {
                if (dateRangeWithEntities.IsInDirection)
                {
                    transactions = transactions.Where(t => t.Direction == CoreConstants.DIRECTION_IN);
                }
                else if (dateRangeWithEntities.IsOutDirection)
                {
                    transactions = transactions.Where(t => t.Direction == CoreConstants.DIRECTION_OUT);
                }
            }

            //Owner Filter
            if ((dateRangeWithEntities.IsSiteOwned ^ dateRangeWithEntities.IsCustomerOwned)) // xor
            {
                if (dateRangeWithEntities.IsSiteOwned)
                {
                    transactions = transactions.Where(t => t.VehicleOwner == CoreConstants.OWNER_SITE);
                }
                else if (dateRangeWithEntities.IsCustomerOwned)
                {
                    transactions = transactions.Where(t => t.VehicleOwner == CoreConstants.OWNER_PRIVATE);
                }
            }

            //Charge Rate Filter
            if ((dateRangeWithEntities.IsLocalChargeRate ^ dateRangeWithEntities.IsVisitorChargeRate)) // xor
            {
                if (dateRangeWithEntities.IsLocalChargeRate)
                {
                    transactions = transactions.Where(t => t.ChargeRate == CoreConstants.RATE_LOCAL);
                }
                else if (dateRangeWithEntities.IsVisitorChargeRate)
                {
                    transactions = transactions.Where(t => t.ChargeRate == CoreConstants.RATE_VISITOR);
                }
            }

            //Payment Filter
            List<string> paymentsList = new List<string>();
            string[] paymentsArray = null;
            if (!(dateRangeWithEntities.IsCashPayment && dateRangeWithEntities.IsAccountPayment && dateRangeWithEntities.IsChequePayment && dateRangeWithEntities.IsEFTPOSPayment && dateRangeWithEntities.IsCreditCardPayment) && !(!dateRangeWithEntities.IsCashPayment && !dateRangeWithEntities.IsAccountPayment && !dateRangeWithEntities.IsChequePayment && !dateRangeWithEntities.IsEFTPOSPayment && !dateRangeWithEntities.IsCreditCardPayment))
            {
                if (dateRangeWithEntities.IsCashPayment) paymentsList.Add(CoreConstants.PAYMENT_CASH);
                if (dateRangeWithEntities.IsAccountPayment) paymentsList.Add(CoreConstants.PAYMENT_ACCOUNT);
                if (dateRangeWithEntities.IsChequePayment) paymentsList.Add(CoreConstants.PAYMENT_CHEQUE);
                if (dateRangeWithEntities.IsEFTPOSPayment) paymentsList.Add(CoreConstants.PAYMENT_EFTPOS);
                if (dateRangeWithEntities.IsCreditCardPayment) paymentsList.Add(CoreConstants.PAYMENT_CREDIT);
                paymentsArray = paymentsList.ToArray();
            }

            // Load Type Filter
            List<string> loadTypesList = new List<string>();
            string[] loadTypesArray = null;
            if (!(dateRangeWithEntities.IsStandardLoadType && dateRangeWithEntities.IsCountedLoadType && dateRangeWithEntities.IsSecondLoadType && dateRangeWithEntities.IsMixedLoadType && dateRangeWithEntities.IsCreditCardPayment) && !(!dateRangeWithEntities.IsStandardLoadType && !dateRangeWithEntities.IsCountedLoadType && !dateRangeWithEntities.IsSecondLoadType && !dateRangeWithEntities.IsMixedLoadType && !dateRangeWithEntities.IsRegoLoadType))
            {
                if (dateRangeWithEntities.IsStandardLoadType) loadTypesList.Add(CoreConstants.Load_Standard);
                if (dateRangeWithEntities.IsCountedLoadType) loadTypesList.Add(CoreConstants.Load_Counted);
                if (dateRangeWithEntities.IsSecondLoadType)
                {
                    loadTypesList.Add(CoreConstants.Load_Second);
                    loadTypesList.Add(CoreConstants.Load_StoredTare);
                }
                if (dateRangeWithEntities.IsMixedLoadType) loadTypesList.Add(CoreConstants.Load_Mixed);
                if (dateRangeWithEntities.IsRegoLoadType) loadTypesList.Add(CoreConstants.Load_Rego);
                loadTypesArray = loadTypesList.ToArray();
            }

            if ((paymentsArray != null) && (paymentsArray.Count() >= 1))
            {
                transactions = transactions.Where(t => paymentsArray.Contains(t.Payments));
            }

            if ((loadTypesArray != null) && (loadTypesArray.Count() >= 1))
            {
                transactions = transactions.Where(t => loadTypesArray.Contains(t.LoadType));
            }

            var trans = transactions.Where(t => t.Deleted == false).ToList();




            switch (dateRangeWithEntities.ReportName)
            {
                case "SummaryBySiteTransactionReport":
                case "BySiteTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Site";
                    break;
                case "SummaryByCustomerTransactionReport":
                case "ByCustomerTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.CustomerID)).ToList();
                    }
                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Customer";
                    break;
                //case "SummaryByPaymentTransactionReport":
                //case "ByPaymentTransactionReport":
                //    transactions = transactions.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.CustomerID)).ToList();
                //    break;
                case "SummaryBySupplierTransactionReport":
                case "BySupplierTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.CustomerID)).ToList();
                    }
                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Supplier";
                    break;
                case "SummaryByProductCategoryTransactionReport":
                case "ByProductCategoryTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductCategoryID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Product Category";
                    break;
                case "DocketSummaryListByProductCategoryandByAllVehicleTypes":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductCategoryID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Docket Summary List By Product Category and By All Vehicle Types";
                    break;
                case "SummaryBySourceTransactionReport":
                case "BySourceTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.SourceID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Source";
                    break;
                case "SummaryByDestinationTransactionReport":
                case "ByDestinationTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.DestinationID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Destination";
                    break;
                case "SummaryByProductTransactionReport":
                case "SummaryByCountedItemTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    break;
                case "ByProductTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Product";
                    break;
                case "ByCountedItemTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Counted Item";
                    break;
                case "ByPruductTransactionWithEPASourceReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Pruduct with EPS Source";
                    break;
                case "SummaryByTruckConfigurationTransactionReport":
                case "ByTruckConfigurationTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.VehicleConfigurationID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }

                    reportTitle = "Transaction Report By Truck Configuration";
                    break;
                case "SummaryByVehicleTypeTransactionReport":
                case "ByVehicleTypeTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.VehicleID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Vehicle Type";
                    break;
                case "SummaryByVehicleTransactionReport":
                case "ByVehicleTransactionReport":
                    if (dateRangeWithEntities.Registrations != null && dateRangeWithEntities.Registrations.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.Registrations.Contains(e.Registration1)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Vehicle";
                    break;
                case "SummaryByJobTransactionReport":
                case "ByJobTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.JobID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Job";
                    break;
                case "SummaryByWeighmanTransactionReport":
                case "ByWeighmanTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.WeighmanID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Operator";
                    break;
                case "SummaryByJobByProductTransactionReport":
                    if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs.Contains(e.JobID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs2.Contains(e.ProductID)).ToList();
                    }

                    if (dateRangeWithEntities.EntityIDs3 != null && dateRangeWithEntities.EntityIDs3.Count > 0)
                    {
                        trans = trans.Where(e => dateRangeWithEntities.EntityIDs3.Contains(e.SiteID)).ToList();
                    }
                    reportTitle = "Transaction Report By Job By Product";
                    break;
                default:
                    break;
            }

            if (dateRangeWithEntities.ReportName == "SummaryBySiteTransactionReport" || dateRangeWithEntities.ReportName == "BySiteTransactionReport")
            {
                if (dateRangeWithEntities.EntityIDs != null && dateRangeWithEntities.EntityIDs.Count > 0 && dateRangeWithEntities.EntityIDs.Count == 1)
                {
                    int selectedSiteID = Convert.ToInt32(dateRangeWithEntities.EntityIDs[0]);
                    Site selectedSite = db.Sites.FirstOrDefault(s => s.ID == selectedSiteID);
                    if (selectedSiteID > 1)
                    {
                        organisation = selectedSite.Name;
                        address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                            + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                            + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));
                    }
                    else
                    {
                        organisation = string.IsNullOrEmpty(selectedSite.Address1) ? "Organisation" : selectedSite.Address1;
                        address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                            + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                            + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));

                        address = string.IsNullOrEmpty(address) ? "Address" : address;
                    }
                }
                else
                {
                    Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
                    organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
                    address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                        + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                        + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

                    address = string.IsNullOrEmpty(address) ? "Address" : address;
                }
            }
            else
            {
                if(dateRangeWithEntities.ReportName == "SummaryByJobByProductTransactionReport")
                {
                    if (dateRangeWithEntities.EntityIDs3 != null && dateRangeWithEntities.EntityIDs3.Count > 0 && dateRangeWithEntities.EntityIDs3.Count == 1)
                    {
                        int selectedSiteID = Convert.ToInt32(dateRangeWithEntities.EntityIDs3[0]);
                        Site selectedSite = db.Sites.FirstOrDefault(s => s.ID == selectedSiteID);
                        if (selectedSiteID > 1)
                        {
                            organisation = selectedSite.Name;
                            address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                                + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                                + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));
                        }
                        else
                        {
                            organisation = string.IsNullOrEmpty(selectedSite.Address1) ? "Organisation" : selectedSite.Address1;
                            address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                                + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                                + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));

                            address = string.IsNullOrEmpty(address) ? "Address" : address;
                        }
                    }
                    else
                    {
                        Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
                        organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
                        address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                            + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                            + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

                        address = string.IsNullOrEmpty(address) ? "Address" : address;
                    }
                }
                else if (dateRangeWithEntities.EntityIDs2 != null && dateRangeWithEntities.EntityIDs2.Count > 0 && dateRangeWithEntities.EntityIDs2.Count == 1)
                {
                    int selectedSiteID = Convert.ToInt32(dateRangeWithEntities.EntityIDs2[0]);
                    Site selectedSite = db.Sites.FirstOrDefault(s => s.ID == selectedSiteID);
                    if (selectedSiteID > 1)
                    {
                        organisation = selectedSite.Name;
                        address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                            + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                            + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));
                    }
                    else
                    {
                        organisation = string.IsNullOrEmpty(selectedSite.Address1) ? "Organisation" : selectedSite.Address1;
                        address = selectedSite.Address2 + (string.IsNullOrEmpty(selectedSite.Suburb) ? "" : ("," + selectedSite.Suburb))
                            + (string.IsNullOrEmpty(selectedSite.State) ? "" : ("," + selectedSite.State))
                            + (string.IsNullOrEmpty(selectedSite.Postcode) ? "" : ("," + selectedSite.Postcode));

                        address = string.IsNullOrEmpty(address) ? "Address" : address;
                    }
                }
                else
                {
                    Site centranSite = db.Sites.FirstOrDefault(s => s.ID == CoreConstants.NA_ID);
                    organisation = string.IsNullOrEmpty(centranSite.Address1) ? "Organisation" : centranSite.Address1;
                    address = centranSite.Address2 + (string.IsNullOrEmpty(centranSite.Suburb) ? "" : ("," + centranSite.Suburb))
                        + (string.IsNullOrEmpty(centranSite.State) ? "" : ("," + centranSite.State))
                        + (string.IsNullOrEmpty(centranSite.Postcode) ? "" : ("," + centranSite.Postcode));

                    address = string.IsNullOrEmpty(address) ? "Address" : address;
                }
            }



            var sites = db.Sites.ToList();
            var weighmen = db.Weighmen.ToList();
            var productCategories = db.ProductCategories.ToList();
            var customers = db.Customers.ToList();
            var products = db.Products.ToList();
            var destinations = db.Destinations.ToList();
            var sources = db.Sources.ToList();
            var jobs = db.Jobs.ToList();
            var vehicleTypes = db.Vehicles.ToList();
            var drivers = db.Drivers.ToList();
            var truckconfig = db.VehicleConfigurations.ToList();
            var epaSources = db.EPASources.ToList();

            var entities = from t in trans
                           join s in sites on t.SiteID equals s.ID
                           join w in weighmen on t.WeighmanID equals w.ID
                           join pc in productCategories on t.ProductCategoryID equals pc.ID
                           join c in customers on t.CustomerID equals c.ID
                           join p in products on t.ProductID equals p.ID
                           join d in destinations on t.DestinationID equals d.ID
                           join soc in sources on t.SourceID equals soc.ID
                           join j in jobs on t.JobID equals j.ID
                           join vt in vehicleTypes on t.VehicleID equals vt.ID
                           join dr in drivers on t.DriverID equals dr.ID
                           join tcf in truckconfig on t.VehicleConfigurationID equals tcf.ID
                           //join epas in epaSources on t.ID equals epas.TransactionID
                           select new
                           {
                               ID = t.ID,
                               Docket = t.Docket,
                               TransactionDate = t.TransactionDate,
                               LoadType = t.LoadType,
                               Payments = t.Payments,
                               Direction = t.Direction,
                               VehicleOwner = t.VehicleOwner,
                               ChargeRate = t.ChargeRate,
                               OrderNumber = t.OrderNumber,
                               Comment = t.Comment,
                               Registration1 = t.Registration1,
                               Gross1 = t.Gross1 + t.Gross2 + t.Gross3 + t.Gross4 + t.Gross5,
                               Tare1 = t.Tare1 + t.Tare2 + t.Tare3 + t.Tare4 + t.Tare5,
                               Net = t.Net,
                               Price = t.Price,
                               TranCost = t.TranCost,
                               TotalCost = t.TotalCost,
                               CartageCharge = t.CartageCharge,
                               CartageCost = t.CartageCost,
                               GST = t.GST,
                               EPA = t.EPA,
                               DateStamp = t.DateStamp,
                               Royalty = t.Royalty,
                               Count = t.Count,
                               CartageGST = t.CartageGST,
                               Site = s.Name,
                               Weighman = w.Name,
                               ProductCategory = pc.Name,
                               Customer = c.Name,
                               Product = p.Name,
                               Destination = d.Name,
                               Source = soc.Name,
                               Job = j.Name,
                               VehicleType = vt.Name,
                               Driver = dr.Name,
                               VehicleConfiguration = tcf.Name,

                               //SourceBlock = epas.SourceBlock,
                               //SourceSection = epas.SourceSection,
                               //SourceAddress = epas.SourceAddress,

                               //CatId = c.CatId
                               // other assignments
                           };

            if (entities.Count() == 0)
            {
                TempData["UserMessage"] = "Oops! sorry, no transaction data to report.";
                return RedirectToAction("Index");
            }
            ReportViewerInfo newReportViewerInfo = new ReportViewerInfo();
            newReportViewerInfo.ReportDataSourceKey = "Entities";
            newReportViewerInfo.ReportDataSource = entities;
            //ReportDataSource rd = new ReportDataSource("Entities", entities);

            List<TransactionSummary> entitiySummary = new List<TransactionSummary>();
            bool isSummaryReport = false;

            switch (dateRangeWithEntities.ReportName)
            {
                case "ByPruductTransactionWithEPASourceReport":
                    var epaSourceTran = from t in entities
                                        join epas in epaSources on t.ID equals epas.TransactionID
                                        select new
                                        {
                                            ID = t.ID,
                                            Docket = t.Docket,
                                            TransactionDate = t.TransactionDate,
                                            LoadType = t.LoadType,
                                            Payments = t.Payments,
                                            Direction = t.Direction,
                                            VehicleOwner = t.VehicleOwner,
                                            ChargeRate = t.ChargeRate,
                                            OrderNumber = t.OrderNumber,
                                            Comment = t.Comment,
                                            Registration1 = t.Registration1,
                                            Gross1 = t.Gross1,
                                            Tare1 = t.Tare1,
                                            Net = t.Net,
                                            Price = t.Price,
                                            TranCost = t.TranCost,
                                            TotalCost = t.TotalCost,
                                            CartageCharge = t.CartageCharge,
                                            CartageCost = t.CartageCost,
                                            GST = t.GST,
                                            EPA = t.EPA,
                                            DateStamp = t.DateStamp,

                                            Site = t.Site,
                                            Weighman = t.Weighman,
                                            ProductCategory = t.ProductCategory,
                                            Customer = t.Customer,
                                            Product = t.Product,
                                            Destination = t.Destination,
                                            Source = t.Source,
                                            Job = t.Job,
                                            VehicleType = t.VehicleType,
                                            Driver = t.Driver,
                                            VehicleConfiguration = t.VehicleConfiguration,

                                            SourceBlock = epas.SourceBlock,
                                            SourceSection = epas.SourceSection,
                                            SourceAddress = epas.SourceAddress,
                                            CartageGST = t.CartageGST
                                            //CatId = c.CatId
                                            // other assignments
                                        };
                    if (epaSourceTran.Count() == 0)
                    {
                        TempData["UserMessage"] = "Oops! sorry, no transaction data to report.";
                        return RedirectToAction("Index");
                    }
                    //rd = new ReportDataSource("Entities", epaSourceTran);
                    newReportViewerInfo.ReportDataSource = epaSourceTran;
                    break;
                case "SummaryBySiteTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Site).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Site,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Site";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByCustomerTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Customer).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Customer,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Customer";
                    break;
                case "SummaryByPaymentTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Payments).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Payments,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Payment";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryBySupplierTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Customer).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Customer,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Supplier";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByProductCategoryTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.ProductCategory).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().ProductCategory,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Product Category";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "DocketSummaryListByProductCategoryandByAllVehicleTypes":
                    isSummaryReport = true;                  
                    var entitiySummary2 = entities.GroupBy(e => new { ProductCategory = e.ProductCategory, TransactionDate = e.TransactionDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture), VehicleType = e.VehicleType }).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().ProductCategory,
                        RowsItem = sumary.First().TransactionDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
                        ColumnsItem = sumary.First().VehicleType,
                        TranCount = sumary.Count(),
                        Net = sumary.Sum(e => e.Net),

                    }).ToList();

                    var distinctPC = entitiySummary2.Select(t => t.EntityName).Distinct();
                    var distinctVT = db.Vehicles.Select(t => t.Name).Distinct();
                    foreach (var pc in distinctPC)
                    {
                        for (DateTime date = dateRangeWithEntities.StartDate.Date; date <= dateRangeWithEntities.EndDate.Date; date += TimeSpan.FromDays(1))
                        {
                            string dateString = date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);

                            foreach (var vt in distinctVT)
                            {
                                var rowItemObj = entitiySummary2.Where(s => s.EntityName == pc && s.RowsItem == dateString && s.ColumnsItem == vt).FirstOrDefault();
                                if (rowItemObj != null)
                                {
                                    entitiySummary.Add(rowItemObj);
                                }
                                else
                                {
                                    entitiySummary.Add(new TransactionSummary() { EntityName = pc, RowsItem = dateString, ColumnsItem = vt, TranCount = 0, Net = 0 });
                                }
                            }
                        }
                    }
                    
                    reportTitle = "Docket Summary List By Product Category and By All Vehicle Types";
                    dateRangeWithEntities.ReportName = "DocketSummaryListByProductCategoryandByAllVehicleTypes";//use the same report rdlc
                    break;
                case "SummaryBySourceTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Source).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Source,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Source";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByDestinationTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Destination).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Destination,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Destination";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByProductTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Product).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Product,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Product";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByCountedItemTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Product).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Product,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Counted Item";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByTruckConfigurationTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.VehicleConfiguration).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().VehicleConfiguration,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Vehicle Configuration";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByVehicleTypeTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.VehicleType).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().VehicleType,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Vehicle Type";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByVehicleTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Registration1).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Registration1,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Vehicle Registration";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByJobTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Job).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Job,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Job";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;
                case "SummaryByWeighmanTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => e.Weighman).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Weighman,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Operator";
                    dateRangeWithEntities.ReportName = "SummaryByCustomerTransactionReport";//use the same report rdlc
                    break;

                case "SummaryByJobByProductTransactionReport":
                    isSummaryReport = true;
                    entitiySummary = entities.GroupBy(e => new { Job = e.Job, Product = e.Product }).Select(sumary => new TransactionSummary
                    {
                        EntityName = sumary.First().Job,
                        EntityName2 = sumary.First().Product,
                        TranCount = sumary.Count(),
                        Gross1 = sumary.Sum(e => e.Gross1),
                        Tare1 = sumary.Sum(e => e.Tare1),
                        Net = sumary.Sum(e => e.Net),
                        TranCost = sumary.Sum(e => e.TranCost),
                        GST = sumary.Sum(e => e.GST),
                        EPA = sumary.Sum(e => e.EPA),
                        CartageCharge = sumary.Sum(e => e.CartageCharge),
                        CartageCost = sumary.Sum(e => e.CartageCost),
                        TotalCost = sumary.Sum(e => e.TotalCost),
                        CartageGST = sumary.Sum(e => e.CartageGST)
                    }).ToList();
                    reportTitle = "Transaction Summary Report by Job and by Product";
                    dateRangeWithEntities.ReportName = "SummaryByJobByProductTransactionReport";//use the same report rdlc
                    break;

                default:
                    break;
            }

            if (isSummaryReport)
            {
                //rd = new ReportDataSource("Entities", entitiySummary);
                newReportViewerInfo.ReportDataSource = entitiySummary;
            }


            //rd.Name = "Entities";

            //ReportViewer reportViewer = new ReportViewer();
            //reportViewer.ProcessingMode = ProcessingMode.Local;
            //reportViewer.SizeToReportContent = true;
            //reportViewer.LocalReport.DataSources.Clear();
            //reportViewer.LocalReport.DataSources.Add(rd);
            //reportViewer.LocalReport.ReportPath = Request.MapPath(Request.ApplicationPath) + @"Reports\" + dateRangeWithEntities.ReportName + ".rdlc";
            ViewBag.Title = "Transaction Report";

            if (isSummaryReport)
            {
                ViewBag.Title = "Transaction Summary Report";
            }

            //ReportParameter reportTitleParam = new ReportParameter("ReportTitleParameter", reportTitle);
            //ReportParameter reportSubTitle_Organisation_Param = new ReportParameter("OrganisationParameter", organisation);
            //ReportParameter reportSubTitle_Address_Param = new ReportParameter("AddressParameter", address);
            //ReportParameter reportSubTitle_DateRange_Param = new ReportParameter("DateRangeParameter", "From " + dateRangeWithEntities.StartDate.ToString("dd/MM/yyyy") + " to " + dateRangeWithEntities.EndDate.ToString("dd/MM/yyyy"));

            //reportViewer.LocalReport.SetParameters(new ReportParameter[] { reportTitleParam, reportSubTitle_Organisation_Param, reportSubTitle_Address_Param, reportSubTitle_DateRange_Param });

            //ViewBag.ReportViewer = reportViewer;
            //Session["reportViewerData"] = reportViewer;
            SetViewBagValues();
                        
            newReportViewerInfo.ReportPath= "Reports/" + dateRangeWithEntities.ReportName + ".rdlc";
            newReportViewerInfo.ReportParams = new { ReportTitleParameter = reportTitle, OrganisationParameter = organisation, AddressParameter = address, DateRangeParameter = "From " + dateRangeWithEntities.StartDate.ToString("dd/MM/yyyy") + " to " + dateRangeWithEntities.EndDate.ToString("dd/MM/yyyy") };
                        
            return View("ReportContainer", newReportViewerInfo);
        }

        /// <summary>
        /// For Print
        /// </summary>
        /// <returns></returns>
        public ActionResult LocalReportPrint()
        {
            ReportViewer rptViwer = Session["reportViewerData"] as ReportViewer;
            if (rptViwer != null)
            {
                rptViwer.LocalReport.Print();
            }
            return null;
        }

        public bool DocketIsSigned(int transactionID, List<Signature> _signatures)
        {
            Signature signature = _signatures.FirstOrDefault(t => t.TransactionID == transactionID);
            if (signature == null)
            {
                return false;
            }
            return true;
        }
    }
}