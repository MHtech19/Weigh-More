using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Collections;
using System.Net.Mime;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Threading.Tasks;

namespace AWSWeighingService.Infrastructure
{
    public class Emailer
    {
        //email 
        string _sendTo;
        string _sendFrom;
        string _sendSubject;
        string _sendEmailBody;
        string[] _attachments;

        //smtp
        string smtpServerName;
        string smtpPortNumber;
        string smtpUserID;
        string smtpPassword;

        string returnMessage;



        public Emailer(string sendTo, string sendFrom, string sendSubject, string sendEmailBody, string[] attachments = null)
        {
            _sendTo = sendTo;
            _sendFrom = sendFrom;
            _sendSubject = sendSubject;
            _sendEmailBody = sendEmailBody;
            _attachments = attachments;

            smtpServerName = ConfigurationManager.AppSettings["SmtpServer"];
            smtpPortNumber = ConfigurationManager.AppSettings["SmtpPort"];
            smtpUserID = ConfigurationManager.AppSettings["SmtpUserID"];
            smtpPassword = ConfigurationManager.AppSettings["SmtpPassword"];
        }

        /// <summary>
        /// Transmit an email message asynchronously with attachments
        /// </summary>
        /// <param name="sendTo">Recipient Email Address</param>
        /// <param name="sendFrom">Sender Email Address</param>
        /// <param name="sendSubject">Subject Line Describing Message</param>
        /// <param name="sendMessage">The Email Message Body</param>
        /// <param name="attachments">A string array pointing to the location of each attachment</param>
        /// <returns>Status Message as String</returns>
        public async Task<String> SendMessageAsync()
        {
            try
            {
                returnMessage = "INVALID recipient email address: " + _sendTo;
                string[] addresses = _sendTo.Split(';');
                // if the email address is bad, return errorMessage
                foreach (string address in addresses)
                {
                    if ((address == "") || !IsValidEmailAddress(address))
                    {
                        if ((address == "") || (address.Trim() == string.Empty)) returnMessage = "BLANK recipient email address.";
                        string RegExpressionPattern = @"Customer:.*";
                        Regex RegExp = new Regex(RegExpressionPattern);
                        Match firstMatch = RegExp.Match(_sendEmailBody);


                        if (firstMatch.Success)
                        {
                            string customerName = firstMatch.ToString().Trim();
                            returnMessage = customerName + " has " + returnMessage + "\r\n\r\n";
                        }

                        return returnMessage;
                    }
                }

                if (!TryValidateSmtpSettings(out returnMessage)) return returnMessage;

                // create the email message

                MailMessage message = new MailMessage();
                message.From = new MailAddress(_sendFrom);
                message.Subject = _sendSubject;
                message.Body = _sendEmailBody;
                foreach (string address in addresses)
                {
                    message.To.Add(new MailAddress(address));
                }

                //MailMessage message = new MailMessage()

                // The attachments array should point to a file location
                // where the attachment resides - add the attachments to the message
                if (_attachments != null)
                {
                    foreach (string attach in _attachments)
                    {
                        Attachment attached = new Attachment(attach, MediaTypeNames.Application.Octet);
                        message.Attachments.Add(attached);
                    }
                }

                //message.To.Clear();

                //foreach (var address in _sendTo.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                //{
                //    message.To.Add(address);
                //}

                NetworkCredential nc = new NetworkCredential(smtpUserID, smtpPassword);


                using (SmtpClient smtpClient = new SmtpClient(smtpServerName, int.Parse(smtpPortNumber)))
                {
                    //smtpClient.UseDefaultCredentials = false;
                    smtpClient.EnableSsl = true;

                    smtpClient.Credentials = nc;


                    ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

                    // send message
                    //smtpClient.Send(message);
                    await smtpClient.SendMailAsync(message);
                    returnMessage = "Email sent to " + _sendTo + " at " + DateTime.Now.ToString() + ".";
                    return returnMessage;
                }


            }
            catch (Exception ex)
            {
                returnMessage = ex.Message + " | " + (ex.InnerException == null ? "" : ex.InnerException.Message);
                // Logger.LogActivity("Sending email failed - " + returnMessage);
                return returnMessage;
            }

        }
        /// <summary>
        /// Transmit an email message to a recipient without
        /// any attachments
        /// </summary>
        /// <param name="sendTo">Recipient Email Address</param>
        /// <param name="sendFrom">Sender Email Address</param>
        /// <param name="sendSubject">Subject Line Describing Message</param>
        /// <param name="sendMessage">The Email Message Body</param>
        /// <returns>Status Message as String</returns>
        public string SendMessage(string sendTo, string sendFrom, string sendSubject, string sendMessage)
        {
            try
            {
                returnMessage = "Invalid recipient email address: " + sendTo;

                // if the email address is bad, return errorMessage
                if (!IsValidEmailAddress(sendTo)) return returnMessage;

                if (!TryValidateSmtpSettings(out returnMessage)) return returnMessage;


                // create the email message
                MailMessage message = new MailMessage(sendFrom,
                                                      sendTo,
                                                      sendSubject,
                                                      sendMessage);

                NetworkCredential nc = new NetworkCredential(smtpUserID, smtpPassword);
                SmtpClient client = new SmtpClient(smtpServerName, int.Parse(smtpPortNumber)) { };
                client.EnableSsl = true;

                client.Credentials = nc;

                ServicePointManager.ServerCertificateValidationCallback =
    delegate (object s, X509Certificate certificate,
             X509Chain chain, SslPolicyErrors sslPolicyErrors)
    { return true; };

                // send message
                client.Send(message);

                returnMessage = "Message sent to " + sendTo + " at " + DateTime.Now.ToString() + ".";
                return returnMessage;
            }
            catch (Exception ex)
            {
                returnMessage = ex.InnerException.Message;
                return returnMessage;
            }
        }

        /// <summary>
        /// Transmit an email message with
        /// attachments
        /// </summary>
        /// <param name="sendTo">Recipient Email Address</param>
        /// <param name="sendFrom">Sender Email Address</param>
        /// <param name="sendSubject">Subject Line Describing Message</param>
        /// <param name="sendMessage">The Email Message Body</param>
        /// <param name="attachments">A string array pointing to the location of each attachment</param>
        /// <returns>Status Message as String</returns>
        public string SendMessageWithAttachment(string sendTo, string sendFrom, string sendSubject, string sendMessage, string[] attachments)
        {
            try
            {
                returnMessage = "Invalid recipient email address: " + sendTo;

                // if the email address is bad, return errorMessage
                if (!IsValidEmailAddress(sendTo)) return returnMessage;

                if (!TryValidateSmtpSettings(out returnMessage)) return returnMessage;

                // create the email message
                MailMessage message = new MailMessage(sendFrom, sendTo, sendSubject, sendMessage);

                // The attachments array should point to a file location
                // where the attachment resides - add the attachments to the message
                foreach (string attach in attachments)
                {
                    Attachment attached = new Attachment(attach, MediaTypeNames.Application.Octet);
                    message.Attachments.Add(attached);
                }

                // create smtp client at mail server location
                //SmtpClient client = new SmtpClient();

                NetworkCredential nc = new NetworkCredential(smtpUserID, smtpPassword);
                SmtpClient client = new SmtpClient(smtpServerName, int.Parse(smtpPortNumber)) { };
                client.EnableSsl = true;

                client.Credentials = nc;

                // Add credentials
                // client.UseDefaultCredentials = true;

                // send message
                ServicePointManager.ServerCertificateValidationCallback =
    delegate (object s, X509Certificate certificate,
             X509Chain chain, SslPolicyErrors sslPolicyErrors)
    { return true; };
                client.Send(message);

                returnMessage = "Message sent to " + sendTo + " at " + DateTime.Now.ToString() + ".";
                return returnMessage;
            }
            catch (Exception ex)
            {
                returnMessage = ex.InnerException.Message;
                return returnMessage;
            }

        }

        private bool IsValidEmailAddress(string emailAddress)
        {
            try
            {
                MailAddress m = new MailAddress(emailAddress);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }

            //old code commentd by Ramesh 29/Jul/2019
            //try
            //{

            //    string TextToValidate = emailAddress;

            //    Regex expression = new Regex(@"\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}");

            //    // test email address with expression
            //    if (expression.IsMatch(TextToValidate))
            //    {
            //        // is valid email address
            //        return true;
            //    }
            //    else
            //    {
            //        // is not valid email address
            //        return false;
            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }

        private bool TryValidateSmtpSettings(out string outMessage)
        {
            outMessage = "Ok";

            if (String.IsNullOrEmpty(smtpServerName))
            {
                outMessage = "Invalid Smtp Server Setting!";
                return false;
            }

            if (String.IsNullOrEmpty(smtpPortNumber))
            {
                outMessage = "Invalid Smtp Port Number Setting!";
                return false;
            }

            if (String.IsNullOrEmpty(smtpUserID))
            {
                outMessage = "Invalid Smtp User ID Setting!";
                return false;
            }

            if (String.IsNullOrEmpty(smtpPassword))
            {
                outMessage = "Invalid Smtp Password Setting!";
                return false;
            }

            return true;
        }
    }
}
