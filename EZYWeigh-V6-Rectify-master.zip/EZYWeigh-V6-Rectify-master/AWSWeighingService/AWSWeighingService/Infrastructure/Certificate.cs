﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Infrastructure
{
  public class Certificate : BindableBase
  {
        private string _InstalledEncrypted;
        public string InstalledEncrypted
        {
            get { return _InstalledEncrypted; }
            set { this.SetProperty(ref _InstalledEncrypted, value); }
        }

        private string _CertificateEncrypted;
        public string CertificateEncrypted
        {
            get { return _CertificateEncrypted; }
            set { this.SetProperty(ref _CertificateEncrypted, value); }
        }

        private string _ActivationKey;
        public string ActivationKey
        {
            get { return _ActivationKey; }
            set { this.SetProperty(ref _ActivationKey, value); }
        }

        private  DateTime _InstallDate;
        public  DateTime InstallDate
        {
            get { return _InstallDate; }
            set { this.SetProperty(ref _InstallDate, value); }
        }
        
        private int _TrialsDaysAllowed;
        public int TrialsDaysAllowed
        {
            get { return _TrialsDaysAllowed; }
            set { this.SetProperty(ref _TrialsDaysAllowed, value); }
        }
      
        private int _MaxNumberOfUsersAllowed;
        public int MaxNumberOfUsersAllowed
        {
            get { return _MaxNumberOfUsersAllowed; }
            set { this.SetProperty(ref _MaxNumberOfUsersAllowed, value); }
        }

        public Certificate(string installedEncrypted, string certificateEncrypted)
        {
            InstalledEncrypted = installedEncrypted;
            CertificateEncrypted = certificateEncrypted;
            InstallDate = DateTime.Today;
            TrialsDaysAllowed = 38;
            MaxNumberOfUsersAllowed = 5;
            DecryptInstalled();
        }

        private void DecryptInstalled()
        {
            try
            {
                int posOfLessThan, posOfGreaterThan;
                string yyyymmdd, trialsDaysAllowed, maxNumberOfUsersAllowed, yyyy, mm, dd;

                ActivationKey = InstalledEncrypted.Decrypt();
                posOfLessThan = ActivationKey.IndexOf("<");
                posOfGreaterThan = ActivationKey.IndexOf(">");

                if ((posOfLessThan == -1) || (posOfGreaterThan == -1))
                {  
                    return;

                }

                yyyymmdd = ActivationKey.Substring(0, posOfLessThan);
                trialsDaysAllowed = ActivationKey.Substring(posOfLessThan + 1, posOfGreaterThan - posOfLessThan - 1);
                maxNumberOfUsersAllowed = ActivationKey.Substring(posOfGreaterThan + 1, ActivationKey.Length - posOfGreaterThan - 1);

                yyyy = yyyymmdd.Substring(0, 4);
                mm = yyyymmdd.Substring(4, 2);
                dd = yyyymmdd.Substring(6, 2);

                TrialsDaysAllowed = int.Parse(trialsDaysAllowed);
                MaxNumberOfUsersAllowed = int.Parse(maxNumberOfUsersAllowed);

                InstallDate = new DateTime(int.Parse(yyyy), int.Parse(mm), int.Parse(dd));


            }
            catch (Exception)
            {
                
                return;

            }


        }

        public string GenerateActivationKey(DateTime installDate, int trialsDaysAllowed, int maxNumberOfUsersAllowed)
        {
            InstallDate = installDate;
            string year = installDate.Year.ToString();
            string month = installDate.Month.ToString();

            if (month.Length == 1)
            {
                month = "0" + month;
            }

            string day = installDate.Day.ToString();
            if (day.Length == 1)
            {
                day = "0" + day;
            }

            ActivationKey = year + month + day + "<" + trialsDaysAllowed.ToString() + ">" + maxNumberOfUsersAllowed.ToString();
            return ActivationKey;
        }

        public void GenerateCertificateKey()
        {
            InstalledEncrypted = ActivationKey.Encrypt();
            CertificateEncrypted = InstalledEncrypted.Encrypt();
        }

        public bool IsCertifiedOk(int actualUserCount, out string certificateStatus)
        {
            certificateStatus = string.Empty; // means ok, show nothing
            if (String.IsNullOrEmpty(InstalledEncrypted))
            {   
                return true;  // not formally deployed to site yet
            }

            if (String.IsNullOrEmpty(CertificateEncrypted)) // deployed to site, but still in trials period
            {
                int daysOfTrial = (int)(DateTime.Today - InstallDate).TotalDays;
                if (TrialsDaysAllowed < daysOfTrial)
                {
                    certificateStatus = "Your trial has expired, you can no longer use our program, please contact " + CoreConstants.WeighMoreSolutions + " to get the Certificate Key.";
                    return false;
                }
                else if (TrialsDaysAllowed - daysOfTrial <= 10)
                {
                    int daysLeft = TrialsDaysAllowed - daysOfTrial;
                    string strDaysLeft = daysLeft.ToString() + " days";
                    if (daysLeft == 1)
                    {
                        strDaysLeft = daysOfTrial.ToString() + " day";
                    }
                    certificateStatus = "Your trial period will end in " + strDaysLeft + ", please contact " + CoreConstants.WeighMoreSolutions + " to get the Certificate Key.";
                    return true;
                }
                return true;
            }

            try
            {
                if (CertificateEncrypted.Decrypt() != InstalledEncrypted)
                {
                    certificateStatus = "Your Certificate Key is invalid, you can no longer use our program, please contact " + CoreConstants.WeighMoreSolutions + " to get the Certificate Key.";
                    return false;
                }
                else if (actualUserCount >= MaxNumberOfUsersAllowed)
                {
                    certificateStatus = "You have exceeded the maximum user numbers, please contact " + CoreConstants.WeighMoreSolutions + " to get the Certificate Key updated.";
                    return false;
                }
                //certificateStatus = CertificateStatus.Certified;
                return true;

            }
            catch (Exception)
            {

                certificateStatus = "Your Certificate Key is invalid, you can no longer use our program, please contact " + CoreConstants.WeighMoreSolutions + " to get the Certificate Key.";
                return false;
            }
        }

    }

}