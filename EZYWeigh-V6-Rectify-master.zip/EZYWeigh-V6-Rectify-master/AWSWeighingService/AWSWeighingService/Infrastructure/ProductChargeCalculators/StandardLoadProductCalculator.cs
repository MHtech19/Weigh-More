﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Infrastructure.ProductChargeCalculators
{
    public class StandardLoadProductCalculator : BaseProductCalculator
    {
        public StandardLoadProductCalculator(Product currentProduct, Transaction currentTransaction, List<VehicleProductPrice> vehicleProductPrices, decimal manualInputCartage = 0, bool isEditing = false) : base(currentProduct, currentTransaction, null, vehicleProductPrices, manualInputCartage, isEditing) { }

        public override void CalculateCharges()
        {
            bool GSTApplies = true;
            decimal netCharge = 0;

            _currentProduct.CurrentPrice = 0;
            _currentProduct.CurrentEPA = 0;
            _currentProduct.CurrentGST = 0;
            _currentProduct.CurrentCartage = 0;
            _currentProduct.CurrentTranCost = 0;
            _currentProduct.CurrentTotalCost = 0;
            _currentProduct.CurrentCartageGST = 0;
            _currentProduct.CurrentCustomerDiscount = 0;

            if (_currentTransaction.ChargeRate == CoreConstants.RATE_LOCAL) //LocalButton.Checked 
            {
                _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : _currentTransaction.Vehicle.InLocalDiscount; //prTranCost = prInLocalCost; _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : _currentProduct.OutVisitStandard;
                GSTApplies = _currentTransaction.Vehicle.InLocalDiscountGST;
                //psMinGstApplies = psMinLocalGST;
            }
            else
            {
                _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : _currentTransaction.Vehicle.InVisitStandard;
                GSTApplies = _currentTransaction.Vehicle.InVisitStandardGST;
                //psMinGstApplies = psMinVisitGST;
            }

            var vehicleProductPrice = _vehicleProductPrices != null ? _vehicleProductPrices.FirstOrDefault(vpp => vpp.VehicleID == _currentTransaction.Vehicle.ID && vpp.ProductID == _currentProduct.ID) : null;
            if (vehicleProductPrice != null)
            {
                if (_currentTransaction.ChargeRate == CoreConstants.RATE_LOCAL) //LocalButton.Checked 
                {
                    if (vehicleProductPrice.InLocalDiscount > 0)
                    {
                        _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : (vehicleProductPrice.InLocalDiscount);
                        //GSTApplies = vehicleProductPrice.InLocalDiscountGST;

                    }
                }
                else
                {
                    if (vehicleProductPrice.InVisitStandard > 0)
                    {
                        _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : vehicleProductPrice.InVisitStandard;
                        //GSTApplies = vehicleProductPrice.InVisitStandardGST;
                    }
                }
            }

            _currentProduct.CurrentPrice = decimal.Round(_currentProduct.CurrentPrice, 2);
            netCharge = _currentProduct.CurrentPrice;

            decimal epaCharge = ((_isEditing) ? _currentTransaction.EPARate : _currentProduct.EPALevy) * _currentTransaction.Vehicle.NetWeight;
            _currentProduct.CurrentEPA = (epaCharge > _currentProduct.MinEPALevy) ? epaCharge : _currentProduct.MinEPALevy;
            _currentProduct.CurrentEPA = decimal.Round(_currentProduct.CurrentEPA, 2);
            _currentProduct.CurrentTotalCost = netCharge + _currentProduct.CurrentEPA;

            decimal gstExclusive = 0;
            if (GSTApplies)
            {
                //gstExclusive = decimal.Round(_currentProduct.CurrentTotalCost / CoreConstants.GST_Rate, 2);
                //_currentProduct.CurrentGST = _currentProduct.CurrentTotalCost - gstExclusive;

                if (_currentTransaction.Site.IsVehicleTypePricesIncludingGST)
                {
                    gstExclusive = decimal.Round(_currentProduct.CurrentTotalCost / CoreConstants.GST_Rate, 2);
                    _currentProduct.CurrentGST = _currentProduct.CurrentTotalCost - gstExclusive;
                }
                else
                {                  
                    gstExclusive = decimal.Round(_currentProduct.CurrentTotalCost / CoreConstants.GST_Percentage, 2);
                    _currentProduct.CurrentGST = gstExclusive;
                    _currentProduct.CurrentTotalCost = _currentProduct.CurrentTotalCost + gstExclusive;
                }
            }

            _currentProduct.CurrentTranCost = _currentProduct.CurrentTotalCost - _currentProduct.CurrentGST - _currentProduct.CurrentEPA;

            if (_currentTransaction.Haulage > 0)
            {
                decimal haulageGSTExclusive = decimal.Round(_currentTransaction.Haulage / CoreConstants.GST_Rate, 2);
                decimal haulageGST = _currentTransaction.Haulage - haulageGSTExclusive;

                _currentProduct.CurrentTranCost = _currentProduct.CurrentTranCost + haulageGSTExclusive;
                _currentProduct.CurrentGST = _currentProduct.CurrentGST + haulageGST;
                _currentProduct.CurrentTotalCost = _currentProduct.CurrentTotalCost + _currentTransaction.Haulage;
            }

            if (_currentProduct.Royalty > 0)
            {
                _currentProduct.CurrentRoyalty = Math.Abs(_currentTransaction.Vehicle.NetWeight * _currentProduct.Royalty);
            }
            else
            {
                _currentProduct.CurrentRoyalty = 0;
            }

            if (_currentProduct.ToVolumeFactor > 0)
            {
                _currentProduct.CurrentCount = Math.Abs(_currentTransaction.Vehicle.NetWeight * _currentProduct.ToVolumeFactor);
            }
            else
            {
                _currentProduct.CurrentCount = 0;
            }
        }
    }
}