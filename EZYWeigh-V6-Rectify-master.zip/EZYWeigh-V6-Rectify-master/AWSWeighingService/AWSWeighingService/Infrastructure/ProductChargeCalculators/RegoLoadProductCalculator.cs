﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Infrastructure.ProductChargeCalculators
{
    public class RegoLoadProductCalculator : BaseProductCalculator
    {
        public RegoLoadProductCalculator(Product currentProduct,Transaction currentTransaction) : base(currentProduct, currentTransaction, null, null) { }

        public override void CalculateCharges()
        {
            bool GSTApplies = true;
            decimal netCharge = 0;

            _currentProduct.CurrentPrice = 0;
            _currentProduct.CurrentEPA = 0;
            _currentProduct.CurrentGST = 0;
            _currentProduct.CurrentCartage = 0;
            _currentProduct.CurrentTranCost = 0;
            _currentProduct.CurrentTotalCost = 0;
            _currentProduct.CurrentCartageGST = 0;
            _currentProduct.CurrentCustomerDiscount = 0;

            if (_currentTransaction.Direction == CoreConstants.DIRECTION_OUT)
            {
                if (_currentTransaction.ChargeRate == CoreConstants.RATE_LOCAL)
                {
                    GSTApplies = _currentProduct.OutLocalDiscountGST && !_currentTransaction.Customer.NoGST;
                    _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : _currentProduct.OutLocalDiscount;
                    //_currentProduct.CurrentMinimumCharge = (_isEditing) ? _currentTransaction.Price : _currentProduct.MinLocalDiscount;
                    _currentProduct.CurrentMinimumCharge = _currentProduct.MinLocalDiscount;
                }
                else if (_currentTransaction.ChargeRate == CoreConstants.RATE_VISITOR)
                {
                    GSTApplies = _currentProduct.OutVisitStandardGST && !_currentTransaction.Customer.NoGST;
                    _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : _currentProduct.OutVisitStandard;
                    //_currentProduct.CurrentMinimumCharge = (_isEditing) ? _currentTransaction.Price : _currentProduct.MinVisitStandard;
                    _currentProduct.CurrentMinimumCharge = _currentProduct.MinVisitStandard;
                }
            }
            else
            {
                if (_currentTransaction.ChargeRate == CoreConstants.RATE_LOCAL)
                {
                    GSTApplies = _currentProduct.InLocalDiscountGST && !_currentTransaction.Customer.NoGST;
                    _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : _currentProduct.InLocalDiscount;
                    //_currentProduct.CurrentMinimumCharge = (_isEditing) ? _currentTransaction.Price : _currentProduct.MinLocalDiscount;
                    _currentProduct.CurrentMinimumCharge = _currentProduct.MinLocalDiscount;
                }
                else if (_currentTransaction.ChargeRate == CoreConstants.RATE_VISITOR)
                {
                    GSTApplies = _currentProduct.InVisitStandardGST && !_currentTransaction.Customer.NoGST;
                    _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : _currentProduct.InVisitStandard;
                    //_currentProduct.CurrentMinimumCharge = (_isEditing) ? _currentTransaction.Price : _currentProduct.MinVisitStandard;
                    _currentProduct.CurrentMinimumCharge = _currentProduct.MinVisitStandard;
                }
            }


            //calculate price
            //if (_currentTransaction.Job.ID != CoreConstants.NA_ID)
            //{
            //    if (_isEditing)
            //    {
            //        _currentProduct.CurrentPrice = _currentTransaction.Price;
            //        _currentProduct.CurrentCartage = _currentTransaction.CartageCharge;
            //        _currentProduct.CurrentCartageCost = _currentTransaction.CartageCost;
            //    }
            //    else
            //    {
            //        var jobProduct = _jobProductPrices.FirstOrDefault(jpp => jpp.JobID == _currentTransaction.Job.ID && jpp.ProductID == _currentProduct.ID);
            //        _currentProduct.CurrentPrice = (jobProduct != null) ? jobProduct.Price : _currentProduct.CurrentPrice;
            //        _currentProduct.CurrentCartage = ((_currentTransaction.Net * _currentTransaction.Job.CartagePerTonne) > _currentTransaction.Job.MinimumCartage) ? (_currentTransaction.Net * _currentTransaction.Job.CartagePerTonne) : _currentTransaction.Job.MinimumCartage;
            //        _currentProduct.CurrentCartage = decimal.Round(_currentProduct.CurrentCartage, 2);
            //        _currentProduct.CurrentCartageCost = decimal.Round(_currentProduct.CurrentCartageCost * _currentProduct.CurrentAmount, 2);
            //    }

            //    //  GSTApplies = !_currentTransaction.Customer.NoGST;

            //}



            //if ((_currentTransaction.Customer.FixedCharge > 0)) //&& (_currentTransaction.Job.ID != CoreConstants.NA_ID)
            //{

            //    _currentProduct.CurrentPrice = (_isEditing) ? _currentTransaction.Price : decimal.Round(_currentTransaction.Customer.FixedCharge, 2);
            //    _currentProduct.CurrentMinimumCharge = (_isEditing) ? _currentTransaction.Price : _currentProduct.CurrentPrice;
            //    netCharge = _currentProduct.CurrentPrice;
            //    _currentProduct.CurrentCartage = 0;
            //}
            //else
            //{
            //    if (_isEditing)
            //    {
            //        _currentProduct.CurrentEPA = (_currentTransaction.EPARate);
            //        _currentProduct.CurrentEPA = decimal.Round(_currentProduct.CurrentEPA, 2);
            //    }
            //    else
            //    {
            //        _currentProduct.CurrentEPA = ((_currentProduct.CurrentAmount * _currentProduct.EPALevy) > _currentProduct.MinEPALevy) ? (_currentProduct.CurrentAmount * _currentProduct.EPALevy) : _currentProduct.MinEPALevy;
            //        _currentProduct.CurrentEPA = decimal.Round(_currentProduct.CurrentEPA, 2);
            //    }


            //    netCharge = (_currentProduct.CurrentPrice * _currentProduct.CurrentAmount > _currentProduct.CurrentMinimumCharge) ? _currentProduct.CurrentPrice * _currentProduct.CurrentAmount : _currentProduct.CurrentMinimumCharge;
            //}

            //if (_manualInputCartage > 0)
            //{
            //    _currentProduct.CurrentCartage = _manualInputCartage;
            //}
            //else if ((_currentTransaction.Customer.FixedCartage > 0) && (_currentProduct.CurrentCartage == 0))
            //{
            //    _currentProduct.CurrentCartage = _currentTransaction.Customer.FixedCartage;
            //}



            //_currentProduct.CurrentTotalCost = netCharge + _currentProduct.CurrentEPA + _currentProduct.CurrentCartage;
            //_currentProduct.CurrentTotalCost = decimal.Round(_currentProduct.CurrentTotalCost, 2);
            netCharge = _currentProduct.CurrentPrice;
            _currentProduct.CurrentTotalCost = netCharge;
            _currentProduct.CurrentTotalCost = decimal.Round(_currentProduct.CurrentTotalCost, 2);

            decimal gstExclusive = 0;
            if (GSTApplies)
            {
                if (_currentTransaction.Site.IsProductPricesIncludingGST)
                {
                    gstExclusive = decimal.Round(_currentProduct.CurrentTotalCost / CoreConstants.GST_Rate, 2);
                    _currentProduct.CurrentGST = _currentProduct.CurrentTotalCost - gstExclusive;
                }
                else
                {
                    gstExclusive = decimal.Round(_currentProduct.CurrentTotalCost / CoreConstants.GST_Percentage, 2);
                    _currentProduct.CurrentGST = gstExclusive;
                    _currentProduct.CurrentTotalCost = _currentProduct.CurrentTotalCost + gstExclusive;
                }

                //gstExclusive = decimal.Round(_currentProduct.CurrentTotalCost / CoreConstants.GST_Rate, 2);
                //_currentProduct.CurrentGST = _currentProduct.CurrentTotalCost - gstExclusive;
            }
            //else
            //{
            //    gstExclusive = decimal.Round(_currentProduct.CurrentCartage / CoreConstants.GST_Rate, 2); //always charge _currentTransaction.GST on cartage
            //    _currentProduct.CurrentGST = _currentProduct.CurrentCartage - gstExclusive;
            //}

            _currentProduct.CurrentTranCost = _currentProduct.CurrentTotalCost - _currentProduct.CurrentGST;
            //_currentProduct.CurrentTranCost = _currentProduct.CurrentTotalCost - _currentProduct.CurrentGST - _currentProduct.CurrentEPA - _currentProduct.CurrentCartage;

            if (_currentTransaction.Haulage > 0)
            {
                decimal haulageGSTExclusive = decimal.Round(_currentTransaction.Haulage / CoreConstants.GST_Rate, 2);
                decimal haulageGST = _currentTransaction.Haulage - haulageGSTExclusive;

                _currentProduct.CurrentTranCost = _currentProduct.CurrentTranCost + haulageGSTExclusive;
                _currentProduct.CurrentGST = _currentProduct.CurrentGST + haulageGST;
                _currentProduct.CurrentTotalCost = _currentProduct.CurrentTotalCost + _currentTransaction.Haulage;
            }

            if (_currentProduct.Royalty > 0)
            {
                _currentProduct.CurrentRoyalty = Math.Abs(_currentProduct.CurrentAmount * _currentProduct.Royalty);
            }
            else
            {
                _currentProduct.CurrentRoyalty = 0;
            }

            if (_currentProduct.ToVolumeFactor > 0)
            {
                _currentProduct.CurrentCount = Math.Abs(_currentProduct.CurrentAmount * _currentProduct.ToVolumeFactor);
            }
            else
            {
                _currentProduct.CurrentCount = 0;
            }

        }
    }
}