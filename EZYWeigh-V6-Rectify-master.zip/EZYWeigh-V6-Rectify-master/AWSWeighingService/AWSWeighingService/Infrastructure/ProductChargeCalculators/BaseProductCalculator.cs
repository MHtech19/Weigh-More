﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure.ProductChargeCalculators
{
    public abstract class BaseProductCalculator
    {
        protected Product _currentProduct;
        protected Transaction _currentTransaction { get; set; }
        protected List<JobProductPrice> _jobProductPrices {get; set;}
        protected List<VehicleProductPrice> _vehicleProductPrices { get; set; }
        protected decimal _manualInputCartage { get; set; }
        protected bool _isEditing { get; set; }

        public BaseProductCalculator(Product currentProduct, Transaction currentTransaction, List<JobProductPrice> jobProductPrices = null, List<VehicleProductPrice> vehicleProductPrices = null, decimal manualInputCartage = 0, bool isEditing = false)
        {
            _currentProduct = currentProduct;
            _currentTransaction = currentTransaction;
            _jobProductPrices = jobProductPrices;
            _vehicleProductPrices = vehicleProductPrices;
            _manualInputCartage = manualInputCartage;
            _isEditing = isEditing;
        }

        public abstract void CalculateCharges();
    }

    

}