﻿using AWSWeighingService.Abstract;
using AWSWeighingService.DAL;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Net.NetworkInformation;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using Microsoft.Reporting.WebForms;
using System.Drawing.Printing;
using System.Drawing.Imaging;
using System.Drawing;

namespace AWSWeighingService.Infrastructure
{
    public static class Extentions
    {
        public static string DateToStringYYYYMMDD(this DateTime aDate)
        {
            string month = aDate.Month.ToString();
            string day = aDate.Day.ToString();

            if (month.Length == 1) month = "0" + month;
            if (day.Length == 1) day = "0" + day;

            return aDate.Year.ToString() + month + day;
        }

        public static string DateToStringYYYYMMDDHHMM(this DateTime aDate)
        {
            string month = aDate.Month.ToString();
            string day = aDate.Day.ToString();
            string hour = aDate.Hour.ToString();
            string minute = aDate.Minute.ToString();

            if (month.Length == 1) month = "0" + month;
            if (day.Length == 1) day = "0" + day;
            if (hour.Length == 1) hour = "0" + hour;
            if (minute.Length == 1) minute = "0" + minute;


            return aDate.Year.ToString() + month + day + hour + minute;
        }

        public static bool PingHost(string nameOrAddress)
        {
            bool pingable = false;
            Ping pinger = null;

            try
            {
                pinger = new Ping();
                PingReply reply = pinger.Send(nameOrAddress);
                pingable = reply.Status == IPStatus.Success;
            }
            catch (PingException)
            {
                // Discard PingExceptions and return false;
            }
            finally
            {
                if (pinger != null)
                {
                    pinger.Dispose();
                }
            }

            return pingable;
        }

        public static ProductStockMovement GenerateProductStockMovement(this Transaction tran, decimal currentStockLevel)
        {
            string direction, comment;
            decimal in_Take, out_Take, stockLevelIncrement;

            direction = tran.Direction;

            if (direction == CoreConstants.DIRECTION_IN)
            {   
                comment = "Transaction Add Goods In";
                in_Take = tran.Net;
                out_Take = 0;
                stockLevelIncrement = tran.Net;
            }
            else
            {
                comment = "Transaction Subtract Goods Out";
                in_Take = 0;
                out_Take = tran.Net;
                stockLevelIncrement = tran.Net * -1;
            }

            ProductStockMovement stockMove = new ProductStockMovement
            {
                MovementDate = DateTime.Now,
                Docket = tran.Docket,
                Direction = direction,
                MANUAL_INPUT = false,
                IN_TAKE = in_Take, //newly added amount
                OUT_TAKE = out_Take,
                STOCKLEVEL = currentStockLevel + stockLevelIncrement,
                Comment = comment,
                ProductID = tran.ProductID,
                SiteID = tran.SiteID,
                WeighmanID = tran.WeighmanID,
            };

            return stockMove;
        }

        public static ProductStockMovement GenerateOffsetProductStockMovement(this Transaction tran, decimal currentStockLevel)
        {
            string direction, comment;
            decimal in_Take, out_Take, stockLevelIncrement;

            direction = tran.Direction;

            if (direction == CoreConstants.DIRECTION_IN)
            {
                comment = "Offset original Goods In(editing transaction)";
                in_Take = 0;
                out_Take = tran.Net;
                stockLevelIncrement = tran.Net * -1;
                
            }
            else
            {
                comment = "Offset original Goods Out(editing transaction)";
                in_Take = tran.Net;
                out_Take = 0;
                stockLevelIncrement = tran.Net;
                
            }

            ProductStockMovement stockMove = new ProductStockMovement
            {
                MovementDate = DateTime.Now,
                Docket = tran.Docket,
                Direction = direction,
                MANUAL_INPUT = false,
                IN_TAKE = in_Take, //newly added amount
                OUT_TAKE = out_Take,
                STOCKLEVEL = currentStockLevel + stockLevelIncrement,
                Comment = comment,
                ProductID = tran.ProductID,
                SiteID = tran.SiteID,
                WeighmanID = tran.WeighmanID,
            };

            return stockMove;

        }

        public static ProductStockMovement GenerateProductStockMovement(this ProductStockActivation stockActivation, decimal currentStockLevel)
        {    
            string direction, comment;
            decimal in_Take, out_Take;

            if (stockActivation.STOCKLEVEL > 0)
            {
                direction = CoreConstants.DIRECTION_IN;
                comment = "Manual Input Add";
                in_Take = stockActivation.STOCKLEVEL;
                out_Take = 0;
            }
            else
            {
                direction = CoreConstants.DIRECTION_OUT;
                comment = "Manual Input Subtract";
                in_Take = 0;
                out_Take = Math.Abs(stockActivation.STOCKLEVEL);
            }

            ProductStockMovement stockMove = new ProductStockMovement
            {
                MovementDate = DateTime.Now,
                Docket = CoreConstants.NA,
                Direction = direction,
                MANUAL_INPUT = true,
                IN_TAKE = in_Take, //newly added amount
                OUT_TAKE = out_Take,
                STOCKLEVEL = currentStockLevel + stockActivation.STOCKLEVEL,
                Comment = comment,
                ProductID = stockActivation.ProductID,
                SiteID = stockActivation.SiteID,
                WeighmanID = stockActivation.WeighmanID,
            };

            return stockMove;

        }

        public static void AddRange<T>(this ObservableCollection<T> observableCollection, IEnumerable<T> collection, bool clearFirst) 
        {
            if (collection == null) throw new ArgumentNullException("collection");

            if (clearFirst) observableCollection.Clear();
            //observableCollection.Clear();

            foreach (T i in collection)
            {
                observableCollection.Add(i);
            }

        }

        public static void AddRange(this ObservableCollection<Product> observableCollection, IEnumerable<Product> collection) 
        {
            if (collection == null) throw new ArgumentNullException("collection");

            observableCollection.Clear();

            foreach (var i in collection)
            {
                observableCollection.Add(i);
            }
        }

        public static void AddRange(this ObservableCollection<string> observableCollection, List<string> collection)
        {
            if (collection == null) throw new ArgumentNullException("collection");

            observableCollection.Clear();

            foreach (var i in collection)
            {
                observableCollection.Add(i);
            }
        }

        public static void AddRange(this ObservableCollection<Customer> observableCollection, IEnumerable<Customer> collection)
        {
            if (collection == null) throw new ArgumentNullException("collection");

            observableCollection.Clear();

            foreach (var i in collection)
            {
                observableCollection.Add(i);
            }
        }

        public static int NextID<TEntity>(this IList<TEntity> entityList) where TEntity : class, IEntityID
        {
            int nextID = -1;

            var orderedListLastItem = entityList.OrderByDescending(e => e.ID).FirstOrDefault();
            if (orderedListLastItem != null)
            {
                nextID = orderedListLastItem.ID + 1;

            }

            return nextID;
        }

        public static List<SelectListItem> ConvertToSelectListItemListFor<TEntity>(this IEnumerable<TEntity> entityCollection, int selectedEntityID) where TEntity : class, IEntityID, IEntityName
        {
            List<SelectListItem> listSelectListItems = new List<SelectListItem>();

            foreach (var entity in entityCollection)
            {
                SelectListItem selectList = new SelectListItem()
                {
                    Text = entity.Name,
                    Value = entity.ID.ToString(),

                };

                if (selectedEntityID == CoreConstants.ListItemsAllSelected)
                {
                    selectList.Selected = true;
                }
                else if (selectedEntityID == CoreConstants.ListItemsNoneSelected)
                {
                    selectList.Selected = false;
                }
                else
                {
                    selectList.Selected = (entity.ID == selectedEntityID) ? true : false;
                }

                listSelectListItems.Add(selectList);

            }

            return listSelectListItems;

        }

        public static string ToWebApiURLString(this string serverIP, bool useSSL)
        {
            //example url = "http://localhost:21306/api/";
            string apiURL;
            //string apiURL = "https://" + serverIP + "/api/";
            if (useSSL)
            {
                apiURL = "https://" + serverIP + "/api/";
            }
            else
            {
                apiURL = "http://" + serverIP + "/api/";
            }
            return apiURL;
        }

        public static string ToHttpURLRootPartString(this string serverIP, bool useSSL)
        {
            //example url = "http://localhost/";
            string apiURL;
            if (useSSL)
            {
                apiURL = "https://" + serverIP + "/";
            }
            else
            {
                apiURL = "http://" + serverIP + "/";
            }
            return apiURL;
        }

        public static string DateRangeToQueryString(this DateRange dateRange)
        {
            var nvc = new NameValueCollection();

            nvc["startDate"] = dateRange.StartingDate.ToShortDateString();
            nvc["endDate"] = dateRange.EndingDate.ToShortDateString();
            nvc["siteID"] = dateRange.SiteID.ToString();

            return nvc.ToQueryString();
        }

        public static string ToQueryString(this NameValueCollection nvc)
        {
            StringBuilder sb = new StringBuilder("?");

            bool first = true;

            foreach (string key in nvc.AllKeys)
            {
                foreach (string value in nvc.GetValues(key))
                {
                    if (!first)
                    {
                        sb.Append("&");
                    }

                    sb.AppendFormat("{0}={1}", Uri.EscapeDataString(key), Uri.EscapeDataString(value));

                    first = false;
                }
            }

            return sb.ToString();
        }

        public static Site GetSiteFromSession(this Controller controller, AWSWeighingServiceContext db)
        {
            Site logOnSite = null;
            var sessionCurrentSiteID = controller.Session["CurrentSiteID"];

            if (sessionCurrentSiteID == null)
            {

                return logOnSite;
            }
            else
            {
                int logOnSiteIDFromSession = (int)sessionCurrentSiteID;
                //logOnSite = db.Sites.Find(logOnSiteIDFromSession);
                logOnSite = db.Sites.Where(s => s.ID == logOnSiteIDFromSession).Include(s => s.Customers).FirstOrDefault();
                return logOnSite;
            }
        }

        public static string ComposeTempDisplayMessage(this Controller controller, string message, Site logOnSite=null)
        {
            string displayMessage = message;

            if (logOnSite != null)
            {
                if (logOnSite.ID != Constants.NAEntityID) //
                {
                    if (!SingletonWebConfigAppSetttings.Instance.UseSiteCodeAsPrefix)
                    {
                        displayMessage = message + Environment.NewLine + "Note: the site name prefix " + logOnSite.Name + ". is for avoiding name confilct!";
                    }
                    else
                    {
                        displayMessage = message + Environment.NewLine + "Note: the site code prefix " + logOnSite.Code + ". is for avoiding name confilct!";
                    }

                }
            }

            return displayMessage;

        }

        public static bool IsInteger(this string strInt)
        {
            int output;
            return int.TryParse(strInt, out output);
        }

        public static int IncreateSiteDocketNumber(this Site site, AWSWeighingServiceContext db)
        {
            int currentSiteDocket = site.CurrentDocket;
            currentSiteDocket++;
            site.CurrentDocket = currentSiteDocket;

            db.Entry(site).State = EntityState.Modified;
            db.SaveChanges();

            return currentSiteDocket;
        }

        public static Boolean IsEmpty<T>(this IEnumerable<T> source)
        {
            if (source == null)
                return true; // or throw an exception
            return !source.Any();
        }

        public static DateTime SetTime(this DateTime dateTime, int hours, int minutes, int seconds, int milliseconds)
        {
            return new DateTime(
                dateTime.Year,
                dateTime.Month,
                dateTime.Day,
                hours,
                minutes,
                seconds,
                milliseconds,
                dateTime.Kind);
        }

        public static string Encrypt(this string clearText)
        {
            string EncryptionKey = CoreConstants.MiDianMa;
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        public static string Decrypt(this string cipherText)
        {
            string EncryptionKey = CoreConstants.MiDianMa;
            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

        public static void Print(this LocalReport report)
        {
            var pageSettings = new PageSettings();
            pageSettings.PaperSize = report.GetDefaultPageSettings().PaperSize;
            pageSettings.Landscape = report.GetDefaultPageSettings().IsLandscape;
            pageSettings.Margins = report.GetDefaultPageSettings().Margins;
            Print(report, pageSettings);
        }

        public static void Print(this LocalReport report, PageSettings pageSettings)
        {
           string deviceInfo =
                $@"<DeviceInfo>
                <OutputFormat>EMF</OutputFormat>
                <PageWidth>{pageSettings.PaperSize.Width * 100}in</PageWidth>
                <PageHeight>{pageSettings.PaperSize.Height * 100}in</PageHeight>
                <MarginTop>{pageSettings.Margins.Top * 100}in</MarginTop>
                <MarginLeft>{pageSettings.Margins.Left * 100}in</MarginLeft>
                <MarginRight>{pageSettings.Margins.Right * 100}in</MarginRight>
                <MarginBottom>{pageSettings.Margins.Bottom * 100}in</MarginBottom>
            </DeviceInfo>";
            
            Warning[] warnings;
            var streams = new List<Stream>();
            var currentPageIndex = 0;

            report.Render("Image", deviceInfo,
                (name, fileNameExtension, encoding, mimeType, willSeek) =>
                {
                    var stream = new MemoryStream();
                    streams.Add(stream);
                    return stream;
                }, out warnings);

            foreach (Stream stream in streams)
                stream.Position = 0;

            if (streams == null || streams.Count == 0)
                throw new Exception("Error: no stream to print.");

            var printDocument = new PrintDocument();
            printDocument.DefaultPageSettings = pageSettings;
            if (!printDocument.PrinterSettings.IsValid)
                throw new Exception("Error: cannot find the default printer.");
            else
            {
                printDocument.PrintPage += (sender, e) =>
                {
                    Metafile pageImage = new Metafile(streams[currentPageIndex]);
                    Rectangle adjustedRect = new Rectangle(
                        e.PageBounds.Left - (int)e.PageSettings.HardMarginX,
                        e.PageBounds.Top - (int)e.PageSettings.HardMarginY,
                        e.PageBounds.Width,
                        e.PageBounds.Height);
                    e.Graphics.FillRectangle(Brushes.White, adjustedRect);
                    e.Graphics.DrawImage(pageImage, adjustedRect);
                    currentPageIndex++;
                    e.HasMorePages = (currentPageIndex < streams.Count);
                    e.Graphics.DrawRectangle(Pens.Red, adjustedRect);
                };
                printDocument.EndPrint += (Sender, e) =>
                {
                    if (streams != null)
                    {
                        foreach (Stream stream in streams)
                            stream.Close();
                        streams = null;
                    }
                };

                printDocument.Print();                
            }
        }
    }
}