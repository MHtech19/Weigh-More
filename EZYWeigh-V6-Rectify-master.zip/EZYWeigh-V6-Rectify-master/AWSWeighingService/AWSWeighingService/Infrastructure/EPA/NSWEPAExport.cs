﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace AWSWeighingService.Infrastructure.EPA
{
    public class NSWEPAExport
    {
        public static string ExportHead = "Transaction Number,Facility EPL Number,Date In,Time In,Date Out,Time Out,Vehicle Registration,Vehicle Type,Customer Name,Customer Address,Customer ABN,Purpos Of Entry,Direction,Gross,Tare,Net,Stored Tare,Stored Tare Date Of Effect,Product Description,MCC,Waste Stream,Municipal Sub Stream,Destination,Destination Purpose,Source,OWP EPL Number,Counted Item,Manual Entry,Manual Entry Date/Time,Approval Number,Levy Status,Reportable,Levy Amount,EPA Levy Rate,Transaction Completed,Docket Number,Comment";
        public string TransactionNumber { get; set; }
        public string FacilityEPLNumber { get; set; }
        public string DateIn { get; set; } 
        public string TimeIn { get; set; }
        public string DateOut { get; set; }
        public string TimeOut { get; set; }
        public string VehicleRegistration { get; set; }
        public string VehicleType { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerABN { get; set; }
        public string PurposeOfEntry { get; set; }
        public string Direction { get; set; }
        public string Gross { get; set; }
        public string Tare { get; set; }
        public string Net { get; set; }
        public string StoredTare { get; set; }
        public string StoredTareDateOfEffect { get; set; }
        public string ProductDescription { get; set; }
        public string MCC { get; set; }
        public string WasteStream { get; set; }
        public string MunicipalSubStream { get; set; }
        public string Destination { get; set; }
        public string DestinationPurpose { get; set; }
        public string Source { get; set; }
        public string OWP_EPL_Number { get; set; }
        public string CountedItem { get; set; }
        public string ManualEntry { get; set; }
        public string ManualEntryDateTime { get; set; }
        public string ApprovalNumber { get; set; }
        public string LevyStatus { get; set; }
        public string Reportable { get; set; }
        public string LevyAmount { get; set; }
        public string EPALevyRate { get; set; }
        public string TransactionCompleted { get; set; }
        public string DocketNumber { get; set; }
        public string Comment { get; set; }

        public override string ToString()
        {
            StringBuilder strBuild = new StringBuilder();

            strBuild = strBuild.Append(TransactionNumber);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(FacilityEPLNumber);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(DateIn);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(TimeIn);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(DateOut);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(TimeOut);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(VehicleRegistration);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(VehicleType);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(CustomerName);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(CustomerAddress);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(CustomerABN);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(PurposeOfEntry);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(Direction);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(Gross);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(Tare);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(Net);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(StoredTare);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(StoredTareDateOfEffect);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(ProductDescription);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(MCC);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(WasteStream);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(MunicipalSubStream);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(Destination);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(DestinationPurpose);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(Source);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(OWP_EPL_Number);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(CountedItem);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(ManualEntry);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(ManualEntryDateTime);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(ApprovalNumber);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(LevyStatus);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(Reportable);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(LevyAmount);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(EPALevyRate);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(TransactionCompleted);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(DocketNumber);
            strBuild = strBuild.Append(",");

            strBuild = strBuild.Append(Comment);
           // strBuild = strBuild.Append(Environment.NewLine);
            
            return strBuild.ToString();
        }
    }
}