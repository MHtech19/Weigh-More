﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure.PriceCalculator
{
    public class MixedLoadCalculator:BaseCalculator
    {
        public MixedLoadCalculator(Transaction currentTran) : base(currentTran) { }

        public override void Calculate(List<JobProductPrice> jobProductPrices)
        {
            currentTransaction.Price = 0;
            currentTransaction.TranCost = 0;
            currentTransaction.EPA = 0;
            currentTransaction.GST = 0;
            currentTransaction.TotalCost = 0;
            currentTransaction.CartageCharge = 0;
            currentTransaction.CartageCost = 0;
            currentTransaction.MinimumCharge = 0;


        }
    }
}