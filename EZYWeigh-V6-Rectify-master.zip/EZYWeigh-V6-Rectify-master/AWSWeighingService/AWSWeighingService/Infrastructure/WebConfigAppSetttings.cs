﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure
{
     public class WebConfigAppSetttings
    {
        public WebConfigAppSetttings()
        {
            this.UseSiteCodeAsPrefix = (System.Configuration.ConfigurationManager.AppSettings["UseSiteCodeAsPrefix"] == "true");
            this.ReportLink = System.Configuration.ConfigurationManager.AppSettings["ReportLink"];
            this.ImportFromFiles = (System.Configuration.ConfigurationManager.AppSettings["ImportFromFiles"] == "true");

            int pageSize;
            if (int.TryParse(System.Configuration.ConfigurationManager.AppSettings["PageSize"], out pageSize))
            {
                this.PageSize = pageSize;
            }
            else
            {
                this.PageSize = 9;
            }
            
        }

        public bool UseSiteCodeAsPrefix { get; private set; }
        public int PageSize { get; private set; }
        public string ReportLink { get; private set; }
        public bool ImportFromFiles { get; set; }
        
    }

     public sealed class SingletonWebConfigAppSetttings
     {
         private static readonly WebConfigAppSetttings instance = new WebConfigAppSetttings();

         static SingletonWebConfigAppSetttings() { }

         private SingletonWebConfigAppSetttings() { }

         public static WebConfigAppSetttings Instance
         {
             get
             {
                 return instance;
             }
         }
     }  
}