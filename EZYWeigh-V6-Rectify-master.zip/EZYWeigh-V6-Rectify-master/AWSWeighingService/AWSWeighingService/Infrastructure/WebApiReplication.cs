﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;

using AWSWeighingService.Infrastructure;
using AWSWeighingService.Logging;

namespace AWSWeighingService.Models
{
    public class WebApiReplication : IReplication
    {  
        private List<ReplicationLogItem> originalLogCopy = new List<ReplicationLogItem> { };

        public List<ReplicationLogItem> ReplLog {get; set;}

        //public List<ReplicationLogItem> markReplFailedLog { get; set; }

        public ReplStateMachine State_Repl {get; set;}
        public ReplEntityType EntityType_Repl {get; set;}
        public OperationType OperationType_Repl { get; set; } 

        public ReplicationLogItem LogItem_Repl { get; set; }
        public string ReplTargetURL { get; set; }

        public Transaction Transaction_Repl { get; set; }
        public AxleGroup AxleGroup_Repl { get; set; }
        public Customer Customer_Repl { get; set; }
        public Job Job_Repl { get; set; }
        public Site Site_Repl { get; set; }
        public Truck Truck_Repl { get; set; }
        public VehicleConfiguration VehicleConfigurationType_Repl { get; set; }
        
        public Weighman Operator_Repl { get; set; }
       

        public bool AsyncDeleteOK { get; set; }
        public bool NoNetworking { get; set; }

        public bool GettingReplLogItemFinished { get; set; }

        
        public bool EntityReplicationFinishedOK { get; set; }


        public WebApiReplication()
        {
            ReplLog = new List<ReplicationLogItem> { };
            State_Repl = ReplStateMachine.GetReplItem;
            //EntityType_Repl = Concrete.ReplEntityType.Transaction;

        }

        public void Reset()
        {
            NoNetworking = false;
            AsyncDeleteOK = false;
            GettingReplLogItemFinished = false;

            EntityReplicationFinishedOK = false;


            EntityType_Repl = ReplEntityType.None;
            ReplTargetURL = null;
            Transaction_Repl = null;
            AxleGroup_Repl = null;
            Customer_Repl = null;
            Job_Repl = null;
            Site_Repl = null;
            Truck_Repl = null;
            VehicleConfigurationType_Repl = null;
            


            
        }

        public async void MarkAsReplicationFinishedOK(string webApiUrl, List<ReplicationLogItem> replLog, ReplicationLogItem replLogItem)
        {
            // mark ReplFailedTimes as -1 to indicate 
            var indexOf = replLog.FindIndex(r => r.ID == replLogItem.ID);
            //replLog[indexOf].ReplFailedTimes = -1;
            await PutEntityDataAsync<ReplicationLogItem>(webApiUrl, replLog[indexOf]); // this will cause it to be deleted on database by the trigger
            //then remote from replLog;
            replLog.Remove(replLogItem);
        }

        public void MarkAsReplicationFailedInReplLog(string webApiUrl, List<ReplicationLogItem> replLog, ReplicationLogItem replLogItem)
        {
            /*
            var indexOf = replLog.FindIndex(r => r.ID == replLogItem.ID);
            replLog[indexOf].ReplFailed = false; // do not write ReplFailed = true to database
            if (!NoNetworking) // not network connection problem, in other words, networking issue does not count for failedtimes
            {
                replLog[indexOf].ReplFailedTimes += 1;
                await PutEntityDataAsync<ReplicationLogItem>(webApiUrl, replLog[indexOf]);
            }
            
            replLog[indexOf].ReplFailed = true; // now can safely mark it as failed
             */
        }

        private async Task<TEntity[]> GetEntityDataArrayAsync<TEntity>(string webApiURL) where TEntity : class
        {
            string typeName = typeof(TEntity).Name;
            TEntity[] returnValue = null;
            using (var client = new HttpClient())
            {
                //example url = "http://localhost:21306/api/customer";
                
                using (var result = await client.GetAsync(webApiURL + typeName))
                {
                    if (result.IsSuccessStatusCode)
                    {
                        var jsonString = await result.Content.ReadAsStringAsync();
                        returnValue = JsonConvert.DeserializeObject<TEntity[]>(jsonString);
                        GettingReplLogItemFinished = true;
                    }
                }
            }

            return returnValue;

        }

       


        //except transaction entity
        private async Task<bool> DeleteEntityDataAsync<TEntity>(string webApiURL, int id) where TEntity : class
        {
            try
            {
                string typeName = typeof(TEntity).Name;

                using (var client = new HttpClient())
                {
                    //example url = "http://localhost:21306/api/customer";

                    using (var result = await client.DeleteAsync(webApiURL + typeName + "/" + id.ToString()))
                    {
                        if (result.IsSuccessStatusCode)
                        {

                        }

                        return (result.IsSuccessStatusCode);
                    }
                }
            }
            catch (Exception excep)
            {

                ProcessWebApiCallFailure(excep);
                return false;
            }
            

        }

        public  async Task<TEntity> GetEntityDataAsync<TEntity>(string webApiURL, int id) where TEntity : class
        {
            string typeName = typeof(TEntity).Name;
            TEntity returnValue = null;
            using (var client = new HttpClient())
            {
                
                //example url = "http://localhost:21306/api/customer";
                using (var result = await client.GetAsync(webApiURL + typeName + "/" + id.ToString()))
                {
                    if (result.IsSuccessStatusCode)
                    {
                        var jsonString = await result.Content.ReadAsStringAsync();
                        returnValue = JsonConvert.DeserializeObject<TEntity>(jsonString);
                        
                        AsyncDeleteOK = (returnValue == null);
                    }
                    else
                    {
                        AsyncDeleteOK = true;
                    }
                }
            }

            return returnValue;

        }

        

        

        private async Task<TEntity> PostEntityDataAsync<TEntity>(string webApiURL, TEntity entityObj) where TEntity : class
        {
            try
            {
                string entityTypeName = typeof(TEntity).Name;

                using (var client = new HttpClient())
                {
                    var serializedEntityObj = JsonConvert.SerializeObject(entityObj);
                    var content = new StringContent(serializedEntityObj, Encoding.UTF8, "application/json");
                    var result = await client.PostAsync(webApiURL + entityTypeName, content);
                    if (result.IsSuccessStatusCode)
                    {

                        TEntity readBackEntity = await result.Content.ReadAsAsync<TEntity>();
                        EntityReplicationFinishedOK = true;
                        AsyncDeleteOK = (readBackEntity == null);
                        return readBackEntity;

                    }
                    else
                    {
                        AsyncDeleteOK = false;
                        return null;
                    }

                }

            }
            catch (Exception excep)
            {
                ProcessWebApiCallFailure(excep);
                return null;
            }
            

        }

        private async void  PostAxleGroupAsync(string webApiURL, IEnumerable<AxleGroup> axleGroups) 
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var serializedAxleGroups = JsonConvert.SerializeObject(axleGroups);
                    var content = new StringContent(serializedAxleGroups, Encoding.UTF8, "application/json");
                    var result = await client.PostAsync(webApiURL + "AxleGroup", content);

                    if (result.IsSuccessStatusCode)
                    {


                        EntityReplicationFinishedOK = true;


                    }
                    else
                    {
                        AsyncDeleteOK = true;
                    }

                }

            }
            catch (Exception excep)
            { 
                ProcessWebApiCallFailure(excep);
            }
           

        }

        public async Task<TEntity> PutEntityDataAsync<TEntity>(string webApiURL, TEntity entityObj) where TEntity : class
        {
            try
            {
                string entityTypeName = typeof(TEntity).Name;
                using (var client = new HttpClient())
                {
                    var serializedEntityObj = JsonConvert.SerializeObject(entityObj);
                    var content = new StringContent(serializedEntityObj, Encoding.UTF8, "application/json");
                    var result = await client.PutAsync(webApiURL + entityTypeName, content);
                    if (result.IsSuccessStatusCode)
                    {

                        TEntity readBackEntity = await result.Content.ReadAsAsync<TEntity>();
                        EntityReplicationFinishedOK = true;
                        AsyncDeleteOK = (readBackEntity == null);
                        return readBackEntity;

                    }
                    else
                    {
                        AsyncDeleteOK = false;
                        return null;
                    }

                }

            }
            catch (Exception excep)
            {
                ProcessWebApiCallFailure(excep);
                return null;
            }
            

        }

        private void ProcessWebApiCallFailure(Exception excep)
        {
            //Logger.LogActivity("Failed replicating - " + excep.Message);
            //Logger.LogActivity("Failed replicating - " + excep.InnerException);
            AsyncDeleteOK = false;
            NoNetworking = excep.InnerException.ToString().Contains("The underlying connection was closed");
        }


        public async void GetReplLogFromReplicationSource(string webApiURL)
        {
            var replLog = await GetEntityDataArrayAsync<ReplicationLogItem>(webApiURL);
            if (replLog != null)
            {
                var replLogList = replLog.ToList();

                ReplLog.Clear();
                ReplLog.AddRange(replLogList);

                //plLog = ReplLog.AddRange(replLogList);

                originalLogCopy.Clear();
                originalLogCopy.AddRange(ReplLog);
            }
           
        }

        public async Task<ReplicationLogItem[]> GetReplLogFromReplicationSourceAsync(string webApiURL)
        {
            var replLog = await GetEntityDataArrayAsync<ReplicationLogItem>(webApiURL);
            return replLog;

        }

        public OperationType ConvertToReplOperationType(string operType)
        {
            OperationType returnType = OperationType.Update;
            switch (operType)
            {
                case "I":
                    returnType = OperationType.Insert;
                    break;
                case "U":
                    returnType = OperationType.Update;
                    break;
                case "D":
                    returnType = OperationType.Delete;
                    break;
                default:
                    break;
            }
            return returnType;
        }

        public async void GetEntityDataByReplLogItem(string webApiURL, ReplicationLogItem logItem)
        {
            OperationType_Repl = ConvertToReplOperationType(logItem.Operation);

            switch (logItem.EntityType)
            {
                case "Transaction":
                    Transaction_Repl = await GetEntityDataAsync<Transaction>(webApiURL, logItem.EntityID);
                    EntityType_Repl = ReplEntityType.Transaction;
                    break;
                case "AxleGroup":
                    AxleGroup_Repl = await GetEntityDataAsync<AxleGroup>(webApiURL, logItem.EntityID);
                    EntityType_Repl = ReplEntityType.AxleGroup;
                    break;
                case "Customer":
                    Customer_Repl = await  GetEntityDataAsync<Customer>(webApiURL, logItem.EntityID);
                    EntityType_Repl = ReplEntityType.Customer;
                    break;
                case "Job":
                    Job_Repl = await GetEntityDataAsync<Job>(webApiURL, logItem.EntityID);
                    EntityType_Repl = ReplEntityType.Job;
                    break;
                case "Site":
                    Site_Repl = await GetEntityDataAsync<Site>(webApiURL, logItem.EntityID);
                    EntityType_Repl = ReplEntityType.Site;
                    break;
                case "Truck":
                    Truck_Repl = await GetEntityDataAsync<Truck>(webApiURL, logItem.EntityID);
                    EntityType_Repl = ReplEntityType.Truck;
                    break;
                case "VehicleType":
                    VehicleConfigurationType_Repl = await GetEntityDataAsync<VehicleConfiguration>(webApiURL, logItem.EntityID);
                    EntityType_Repl = ReplEntityType.VehicleType;
                    break;
                case "Operator":
                    Operator_Repl = await GetEntityDataAsync<Weighman>(webApiURL, logItem.EntityID);
                    EntityType_Repl = ReplEntityType.Operator;
                    break;
                case "CustomerDallasIDAssignment":
                  
                    break;
                case "TruckDallasIDAssignment":
                    
                    break;
                default:
                    break;
            }

        }

        public async Task<ReplEntityType> GetEntityDataByReplLogItemAsync(string webApiURL, ReplicationLogItem logItem)
        {
            ReplEntityType replType = ReplEntityType.None;
            OperationType_Repl = ConvertToReplOperationType(logItem.Operation);

            switch (logItem.EntityType)
            {
                case "Transaction":
                    Transaction_Repl = await GetEntityDataAsync<Transaction>(webApiURL, logItem.EntityID);
                    if (Transaction_Repl != null) replType = ReplEntityType.Transaction;
                    break;
                case "AxleGroup":
                    AxleGroup_Repl = await GetEntityDataAsync<AxleGroup>(webApiURL, logItem.EntityID);
                    if (AxleGroup_Repl != null) replType = ReplEntityType.AxleGroup;
                    break;
                case "Customer":
                    if (OperationType_Repl != OperationType.Delete)
                    {
                        Customer_Repl = await GetEntityDataAsync<Customer>(webApiURL, logItem.EntityID);
                        if (Customer_Repl != null)
                        {
                            //Customer_Repl.FromReplication = true; // mark it as getting from replication
                            replType = ReplEntityType.Customer;
                        }
                    }
                    else
                    {
                        replType = ReplEntityType.Customer;
                    }
                    break;
                case "Job":
                    if (OperationType_Repl != OperationType.Delete)
                    {
                        Job_Repl = await GetEntityDataAsync<Job>(webApiURL, logItem.EntityID);
                        if (Job_Repl != null)
                        {
                            replType = ReplEntityType.Job;
                            //Job_Repl.FromReplication = true;
                        }
                    }
                    else
                    {
                        replType = ReplEntityType.Job;
                    }
                    break;
                case "Site":
                    Site_Repl = await GetEntityDataAsync<Site>(webApiURL, logItem.EntityID);
                    replType = ReplEntityType.Site;
                    break;
                case "Truck":
                    if (OperationType_Repl != OperationType.Delete)
                    {
                        Truck_Repl = await GetEntityDataAsync<Truck>(webApiURL, logItem.EntityID);
                        if (Truck_Repl != null)
                        {
                            replType = ReplEntityType.Truck;
                            //Truck_Repl.FromReplication = true;
                        }
                    }
                    else
                    {
                        replType = ReplEntityType.Truck;
                    }
                    break;
                case "TicketTypeRate":
                    
                    break;
                case "VehicleType":
                    if (OperationType_Repl != OperationType.Delete)
                    {
                        VehicleConfigurationType_Repl = await GetEntityDataAsync<VehicleConfiguration>(webApiURL, logItem.EntityID);
                        if (VehicleConfigurationType_Repl != null)
                        {
                            replType = ReplEntityType.VehicleType;
                            //VehicleConfigurationType_Repl.FromReplication = true;
                        }
                    }
                    else
                    {
                        replType = ReplEntityType.VehicleType;
                    }
                    break;
                case "Operator":
                    if (OperationType_Repl != OperationType.Delete)
                    {
                        Operator_Repl = await GetEntityDataAsync<Weighman>(webApiURL, logItem.EntityID);
                        if (Operator_Repl != null)
                        {
                            replType = ReplEntityType.Operator;
                            //Operator_Repl.FromReplication = true;
                        }
                    }
                    else
                    {
                        replType = ReplEntityType.Operator;
                    }
                    break;
                case "CustomerDallasIDAssignment":
                    
                    break;
                case "TruckDallasIDAssignment":
                    
                    break;
                default:
                    break;
            }

            return replType;

        }

        public async void DeteleReplItemSource(string webApiURL, int id)
        {

            AsyncDeleteOK = !(await DeleteEntityDataAsync<ReplicationLogItem>(webApiURL, id));
           
        }

        public async Task<bool> DeteleReplItemSourceAsync(string webApiURL, int id)
        {
            bool deleteOk = false;
            deleteOk = (await DeleteEntityDataAsync<ReplicationLogItem>(webApiURL, id)); //AsyncCallFailed
            return deleteOk;
        }

        public void DeleteReplItemsFailedThen(int failedTimes, string webApiURL)
        {
            /*
            var failedMoreThen = ReplLog.Where(ri => ri.ReplFailedTimes >= failedTimes);
            //failedMoreThen.ForEach(ri => (await DeteleReplItemSourceAsync(webApiURL, ri.ID)));
            foreach (var ri in failedMoreThen)
            {
                ReplLog.Remove(ri);
                await DeteleReplItemSourceAsync(webApiURL, ri.ID);
            }
             */

        }

        public async Task<bool> ReplicateEntityDataAsync(string webApiUrl, ReplEntityType entityType, OperationType operationType, ReplicationLogItem replLogItem)
        {
            bool replResult = false;

            switch (entityType)
            {
                case ReplEntityType.Transaction:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            Transaction_Repl = await PostEntityDataAsync<Transaction>(webApiUrl, Transaction_Repl);
                            replResult = (Transaction_Repl != null);
                            break;
                        case OperationType.Update:
                            //Transaction_Repl.FromReplication = true;
                            Transaction_Repl = await PutEntityDataAsync<Transaction>(webApiUrl, Transaction_Repl);
                            replResult = EntityReplicationFinishedOK;
                            break;
                        case OperationType.Delete:
                            //var siteDocket = new SiteDocket(replLogItem.SourceSiteID, replLogItem.EntityCode);
                            //replResult = await DeleteTransactionAsync<Transaction>(webApiUrl, siteDocket);
                            break;
                    }
                    
                    break;
                case ReplEntityType.AxleGroup:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            List<AxleGroup> axgroups = new List<AxleGroup>();
                            axgroups.Add(AxleGroup_Repl);
                            PostAxleGroupAsync(webApiUrl, axgroups);
                            replResult = (true);
                            break;
                        case OperationType.Update:
                            //AxleGroup_Repl.FromReplication = true;
                            AxleGroup_Repl = await PutEntityDataAsync<AxleGroup>(webApiUrl, AxleGroup_Repl);
                            replResult = EntityReplicationFinishedOK;
                            break;
                        case OperationType.Delete:
                            {
                                //var siteDocket = new SiteDocket(replLogItem.SourceSiteID, replLogItem.EntityCode);
                                //replResult = await DeleteTransactionAsync<AxleGroup>(webApiUrl, siteDocket);
                                //AxleGroup_Repl.FromReplication = true;
                                // Transaction_Repl = await DeleteEntityDataAsync<Transaction>(webApiUrl, Transaction_Repl);
                                break;
                            }
                            
                    }
                    
                    break;
                case ReplEntityType.Customer:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            Customer_Repl = await PostEntityDataAsync<Customer>(webApiUrl, Customer_Repl);
                            replResult = (Customer_Repl != null);
                            break;
                        case OperationType.Update:
                            //Customer_Repl.FromReplication = true;
                            Customer_Repl = await PutEntityDataAsync<Customer>(webApiUrl, Customer_Repl);
                            replResult = EntityReplicationFinishedOK;
                            
                            break;
                        case OperationType.Delete:
                            EntityReplicationFinishedOK = await DeleteEntityDataAsync<Customer>(webApiUrl, LogItem_Repl.EntityID); //EntityID must hold the Code 
                            replResult = EntityReplicationFinishedOK;
                            break;
                    }
                    
                    break;
                case ReplEntityType.Job:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            Job_Repl = await PostEntityDataAsync<Job>(webApiUrl, Job_Repl);
                            replResult = (Job_Repl != null);
                            break;
                        case OperationType.Update:
                            //Job_Repl.FromReplication = true;
                            Job_Repl = await PutEntityDataAsync<Job>(webApiUrl, Job_Repl);
                            replResult = EntityReplicationFinishedOK;
                            break;
                        case OperationType.Delete:
                            EntityReplicationFinishedOK = await DeleteEntityDataAsync<Job>(webApiUrl, LogItem_Repl.EntityID);
                            replResult = EntityReplicationFinishedOK;
                            //Job_Repl.FromReplication = true;
                            // Transaction_Repl = await DeleteEntityDataAsync<Transaction>(webApiUrl, Transaction_Repl);
                            break;
                    }
                    break;
                case ReplEntityType.Site:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            Site_Repl = await PostEntityDataAsync<Site>(webApiUrl, Site_Repl);
                            replResult = (Site_Repl != null);
                            break;
                        case OperationType.Update:
                            //Site_Repl.FromReplication = true;
                            Site_Repl = await PutEntityDataAsync<Site>(webApiUrl, Site_Repl);
                            replResult = EntityReplicationFinishedOK;
                            break;
                        case OperationType.Delete:
                            //Site_Repl.FromReplication = true;
                            replResult = EntityReplicationFinishedOK;    
                        // Transaction_Repl = await DeleteEntityDataAsync<Transaction>(webApiUrl, Transaction_Repl);
                            break;
                    }
                    
                    break;
                case ReplEntityType.Truck:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            Truck_Repl = await PostEntityDataAsync<Truck>(webApiUrl, Truck_Repl);
                            replResult = (Truck_Repl != null); 
                            break;
                        case OperationType.Update:
                            //Truck_Repl.FromReplication = true;
                            Truck_Repl = await PutEntityDataAsync<Truck>(webApiUrl, Truck_Repl);
                            replResult = EntityReplicationFinishedOK;
                            break;
                        case OperationType.Delete:
                            EntityReplicationFinishedOK = await DeleteEntityDataAsync<Truck>(webApiUrl, LogItem_Repl.EntityID);
                            replResult = EntityReplicationFinishedOK;
                            break;
                    }
                    
                    break;
                case ReplEntityType.TicketTypeRate:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            
                        case OperationType.Update:
                            //Truck_Repl.FromReplication = true;
                            //TicketTypeRate_Repl = await PutEntityDataAsync<TicketTypeRate>(webApiUrl, TicketTypeRate_Repl);
                            replResult = EntityReplicationFinishedOK;
                            break;
                        case OperationType.Delete:
                            //EntityReplicationFinishedOK = await DeleteEntityDataAsync<TicketTypeRate>(webApiUrl, LogItem_Repl.EntityCode);
                            //replResult = EntityReplicationFinishedOK;
                            break;
                    }

                    break;
                case ReplEntityType.VehicleType:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            VehicleConfigurationType_Repl = await PostEntityDataAsync<VehicleConfiguration>(webApiUrl, VehicleConfigurationType_Repl);
                            replResult = (VehicleConfigurationType_Repl != null);
                            break;
                        case OperationType.Update:
                            //Truck_Repl.FromReplication = true;
                            VehicleConfigurationType_Repl = await PutEntityDataAsync<VehicleConfiguration>(webApiUrl, VehicleConfigurationType_Repl);
                            replResult = EntityReplicationFinishedOK;
                            break;
                        case OperationType.Delete:
                            EntityReplicationFinishedOK = await DeleteEntityDataAsync<VehicleConfiguration>(webApiUrl, LogItem_Repl.EntityID);
                            replResult = EntityReplicationFinishedOK;
                            break;
                    }

                    break;
                case ReplEntityType.Operator:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            Operator_Repl = await PostEntityDataAsync<Weighman>(webApiUrl, Operator_Repl);
                            replResult = (Operator_Repl != null);
                            break;
                        case OperationType.Update:
                            //Operator_Repl.FromReplication = true;
                            Operator_Repl = await PutEntityDataAsync<Weighman>(webApiUrl, Operator_Repl);
                            replResult = EntityReplicationFinishedOK;
                            break;
                        case OperationType.Delete:
                            EntityReplicationFinishedOK = await DeleteEntityDataAsync<Weighman>(webApiUrl, LogItem_Repl.EntityID);
                            replResult = EntityReplicationFinishedOK;
                            break;
                    }
                    
                    break;

                case ReplEntityType.CustomerDallasIDAssignment:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            // CustomerDallasIDAssignment_Repl = await PostEntityDataAsync<CustomerDallasIDAssignment>(webApiUrl, CustomerDallasIDAssignment_Repl);
                            //replResult = (CustomerDallasIDAssignment_Repl != null);
                            break;
                        case OperationType.Update:
                            //Customer_Repl.FromReplication = true;
                            //CustomerDallasIDAssignment_Repl = await PutEntityDataAsync<CustomerDallasIDAssignment>(webApiUrl, CustomerDallasIDAssignment_Repl);
                            replResult = EntityReplicationFinishedOK;

                            break;
                        case OperationType.Delete:
                            //EntityReplicationFinishedOK = await DeleteEntityDataAsync<CustomerDallasIDAssignment>(webApiUrl, LogItem_Repl.EntityCode); //EntityCode holds the ID form(for) Central 
                            //replResult = EntityReplicationFinishedOK;
                            break;
                    }

                    break;
                case ReplEntityType.TruckDallasIDAssignment:
                    switch (operationType)
                    {
                        case OperationType.Insert:
                            //TruckDallasIDAssignment_Repl = await PostEntityDataAsync<TruckDallasIDAssignment>(webApiUrl, TruckDallasIDAssignment_Repl);
                           // replResult = (TruckDallasIDAssignment_Repl != null);
                            break;
                        case OperationType.Update:
                            //Customer_Repl.FromReplication = true;
                            //TruckDallasIDAssignment_Repl = await PutEntityDataAsync<TruckDallasIDAssignment>(webApiUrl, TruckDallasIDAssignment_Repl);
                            replResult = EntityReplicationFinishedOK;

                            break;
                        case OperationType.Delete:
                            //EntityReplicationFinishedOK = await DeleteEntityDataAsync<TruckDallasIDAssignment>(webApiUrl, LogItem_Repl.EntityCode); //EntityCode holds the ID from(for) Central 
                            //replResult = EntityReplicationFinishedOK;
                            break;
                    }

                    break;
                default:
                    break;
            }

            return replResult;
        }


        public List<ReplicationLogItem> OptimiseReplLog(List<ReplicationLogItem> replLogParam)
        {

            return null;
        }

        //Commented this function for now, no where it is called
        /*
        private  bool ReplicateItemToDestination(ReplicationLogItem replRecordParam)
        {
            throw new NotImplementedException();
        }*/

        public void ApplyReplLog(List<ReplicationLogItem> replLogParam)
        {
            throw new NotImplementedException();
        }

        public void CleanupReplLogInReplicationSource()
        {
            /*
            var OptimisedOutReplItems = originalLogCopy.Except(ReplLog);

            if ((OptimisedOutReplItems != null) && (OptimisedOutReplItems.Count() > 0))
            {
                //for each item in OptimisedReplItems, delete the corresponding item in repl source db
                foreach (var item in OptimisedOutReplItems)
                {
                    DeleteItemInReplicationSource(item);
                }
            }

            var successfullyReplicatedItems = ReplLog.Where(item => item.ReplFailedTimes == 0);

            if ((successfullyReplicatedItems != null) && (successfullyReplicatedItems.Count() > 0))
            {
                //for each item in successfullyReplicatedItems, delete the corresponding item in repl source db
                foreach (var item in successfullyReplicatedItems)
                {
                    DeleteItemInReplicationSource(item);
                }
            }
             */
        }


        //Commented this function for now, no where it is called
        /*
        private void DeleteItemInReplicationSource(ReplicationLogItem replRecordParam)
        {
            throw new NotImplementedException();
        } */
    }
}
