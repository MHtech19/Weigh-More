﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public class CountedTicket : BaseTicket
    {
        public CountedTicket(string title, bool isReprint, Transaction currentTransaction, AWSConfiguration config)
            : base(title, isReprint, currentTransaction, config)
        { }

        protected override void GeneratePrice()
        {
            if (PrintPrice)
            {
                string line = string.Empty;

                line = " ";
                ticket.Add(line);

                string priceType = "Price/" + Config.CompanyProfileSettings.CountedItemAs;
            
           
                if (CurrentTransaction.Customer!=null && CurrentTransaction.Customer.FixedCharge > 0)
                {
                    priceType = "Fixed Price";
                }   
                line = PadTitle(priceType) + CurrentTransaction.Price.ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);
            }

        }

        public override List<string> GenerateTicket()
        {
            GenerateHead();
            string line;

            if (CurrentTransaction.TransactionDate != null)
            {
                line = PadTitle("Date/Time") + CurrentTransaction.TransactionDate;
                ticket.Add(line);
            }

            GenerateEntityLines();

            line = PadTitle(Config.CompanyProfileSettings.CountedItemAs) + CurrentTransaction.Net.ToString();
            ticket.Add(line);
            
            GenerateCharges();

            GenerateFooter();

            return ticket;
        }
    }
}