﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public class RegoWeighTicket : BaseTicket
    {
        public RegoWeighTicket(string title, bool isReprint, Transaction currentTransaction, AWSConfiguration config)
            : base(title, isReprint, currentTransaction, config)
        { }

        public override List<string> GenerateTicket()
        {
            GenerateHead();

            string line = PadTitle("VIN Number") + CurrentTransaction.VINNumber;
            ticket.Add(line);

            line = PadTitle("Date/Time") + CurrentTransaction.TransactionDate;
            ticket.Add(line);

            GenerateEntityLines();

            //GenerateGrosses();
            //GenerateTares(CurrentTransaction.LoadType);
            //line = PadTitle("Net") + CurrentTransaction.Net.ToString("N2") + "t";
            //ticket.Add(line);

            //string line = string.Empty;
            if ((CurrentTransaction.Gross2 > 0) || (CurrentTransaction.Gross3 > 0) || (CurrentTransaction.Gross4 > 0) || (CurrentTransaction.Gross5 > 0))
            {
                line = PadTitle("Tare1") + CurrentTransaction.Gross1.ToString("N2") + "t";
                ticket.Add(line);

                line = PadTitle("Tare2") + CurrentTransaction.Gross2.ToString("N2") + "t";
                ticket.Add(line);

                if (CurrentTransaction.Gross3 > 0)
                {
                    line = PadTitle("Tare3") + CurrentTransaction.Gross3.ToString("N2") + "t";
                    ticket.Add(line);
                }

                if (CurrentTransaction.Gross4 > 0)
                {
                    line = PadTitle("Tare4") + CurrentTransaction.Gross4.ToString("N2") + "t";
                    ticket.Add(line);
                }

                if (CurrentTransaction.Gross5 > 0)
                {
                    line = PadTitle("Tare5") + CurrentTransaction.Gross5.ToString("N2") + "t";
                    ticket.Add(line);
                }
            }

            line = PadTitle("Tare") + CurrentTransaction.Gross.ToString("N2") + "t";
            ticket.Add(line);

            if (PrintPrice)
            {
                GenerateCharges();
            }

            GenerateFooter();

            return ticket;
        }
    }
}