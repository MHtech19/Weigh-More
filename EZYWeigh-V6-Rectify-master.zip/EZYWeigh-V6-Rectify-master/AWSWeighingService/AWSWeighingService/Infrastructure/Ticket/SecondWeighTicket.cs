﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public class SecondWeighTicket : BaseTicket
    {
        public SecondWeighTicket(string title, bool isReprint, Transaction currentTransaction, AWSConfiguration config) : base(title, isReprint, currentTransaction, config)
        { }

        public override List<string> GenerateTicket()
        {
            string line;
            GenerateHead();

            if (CurrentTransaction.TareInDate != null)
            {
                line = PadTitle("Tare In") + CurrentTransaction.TareInDate;
                ticket.Add(line);
            }

            if (CurrentTransaction.TransactionDate != null)
            {
                line = PadTitle("Tare Out") + CurrentTransaction.TransactionDate;
                ticket.Add(line);
            }
            
            //PrntTextLine(iLineSp, iInd, y, 'Date In : ' + psDateIn);
            // PrntTextLine(iLineSp, iInd, y, 'Time In : ' + psTimeIn);
            // PrntTextLine(iLineSp, iInd, y, 'Date Out: ' + psMainDate);
            // PrntTextLine(iLineSp, iInd, y, 'Time Out: ' + psMainTime);


            GenerateEntityLines();

            GenerateGrosses();

            GenerateTares(CurrentTransaction.LoadType);

            line = PadTitle("Net") + CurrentTransaction.Net.ToString("N2") + "t";
            ticket.Add(line);

            if (CurrentTransaction.Count > 0 && Config.TicketSettings.PrintVolume)
            {
                line = PadTitle("Volume") + CurrentTransaction.Count.ToString("N2") + "m3";
                ticket.Add(line);
            }

            if (CurrentTransaction.MaxLoad > 0 && CurrentTransaction.MaxLoad < CurrentTransaction.Gross)
            {
                line = PadTitle("Max Load") + CurrentTransaction.MaxLoad.ToString("N2") + "t";
                ticket.Add(line);
                line = PadTitle("") + "Max Load Exceeded";
                ticket.Add(line);
            }

            line = " ";
            ticket.Add(line);


            if (PrintPrice)
            {
                GenerateCharges();
            }

            GenerateFooter();

            return ticket;

        }
    }
}