﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public class MixedLoadTicket : BaseTicket
    {
        public MixedLoadTicket(string title, bool isReprint, Transaction currentTransaction, AWSConfiguration config)
            : base(title, isReprint, currentTransaction, config)
        { }

        public override List<string> GenerateTicket()
        {
            GenerateHead();

            GenerateEntityLines();

            GenerateCharges();

            GenerateFooter();

            return ticket;
        }

        protected override void GenerateCharges()
        {
            string line = string.Empty;

            
            if (PrintPrice)
            {

                line = PadTitle("Cost") + CurrentTransaction.SelectedMixedProducts.Sum(p => p.CurrentTranCost).ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                line = PadTitle("GST") + CurrentTransaction.SelectedMixedProducts.Sum(p => p.CurrentGST).ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                decimal epaSum = CurrentTransaction.SelectedMixedProducts.Sum(p => p.CurrentEPA);
                if (epaSum > 0)
                {
                    line = PadTitle("EPA") + epaSum.ToString("C", CultureInfo.CurrentCulture);
                    ticket.Add(line);
                }

                line = PadTitle("Amount Due") + CurrentTransaction.SelectedMixedProducts.Sum(p => p.CurrentTotalCost).ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                //line = PadTitle("Paid By") + CurrentTransaction.Payments;
                //ticket.Add(line);

                //if ((Config.TicketSettings.PrintComment) && (CurrentTransaction.Comment.Trim() != string.Empty))
                //{
                //    line = PadTitle("Comment") + CurrentTransaction.Comment;
                //    ticket.Add(line);
                //}

            }
        }

        protected override void GenerateProductEntityLines()
        {
            string line = string.Empty;
            ticket.Add(line);

            if (CurrentTransaction.SelectedMixedProducts!=null && CurrentTransaction.SelectedMixedProducts.Count >= 1)
            {
                line = "Product Name";
                ticket.Add(line);

                line = "Price".PadLeft(10) + "Amount".PadLeft(10) + "Sum".PadLeft(10);
                ticket.Add(line);

                foreach (var p in CurrentTransaction.SelectedMixedProducts)
                {

                    line = p.Name.PadRight(40);
                    ticket.Add(line);

                    line = p.CurrentPrice.ToString("c").PadLeft(10) + p.CurrentAmount.ToString().PadLeft(10) + p.CurrentTotalCost.ToString("c").PadLeft(10);
                    ticket.Add(line);
                }

            }
            

        }
    }
}