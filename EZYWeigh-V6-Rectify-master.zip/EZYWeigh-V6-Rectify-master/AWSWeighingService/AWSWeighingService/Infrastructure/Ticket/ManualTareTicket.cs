﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public class ManualTareTicket : BaseTicket
    {
        public ManualTareTicket(string title, bool isReprint, Transaction currentTransaction, AWSConfiguration config) : base(title, isReprint, currentTransaction, config)
        { }

        public override List<string> GenerateTicket()
        {
            GenerateHead();

            GenerateFooter();

            return ticket;
        }
    }
}