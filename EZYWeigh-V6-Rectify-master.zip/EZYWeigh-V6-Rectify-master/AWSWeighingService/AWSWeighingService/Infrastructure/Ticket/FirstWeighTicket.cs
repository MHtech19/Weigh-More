﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public class FirstWeighTicket : BaseTicket
    {
        public FirstWeighTicket(string title, FirstWeigh currentFirstWeigh, Transaction currentTransaction, AWSConfiguration config) : base(title, currentFirstWeigh, currentTransaction, config)
        { }     
        

        public override List<string> GenerateTicket()
        {
            //GenerateBlankLines(2);

            string line = Title;
            ticket.Add(line);

            GenerateBlankLines(1);

            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Site.Name))
            {
                line = CurrentFirstWeigh.Site.Name;
                ticket.Add(line);
            }



            //street address
            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Site.Address1))
            {
                line = CurrentFirstWeigh.Site.Address1;
                ticket.Add(line);
            }


            //state
            line = null;
            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Site.Suburb))
            {
                line = CurrentFirstWeigh.Site.Suburb + " ";
            }

            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Site.Suburb))
            {
                line = line +  CurrentFirstWeigh.Site.Suburb + " ";
            }

            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Site.Postcode))
            {
                line = line + CurrentFirstWeigh.Site.Postcode + " ";
            }
            //line = CurrentFirstWeigh.Site.Suburb + " " + CurrentFirstWeigh.Site.State + " " + CurrentFirstWeigh.Site.Postcode;

            if (!string.IsNullOrEmpty(line))
            {
                ticket.Add(line); ;
            }

            //PHONE
            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Site.Phone))
            {
                line = PadTitle("PHONE") + CurrentFirstWeigh.Site.Phone; // +" FAX: " + site.Fax;
                ticket.Add(line);
            }

            //ABN
            if (!string.IsNullOrEmpty(Config.CompanyProfileSettings.ABN))
            {
                line = PadTitle("ABN") + Config.CompanyProfileSettings.ABN; // +" FAX: " + site.Fax;
                ticket.Add(line);
            }
            

            line = " ";
            ticket.Add(line);

            line = PadTitle("Load Type") + "First";
            ticket.Add(line);

            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Payments))
            {
                line = PadTitle("Payment") + CurrentFirstWeigh.Payments;
                ticket.Add(line);
            }

            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Direction))
            {
                line = PadTitle("Direction") + CurrentFirstWeigh.Direction;
                ticket.Add(line);
            }

            if (!string.IsNullOrEmpty(CurrentFirstWeigh.VehicleOwner))
            {
                line = PadTitle("Vehicle Owner") + CurrentFirstWeigh.VehicleOwner;
                ticket.Add(line);
            }

            if (!string.IsNullOrEmpty(CurrentFirstWeigh.ChargeRate))
            {
                line = PadTitle("Charge Rate") + CurrentFirstWeigh.ChargeRate;
                ticket.Add(line);
            }
            

            line = " ";
            ticket.Add(line);

            if (CurrentFirstWeigh.Weighman!=null && !string.IsNullOrEmpty(CurrentFirstWeigh.Weighman.Name))
            {
                line = PadTitle("Operator") + CurrentFirstWeigh.Weighman.Name;
                ticket.Add(line);
            }

            if (!string.IsNullOrEmpty(CurrentFirstWeigh.Name))
            {
                line = PadTitle("Rego No.") + CurrentFirstWeigh.Name;
                ticket.Add(line);
            }

            if (CurrentFirstWeigh.TareInDate != null)
            {
                line = PadTitle("Tare In") + CurrentFirstWeigh.TareInDate;
                ticket.Add(line);
            }
            
            if (CurrentFirstWeigh.Job != null)
            {
                line = PadTitle("Job Number") + CurrentFirstWeigh.Job.Name;
                ticket.Add(line);
            }

            if (CurrentFirstWeigh.Customer!=null && !string.IsNullOrEmpty(CurrentFirstWeigh.Customer.Name))
            {
                line = PadTitle("Customer") + CurrentFirstWeigh.Customer.Name;
                ticket.Add(line);
            }

            if (CurrentFirstWeigh.Product!=null && !string.IsNullOrEmpty(CurrentFirstWeigh.Product.Name))
            {
                line = PadTitle("Product") + CurrentFirstWeigh.Product.Name;
                ticket.Add(line);
            }

            if (CurrentFirstWeigh.Source!=null && !string.IsNullOrEmpty(CurrentFirstWeigh.Source.Name))
            {
                line = PadTitle("Source") + CurrentFirstWeigh.Source.Name;
                ticket.Add(line);
            }

            if (CurrentFirstWeigh.Destination!=null && !string.IsNullOrEmpty(CurrentFirstWeigh.Destination.Name))
            {
                line = PadTitle("Destination") + CurrentFirstWeigh.Destination.Name;
                ticket.Add(line);
            }
            
            line = " ";
            ticket.Add(line);

            if ((CurrentFirstWeigh.Tare2 > 0) || (CurrentFirstWeigh.Tare3 > 0) || (CurrentFirstWeigh.Tare4 > 0) || (CurrentFirstWeigh.Tare5 > 0))
            {
                line = PadTitle("Weigh1") + CurrentFirstWeigh.Tare1.ToString("N2") + "t";
                ticket.Add(line);

                line = PadTitle("Weigh2") + CurrentFirstWeigh.Tare2.ToString("N2") + "t";
                ticket.Add(line);

                if (CurrentFirstWeigh.Tare3 > 0)
                {
                    line = PadTitle("Weigh3") + CurrentFirstWeigh.Tare3.ToString("N2") + "t";
                    ticket.Add(line);
                }

                if (CurrentFirstWeigh.Tare4 > 0)
                {
                    line = PadTitle("Weigh4") + CurrentFirstWeigh.Tare4.ToString("N2") + "t";
                    ticket.Add(line);
                }

                if (CurrentFirstWeigh.Tare5 > 0)
                {
                    line = PadTitle("Weigh5") + CurrentFirstWeigh.Tare5.ToString("N2") + "t";
                    ticket.Add(line);
                }
            }

            line = PadTitle("Total") + CurrentFirstWeigh.Tare.ToString("N2") + "t";
            ticket.Add(line);

            GenerateFooter();

            return ticket;
        }
    }
}