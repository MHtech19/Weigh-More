﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public class StandardTicket : BaseTicket
    {
        public StandardTicket(string title, bool isReprint, Transaction currentTransaction, AWSConfiguration config)
            : base(title, isReprint, currentTransaction, config)
        { }


        protected override void GeneratePrice()
        {
            string line = string.Empty;

            line = " ";
            ticket.Add(line);

            if (CurrentTransaction.SelectedMixedProducts.Count > 1) return;

            string priceType = "Price/Vehicle";
            //if (CurrentTransaction.LoadType == CoreConstants.Load_Counted) priceType = "Price/Item";
            //bool printPrice = ((CurrentTransaction.Payments != CoreConstants.PAYMENT_ACCOUNT) || ((CurrentTransaction.Payments == CoreConstants.PAYMENT_ACCOUNT) && !Config.TicketSettings.HidePriceForAccountPayment));

            if (PrintPrice)
            {   
                line = PadTitle(priceType) + CurrentTransaction.SelectedMixedProducts[0].CurrentPrice.ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);
            }

        }

        protected override void GenerateCharges()
        {
            string line = string.Empty;

            GeneratePrice();
            if (PrintPrice)
            {

                line = PadTitle("Cost") + CurrentTransaction.SelectedMixedProducts.Sum(p => p.CurrentTranCost).ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                line = PadTitle("GST") + CurrentTransaction.SelectedMixedProducts.Sum(p => p.CurrentGST).ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                var epaCharge = CurrentTransaction.SelectedMixedProducts.Sum(p => p.CurrentEPA);

                if (epaCharge > 0)
                {
                    line = PadTitle("EPA") + epaCharge.ToString("C", CultureInfo.CurrentCulture);
                    ticket.Add(line);
                }

                line = PadTitle("Amount Due") + CurrentTransaction.SelectedMixedProducts.Sum(p => p.CurrentTotalCost).ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                //line = PadTitle("Paid By") + CurrentTransaction.Payments;
                //ticket.Add(line);

                //if ((Config.TicketSettings.PrintComment) && (CurrentTransaction.Comment.Trim() != string.Empty))
                //{
                //    line = PadTitle("Comment") + CurrentTransaction.Comment;
                //    ticket.Add(line);
                //}

            }
        }

        protected override void GenerateProductEntityLines()
        {
            string line = null;


            line = PadTitle("Products");
            ticket.Add(line);

            foreach (var p in CurrentTransaction.SelectedMixedProducts)
            {

                line = p.Name.PadRight(30) + p.CurrentPrice.ToString("c").PadLeft(10);
                ticket.Add(line);
            }

        }

        

        public override List<string> GenerateTicket()
        {
            GenerateHead();

            string line = PadTitle("Date/Time") + CurrentTransaction.TransactionDate;
            ticket.Add(line);

            GenerateEntityLines();

            if (CurrentTransaction.Vehicle != null)
            {
                line = PadTitle("Vehicle Class") + CurrentTransaction.Vehicle.NetWeight.ToString("N") + "(t)";
                ticket.Add(line);
            }

            if (CurrentTransaction.Count > 0 && Config.TicketSettings.PrintVolume)
            {
                line = PadTitle("Volume") + CurrentTransaction.Count.ToString("N2") + "m3";
                ticket.Add(line);
            }

            GenerateCharges();

            GenerateFooter();

            return ticket;
        }
    }
}