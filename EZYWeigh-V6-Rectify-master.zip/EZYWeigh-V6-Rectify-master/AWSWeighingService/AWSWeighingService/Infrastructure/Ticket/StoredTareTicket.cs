﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public class StoredTareTicket : BaseTicket
    {
        public StoredTareTicket(string title, bool isReprint, Transaction currentTransaction, AWSConfiguration config)
            : base(title, isReprint, currentTransaction, config)
        { }

        public override List<string> GenerateTicket()
        {
            GenerateHead();

            string line = PadTitle("Date/Time") + CurrentTransaction.TransactionDate;
            ticket.Add(line);

            GenerateEntityLines();

            GenerateGrosses();

            GenerateTares(CurrentTransaction.LoadType);

            line = PadTitle("Net") + CurrentTransaction.Net.ToString("N2") + "t";
            ticket.Add(line);

            if (CurrentTransaction.Count > 0 && Config.TicketSettings.PrintVolume)
            {
                line = PadTitle("Volume") + CurrentTransaction.Count.ToString("N2") + "m3";
                ticket.Add(line);
            }

            if (CurrentTransaction.MaxLoad > 0 && CurrentTransaction.MaxLoad < CurrentTransaction.Gross)
            {
                line = PadTitle("Max Load") + CurrentTransaction.MaxLoad.ToString("N2") + "t";
                ticket.Add(line);
                line = PadTitle("") + "Max Load Exceeded";
                ticket.Add(line);
            }

            line = " ";
            ticket.Add(line);

            if (PrintPrice)
            {
                GenerateCharges();
            }
            

            GenerateFooter();

            return ticket;
        }
    }
}