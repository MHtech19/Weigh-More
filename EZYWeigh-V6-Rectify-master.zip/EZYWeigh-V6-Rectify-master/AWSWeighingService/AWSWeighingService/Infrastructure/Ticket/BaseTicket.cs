﻿using AWSWeighingService.Models;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Infrastructure.Ticket
{
    public abstract class BaseTicket
    {
        protected List<string> ticket;
        protected string Title { get; set; }
        protected bool IsReprint { get; set; }
        protected bool PrintPrice { get; set; }
        protected Transaction CurrentTransaction { get; set; }
        protected AWSConfiguration Config { get; set; }
        protected FirstWeigh CurrentFirstWeigh { get; set; }

        public BaseTicket(string title, FirstWeigh currentFirstWeigh, Transaction currentTransaction, AWSConfiguration config)
        {
            Title = title;
            CurrentFirstWeigh = currentFirstWeigh;
            CurrentTransaction = currentTransaction;
            Config = config;

            PrintPrice = (!currentTransaction.Customer.HidePriceOnTicket) && ((CurrentTransaction.Payments != CoreConstants.PAYMENT_ACCOUNT) || ((CurrentTransaction.Payments == CoreConstants.PAYMENT_ACCOUNT) && !Config.TicketSettings.HidePriceForAccountPayment));


            ticket = new List<string>();
        }

        public BaseTicket(string title, bool isReprint, Transaction currentTransaction, AWSConfiguration config)
        {
            Title = title;
            IsReprint = isReprint;
            CurrentTransaction = currentTransaction;
            Config = config;

            PrintPrice = (!currentTransaction.Customer.HidePriceOnTicket) && ((CurrentTransaction.Payments != CoreConstants.PAYMENT_ACCOUNT) || ((CurrentTransaction.Payments == CoreConstants.PAYMENT_ACCOUNT) && !Config.TicketSettings.HidePriceForAccountPayment));

            ticket = new List<string>();
        }

        protected string PadTitle(string title)
        {
            string strOut = title;

            strOut = strOut.PadRight(13);

            strOut = strOut + ": ";

            return strOut;
        }

        private void PrintPrintLegalDeclaration()
        {
            string[] legalDeclaration = Config.TicketSettings.LegalDeclaration.Split('\n');
            string line;
            for (int i = 0; i < 3; i++)
            {
                line = legalDeclaration[i];
                ticket.Add(line);
            }


        }

        public void GenerateHead()
        {
            //GenerateBlankLines(2);

            string line = (IsReprint) ? Title + " (Reprint)" : Title;
            ticket.Add(line);

            GenerateBlankLines(1);

            //if (Config.TicketSettings.PrintLegalDeclaration)
            //{
            //    PrintPrintLegalDeclaration();
            //}

            line = CurrentTransaction.Site.Name;
            ticket.Add(line);

            //street address
            line = (CurrentTransaction.Site.Address1 == null) ? string.Empty : CurrentTransaction.Site.Address1;
            ticket.Add(line);

            //state
            string suburb = (CurrentTransaction.Site.Suburb == null) ? string.Empty : CurrentTransaction.Site.Suburb;
            string state = (CurrentTransaction.Site.State == null) ? string.Empty : CurrentTransaction.Site.State;
            string postcode = (CurrentTransaction.Site.State == null) ? string.Empty : CurrentTransaction.Site.Postcode;
            line = suburb + " " + state + " " + postcode;
            ticket.Add(line);

            //PHONE
            string phone = (CurrentTransaction.Site.Phone == null) ? string.Empty : CurrentTransaction.Site.Phone;
            line = PadTitle("PHONE") + phone; // +" FAX: " + site.Fax;
            ticket.Add(line);

            //ABN
            line = PadTitle("ABN") + Config.CompanyProfileSettings.ABN; // +" FAX: " + site.Fax;
            ticket.Add(line);

            if (Config.TicketSettings.PrintRegisteredPublicWeighbridgeNo)
            {
                line = Config.CompanyProfileSettings.RegisteredPublicWeighbridgeNo;
                ticket.Add(line);
            }

            if (Config.TicketSettings.PrintLegalDeclaration)
            {
                PrintPrintLegalDeclaration();
            }

            line = " ";
            ticket.Add(line);

            if (!String.IsNullOrEmpty(CurrentTransaction.Docket))
            {
                line = PadTitle("Docket No.") + CurrentTransaction.Docket;
                ticket.Add(line);
            }

            string loadType = CurrentTransaction.LoadType;
            if (loadType == CoreConstants.Load_Counted)
            {
                loadType = Config.CompanyProfileSettings.CountedItemAs;
            }
            line = PadTitle("Load Type") + loadType;
            ticket.Add(line);

            if (CurrentTransaction.Weighman != null)
            {
                line = PadTitle("Operator") + CurrentTransaction.Weighman.Name;
                ticket.Add(line);
            }

            line = PadTitle("Rego No.") + CurrentTransaction.Registration1;
            ticket.Add(line);
        }

        protected void GenerateEntityLines()
        {
            string line = null;

            if ((CurrentTransaction.Job != null && CurrentTransaction.Job.Name != CoreConstants.NA) && (CurrentTransaction.LoadType != CoreConstants.Load_Rego) && (CurrentTransaction.LoadType != CoreConstants.Load_Standard))
            {
                line = PadTitle("Job Number") + CurrentTransaction.Job.Name;
                ticket.Add(line);
            }

            //if (Config.TicketSettings.PrintOrderNumber && (CurrentTransaction.Job!=null && CurrentTransaction.Job.OrderNumber != null) && (CurrentTransaction.Job.OrderNumber.Trim() != string.Empty))
            if (Config.TicketSettings.PrintOrderNumber && CurrentTransaction.OrderNumber != null && !String.IsNullOrEmpty(CurrentTransaction.OrderNumber.Trim()))
            {
                line = PadTitle("Order Number") + CurrentTransaction.OrderNumber.Trim();
                ticket.Add(line);
            }

            if (CurrentTransaction.Customer != null)
            {
                line = PadTitle("Customer") + CurrentTransaction.Customer.Name;
                ticket.Add(line);
            }

            if (Config.TicketSettings.PrintAccountNumber && (CurrentTransaction.Customer != null && CurrentTransaction.Customer.AccountNumber != null) && (CurrentTransaction.Customer.AccountNumber.Trim() != string.Empty))
            {
                line = PadTitle("Acc. Number") + CurrentTransaction.Customer.AccountNumber;
                ticket.Add(line);
            }

            if (Config.TicketSettings.PrintDirection)
            {
                line = PadTitle("Direction") + CurrentTransaction.Direction;
                ticket.Add(line);
            }

            if (Config.TicketSettings.PrintSource)
            {
                if (CurrentTransaction.Source != null)
                {
                    line = PadTitle("Source") + CurrentTransaction.Source.Name;
                }
                else
                {
                    line = PadTitle("Source") + CoreConstants.NA;
                }
                ticket.Add(line);
            }

            if (Config.TicketSettings.PrintDestination)
            {
                if (CurrentTransaction.Destination != null)
                {
                    line = PadTitle("Destination") + CurrentTransaction.Destination.Name;
                }
                else
                {
                    line = PadTitle("Destination") + CoreConstants.NA;
                }
                ticket.Add(line);
            }

            if (CurrentTransaction.LoadType == CoreConstants.Load_Standard)
            {
                if (CurrentTransaction.Vehicle != null)
                {
                    line = PadTitle("Vehicle Type") + CurrentTransaction.Vehicle.Name;
                }
                else
                {
                    line = PadTitle("Vehicle Type") + CoreConstants.NA;
                }
                ticket.Add(line);
            }

            GenerateProductEntityLines();

            line = " ";
            ticket.Add(line);
        }

        protected virtual void GenerateProductEntityLines()
        {
            string line = null;

            if (Config.TicketSettings.PrintProductCode && (CurrentTransaction.Product != null && CurrentTransaction.Product.Code != null) && (CurrentTransaction.Product.Code.Trim() != string.Empty))
            {
                line = PadTitle("Prod. Code") + CurrentTransaction.Product.Code;
                ticket.Add(line);
            }

            if (CurrentTransaction.Product != null)
            {
                line = PadTitle("Product") + CurrentTransaction.Product.Name;
            }
            else
            {
                line = PadTitle("Product") + CoreConstants.NA;
            }
            ticket.Add(line);

            if (!IsReprint && Config.TicketSettings.PrintJobTonnage)
            {
                //CurrentTransaction.Product.CurrentGST = jobTonnage.TodayTotal;
                //CurrentTransaction.Product.CurrentEPA = jobTonnage.MonthlyTotal;
                //CurrentTransaction.Product.CurrentPrice = jobTonnage.RunningTotal;
                if (CurrentTransaction.Product != null && CurrentTransaction.Product.CurrentGST != -1)
                {
                    //line = PadTitle(" Todays Total") + CurrentTransaction.Product.CurrentGST.ToString() + "t";
                    line = PadTitle("Ton's Ordered") + CurrentTransaction.Product.CurrentGST.ToString() + "t";
                    ticket.Add(line);
                }
                else
                {
                    //line = PadTitle(" Todays Total") + CoreConstants.NA;
                    line = PadTitle("Ton's Ordered") + CoreConstants.NA;
                    ticket.Add(line);
                }

                if (CurrentTransaction.Product != null && CurrentTransaction.Product.CurrentEPA != -1)
                {
                    //line = PadTitle("Monthly Total") + CurrentTransaction.Product.CurrentEPA.ToString() + "t";
                    line = PadTitle("Ton's Proce'd") + CurrentTransaction.Product.CurrentEPA.ToString() + "t";
                    ticket.Add(line);
                }
                else
                {
                    //line = PadTitle("Monthly Total") + CoreConstants.NA;
                    line = PadTitle("Ton's Proce'd") + CoreConstants.NA;
                    ticket.Add(line);
                }

                if (CurrentTransaction.Product != null && CurrentTransaction.Product.CurrentPrice != -1)
                {
                    //line = PadTitle("Running Total") + CurrentTransaction.Product.CurrentPrice.ToString() + "t";
                    line = PadTitle("Ton's Left") + CurrentTransaction.Product.CurrentPrice.ToString() + "t";
                    ticket.Add(line);
                }
                else
                {
                    //line = PadTitle("Running Total") + CoreConstants.NA;
                    line = PadTitle("Ton's Left") + CoreConstants.NA;
                    ticket.Add(line);
                }
            }

        }

        protected void GenerateGrosses()
        {
            string line = string.Empty;

            if ((CurrentTransaction.Gross2 > 0) || (CurrentTransaction.Gross3 > 0) || (CurrentTransaction.Gross4 > 0) || (CurrentTransaction.Gross5 > 0))
            {
                line = PadTitle("Gross1") + CurrentTransaction.Gross1.ToString("N2") + "t";
                ticket.Add(line);

                line = PadTitle("Gross2") + CurrentTransaction.Gross2.ToString("N2") + "t";
                ticket.Add(line);

                if (CurrentTransaction.Gross3 > 0)
                {
                    line = PadTitle("Gross3") + CurrentTransaction.Gross3.ToString("N2") + "t";
                    ticket.Add(line);
                }

                if (CurrentTransaction.Gross4 > 0)
                {
                    line = PadTitle("Gross4") + CurrentTransaction.Gross4.ToString("N2") + "t";
                    ticket.Add(line);
                }

                if (CurrentTransaction.Gross5 > 0)
                {
                    line = PadTitle("Gross5") + CurrentTransaction.Gross5.ToString("N2") + "t";
                    ticket.Add(line);
                }
            }

            line = PadTitle("Gross") + CurrentTransaction.Gross.ToString("N2") + "t";
            ticket.Add(line);
        }

        protected void GenerateTares(string loadType)
        {
            string line = string.Empty;
            string tareType = string.Empty;

            switch (loadType)
            {
                case "StoredTare": tareType = " (Stored)"; break;
                case "ManualTare": tareType = " (Manually Entered"; break;
                default: break;
            }

            if ((CurrentTransaction.Tare2 > 0) || (CurrentTransaction.Tare3 > 0) || (CurrentTransaction.Tare4 > 0) || (CurrentTransaction.Tare5 > 0))
            {
                line = PadTitle("Tare1") + CurrentTransaction.Tare1.ToString("N2") + "t" + tareType;
                ticket.Add(line);

                line = PadTitle("Tare2") + CurrentTransaction.Tare2.ToString("N2") + "t" + tareType;
                ticket.Add(line);

                if (CurrentTransaction.Tare3 > 0)
                {
                    line = PadTitle("Tare3") + CurrentTransaction.Tare3.ToString("N2") + "t" + tareType;
                    ticket.Add(line);
                }

                if (CurrentTransaction.Tare4 > 0)
                {
                    line = PadTitle("Tare4") + CurrentTransaction.Tare4.ToString("N2") + "t" + tareType;
                    ticket.Add(line);
                }

                if (CurrentTransaction.Tare5 > 0)
                {
                    line = PadTitle("Tare5") + CurrentTransaction.Tare5.ToString("N2") + "t" + tareType;
                    ticket.Add(line);
                }
            }

            line = PadTitle("Tare") + CurrentTransaction.Tare.ToString("N2") + "t" + tareType;
            ticket.Add(line);
        }

        protected virtual void GeneratePrice()
        {
            string line = string.Empty;

            // line = " ";
            // ticket.Add(line);

            string priceType = "Price/t";
            //if (CurrentTransaction.LoadType == CoreConstants.Load_Counted) priceType = "Price/Item";
            //bool printPrice = ((CurrentTransaction.Payments != CoreConstants.PAYMENT_ACCOUNT) || ((CurrentTransaction.Payments == CoreConstants.PAYMENT_ACCOUNT) && !Config.TicketSettings.HidePriceForAccountPayment));

            if (PrintPrice)
            {
                if (CurrentTransaction.Customer != null && CurrentTransaction.Customer.FixedCharge > 0)
                {
                    priceType = "Fixed Price";
                }
                line = PadTitle(priceType) + CurrentTransaction.Price.ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);
            }

        }

        protected virtual void GenerateCharges()
        {
            string line = string.Empty;

            GeneratePrice();
            if (PrintPrice)
            {
                //Str(prMinChgWgtEachTime:4:2,sTemp);
                //PrntTextLine(iLineSp, iInd, y, 'Min. Cost Under '+sTemp + 't: ' + Real2StrWDM(prCurrentMinCost,8,2));
                line = PadTitle("Min. Cost") + CurrentTransaction.MinimumCharge.ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                if (CurrentTransaction.CustomerDiscount > 0)
                {
                    line = PadTitle("Cust Disc(%)") + CurrentTransaction.CustomerDiscount.ToString();
                    ticket.Add(line);
                }

                line = PadTitle("Cost") + (CurrentTransaction.TranCost).ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                line = PadTitle("GST") + CurrentTransaction.GST.ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

                if (CurrentTransaction.EPA > 0)
                {
                    line = PadTitle("EPA") + CurrentTransaction.EPA.ToString("C", CultureInfo.CurrentCulture);
                    ticket.Add(line);
                }

                if (CurrentTransaction.CartageCharge > 0)
                {
                    line = PadTitle("Cartage") + CurrentTransaction.CartageCharge.ToString("C", CultureInfo.CurrentCulture);
                    ticket.Add(line);
                }

                if (CurrentTransaction.CartageGST > 0)
                {
                    line = PadTitle("Cartage GST") + CurrentTransaction.CartageGST.ToString("C", CultureInfo.CurrentCulture);
                    ticket.Add(line);
                }

                //if (CurrentTransaction.Haulage > 0)
                //{
                //    line = PadTitle("Haulage") + CurrentTransaction.Haulage.ToString("C", CultureInfo.CurrentCulture);
                //    ticket.Add(line);
                //}

                line = PadTitle("Amount Due") + CurrentTransaction.TotalCost.ToString("C", CultureInfo.CurrentCulture);
                ticket.Add(line);

            }
        }

        public void GenerateFooter()
        {
            string line = string.Empty;

            if (!string.IsNullOrEmpty(CurrentTransaction.Payments))
            {
                line = PadTitle("Paid By") + CurrentTransaction.Payments;
                ticket.Add(line);
            }

            if (!string.IsNullOrEmpty(CurrentTransaction.DeliveryAddress))
            {
                line = PadTitle("Delivery Address") + CurrentTransaction.DeliveryAddress;
                ticket.Add(line);
            }

            if (Config.TicketSettings.PrintComment && (!string.IsNullOrEmpty(CurrentTransaction.Comment) && CurrentTransaction.Comment.Trim() != string.Empty))
            {
                line = PadTitle(Config.TicketSettings.CommentTitle) + CurrentTransaction.Comment;
                ticket.Add(line);
            }

            // Placeholder for driver's signature. Added by Abhay on 19-Nov-2018 during onsite visit.
            if (Config.TicketSettings.PrintSignatureLabel)
            {
                line = " ";
                ticket.Add(line);
                line = " ";
                ticket.Add(line);
                line = " ";
                ticket.Add(line);
                line = PadTitle("Signature") + "_________________________";
                ticket.Add(line);
                line = " ";
                ticket.Add(line);
                line = " ";
                ticket.Add(line);
            }

        }

        protected void GenerateBlankLines(int lines)
        {
            for (int i = 0; i < lines; i++)
            {
                ticket.Add("");
            }
        }

        public abstract List<string> GenerateTicket();

    }
}