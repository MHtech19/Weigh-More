﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace AWSWeighingService.Infrastructure
{
    public  enum ReplStateMachine
    {
        GetReplItem,
        GetCorrespondingEntity,
        GetReplDestinationUrl,
        ReplicateEntity,
        DeteleReplItem,
    }

    public enum ReplEntityType
    {
        None,
        Transaction,
        AxleGroup,
        Customer,
        Job,
        Site,
        Truck,
        Operator,
        VehicleType,
        TicketTypeRate,
        CustomerDallasIDAssignment,
        TruckDallasIDAssignment,
    }

    public enum OperationType
    {
        Insert,
        Update,
        Delete,
    }

    //public enum TicketPrintOut
    //{
    //    NormalA4    = 0,
    //    NormalPos   = 1,
    //    PlatformPos = 2,
    //}

    public enum TicketMedia
    {
        NA,
        Paper,
        Email,
        PaperAndEmail,
    }

    public enum DigitalOutputPort0
    {
        InLightRed = 0x01,
        InLightGreen = 0x02,
        OutLightRed = 0x04,
        OutLightGreen = 0x08,
        InGateDown = 0x10,
        InGateUp = 0x20,
        OutGateDown = 0x40,
        OutGateUp = 0x80,

    }

    public enum AustraliaStates
    {
        NSW,
        ACT,
        QLD,
        VIC,
        TAS,
        SA,
        NT,
        WA
    }

    public enum ExceptionalTransactionType
    {
        NA,
        TerminateFirstWeighAsGross,
        RegoHoldingTare,
        RegoFromHoldingTareHavingNet,
        
    }

    public enum CertificateStatus
    {
        NotDeployed,
        InTrialPeriod,
        InLastTenDaysTrialPeriod,
        TrialPeriodExpired,
        MaximumUsersExceed,
        InvalidCerfificateKey,
        Certified
    }

    public enum WMSEventTypes
    {
        [Description("System")]
        System = 0,
        [Description("First Weigh")]
        FirstWeigh = 1,
        [Description("InComplete Transaction")]
        IncompleteTransaction = 2,
        [Description("Complete Transaction")]
        CompleteTransaction = 3,
        [Description("Visiting")]
        Visiting = 4,
        [Description("Offence")]
        Offence = 5,
        [Description("Other")]
        Other = 6
    }
}

