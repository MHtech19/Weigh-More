﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AWSWeighingService.Infrastructure
{
    public interface IReplication
    {
        List<ReplicationLogItem> ReplLog { get; set; }

        void GetReplLogFromReplicationSource(string uriString);

         List<ReplicationLogItem> OptimiseReplLog(List<ReplicationLogItem> replLogParam);  //remove duplicated operations in the repl log

         void ApplyReplLog(List<ReplicationLogItem> replLogParam);

         void CleanupReplLogInReplicationSource();   //remote successfully replicated items in replication source db

         
    }

}
