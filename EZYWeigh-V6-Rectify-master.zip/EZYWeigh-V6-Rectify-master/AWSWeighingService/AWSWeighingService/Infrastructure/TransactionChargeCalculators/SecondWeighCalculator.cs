﻿using AWSWeighingService.Infrastructure.TransactionChargeCalculators;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Infrastructure.TransactionChargeCalculators
{
    public class SecondWeighCalculator : BaseCalculator
    {
        public SecondWeighCalculator(Transaction currentTran) : base(currentTran) { }

        public override void Calculate(List<JobProductPrice> jobProductPrices)
        {
            bool GSTApplies = true;

            currentTransaction.Price = 0;
            currentTransaction.TranCost = 0;
            currentTransaction.EPA = 0;
            currentTransaction.GST = 0;
            currentTransaction.TotalCost = 0;
            currentTransaction.CartageCharge = 0;
            currentTransaction.CartageCost = 0;
            currentTransaction.MinimumCharge = 0;

            if (currentTransaction.Direction == CoreConstants.DIRECTION_OUT)
            {
                if (currentTransaction.ChargeRate == CoreConstants.RATE_LOCAL)
                {
                    GSTApplies = currentTransaction.Product.OutLocalDiscountGST;
                    currentTransaction.Price = currentTransaction.Product.OutLocalDiscount;
                    currentTransaction.MinimumCharge = currentTransaction.Product.MinLocalDiscount;
                }
                else if (currentTransaction.ChargeRate == CoreConstants.RATE_VISITOR)
                {
                    GSTApplies = currentTransaction.Product.OutVisitStandardGST;
                    currentTransaction.Price = currentTransaction.Product.OutVisitStandard;
                    currentTransaction.MinimumCharge = currentTransaction.Product.MinVisitStandard;
                }
            }
            else 
            {
                if (currentTransaction.ChargeRate == CoreConstants.RATE_LOCAL)
                {
                    GSTApplies = currentTransaction.Product.InLocalDiscountGST;
                    currentTransaction.Price = currentTransaction.Product.InLocalDiscount;
                    currentTransaction.MinimumCharge = currentTransaction.Product.MinLocalDiscount;
                }
                else if (currentTransaction.ChargeRate == CoreConstants.RATE_VISITOR)
                {
                    GSTApplies = currentTransaction.Product.InVisitStandardGST;
                    currentTransaction.Price = currentTransaction.Product.InVisitStandard;
                    currentTransaction.MinimumCharge = currentTransaction.Product.MinVisitStandard;
                }
            }
            

            //calculate price
            if (currentTransaction.Job.Name != CoreConstants.NA)
            {
                var jobProduct = jobProductPrices.FirstOrDefault(jpp => jpp.JobID == currentTransaction.JobID && jpp.ProductID == currentTransaction.ProductID);
                currentTransaction.Price = (jobProduct != null) ? jobProduct.Price : 0;
                currentTransaction.CartageCharge = ((currentTransaction.Net * currentTransaction.Job.CartagePerTonne) > currentTransaction.Job.MinimumCartage) ? (currentTransaction.Net * currentTransaction.Job.CartagePerTonne) : currentTransaction.Job.MinimumCartage;
                currentTransaction.CartageCharge = decimal.Round(currentTransaction.CartageCharge, 2);
            }

            currentTransaction.TranCost = decimal.Round(currentTransaction.Price * currentTransaction.Net, 2);

            GSTApplies = !currentTransaction.Customer.NoGST;

            if ((currentTransaction.Customer.FixedCharge > 0) && (currentTransaction.Job.Name == CoreConstants.NA))
            {
                
                currentTransaction.TranCost = decimal.Round(currentTransaction.Customer.FixedCharge, 2);
                currentTransaction.Price = currentTransaction.TranCost;
                currentTransaction.MinimumCharge = currentTransaction.TranCost;
                currentTransaction.CartageCharge = 0;
            }
            else
            {
                currentTransaction.EPA = ((currentTransaction.Net * currentTransaction.Product.EPALevy) > currentTransaction.Product.MinEPALevy) ? (currentTransaction.Net * currentTransaction.Product.EPALevy) : currentTransaction.Product.MinEPALevy;
                currentTransaction.EPA = decimal.Round(currentTransaction.EPA, 2);
            }

            currentTransaction.TotalCost = currentTransaction.TranCost + currentTransaction.EPA + currentTransaction.CartageCharge;
            currentTransaction.TotalCost = decimal.Round(currentTransaction.TotalCost, 2);

            decimal gstExclusive = 0;
            if (GSTApplies)
            {
                gstExclusive = decimal.Round(currentTransaction.TotalCost / CoreConstants.GST_Rate, 2);
                currentTransaction.GST = currentTransaction.TotalCost - gstExclusive;
            }
            else
            {
                gstExclusive = decimal.Round(currentTransaction.CartageCharge / CoreConstants.GST_Rate, 2); //always charge currentTransaction.GST on cartage
                currentTransaction.GST = currentTransaction.CartageCharge - gstExclusive;
            }

            currentTransaction.TranCost = currentTransaction.TotalCost - gstExclusive - currentTransaction.EPA - currentTransaction.CartageCharge;

        }
    }
}