﻿using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Infrastructure.TransactionChargeCalculators
{
    public class StandardLoadCalculator :BaseCalculator
    {
        public StandardLoadCalculator(Transaction currentTran) : base(currentTran) { }

        public override void Calculate(List<JobProductPrice> jobProductPrices)
        {
            bool GSTApplies = true;

            currentTransaction.Price = 0;
            currentTransaction.TranCost = 0;
            currentTransaction.EPA = 0;
            currentTransaction.GST = 0;
            currentTransaction.TotalCost = 0;
            currentTransaction.TranCost = 0;
            currentTransaction.CartageCharge = 0;
            currentTransaction.CartageCost = 0;
            currentTransaction.MinimumCharge = 0;

           // if  (currentTransaction.Direction == CoreConstants.DIRECTION_IN) //GoodsInButton.Checked 
            {
                // psCurrentDirect = kpsInTitle;
                //prCO2Rate = prCO2Rate_In;
                if (currentTransaction.ChargeRate == CoreConstants.RATE_LOCAL) //LocalButton.Checked 
                {
                    currentTransaction.Price = currentTransaction.Vehicle.InLocalDiscount; //prTranCost = prInLocalCost;
                    GSTApplies = currentTransaction.Vehicle.InLocalDiscountGST;
                    //psMinGstApplies = psMinLocalGST;
                }
                else
                {
                    currentTransaction.Price = currentTransaction.Vehicle.InVisitStandard;
                    GSTApplies = currentTransaction.Vehicle.InVisitStandardGST;
                    //psMinGstApplies = psMinVisitGST;
                }
            }
            
            currentTransaction.Price = decimal.Round(currentTransaction.Price, 2);
            //currentTransaction.TranCost = currentTransaction.Price;
            decimal epaCharge = currentTransaction.Product.EPALevy * currentTransaction.Vehicle.NetWeight;
            currentTransaction.EPA = (epaCharge > currentTransaction.Product.MinEPALevy) ? epaCharge : currentTransaction.Product.MinEPALevy;
            currentTransaction.EPA = decimal.Round(currentTransaction.EPA, 2);
            currentTransaction.TotalCost = currentTransaction.Price + currentTransaction.EPA;

            decimal gstExclusive = 0;
            if (GSTApplies)
            {
                gstExclusive = decimal.Round(currentTransaction.TotalCost / CoreConstants.GST_Rate, 2);
                currentTransaction.GST = currentTransaction.TotalCost - gstExclusive;
                
            }

            currentTransaction.TranCost = currentTransaction.TotalCost - currentTransaction.GST;

        }
    }
}