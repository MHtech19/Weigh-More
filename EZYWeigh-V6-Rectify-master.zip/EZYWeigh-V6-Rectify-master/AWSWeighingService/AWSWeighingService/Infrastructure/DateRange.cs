﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Infrastructure
{
    public class DateRange : BindableBase
    {
        private DateTime _StartingDate;
        public DateTime StartingDate
        {
            get { return _StartingDate; }
            set { this.SetProperty(ref _StartingDate, value); }
        }

        private DateTime _EndingDate;
        public DateTime EndingDate
        {
            get { return _EndingDate; }
            set { this.SetProperty(ref _EndingDate, value); }
        }

        public int SiteID { get; set; }

        public DateRange(int siteID)
        {
            SiteID = siteID;
            StartingDate = DateTime.Today.Date.SetTime(0, 0, 0, 0); 
            EndingDate = DateTime.Today.Date.SetTime(23, 59, 0, 0);

        }
    }
}
