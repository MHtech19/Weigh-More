﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace AWSWeighingService.Infrastructure
{
    public class ExportFiles
    {
        public List<FileNames> GetFiles(int fileTypeID,string dbname)
        {
            string folderPath;
            switch (fileTypeID)
            {
                case 0:
                    folderPath =(string.IsNullOrEmpty(dbname))? "~/ExportFiles/Transactions": "~/ExportFiles/Transactions/"+ dbname.ToLower();
                    break;
                case 1:
                    folderPath = (string.IsNullOrEmpty(dbname)) ? "~/ExportFiles/Customers": "~/ExportFiles/Customers/" + dbname.ToLower(); ;
                    break;
                default:
                    folderPath = (string.IsNullOrEmpty(dbname)) ? "~/ExportFiles/Transactions" : "~/ExportFiles/Transactions/" + dbname.ToLower();
                    break;
            }

            bool exists = Directory.Exists(HostingEnvironment.MapPath(folderPath));
            if (!exists)
                Directory.CreateDirectory(HostingEnvironment.MapPath(folderPath));

            List<FileNames> lstFiles = new List<FileNames>();
            DirectoryInfo dirInfo = new DirectoryInfo(HostingEnvironment.MapPath(folderPath));
           
            int i = 0;
            foreach (var item in dirInfo.GetFiles().OrderByDescending(f => f.LastWriteTime))
            {

                lstFiles.Add(new FileNames() { FileId = i + 1, FileName = item.Name, FilePath = dirInfo.FullName + @"\" + item.Name, ExportType = fileTypeID });
                i = i + 1;
            }

            return lstFiles;
        }
    }
}