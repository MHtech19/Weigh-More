﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Infrastructure
{
    public class TransactionSummary
    {
        public string EntityName { get; set; }
        public int TranCount { get; set; }
        public decimal Gross1 { get; set; }
        public decimal Tare1 { get; set; }
        public decimal Net { get; set; }
        public decimal TranCost { get; set; }
        public decimal GST { get; set; }
        public decimal EPA { get; set; }
        public decimal CartageCharge { get; set; }
        public decimal CartageCost { get; set; }
        public decimal TotalCost { get; set; }
        public decimal Royalty { get; set; }
        public decimal CartageGST { get; set; }
        public string EntityName2 { get; set; }
        public string RowsItem { get; set; }
        public string ColumnsItem { get; set; }
    }   

    public class ReportViewerInfo
    {
        public string ReportPath { get; set; }
        public object ReportParams { get; set; }
        public string ReportDataSourceKey { get; set; }
        public object ReportDataSource { get; set; }
    }
}