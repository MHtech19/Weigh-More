﻿using AWSWeighingService.Infrastructure;
using AWSWeighingService.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.DAL
{
    public class DbInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<AWSWeighingServiceContext>
     {
        private string recordLine;
        private string[] recordArry;

        private Site centralSite;
        private Role adminRole;
        private Role operatorRole;
        private Customer customerNA ;
        private ProductCategory productCategoryNA;
        private Product productNA;
        private Destination destinationNA;
        private Source sourceNA;
        private Weighman masterWeighman;
        private Weighman awsWeighman;
        private Driver driverNA;
        private VehicleConfiguration vehicleConfigurationNA;
        private Mark markNA;
        private Container containerNA;
        private ExBin exBinNA;
        private Job jobNA;
        private Truck truckNA;
        private Vehicle vehicleNA;
        
        private List<Site> sites = new List<Site>();
        private List<Customer> customers = new List<Customer>();
        private List<Product> products = new List<Product>();
        private List<ProductCategory> productCategories = new List<ProductCategory>();
        private List<Job> jobs = new List<Job>();
        private List<Truck> trucks = new List<Truck>();
        private List<VehicleConfiguration> truckConfigurations = new List<VehicleConfiguration>();
        private List<Weighman> weighwen = new List<Weighman>();
        private List<Destination> destinations = new List<Destination>();
        private List<Source> sources = new List<Source>();
        private List<Vehicle> vehicles = new List<Vehicle>();
        private List<WeightMove> weightMoves = new List<WeightMove>();
        private List<Visitor> visitors = new List<Visitor>();
        private List<Offence> offences = new List<Offence>();       

        protected override void Seed(AWSWeighingServiceContext db)
        {
            CreateNAEntities(db);
            if (SingletonWebConfigAppSetttings.Instance.ImportFromFiles)
            {
                ImportWeighmen(db);
                ImportSites(db);
                ImportCustomers(db);
                ImportProductCategories(db);
                ImportDestinations(db);
                ImportSources(db);
                ImportTruckConfigurations(db);

                ImportProducts(db);
                ImportVehicles(db);
                ImportJobs(db);
                ImportTrucks(db);
               
            }
            else
            {
                ImportSites(db);
            }
        }

        private void CreateNAEntities(AWSWeighingServiceContext db)
        {
            string databaseName = db.Database.Connection.Database;

            string siteCount = "1";
            centralSite = new Site
            {
                Name = CoreConstants.CentralSiteName,
                Code = CoreConstants.CentralSiteName,
                Description = CoreConstants.CentralSiteName,
                SiteCount = siteCount.Encrypt(),

            };
            db.Sites.Add(centralSite);
            db.SaveChanges();
            
            adminRole = new Role
            {
                Name = "Administrator",
                CanNewProduct = true,
                CanEditProduct = true,
                CanNewProductCategory = true,
                CanEditProductCategory = true,
                CanNewCustomer = true,
                CanEditCustomer = true,
                CanNewDestination = true,
                CanEditDestination = true,
                CanNewSource = true,
                CanEditSource = true,
                CanNewJob = true,
                CanEditJob = true,
                CanNewTruck = true,
                CanEditTruck = true,
                CanNewTruckConfiguration = true,
                CanEditTruckConfiguration = true,
                CanNewVehicleType = true,
                CanEditVehicleType = true,
                CanNewWeighman = true,
                CanEditWeighman = true,
                CanNewDriver = true,
                CanEditDriver = true,
                CanNewTransaction = true,
                CanEditTransaction = true,
                CanReportProduct = true,
                CanReportProductCategory = true,
                CanReportCustomer = true,
                CanReportDestination = true,
                CanReportSource = true,
                CanReportJob = true,
                CanReportTruck = true,
                CanReportTruckConfiguration = true,
                CanReportVehicleType = true,
                CanReportWeighman = true,
                CanReportDriver = true,
                CanReportTransaction = true,
                CanNewRole = true,
                CanEditRole = true,
                CanReportRole = true,
            };

            operatorRole = new Role
            {
                Name = "Operator",
                CanNewProduct = false,
                CanEditProduct = false,
                CanNewProductCategory = false,
                CanEditProductCategory = false,
                CanNewCustomer = false,
                CanEditCustomer = false,
                CanNewDestination = false,
                CanEditDestination = false,
                CanNewSource = false,
                CanEditSource = false,
                CanNewJob = false,
                CanEditJob = false,
                CanNewTruck = false,
                CanEditTruck = false,
                CanNewTruckConfiguration = false,
                CanEditTruckConfiguration = false,
                CanNewVehicleType = false,
                CanEditVehicleType = false,
                CanNewWeighman = false,
                CanEditWeighman = false,
                CanNewDriver = false,
                CanEditDriver = false,
                CanNewTransaction = false,
                CanEditTransaction = false,
                CanReportProduct = false,
                CanReportProductCategory = false,
                CanReportCustomer = false,
                CanReportDestination = false,
                CanReportSource = false,
                CanReportJob = false,
                CanReportTruck = false,
                CanReportTruckConfiguration = false,
                CanReportVehicleType = false,
                CanReportWeighman = false,
                CanReportDriver = false,
                CanReportTransaction = false,
                CanNewRole = false,
                CanEditRole = false,
                CanReportRole = false,
            };

            db.Roles.Add(adminRole);
            db.Roles.Add(operatorRole);
            db.SaveChanges();

            if (databaseName != CoreConstants.AWSWeighingServiceDBName)
            {
                masterWeighman = new Weighman
                {
                    Name = databaseName + "." + CoreConstants.AdminRoleName,
                    Password = CoreConstants.AdminRoleName,
                    //ConfirmPassword = CoreConstants.AdminRoleName,
                    Description = CoreConstants.AdminRoleName,
                    IsAdmin = true,
                    DefaultLogon = false,
                    RoleID = adminRole.ID,
                };

                awsWeighman = new Weighman
                {
                    Name = databaseName + "." + CoreConstants.UserName,
                    Password = CoreConstants.UserName,
                    //ConfirmPassword = CoreConstants.UserName,
                    Description = CoreConstants.UserName,
                    IsAdmin = true,
                    DefaultLogon = true,
                    RoleID = adminRole.ID,
                };

            }
            else
            {
                masterWeighman = new Weighman
                {
                    Name = CoreConstants.MasterWeighmanName,
                    Password = CoreConstants.MasterWeighmanName,
                    //ConfirmPassword = CoreConstants.MasterWeighmanName,
                    Description = CoreConstants.MasterWeighmanName,
                    IsAdmin = true,
                    DefaultLogon = false,
                    RoleID = adminRole.ID,
                };

                awsWeighman = new Weighman
                {
                    Name = CoreConstants.AWSWeighmanName,
                    Password = CoreConstants.AWSWeighmanPassword,
                    //ConfirmPassword = CoreConstants.AWSWeighmanPassword,
                    Description = CoreConstants.AWSWeighmanName,
                    IsAdmin = true,
                    DefaultLogon = true,
                    RoleID = adminRole.ID,
                };

            }
            
            db.Weighmen.Add(masterWeighman);
            db.Weighmen.Add(awsWeighman);
            db.SaveChanges();

            productCategoryNA = new ProductCategory
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,

            };
            db.ProductCategories.Add(productCategoryNA);
            db.SaveChanges();

            customerNA = new Customer
            {
                Name = CoreConstants.NA,
                AccountNumber = CoreConstants.NA,
                Description = CoreConstants.NA,
                PaymentMethod = CoreConstants.PAYMENT_CASH,
                
            };
            db.Customers.Add(customerNA);
            db.SaveChanges();

            sourceNA = new Source
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,

            };
            db.Sources.Add(sourceNA);
            db.SaveChanges();

            destinationNA = new Destination
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,

            };
            db.Destinations.Add(destinationNA);
            db.SaveChanges();

            driverNA = new Driver
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,

            };
            db.Drivers.Add(driverNA);
            db.SaveChanges();

            vehicleConfigurationNA = new VehicleConfiguration
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,
            };

            db.VehicleConfigurations.Add(vehicleConfigurationNA);
            db.SaveChanges();

            markNA = new Mark
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,

            };
            db.Marks.Add(markNA);
            db.SaveChanges();

            containerNA = new Container
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,
            };
            db.Containers.Add(containerNA);
            db.SaveChanges();

            exBinNA = new ExBin
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,
            };
            db.ExBins.Add(exBinNA);
            db.SaveChanges();

            productNA = new Product
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,
            };
            db.Products.Add(productNA);
            db.SaveChanges();

            vehicleNA = new Vehicle
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,
            };
            db.Vehicles.Add(vehicleNA);
            db.SaveChanges();

            jobNA = new Job
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,
            };
            db.Jobs.Add(jobNA);
            db.SaveChanges();
            
            truckNA = new Truck
            {
                Name = CoreConstants.NA,
                Code = CoreConstants.NA,
                Description = CoreConstants.NA,
                VehicleID = Constants.NAEntityID,
            };
            db.Trucks.Add(truckNA);
            db.SaveChanges();
        }

        private void ImportSites(AWSWeighingServiceContext db)
        {
            int siteCount = 0;
            if (!SingletonWebConfigAppSetttings.Instance.ImportFromFiles)
            {
                var newSite = new Site
                {
                    Name = "Site1",
                    Code = "Site1",
                    Description = "First Site",

                };

                newSite.Customers = new List<Customer> { customerNA };
                newSite.Products = new List<Product> { productNA };
                newSite.Destinations = new List<Destination> { destinationNA };
                newSite.Sources = new List<Source> { sourceNA };
                newSite.Jobs = new List<Job> { jobNA };

                db.Sites.Add(newSite);
                CreateRealTimeWeightsForSite(db, newSite);
                db.SaveChanges();
                return;
            }

            {
                using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\SiteExport.csv"))
                {
                    while ((recordLine = importFile.ReadLine()) != null)
                    {

                        try
                        {
                            recordArry = recordLine.Split(',');

                            if ((recordArry[4] != "NAME") && (recordArry[4].ToUpper() != CoreConstants.NA) && (recordArry[4].ToUpper() != Constants.CentralSiteName))
                            {
                                var importEntity = new Site() { };

                                importEntity.Address1 = recordArry[0].Trim();
                                importEntity.Suburb = recordArry[1].Trim();
                                importEntity.Fax = recordArry[2].Trim();
                                importEntity.Mobile = recordArry[3].Trim();
                                importEntity.Name = recordArry[4].Trim();
                                importEntity.Description = recordArry[5].Trim();
                                importEntity.Phone = recordArry[6].Trim();
                                importEntity.Code = recordArry[7].Trim();
                                importEntity.State = recordArry[8].Trim();
                                importEntity.Postcode = recordArry[9].Trim();

                                if (String.IsNullOrEmpty(importEntity.Name))
                                {
                                    importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                                }
                                else if (importEntity.Name.Length > 40)
                                {
                                    importEntity.Name = importEntity.Name.Substring(0, 40);
                                }

                                if (String.IsNullOrEmpty(importEntity.Description))
                                {
                                    importEntity.Description = importEntity.Name;
                                }

                                if (String.IsNullOrEmpty(importEntity.Code))
                                {
                                    importEntity.Code = importEntity.Name;
                                }

                                importEntity.Customers = new List<Customer> { customerNA };
                                importEntity.Products = new List<Product> { productNA };
                                importEntity.Destinations = new List<Destination> { destinationNA };
                                importEntity.Sources = new List<Source> { sourceNA };
                                importEntity.Jobs = new List<Job> { jobNA };

                                sites.Add(importEntity);
                                siteCount++;
                            }
                        }
                        catch (Exception)
                        {

                            continue;
                        }

                    }

                    sites.ForEach(e => db.Sites.Add(e));
                    db.SaveChanges();

                    sites.ForEach(e => CreateRealTimeWeightsForSite(db, e));

                    var centralSite = db.Sites.Find(1);
                    centralSite.SiteCount = siteCount.ToString().Encrypt();
                    db.SaveChanges();

                }

            }
            
        }

        private void ImportCustomers(AWSWeighingServiceContext db)
        {
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\CustomerExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {

                    try
                    {
                        recordArry = recordLine.Split(',');

                        if ((recordArry[4] != "NAME") && (recordArry[4] != CoreConstants.NA))
                        {
                            var importEntity = new Customer() { };
                            importEntity.AccountNumber = recordArry[0].Trim();
                            importEntity.Suburb = recordArry[1].Trim();
                            importEntity.Description = recordArry[2].Trim();
                            importEntity.CustomerType = recordArry[3].Trim().ToUpper();
                            if ((importEntity.CustomerType != CoreConstants.CustomerType) && (importEntity.CustomerType != CoreConstants.SupplierType))
                            {
                                importEntity.CustomerType = CoreConstants.CustomerType;
                            }
                            importEntity.Name = recordArry[4].Trim();
                            importEntity.PaymentMethod = recordArry[5].Trim();
                            importEntity.Postcode = recordArry[6].Trim();
                            importEntity.State = recordArry[7].Trim();




                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.AccountNumber))
                            {
                                importEntity.AccountNumber = importEntity.Name;
                            }

                            importEntity.TicketCopies = 1;

                            importEntity.Active = true;

                            customers.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }
                }

                customers.ForEach(e => db.Customers.Add(e));
                db.SaveChanges();

            }

        }

        private void ImportProducts(AWSWeighingServiceContext db)
        {
            string strTemp, productCategoryName, sourceName, desinationName;
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\ProductExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');

                        if ((recordArry[0] != "COMMENT") && (recordArry[9] != CoreConstants.NA) && (recordArry[9] != "GENERAL WEIGHING"))
                        {
                            var importEntity = new Product() { };
                            importEntity.Description = recordArry[0].Trim();
                            desinationName = recordArry[1].Trim();
                            importEntity.InLocalDiscount = Decimal.Parse(recordArry[2].Trim());
                            importEntity.InVisitStandard = Decimal.Parse(recordArry[3].Trim());

                            strTemp = recordArry[4].Trim();
                            if (strTemp == "Yes")
                            {
                                importEntity.InLocalDiscountGST = true;
                                importEntity.InLocalDiscount = 1.1M * importEntity.InLocalDiscount; //Price GST inclusive
                            }
                            else
                            {
                                importEntity.InLocalDiscountGST = false;
                            }

                            strTemp = recordArry[5].Trim();
                            if (strTemp == "Yes")
                            {
                                importEntity.InVisitStandardGST = true;
                                importEntity.InVisitStandard = 1.1M * importEntity.InVisitStandard; //Price GST inclusive
                            }
                            else
                            {
                                importEntity.InVisitStandardGST = false;
                            }

                            importEntity.MinEPALevy = Decimal.Parse(recordArry[6].Trim());
                            importEntity.MinLocalDiscount = Decimal.Parse(recordArry[7].Trim());
                            importEntity.MinVisitStandard = Decimal.Parse(recordArry[8].Trim());

                            importEntity.Name = recordArry[9].Trim();  //name
                            importEntity.Code = recordArry[10].Trim(); //number

                            importEntity.EPALevy = Decimal.Parse(recordArry[11].Trim());  //EPA Charge

                            importEntity.OutLocalDiscount = Decimal.Parse(recordArry[12].Trim());
                            importEntity.OutVisitStandard = Decimal.Parse(recordArry[13].Trim());

                            strTemp = recordArry[14].Trim();
                            if (strTemp == "Yes")
                            {
                                importEntity.OutLocalDiscountGST = true;
                                importEntity.OutLocalDiscount = 1.1M * importEntity.OutLocalDiscount; //Price GST inclusive
                            }
                            else
                            {
                                importEntity.OutLocalDiscountGST = false;
                            }

                            strTemp = recordArry[15].Trim();
                            if (strTemp == "Yes")
                            {
                                importEntity.OutVisitStandardGST = true;
                                importEntity.OutVisitStandard = 1.1M * importEntity.OutVisitStandard; //Price GST inclusive
                            }
                            else
                            {
                                importEntity.OutVisitStandardGST = false;
                            }

                            productCategoryName = recordArry[16].Trim();

                            strTemp = recordArry[17].Trim().ToUpper();
                            if (strTemp == CoreConstants.ProductType_Weighed)
                            {
                                importEntity.ProductType = strTemp; //weighed
                            }
                            else
                            {
                                importEntity.ProductType = CoreConstants.ProductType_Counted; //counted
                            }

                            sourceName = recordArry[18].Trim();

                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.Code))
                            {
                                importEntity.Code = importEntity.Name;
                            }

                            if (!String.IsNullOrEmpty(productCategoryName) && (productCategoryName != CoreConstants.NA))
                            {
                                var entity = db.ProductCategories.FirstOrDefault(e => e.Name == productCategoryName);
                                if (entity != null)
                                {
                                    importEntity.ProductCategoryID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(sourceName) && (sourceName != CoreConstants.NA))
                            {
                                var entity = db.Sources.FirstOrDefault(e => e.Name == sourceName);
                                if (entity != null)
                                {
                                    importEntity.SourceID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(desinationName) && (desinationName != CoreConstants.NA))
                            {
                                var entity = db.Destinations.FirstOrDefault(e => e.Name == desinationName);
                                if (entity != null)
                                {
                                    importEntity.DestinationID = entity.ID;
                                }
                            }

                            products.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                products.ForEach(e => db.Products.Add(e));
                db.SaveChanges();
            }

        }

        private void ImportProductCategories(AWSWeighingServiceContext db)
        {
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\ProductCategoryExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');
                        if ((recordArry[0] != "COMMENT") && (recordArry[1] != CoreConstants.NA))
                        {
                            var importEntity = new ProductCategory() { };
                            importEntity.Description = recordArry[0].Trim();
                            importEntity.Name = recordArry[1].Trim();
                            importEntity.Code = recordArry[2].Trim();


                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.Code))
                            {
                                importEntity.Code = importEntity.Name;
                            }

                            productCategories.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                productCategories.ForEach(e => db.ProductCategories.Add(e));
                db.SaveChanges();
            }
        }

        private void ImportJobs(AWSWeighingServiceContext db)
        {
            string customerName, productName, destinationName, sourceName;
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\JobExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {

                    try
                    {
                        recordArry = recordLine.Split(',');

                        if ((recordArry[7] != "NAME") && (recordArry[7] != CoreConstants.NA))
                        {
                            var importEntity = new Job();

                            customerName = recordArry[0].Trim();
                            importEntity.JobAddress1 = recordArry[1].Trim();
                            importEntity.JobSuburb = recordArry[2].Trim();
                            importEntity.JobPhone = recordArry[3].Trim();
                            importEntity.JobPostcode = recordArry[4].Trim();
                            importEntity.JobState = recordArry[5].Trim();
                            destinationName = recordArry[6].Trim();
                            importEntity.Name = recordArry[7].Trim();
                            importEntity.Code = recordArry[8].Trim();
                            importEntity.OrderNumber = recordArry[9].Trim();
                            productName = recordArry[10].Trim();
                            sourceName = recordArry[11].Trim();

                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.Code))
                            {
                                importEntity.Code = importEntity.Name;
                            }

                            if (!String.IsNullOrEmpty(customerName) && (customerName != CoreConstants.NA))
                            {
                                var entity = db.Customers.FirstOrDefault(e => e.Name == customerName);
                                if (entity != null)
                                {
                                    importEntity.CustomerID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(productName) && (productName != CoreConstants.NA))
                            {
                                var entity = db.Products.FirstOrDefault(e => e.Name == productName);
                                if (entity != null)
                                {
                                    importEntity.ProductID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(sourceName) && (sourceName != CoreConstants.NA))
                            {
                                var entity = db.Sources.FirstOrDefault(e => e.Name == sourceName);
                                if (entity != null)
                                {
                                    //importEntity.SourceID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(destinationName) && (destinationName != CoreConstants.NA))
                            {
                                var entity = db.Destinations.FirstOrDefault(e => e.Name == destinationName);
                                if (entity != null)
                                {
                                    //importEntity.DestinationID = entity.ID;
                                }
                            }




                            jobs.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }
                }

                jobs.ForEach(e => db.Jobs.Add(e));
                db.SaveChanges();

            }

        }

        private void ImportTrucks(AWSWeighingServiceContext db)
        {
            string customerName, destinationName, sourceName, productName, jobName, driverName, markName, vehicleConfigName;
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\TruckExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');
                        if ((recordArry[10] != "NAME") && (recordArry[10] != CoreConstants.NA))
                        {
                            var importEntity = new Truck();
                            if (recordArry[0].Trim() == "L")
                            {
                                importEntity.ChargeRate = CoreConstants.RATE_LOCAL;
                            }
                            else
                            {
                                importEntity.ChargeRate = CoreConstants.RATE_VISITOR;
                            }
                            importEntity.Code = recordArry[1].Trim();
                            customerName = recordArry[2].Trim();
                            destinationName = recordArry[3].Trim();
                            importEntity.TagID = recordArry[4].Trim();
                            driverName = recordArry[5].Trim();
                            importEntity.Fleet = recordArry[6].Trim();
                            jobName = recordArry[7].Trim();
                            markName = recordArry[8].Trim();
                            importEntity.MaxLoad = Decimal.Parse(recordArry[9].Trim());
                            importEntity.Name = recordArry[10].Trim();
                            productName = recordArry[11].Trim();
                            importEntity.Registration2 = recordArry[12].Trim();
                            importEntity.Registration3 = recordArry[13].Trim();
                            sourceName = recordArry[14].Trim();
                            importEntity.Tare1 = Decimal.Parse(recordArry[15].Trim());
                            importEntity.Tare2 = Decimal.Parse(recordArry[16].Trim());
                            importEntity.Tare3 = Decimal.Parse(recordArry[17].Trim());
                            importEntity.Tare4 = Decimal.Parse(recordArry[18].Trim());
                            importEntity.Tare5 = Decimal.Parse(recordArry[19].Trim());
                            importEntity.TareTerm = int.Parse(recordArry[20]);
                            vehicleConfigName = recordArry[21].Trim();


                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.Code))
                            {
                                importEntity.Code = importEntity.Name;
                            }

                            if (!String.IsNullOrEmpty(customerName) && (customerName != CoreConstants.NA))
                            {
                                var entity = db.Customers.FirstOrDefault(e => e.Name == customerName);
                                if (entity != null)
                                {
                                    // importEntity.CustomerID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(destinationName) && (destinationName != CoreConstants.NA))
                            {
                                var entity = db.Destinations.FirstOrDefault(e => e.Name == destinationName);
                                if (entity != null)
                                {
                                    //importEntity.DestinationID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(driverName) && (driverName != CoreConstants.NA))
                            {
                                var entity = db.Drivers.FirstOrDefault(e => e.Name == driverName);
                                if (entity != null)
                                {
                                    importEntity.DriverID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(jobName) && (jobName != CoreConstants.NA))
                            {
                                var entity = db.Jobs.FirstOrDefault(e => e.Name == jobName);
                                if (entity != null)
                                {
                                    // importEntity.JobID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(markName) && (markName != CoreConstants.NA))
                            {
                                var entity = db.Marks.FirstOrDefault(e => e.Name == markName);
                                if (entity != null)
                                {
                                    importEntity.MarkID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(productName) && (productName != CoreConstants.NA))
                            {
                                var entity = db.Products.FirstOrDefault(e => e.Name == productName);
                                if (entity != null)
                                {
                                    //importEntity.ProductID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(sourceName) && (sourceName != CoreConstants.NA))
                            {
                                var entity = db.Sources.FirstOrDefault(e => e.Name == sourceName);
                                if (entity != null)
                                {
                                    // importEntity.SourceID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(vehicleConfigName) && (vehicleConfigName != CoreConstants.NA))
                            {
                                var entity = db.VehicleConfigurations.FirstOrDefault(e => e.Name == vehicleConfigName);
                                if (entity != null)
                                {
                                    //importEntity.VehicleConfigurationID = entity.ID;
                                }
                            }

                            if (importEntity.HasStoredTare && importEntity.TareTerm > 0)
                            {
                                importEntity.LoadType = CoreConstants.Load_Second;
                                importEntity.LastTareDate = DateTime.Now;
                            }

                            {
                                var entity = db.Vehicles.FirstOrDefault(e => e.Name == CoreConstants.NA);
                                importEntity.VehicleID = entity.ID;
                            }


                            trucks.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                trucks.ForEach(e => db.Trucks.Add(e));
                db.SaveChanges();
            }
        }

        // Commented this function for now. no where it is called
        /*
        private void ImportTransactions(AWSWeighingServiceContext db)
        {
            string siteName, operatorName, customerName, destinationName, sourceName, productName, truckName, jobName, driverName, markName, vehicleConfigName, vehicleName, strDate, strTime;
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\TransactExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    //try
                   // {
                        recordArry = recordLine.Split(',');
                        if (recordArry[0] != "AA_OPERATOR")
                        {
                            var importEntity = new Transaction();

                            operatorName = recordArry[0].Trim();
                            importEntity.CartageCharge = Decimal.Parse(recordArry[1].Trim());
                            importEntity.CartageCost = Decimal.Parse(recordArry[2].Trim());
                            importEntity.Comment = recordArry[3].Trim();
                            customerName = recordArry[4].Trim();
                            strDate = recordArry[5].Trim();
                            strDate = strDate.Substring(6, 2) + "/" + strDate.Substring(4, 2) + "/" + strDate.Substring(0, 4);
                            destinationName = recordArry[6].Trim();
                            importEntity.Direction = recordArry[7].Trim();
                            importEntity.Docket = recordArry[8].Trim();
                            driverName = recordArry[9].Trim();
                            importEntity.EPA = Decimal.Parse(recordArry[10].Trim());
                            importEntity.Gross1 = Decimal.Parse(recordArry[11].Trim());
                            importEntity.Gross2 = Decimal.Parse(recordArry[12].Trim());
                            importEntity.Gross3 = Decimal.Parse(recordArry[13].Trim());
                            importEntity.Gross4 = Decimal.Parse(recordArry[14].Trim());
                            importEntity.Gross5 = Decimal.Parse(recordArry[15].Trim());
                            importEntity.GST = Decimal.Parse(recordArry[16].Trim());
                            importEntity.LoadType = recordArry[17].Trim();
                            switch (importEntity.LoadType)
                            {
                                case "STD":
                                    importEntity.LoadType = CoreConstants.Load_Standard;
                                    break;
                                case "2nd":
                                    importEntity.LoadType = CoreConstants.Load_StoredTare;
                                    break;
                                case "1n2":
                                    importEntity.LoadType = CoreConstants.Load_Second;
                                    break;
                                case "Yes":
                                    importEntity.LoadType = CoreConstants.Load_Counted;
                                    break;
                                case "Reg":
                                    importEntity.LoadType = CoreConstants.Load_Rego;
                                    break;
                                case "MIX":
                                    importEntity.LoadType = CoreConstants.Load_Mixed;
                                    break;
                                default:
                                    importEntity.LoadType = CoreConstants.Load_StoredTare;
                                    break;
                            }

                            jobName = recordArry[18].Trim();
                            markName = recordArry[19].Trim();
                            importEntity.Net = Decimal.Parse(recordArry[20].Trim());
                            importEntity.OrderNumber = recordArry[21].Trim();
                            importEntity.Payments = recordArry[22].Trim();
                            productName = recordArry[23].Trim();
                            importEntity.Registration1 = recordArry[25].Trim();
                            siteName = recordArry[26].Trim();
                            sourceName = recordArry[27].Trim();
                            importEntity.Tare1 = Decimal.Parse(recordArry[28].Trim());
                            importEntity.Tare2 = Decimal.Parse(recordArry[29].Trim());
                            importEntity.Tare3 = Decimal.Parse(recordArry[30].Trim());
                            importEntity.Tare4 = Decimal.Parse(recordArry[31].Trim());
                            importEntity.Tare5 = Decimal.Parse(recordArry[32].Trim());
                            strTime = recordArry[33].Trim();
                            importEntity.TotalCost = Decimal.Parse(recordArry[34].Trim());
                            truckName = recordArry[35].Trim();
                            vehicleConfigName = recordArry[36].Trim();
                            importEntity.Price = Decimal.Parse(recordArry[37].Trim());
                            importEntity.VehicleOwner = recordArry[38].Trim();
                            vehicleName = recordArry[39].Trim();

                            try
                            {
                                importEntity.TransactionDate = DateTime.Parse(strDate + " " + strTime);
                                importEntity.DateStamp = importEntity.TransactionDate.ToString("dd/MM/yyyy");

                            }
                            catch (Exception)
                            {

                                continue;
                            }

                            if (!String.IsNullOrEmpty(customerName) && (customerName != CoreConstants.NA))
                            {
                                var entity = db.Customers.FirstOrDefault(e => e.Name == customerName);
                                if (entity != null)
                                {
                                    importEntity.CustomerID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(destinationName) && (destinationName != CoreConstants.NA))
                            {
                                var entity = db.Destinations.FirstOrDefault(e => e.Name == destinationName);
                                if (entity != null)
                                {
                                    importEntity.DestinationID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(driverName) && (driverName != CoreConstants.NA))
                            {
                                var entity = db.Drivers.FirstOrDefault(e => e.Name == driverName);
                                if (entity != null)
                                {
                                    importEntity.DriverID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(jobName) && (jobName != CoreConstants.NA))
                            {
                                var entity = db.Jobs.FirstOrDefault(e => e.Name == jobName);
                                if (entity != null)
                                {
                                    importEntity.JobID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(markName) && (markName != CoreConstants.NA))
                            {
                                var entity = db.Marks.FirstOrDefault(e => e.Name == markName);
                                if (entity != null)
                                {
                                    importEntity.MarkID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(productName) && (productName != CoreConstants.NA))
                            {
                                var entity = db.Products.FirstOrDefault(e => e.Name == productName);
                                if (entity != null)
                                {
                                    importEntity.ProductID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(sourceName) && (sourceName != CoreConstants.NA))
                            {
                                var entity = db.Sources.FirstOrDefault(e => e.Name == sourceName);
                                if (entity != null)
                                {
                                    importEntity.SourceID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(vehicleConfigName) && (vehicleConfigName != CoreConstants.NA))
                            {
                                var entity = db.VehicleConfigurations.FirstOrDefault(e => e.Name == vehicleConfigName);
                                if (entity != null)
                                {
                                    importEntity.VehicleConfigurationID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(operatorName))
                            {
                                if (operatorName.ToUpper() == Constants.AWSWeighmanName)
                                {
                                    importEntity.WeighmanID = Constants.AWSWeighmanID;
                                }
                                else if ((operatorName.ToUpper() != CoreConstants.NA) && (operatorName.ToUpper() != Constants.MasterWeighmanName))
                                {
                                    var entity = db.Weighmen.FirstOrDefault(e => e.Name == operatorName);
                                    if (entity != null)
                                    {
                                        importEntity.WeighmanID = entity.ID;
                                    }
                                }
                            }

                            if (!String.IsNullOrEmpty(siteName) && (siteName.ToUpper() != CoreConstants.NA) && (siteName.ToUpper() != Constants.CentralSiteName))
                            {
                                var entity = db.Sites.FirstOrDefault(e => e.Name == siteName);
                                if (entity != null)
                                {
                                    importEntity.SiteID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(vehicleName) && (vehicleName != CoreConstants.NA))
                            {
                                var entity = db.Vehicles.FirstOrDefault(e => e.Name == vehicleName);
                                if (entity != null)
                                {
                                    importEntity.VehicleID = entity.ID;
                                }
                            }

                            if (!String.IsNullOrEmpty(truckName) && (truckName != CoreConstants.NA))
                            {
                                var entity = db.Trucks.FirstOrDefault(e => e.Name == truckName);
                                if (entity != null)
                                {
                                    importEntity.TruckID = entity.ID;
                                }
                            }

                            Site site = db.Sites.Find(importEntity.SiteID);
                            if (site.CurrentDocket < Int32.Parse(importEntity.Docket))
                            {
                                site.CurrentDocket = Int32.Parse(importEntity.Docket);
                                db.Entry(site).State = EntityState.Modified;
                            }
                            db.Transactions.Add(importEntity);
                            db.SaveChanges();
                            //transactions.Add(importEntity);
                        }
                    }
                    //catch (Exception)
                    //{
                     //   continue;
                   // }

               // }

                //transactions.ForEach(e =>
                //{
                //    Site site = db.Sites.Find(e.SiteID);
                //    if (site.CurrentDocket < Int32.Parse(e.Docket))
                //    {
                //        site.CurrentDocket = Int32.Parse(e.Docket);
                //        db.Entry(site).State = EntityState.Modified;
                //    }
                //    db.Transactions.Add(e);
                //    db.SaveChanges();
                //});

            }
        } */

        // Commented this function for now. no where it is called

        /*  private void ImportOffences(AWSWeighingServiceContext db)
          {
              string strDate, strTime, operatorName, siteName;
              using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\OffenceTruckExport.csv"))
              {
                  while ((recordLine = importFile.ReadLine()) != null)
                  {
                      try
                      {
                          recordArry = recordLine.Split(',');
                          if ((recordArry[0] != "AA_OPERATOR"))
                          {
                              var importEntity = new Offence();
                              operatorName = recordArry[0].Trim();
                              importEntity.Description = recordArry[1].Trim();
                              strDate = recordArry[2].Trim();
                              importEntity.Name = recordArry[3].Trim();
                              siteName = recordArry[4].Trim();
                              strTime = recordArry[5].Trim();

                              importEntity.DateTimeIn = DateTime.Parse(strDate + " " + strTime);

                              if (!String.IsNullOrEmpty(operatorName))
                              {
                                  if (operatorName.ToUpper() == Constants.AWSWeighmanName)
                                  {
                                      importEntity.WeighmanID = Constants.AWSWeighmanID;
                                  }
                                  else if ((operatorName.ToUpper() != CoreConstants.NA) && (operatorName.ToUpper() != Constants.MasterWeighmanName))
                                  {
                                      var weighman = db.Weighmen.FirstOrDefault(e => e.Name == operatorName);
                                      if (weighman != null)
                                      {
                                          importEntity.WeighmanID = weighman.ID;
                                      }
                                  }

                              }

                              if (!String.IsNullOrEmpty(siteName) && (siteName.ToUpper() != CoreConstants.NA) && (siteName.ToUpper() != Constants.CentralSiteName))
                              {
                                  var site = db.Sites.FirstOrDefault(e => e.Name == siteName);
                                  if (site != null)
                                  {
                                      importEntity.SiteID = site.ID;
                                  }
                              }



                              offences.Add(importEntity);
                          }
                      }
                      catch (Exception)
                      {

                          continue;
                      }

                  }

                  offences.ForEach(e => db.Offences.Add(e));
                  db.SaveChanges();
              }

          }*/

        // Commented this function for now, no where it is called
        /*
        private void ImportVisitors(AWSWeighingServiceContext db)
        {
            string operatorName, siteName, hasLeft;
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\VisitorsExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');
                        if ((recordArry[0] != "AA_OPERATOR"))
                        {
                            var importEntity = new Visitor();
                            operatorName = recordArry[0].Trim();
                            importEntity.Description = recordArry[1].Trim();
                            importEntity.Organisation = recordArry[2].Trim();
                            hasLeft = recordArry[3].Trim();
                            if (hasLeft == "Yes") importEntity.HasLeft = true; else importEntity.HasLeft = false;
                            importEntity.Name = recordArry[4].Trim();
                            importEntity.Phone = recordArry[5].Trim();
                            importEntity.Reason = recordArry[6].Trim();
                            importEntity.Registration = recordArry[7].Trim();
                            siteName = recordArry[8].Trim();
                            importEntity.DateTimeIn = DateTime.Parse(recordArry[9].Trim());
                            if (!String.IsNullOrEmpty(recordArry[10].Trim())) importEntity.DateTimeOut = DateTime.Parse(recordArry[10].Trim());

                            importEntity.Visiting = recordArry[11].Trim();

                            if (!String.IsNullOrEmpty(operatorName))
                            {
                                if (operatorName.ToUpper() == Constants.AWSWeighmanName)
                                {
                                    importEntity.WeighmanID = Constants.AWSWeighmanID;
                                }
                                else if ((operatorName.ToUpper() != CoreConstants.NA) && (operatorName.ToUpper() != Constants.MasterWeighmanName))
                                {
                                    var entity = db.Weighmen.FirstOrDefault(e => e.Name == operatorName);
                                    if (entity != null)
                                    {
                                        importEntity.WeighmanID = entity.ID;
                                    }
                                }
                            }

                            if (!String.IsNullOrEmpty(siteName) && (siteName.ToUpper() != CoreConstants.NA) && (siteName.ToUpper() != Constants.CentralSiteName))
                            {
                                var entity = db.Sites.FirstOrDefault(e => e.Name == siteName);
                                if (entity != null)
                                {
                                    importEntity.SiteID = entity.ID;
                                }
                            }

                            visitors.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                visitors.ForEach(e => db.Visitors.Add(e));
                db.SaveChanges();
            }

        } */

        // Commented this function for now, no where it is called
            /*
        private void ImportWeightMoves(AWSWeighingServiceContext db)
        {
            string strDate, strTime, operatorName, siteName;
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\WeighPassExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');
                        if ((recordArry[0] != "AA_OPERATOR"))
                        {
                            var importEntity = new WeightMove();
                            operatorName = recordArry[0].Trim();
                            strDate = recordArry[1].Trim();
                            siteName = recordArry[2].Trim();
                            strTime = recordArry[3].Trim();

                            importEntity.Registration = recordArry[4].Trim();
                            importEntity.WeightPassed = Double.Parse(recordArry[5].Trim());
                            importEntity.IsWeighPass = true;
                            importEntity.DateTimeIn = DateTime.Parse(strDate + " " + strTime);

                            if (!String.IsNullOrEmpty(operatorName))
                            {
                                if (operatorName.ToUpper() == Constants.AWSWeighmanName)
                                {
                                    importEntity.WeighmanID = Constants.AWSWeighmanID;
                                }
                                else if ((operatorName.ToUpper() != CoreConstants.NA) && (operatorName.ToUpper() != Constants.MasterWeighmanName))
                                {
                                    var entity = db.Weighmen.FirstOrDefault(e => e.Name == operatorName);
                                    if (entity != null)
                                    {
                                        importEntity.WeighmanID = entity.ID;
                                    }
                                }
                            }


                            if (!String.IsNullOrEmpty(siteName) && (siteName.ToUpper() != CoreConstants.NA) && (siteName.ToUpper() != Constants.CentralSiteName))
                            {
                                var entity = db.Sites.FirstOrDefault(e => e.Name == siteName);
                                if (entity != null)
                                {
                                    importEntity.SiteID = entity.ID;
                                }
                            }



                            weightMoves.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                weightMoves.ForEach(e => db.WeightMoves.Add(e));
                db.SaveChanges();
            }

        } */

        private void CreateRealTimeWeightsForSite(AWSWeighingServiceContext db, Site aSite)
        {
            var initialSiteRealTimeWeights = new List<RealTimeWeight>
            {
                new RealTimeWeight
                {
                    PlatformID = "1",
                    Site = aSite,
                    Weighman = masterWeighman,
                    CurrentWeight = 0.00M,
                    DateTimeStamp = DateTime.Now,
                    
                    
                },

                new RealTimeWeight
                {
                    PlatformID = "2",
                    Site = aSite,
                    Weighman = masterWeighman,
                    CurrentWeight = 0.00M,
                    DateTimeStamp = DateTime.Now,
                    
                    
                },

                new RealTimeWeight
                {
                    PlatformID = "3",
                    Site = aSite,
                    Weighman = masterWeighman,
                    CurrentWeight = 0.00M,
                    DateTimeStamp = DateTime.Now,
                    
                    
                },

                new RealTimeWeight
                {
                    PlatformID = "4",
                    Site = aSite,
                    Weighman = masterWeighman,
                    CurrentWeight = 0.00M,
                    DateTimeStamp = DateTime.Now,
                    
                    
                },

                new RealTimeWeight
                {
                    PlatformID = "5",
                    Site = aSite,
                    Weighman = masterWeighman,
                    CurrentWeight = 0.00M,
                    DateTimeStamp = DateTime.Now,
                    
                },
            };

            initialSiteRealTimeWeights.ForEach(e => db.RealTimeWeights.Add(e));
            db.SaveChanges();
        }
        
        private void ImportWeighmen(AWSWeighingServiceContext db)
        {
            //string connStrName = db.Database.Connection.Database.
            string databaseName = db.Database.Connection.Database;
            if (databaseName == CoreConstants.AWSWeighingServiceDBName)
            {
                databaseName = string.Empty;
            }
            else
            {
                databaseName = databaseName + ".";
            }

            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\OperatorExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');
                        if ((recordArry[0] != "NAME") && (recordArry[0].ToUpper() != CoreConstants.NA) && (recordArry[0].ToUpper() != Constants.MasterWeighmanName) && (recordArry[0].ToUpper() != Constants.AWSWeighmanName))
                        {
                            var importEntity = new Weighman() { };

                            importEntity.Name = databaseName + recordArry[0].Trim();
                            importEntity.Password = recordArry[1].Trim();
                            //importEntity.ConfirmPassword = recordArry[1].Trim();
                            importEntity.Description = recordArry[0].Trim();
                            importEntity.IsAdmin = false;
                            importEntity.RoleID = 2;

                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            weighwen.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                weighwen.ForEach(e => db.Weighmen.Add(e));
                db.SaveChanges();
            }

        }

        private void ImportTruckConfigurations(AWSWeighingServiceContext db)
        {
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\TruckConfigurationExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');
                        if ((recordArry[1] != "NAME") && (recordArry[1] != CoreConstants.NA))
                        {
                            var importEntity = new VehicleConfiguration() { };
                            importEntity.Description = recordArry[0].Trim();
                            importEntity.Name = recordArry[1].Trim();
                            importEntity.Code = recordArry[2].Trim();


                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.Code))
                            {
                                importEntity.Code = importEntity.Name;
                            }

                            truckConfigurations.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                truckConfigurations.ForEach(e => db.VehicleConfigurations.Add(e));
                db.SaveChanges();
            }

        }

        private void ImportDestinations(AWSWeighingServiceContext db)
        {
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\DestinationExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');

                        if ((recordArry[3] != "NAME") && (recordArry[3] != CoreConstants.NA))
                        {
                            var importEntity = new Destination() { };
                            importEntity.Address1 = recordArry[0].Trim();
                            importEntity.Suburb = recordArry[1].Trim();
                            importEntity.Contact = recordArry[2].Trim();
                            importEntity.Name = recordArry[3].Trim();
                            importEntity.Code = recordArry[4].Trim();
                            importEntity.Phone = recordArry[5].Trim();
                            importEntity.Postcode = recordArry[6].Trim();
                            importEntity.State = recordArry[7].Trim();




                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.Code))
                            {
                                importEntity.Code = importEntity.Name;
                            }

                            destinations.Add(importEntity);

                        }

                    }
                    catch (Exception)
                    {

                        continue;
                    }
                }

                destinations.ForEach(e => db.Destinations.Add(e));
                db.SaveChanges();

            }

        }

        private void ImportSources(AWSWeighingServiceContext db)
        {

            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\SourceExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');

                        if ((recordArry[3] != "NAME") && (recordArry[3] != CoreConstants.NA))
                        {
                            var importEntity = new Source() { };
                            importEntity.Address1 = recordArry[0].Trim();
                            importEntity.Suburb = recordArry[1].Trim();
                            importEntity.Contact = recordArry[2].Trim();
                            importEntity.Name = recordArry[3].Trim();
                            importEntity.Code = recordArry[4].Trim();
                            importEntity.Phone = recordArry[5].Trim();
                            importEntity.Postcode = recordArry[6].Trim();
                            importEntity.State = recordArry[7].Trim();

                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.Code))
                            {
                                importEntity.Code = importEntity.Name;
                            }

                            sources.Add(importEntity);

                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                sources.ForEach(e => db.Sources.Add(e));
                db.SaveChanges();
            }

        }

        private void ImportVehicles(AWSWeighingServiceContext db)
        {
            string strTemp, productName;
            using (System.IO.StreamReader importFile = new System.IO.StreamReader(@"C:\AWS Imports\VehicleExport.csv"))
            {
                while ((recordLine = importFile.ReadLine()) != null)
                {
                    try
                    {
                        recordArry = recordLine.Split(',');

                        if ((recordArry[4] != "NAME") && (recordArry[4] != CoreConstants.NA))
                        {
                            var importEntity = new Vehicle() { };

                            importEntity.InLocalDiscount = Decimal.Parse(recordArry[0].Trim());
                            strTemp = recordArry[2].Trim();
                            if (strTemp == "Yes")
                            {
                                importEntity.InLocalDiscountGST = true;
                                importEntity.InLocalDiscount = 1.1M * importEntity.InLocalDiscount; //Price GST inclusive
                            }
                            else
                            {
                                importEntity.InLocalDiscountGST = false;
                            }

                            importEntity.InVisitStandard = Decimal.Parse(recordArry[1].Trim());
                            strTemp = recordArry[3].Trim();
                            if (strTemp == "Yes")
                            {
                                importEntity.InVisitStandardGST = true;
                                importEntity.InVisitStandard = 1.1M * importEntity.InVisitStandard; //Price GST inclusive
                            }
                            else
                            {
                                importEntity.InVisitStandardGST = false;
                            }


                            importEntity.Name = recordArry[4].Trim();
                            importEntity.NetWeight = Decimal.Parse(recordArry[5].Trim());
                            importEntity.Code = recordArry[6].Trim();

                            productName = recordArry[7].Trim();


                            if (String.IsNullOrEmpty(importEntity.Name))
                            {
                                importEntity.Name = "Name" + DateTime.Now.Millisecond.ToString();
                            }
                            else if (importEntity.Name.Length > 40)
                            {
                                importEntity.Name = importEntity.Name.Substring(0, 40);
                            }

                            if (String.IsNullOrEmpty(importEntity.Description))
                            {
                                importEntity.Description = importEntity.Name;
                            }

                            if (String.IsNullOrEmpty(importEntity.Code))
                            {
                                importEntity.Code = importEntity.Name;
                            }

                            if (!String.IsNullOrEmpty(productName) && (productName != CoreConstants.NA))
                            {
                                var entity = db.Products.FirstOrDefault(e => e.Name == productName);
                                if (entity != null)
                                {
                                    importEntity.ProductID = entity.ID;
                                }
                            }

                            vehicles.Add(importEntity);
                        }
                    }
                    catch (Exception)
                    {

                        continue;
                    }

                }

                vehicles.ForEach(e => db.Vehicles.Add(e));
                db.SaveChanges();
            }

        }
     }
}