﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace AWSWeighingService.DAL
{
    public class AWSWeighingServiceContext : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx

        public AWSWeighingServiceContext()
            : base("name=AWSWeighingServiceContext")
        {
            //base.Configuration.ProxyCreationEnabled = false;
            this.Database.CommandTimeout = 600;
        }

        public AWSWeighingServiceContext(string connStrName)
            : base("name=" + connStrName)
        {
            //base.Configuration.ProxyCreationEnabled = false;
            this.Database.CommandTimeout = 600;
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
        }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Customer> Customers { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.CustomerExt> CustomerExt { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Site> Sites { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.ProductCategory> ProductCategories { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Product> Products { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Transaction> Transactions { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Destination> Destinations { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Source> Sources { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Weighman> Weighmen { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Role> Roles{ get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.JobProductPrice> JobProductPrices { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.VehicleProductPrice> VehicleProductPrices { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Job> Jobs { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Vehicle> Vehicles { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Driver> Drivers { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Truck> Trucks { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Signature> Signatures { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.EPASource> EPASources { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Mark> Marks { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.VehicleConfiguration> VehicleConfigurations { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Container> Containers { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.ExBin> ExBins { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Visitor> Visitors { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.WeightMove> WeightMoves { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.Offence> Offences { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.RealTimeWeight> RealTimeWeights { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.ReplicationLogItem> ReplicationLogItems { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.ProductStockActivation> ProductStockActivations { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.ProductStockMovement> ProductStockMovements { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.TruckJobs> TruckJobs { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.TruckProducts> TruckProducts { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.TruckDestination> TruckDestination { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.TruckCustomers> TruckCustomers { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.TruckSource> TruckSource { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.TruckConfigs> TruckConfigs { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.TruckSuppliers> TruckSuppliers { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.JobDestination> JobDestination { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.JobSource> JobSource { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.ExportWizard> ExportWizard { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.FirstWeigh> FirstWeighs { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.WMSEventLog> WMSEventLogs { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.DestinationVehicleConfiguration> DestinationVehicleConfigurations { get; set; }

        public System.Data.Entity.DbSet<AWSWeighingService.Models.CameraSnapshot> CameraSnapshots { get; set; }
    }
}
