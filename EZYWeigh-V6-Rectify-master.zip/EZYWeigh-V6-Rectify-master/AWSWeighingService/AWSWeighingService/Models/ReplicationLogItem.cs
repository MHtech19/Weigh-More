﻿using AWSWeighingService.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace AWSWeighingService.Models
{
    public class ReplicationLogItem : IEntityID, IEquatable<ReplicationLogItem>
    {
        [HiddenInput(DisplayValue = false)]
        public int ID { get; set; }
       
        public int DestinationSiteID { get; set; }
        public string EntityType { get; set; }
        public int EntityID { get; set; }
        public string Operation { get; set; }
        public int SourceSiteID { get; set; }
        public DateTime LogCreated { get; set; }

        public bool Equals(ReplicationLogItem other)
        {
            //Check whether the compared object is null.
            if (Object.ReferenceEquals(other, null)) return false;

            //Check whether the compared object references the same data.
            if (Object.ReferenceEquals(this, other)) return true;

            //Check whether the EntityReplicationLogs' selected properties are equal.
            return DestinationSiteID.Equals(other.DestinationSiteID) &&
                   EntityType.Equals(other.EntityType) &&
                   EntityID.Equals(other.EntityID) &&
                   Operation.Equals(other.Operation)
                   ;
        }

        // If Equals() returns true for a pair of objects 
        // then GetHashCode() must return the same value for these objects.
        public override int GetHashCode()
        {
            //Get hash code for the DestinationSiteID field.
            int hashDestinationSiteID = DestinationSiteID.GetHashCode();

            //Get hash code for the EntityType field if it is not null.
            int hashEntityType = EntityType == null ? 0 : EntityType.GetHashCode();

            //Get hash code for the EntityID field.
            int hashEntityID = EntityID.GetHashCode();

            //Get hash code for the Operation field if it is not null.
            int hashOperation = Operation == null ? 0 : Operation.GetHashCode();

            //Calculate the hash code for the EntityReplicationLog.
            return hashDestinationSiteID ^ hashEntityType ^ hashEntityID ^ hashOperation;
        }


        public void Reset(int naEntityID)
        {
            
        }
    }


    
}
