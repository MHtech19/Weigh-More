﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace AWSWeighingService.Models
{
    public class TransactionReportViewModel
    {
        public string EntityType { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate {get;set;}

        public List<SelectListItem> EntitiesToSelect { get; set; }
        public List<string> SelectedEntities { get; set; }

        public List<SelectListItem> TicketTypesToSelect { get; set; }
        public List<string> SelectedTicketTypes { get; set; }
        //public PostedTicketTypes PostedTicketTypes { get; set; }

        //public List<SelectListItem> SitesToSelect { get; set; }
        //public int SiteID { get; set; }

        
    }

    //public class PostedTicketTypes
    //{
    //    public string[] IDs{get;set;}
    //}
}