using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;

using System.ComponentModel.DataAnnotations.Schema;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Customer : BindableBase, IEntityID, IEntityName 
    {
        public int ID { get; set; }

        private string _Name;
        [Required]
        [StringLength(100, ErrorMessage = "Name cannot be longer than 100 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }


        [JsonIgnore]
        public string Description { get; set; }

        private string _AccountNumber;
        [Required]
        [StringLength(100, ErrorMessage = "Account Number cannot be longer than 100 characters.")]
        public string AccountNumber
        {
            get { return _AccountNumber; }
            set { this.SetProperty(ref _AccountNumber, value); }
        }

        private string _PaymentMethod;
        public string PaymentMethod
        {
            get { return _PaymentMethod; }
            set { this.SetProperty(ref _PaymentMethod, value); }
        }

        private bool _SiteCreated;
        public bool SiteCreated
        {
            get { return _SiteCreated; }
            set { this.SetProperty(ref _SiteCreated, value); }
        }

        
        public string Address1 { get; set; }
        [JsonIgnore]
        public string Address2 { get; set; }
        
        public string Suburb { get; set; }
        [JsonIgnore]
        public string State { get; set; }
       
        public string Postcode { get; set; }
        [JsonIgnore]
        public string Country { get; set; }

        private string _Phone;
        public string Phone
        {
            get { return _Phone; }
            set { this.SetProperty(ref _Phone, value); }
        }

        [JsonIgnore]
        public string Fax { get; set; }

        private string _Mobile;
        public string Mobile
        {
            get { return _Mobile; }
            set { this.SetProperty(ref _Mobile, value); }
        }

        private string _Contact;
        public string Contact
        {
            get { return _Contact; }
            set { this.SetProperty(ref _Contact, value); }
        }

        [JsonIgnore]
        public string Comment { get; set; }

        private string _Email;
        public string Email 
        {
            get { return _Email; }
            set { this.SetProperty(ref _Email, value); }
        }

        [JsonIgnore]
        public string ABN { get; set; }

        [JsonIgnore]
        public string Delivery { get; set; }
        [JsonIgnore]
        public string DeliveryAddress1 { get; set; }
        [JsonIgnore]
        public string DeliveryAddress2 { get; set; }
        [JsonIgnore]
        public string DeliverySuburb { get; set; }
        [JsonIgnore]
        public string DeliveryState { get; set; }
        [JsonIgnore]
        public string DeliveryPostcode { get; set; }
        [JsonIgnore]
        public string DeliveryZone { get; set; }
        [JsonIgnore]
        public string DeliveryPhone { get; set; }

        private string _TagID;
        public string TagID
        {
            get { return _TagID; }
            set { this.SetProperty(ref _TagID, value); }
        }


        public string CustomerType { get; set; }

        private decimal _FixedCharge;
        public decimal FixedCharge
        {
            get { return _FixedCharge; }
            set { this.SetProperty(ref _FixedCharge, value); }
        }

        private decimal _Discount;
        public decimal Discount
        {
            get { return _Discount; }
            set { this.SetProperty(ref _Discount, value); }
        }

        private bool _NoGST;
        public bool NoGST
        {
            get { return _NoGST; }
            set { this.SetProperty(ref _NoGST, value); }
        }

        private bool _Active;
        public bool Active
        {
            get { return _Active; }
            set { this.SetProperty(ref _Active, value); }
        }

        private bool _HidePriceOnTicket;
        public bool HidePriceOnTicket
        {
            get { return _HidePriceOnTicket; }
            set { this.SetProperty(ref _HidePriceOnTicket, value); }
        }

        private int _TicketCopies;
        public int TicketCopies
        {
            get { return _TicketCopies; }
            set { this.SetProperty(ref _TicketCopies, value); }
        }

        private decimal _FixedCartage;
        public decimal FixedCartage
        {
            get { return _FixedCartage; }
            set { this.SetProperty(ref _FixedCartage, value); }
        }

        private bool _IsOrderNoRequired;
        public bool IsOrderNoRequired
        {
            get { return _IsOrderNoRequired; }
            set { this.SetProperty(ref _IsOrderNoRequired, value); }
        }

        // [JsonIgnore]
        // public virtual ICollection<Transaction> Transactions { get; set; }

        [JsonIgnore]
        public virtual ICollection<Site> Sites { get; set; }

        [NotMapped]
        public bool IsSelected { set; get; }

        [JsonIgnore]
        public string DocketInitials { get; set; }

        public Customer()
        {
            Reset(Constants.NAEntityID);
        }


        public void Reset(int naEntityID)
        {
            FixedCharge = 0;
            SiteCreated = false;
        }

    }
}
