﻿using AWSWeighingService.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Models
{
    public class JobTonnage : IEntityID
    {
        public int ID { get; set; }

        // public int ProductID { get; set; }

        //public DateTime Today { get; set; }

        public decimal TodayTotal { get; set; }
        public decimal MonthlyTotal { get; set; }
        public decimal RunningTotal { get; set; }

        public decimal TonnesOrdered { get; set; }
        public decimal TonnesProcessed { get; set; }
        public decimal TonnesLeft { get; set; }

        public void Reset(int naEntityID)
        {
            //throw new NotImplementedException();
        }
    }
}