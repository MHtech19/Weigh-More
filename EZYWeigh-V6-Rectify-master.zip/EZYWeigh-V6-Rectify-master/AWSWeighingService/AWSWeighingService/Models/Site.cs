﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using WeighBridge.Core.MVVM;
using System.ComponentModel.DataAnnotations.Schema;

namespace AWSWeighingService.Models
{
    public class Site : BindableBase, IEntityID
    {
        public int ID { get; set; }

        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Code;
        [Required]
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code
        {
            get { return _Code; }
            set { this.SetProperty(ref _Code, value); }
        }


        [JsonIgnore]
        public string Description { get; set; }

        public int CurrentDocket { get; set; }
        public string DocketHead { get; set; }
        
        //web report will use the following 2 fields to populate report title sections from Central site
        public string Address1 { get; set; } //used as Organisation Name
        public string Address2 { get; set; } //used as Address
        public string Suburb { get; set; }
        public string State { get; set; }
        public string Postcode { get; set; }
        public string Country { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Mobile { get; set; }
        public string Contact { get; set; }
        
        public string Email { get; set; }
        //public bool TestToggle { get; set; } 

        public string Installed { get; set; }
        public string Certificate { get; set; }
        public string SiteCount { get; set; }

        [Display(Name = "Is All Product Prices Including GST Price")]
        public bool IsProductPricesIncludingGST { get; set; }

        [Display(Name = "Is All Vehicle Type Prices Including GST Price")]
        public bool IsVehicleTypePricesIncludingGST { get; set; }

        [Display(Name = "Is All Job Cartage Prices Including GST Price")]
        public bool IsJobCartagePricesIncludingGST { get; set; }

        [NotMapped]
        [Display(Name="No of Sites under this Organization")]
        public string NoOfSites { get; set; }

        [Display(Name = "No Of Users Allowed")]
        public Int32 NoOfUsersAllowed { get; set; }

        [JsonIgnore]
        public virtual ICollection<Customer> Customers { get; set; }

        [JsonIgnore]
        public virtual ICollection<Product> Products { get; set; }

        [JsonIgnore]
        public virtual ICollection<Destination> Destinations { get; set; }

        [JsonIgnore]
        public virtual ICollection<Source> Sources { get; set; }

        [JsonIgnore]
        public virtual ICollection<Weighman> Weighmen { get; set; }

        [JsonIgnore]
        public virtual ICollection<Job> Jobs { get; set; }

        [JsonIgnore]
        public virtual ICollection<Transaction> Transactions { get; set; }

        [JsonIgnore]
        public virtual ICollection<Offence> Offences { get; set; }

        [JsonIgnore]
        public virtual ICollection<Visitor> Visitors { get; set; }

        [JsonIgnore]
        public virtual ICollection<WeightMove> WeightMoves { get; set; }

        [JsonIgnore]
        public virtual ICollection<RealTimeWeight> RealTimeWeights { get; set; }

        [JsonIgnore]
        public virtual ICollection<Truck> Trucks { get; set; }

        //public string LastExportedToAccountsOn { get; set; }

        public Site()
        {
            Reset(Constants.NAEntityID);
            //Customers.Add(new Customer { ID = Constants.NAEntityID, Name = Constants.NAEntityName, });
            //Products.Add(new Product { ID = Constants.NAEntityID, Name = Constants.NAEntityName, });
            //Destinations.Add(new Destination { ID = Constants.NAEntityID, Name = Constants.NAEntityName, });
            //Sources.Add(new Source { ID = Constants.NAEntityID, Name = Constants.NAEntityName, });
        }

        public List<Site> ToList()
        {
            var singleSiteList = new List<Site>();
            singleSiteList.Add(this);

            return singleSiteList;
        }


        public void Reset(int naEntityID)
        {
            CurrentDocket = naEntityID;   
        }

        public string ComposeDisplayTitleForView(string inputString)
        {
            //return inputString + " @ " + Name;
            return inputString;
        }

        public string PrefixEntityName(string entityName, bool useCodeValue)
        {
            string prefixCode = Code + ".";
            string prefixName = Name + ".";

            if (useCodeValue)
            {   
                if (!entityName.StartsWith(prefixCode) && !entityName.StartsWith(prefixName))
                {
                    entityName = prefixCode + entityName;
                }
                else if (!entityName.StartsWith(prefixCode) && entityName.StartsWith(prefixName))
                {
                    entityName = entityName.Replace(prefixName, prefixCode);
                }

            }
            else
            {
                if (!entityName.StartsWith(prefixCode) && !entityName.StartsWith(prefixName))
                {
                    entityName = prefixName + entityName;
                }
                else if (!entityName.StartsWith(prefixName) && entityName.StartsWith(prefixCode))
                {
                    entityName = entityName.Replace(prefixCode, prefixName);
                }

            }

            return entityName;
        }
    }
}
