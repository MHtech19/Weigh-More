﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class ProductStockActivation : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public int ProductID { get; set; }
        [JsonIgnore]
        public virtual Product Product { get; set; }

        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }

        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }

        private decimal _STOCKLEVEL;
        public decimal STOCKLEVEL
        {
            get { return _STOCKLEVEL; }
            set { this.SetProperty(ref _STOCKLEVEL, value); }
        }

        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }
}