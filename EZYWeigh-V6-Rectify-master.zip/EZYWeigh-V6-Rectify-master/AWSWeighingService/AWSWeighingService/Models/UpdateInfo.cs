﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AWSWeighingService.Models
{
    public class UpdateInfo
    {
        [AllowHtml]
        public string UpdateDetails { get; set; }

        public int LinksCount { get; set; } = 0;
    }
}