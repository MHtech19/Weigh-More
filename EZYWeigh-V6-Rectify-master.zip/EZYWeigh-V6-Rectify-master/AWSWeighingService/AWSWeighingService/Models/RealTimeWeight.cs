﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class RealTimeWeight : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public decimal CurrentWeight { get; set; }
        
        public string PlatformID { get; set; }
        public DateTime DateTimeStamp { get; set; }

        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }

        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }

        public void Reset(int naEntityID)
        {
            SiteID = naEntityID;
            WeighmanID = naEntityID;
            PlatformID = naEntityID.ToString();
        }

        public RealTimeWeight()
        {
            Reset(Constants.NAEntityID);
        }

    }
}