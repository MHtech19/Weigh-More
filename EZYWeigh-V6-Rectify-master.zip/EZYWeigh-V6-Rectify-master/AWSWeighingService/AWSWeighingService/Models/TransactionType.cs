﻿using AWSWeighingService.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Models
{
    public class TransactionType : IEntityID, IEntityName
    {
        public int ID { get; set; }
        public string Name { get; set; }


        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }


}