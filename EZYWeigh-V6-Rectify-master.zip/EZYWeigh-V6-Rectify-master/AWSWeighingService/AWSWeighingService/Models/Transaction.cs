﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure.Ticket;
using AWSWeighingService.Infrastructure.TransactionChargeCalculators;
using Newtonsoft.Json;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WeighBridge.Core.MVVM;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Models
{
    public class Transaction : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public string Docket { get; set; }
        

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime TransactionDate { get; set; }

        public DateTime? TareInDate { get; set; }

        private string _LoadType = CoreConstants.Load_Second;
        public string LoadType
        {
            get { return _LoadType; }
            set { this.SetProperty(ref _LoadType, value); }
        }

        private string _Payments = CoreConstants.PAYMENT_ACCOUNT;
        public string Payments
        {
            get { return _Payments; }
            set { this.SetProperty(ref _Payments, value); }
        }

       
        private string _Direction = CoreConstants.DIRECTION_IN;
        //[Required]
        public string Direction
        {
            get { return _Direction; }
            set { this.SetProperty(ref _Direction, value); }
        }

        private string _VehicleOwner = CoreConstants.OWNER_PRIVATE;
        public string VehicleOwner
        {
            get { return _VehicleOwner; }
            set { this.SetProperty(ref _VehicleOwner, value); }
        }

        private string _ChargeRate = CoreConstants.RATE_LOCAL;
        public string ChargeRate
        {
            get { return _ChargeRate; }
            set { this.SetProperty(ref _ChargeRate, value); }
        }

        private string _OrderNumber = string.Empty;
        public string OrderNumber
        {
            get { return _OrderNumber; }
            set { this.SetProperty(ref _OrderNumber, value); }
        }

        private string _Comment = string.Empty;
        public string Comment
        {
            get { return _Comment; }
            //get { return GetWrappedComment(); }
            set { this.SetProperty(ref _Comment, value); }
        }

        private string _Registration1 = string.Empty;
//        [Required]
        [StringLength(40, ErrorMessage = "Registration1 cannot be longer than 40 characters.")]
        public string Registration1
        {
            get { return _Registration1; }
            set { this.SetProperty(ref _Registration1, value); }
        }

        private string _Registration2 = string.Empty;
        public string Registration2
        {
            get { return _Registration2; }
            set { this.SetProperty(ref _Registration2, value); }
        }

        private string _Registration3 = string.Empty;
        public string Registration3
        {
            get { return _Registration3; }
            set { this.SetProperty(ref _Registration3, value); }
        }

        //weights
        private decimal _Gross1;
        //[Required]
        //[RegularExpression("^[1-9]*$", ErrorMessage = "Gross1 must be numeric")]
        //[RegularExpression(@"\d+(\.\d{1,2})?", ErrorMessage = "Gross1 must be greater than zero ")]
        //[RegularExpression(@"^(?=.*[1-9])\d*(?:\.\d{1,2})?$", ErrorMessage = "Gross1 must be greater than zero")]
        [DefaultValue(0.00)]
        public decimal Gross1
        {
            get { return _Gross1; }
            set { this.SetProperty(ref _Gross1, value); }
        }

        private decimal _Gross2;
        [DefaultValue(0.00)]
        public decimal Gross2
        {
            get { return _Gross2; }
            set { this.SetProperty(ref _Gross2, value); }
        }

        private decimal _Gross3;
        [DefaultValue(0.00)]
        public decimal Gross3
        {
            get { return _Gross3; }
            set { this.SetProperty(ref _Gross3, value); }
        }

        private decimal _Gross4;
        [DefaultValue(0.00)]
        public decimal Gross4
        {
            get { return _Gross4; }
            set { this.SetProperty(ref _Gross4, value); }
        }

        private decimal _Gross5;
        [DefaultValue(0.00)]
        public decimal Gross5
        {
            get { return _Gross5; }
            set { this.SetProperty(ref _Gross5, value); }
        }

        [JsonIgnore]
        public decimal Gross
        {
            get
            {
                return Gross1 + Gross2 + Gross3 + Gross4 + Gross5;
            }
        }

        private decimal _Tare1;
        //[Required]
        //[RegularExpression("^[1-9]*$", ErrorMessage = "Gross1 must be numeric")]
        //[RegularExpression(@"\d+(\.\d{1,2})?", ErrorMessage = "Tare1 must be greater than zero ")]
        //[RegularExpression(@"^(?=.*[1-9])\d*(?:\.\d{1,2})?$", ErrorMessage = "Tare1 must be greater than zero")]       
        [DefaultValue(0.00)]
        public decimal Tare1
        {
            get { return _Tare1; }
            set { this.SetProperty(ref _Tare1, value); }
        }

        private decimal _Tare2;
        [DefaultValue(0.00)]
        public decimal Tare2
        {
            get { return _Tare2; }
            set { this.SetProperty(ref _Tare2, value); }
        }

        private decimal _Tare3;
        [DefaultValue(0.00)]
        public decimal Tare3
        {
            get { return _Tare3; }
            set { this.SetProperty(ref _Tare3, value); }
        }

        private decimal _Tare4;
        [DefaultValue(0.00)]
        public decimal Tare4
        {
            get { return _Tare4; }
            set { this.SetProperty(ref _Tare4, value); }
        }

        private decimal _Tare5;
        [DefaultValue(0.00)]
        public decimal Tare5
        {
            get { return _Tare5; }
            set { this.SetProperty(ref _Tare5, value); }
        }

        [JsonIgnore]
        public decimal Tare
        {
            get
            {
                return Tare1 + Tare2 + Tare3 + Tare4 + Tare5;
            }
        }

        private decimal _Net;
        [DefaultValue(0.00)]
        public decimal Net
        {
            get { return _Net; }
            set { this.SetProperty(ref _Net, value); }
        }

        public decimal Count { get; set; }

        [DefaultValue(0.00)]
        public decimal Royalty { get; set; }

        [DefaultValue(0.00)]
        public decimal ProductRoyalty { get; set; }

        [DefaultValue(0.00)]
        public decimal Price { get; set; }

        [DefaultValue(0.00)]
        public decimal EPARate { get; set; }

        [DefaultValue(0.00)]
        public decimal TranCost { get; set; }

        [DefaultValue(0.00)]
        public decimal TotalCost { get; set; }

        [DefaultValue(0.00)]
        public decimal CartageCharge { get; set; }

        [DefaultValue(0.00)]
        public decimal CartageCost { get; set; }

        [DefaultValue(0.00)]
        public decimal GST { get; set; }

        [DefaultValue(0.00)]
        public decimal EPA { get; set; }

        [DefaultValue(0.00)]
        public decimal MinimumCharge { get; set; }

        public int SiteID { get; set; }

        [DefaultValue(0.00)]
        public decimal Haulage { get; set; }

        public string DeliveryAddress { get; set; }

        [DefaultValue(0.00)]
        public decimal CartageGST { get; set; }

        [DefaultValue(0.00)]
        public decimal CustomerDiscount { get; set; }

        [JsonIgnore]
        public virtual Site Site { get; set; }

        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }

        //[Required]
        public int ProductCategoryID { get; set; }
        [JsonIgnore]
        public virtual ProductCategory ProductCategory { get; set; }

        //[Required]
        public int ProductID { get; set; }
        [JsonIgnore]
        public virtual Product Product { get; set; }

        //[Required]
        public int CustomerID { get; set; }
        [JsonIgnore]
        private Customer _Customer;
        [JsonIgnore]
       
        public virtual Customer Customer
        {
            get { return _Customer; }
            set
            {
                _Customer = value;
                //if (_Customer != null)
                //{
                //    Payments = _Customer.PaymentMethod;
                //}
            }
        }

        //[Required]
        public int DestinationID { get; set; }
        [JsonIgnore]
        public virtual Destination Destination { get; set; }

        //[Required]
        public int SourceID { get; set; }
        [JsonIgnore]
        public virtual Source Source { get; set; }

        //[Required]
        public int JobID { get; set; }
        [JsonIgnore]
        public virtual Job Job { get; set; }

        //[Required]
        public int TruckID { get; set; }
        [JsonIgnore]
        public virtual Truck Truck { get; set; }

        public int VehicleID { get; set; }
        [JsonIgnore]
        public virtual Vehicle Vehicle { get; set; }

        public int DriverID { get; set; }
        [JsonIgnore]
        public virtual Driver Driver { get; set; }

        public int VehicleConfigurationID { get; set; }
        [JsonIgnore]
        public virtual VehicleConfiguration VehicleConfiguration { get; set; }

        public int MarkID { get; set; }
        [JsonIgnore]
        public virtual Mark Mark { get; set; }

        public string DateStamp { get; set; }

//        [JsonIgnore]
        public bool ExportedToAccounting { get; set; }

        public bool IsManualEntry { get; set; }

        public bool Deleted { get; set; }

        public string VINNumber { get; set; }

        public decimal MaxLoad { get; set; }

        [NotMapped]
        [JsonIgnore]
        public bool IsShowAllJobsClicked { get; set; }

        [JsonIgnore]
        public virtual List<Product> SelectedMixedProducts { get; set; }

        //public bool Range { get; set; }
       
        public void CalculateCharges(List<JobProductPrice> jobProductPrices)
        {
            BaseCalculator priceCalculator = null;

            switch (LoadType)
            {
                case "Counted":
                case "StoredTare":
                case "ManualTare":
                case "Second": priceCalculator = new SecondWeighCalculator(this); break;
                case "Standard": priceCalculator = new StandardLoadCalculator(this); break;
                case "Rego": priceCalculator = new RegoLoadCalculator(this); break;
                case "Mixed": priceCalculator = new RegoLoadCalculator(this); break;
                default: break;
            }

            priceCalculator.Calculate(jobProductPrices);
            /*
            bool GSTApplies = true; 

            Price = 0;
            TranCost = 0;
            EPA = 0;
            GST = 0;
            TotalCost = 0;
            CartageCharge = 0;
            CartageCost = 0;
            MinimumCharge = 0;

            if (Direction == CoreConstants.DIRECTION_IN)
            {
                if (ChargeRate == CoreConstants.RATE_LOCAL)
                {
                    GSTApplies = Product.InLocalDiscountGST;
                    Price = Product.InLocalDiscount;
                    MinimumCharge = Product.MinLocalDiscount;
                }
                else if (ChargeRate == CoreConstants.RATE_VISITOR)
                {
                    GSTApplies = Product.InVisitStandardGST;
                    Price = Product.InVisitStandard;
                    MinimumCharge = Product.MinVisitStandard;
                }
            }
            else if (Direction == CoreConstants.DIRECTION_OUT)
            {
                if (ChargeRate == CoreConstants.RATE_LOCAL)
                {
                    GSTApplies = Product.OutLocalDiscountGST;
                    Price = Product.OutLocalDiscount;
                    MinimumCharge = Product.MinLocalDiscount;
                }
                else if (ChargeRate == CoreConstants.RATE_VISITOR)
                {
                    GSTApplies = Product.OutVisitStandardGST;
                    Price = Product.OutVisitStandard;
                    MinimumCharge = Product.MinVisitStandard;
                }
            }

            //calculate price
            if (Job.Name != CoreConstants.NA)
            {
                var jobProduct = jobProductPrices.FirstOrDefault(jpp => jpp.JobID == JobID && jpp.ProductID == ProductID);
                Price = (jobProduct != null) ? jobProduct.Price : 0;
                CartageCharge = ((Net * Job.CartagePerTonne) > Job.MinimumCartage) ? (Net * Job.CartagePerTonne) : Job.MinimumCartage;
                CartageCharge = decimal.Round(CartageCharge, 2);
            }

            TranCost = decimal.Round(Price * Net, 2);

            if ((Customer.FixedCharge > 0) && (Job.Name == CoreConstants.NA))
            {
                GSTApplies = !Customer.NoGST;
                TranCost = decimal.Round(Customer.FixedCharge, 2);
                Price = TranCost;
                MinimumCharge = TranCost;
                CartageCharge = 0;
            }
            else
            {
                EPA = ((Net * Product.EPALevy) > Product.MinEPALevy) ? (Net * Product.EPALevy) : Product.MinEPALevy;
                EPA = decimal.Round(EPA, 2);
            }

            TotalCost = TranCost + EPA + CartageCharge;
            TotalCost = decimal.Round(TotalCost, 2);

            decimal gstExclusive = 0;
            if (GSTApplies)
            {
                gstExclusive = decimal.Round(TotalCost / CoreConstants.GST_Rate, 2);
                GST = TotalCost - gstExclusive;
            }
            else
            {
                gstExclusive = decimal.Round(CartageCharge / CoreConstants.GST_Rate, 2); //always charge GST on cartage
                GST = CartageCharge - gstExclusive;
            }
            */


        }

        public List<string> GenerateTicket(AWSConfiguration _conf, bool isReprint)
        {
            BaseTicket tranTicket = new CountedTicket(_conf.TicketSettings.TicketTitle, isReprint, this, _conf);
            List<string> ticket = new List<string>();

            if ((TotalCost > 0) && (Payments == CoreConstants.PAYMENT_CASH) &&
                (_conf.ReplicationSettings.IsRoundOffCashPaymentToClosest5Cents))
            {
                TotalCost = (Math.Round(TotalCost * 20, MidpointRounding.AwayFromZero) / 20);
            }

            switch (LoadType)
            {
                case "Counted": tranTicket = new CountedTicket(_conf.TicketSettings.TicketTitle, isReprint, this, _conf); break;
                case "Standard": tranTicket = new StandardTicket(_conf.TicketSettings.TicketTitle, isReprint, this, _conf); break;
                case "Second": tranTicket = new SecondWeighTicket(_conf.TicketSettings.TicketTitle, isReprint, this, _conf); break;
                case "StoredTare": tranTicket = new StoredTareTicket(_conf.TicketSettings.TicketTitle, isReprint, this, _conf); break;
                case "ManualTare": tranTicket = new StoredTareTicket(_conf.TicketSettings.TicketTitle, isReprint, this, _conf); break;
                case "Rego": tranTicket = new RegoWeighTicket(_conf.TicketSettings.TicketTitle, isReprint, this, _conf); break;
                case "Mixed": tranTicket = new MixedLoadTicket(_conf.TicketSettings.TicketTitle, isReprint, this, _conf); break;
                default: break;
            }
            ticket = tranTicket.GenerateTicket();
            return ticket;
        }

        public Transaction()
        {
            SelectedMixedProducts = new List<Product>();
            Reset(CoreConstants.NA_ID);

        }

        public void Reset(int naEntityID)
        {
            TransactionDate = DateTime.Now;
            Gross1 = 0;
            Gross2 = 0;
            Gross3 = 0;
            Gross4 = 0;
            Gross5 = 0;
            Tare1 = 0;
            Tare2 = 0;
            Tare3 = 0;
            Tare4 = 0;
            Tare5 = 0;
            Net = 0;

            Price = 0;
            TranCost = 0;
            TotalCost = 0;
            CartageCharge = 0;
            CartageCost = 0;
            GST = 0;
            EPA = 0;
            MinimumCharge = 0;

            SiteID = naEntityID;
            WeighmanID = naEntityID;
            CustomerID = naEntityID;
            ProductCategoryID = naEntityID;
            ProductID = naEntityID;
            JobID = naEntityID;
            TruckID = naEntityID;
            DestinationID = naEntityID;
            SourceID = naEntityID;
            DriverID = naEntityID;
            VehicleConfigurationID = naEntityID;
            MarkID = naEntityID;
            VehicleID = naEntityID;

            TareInDate = null;
            Docket = string.Empty;

            Registration1 = string.Empty;
            Registration2 = string.Empty;
            Registration3 = string.Empty;

            LoadType = string.Empty;
            Direction = string.Empty;
            Comment = string.Empty;
            Payments = string.Empty;
            VehicleOwner = string.Empty;
            DateStamp = string.Empty;
            OrderNumber = string.Empty;

            Price = 0;
            TranCost = 0;
            TotalCost = 0;
            CartageCharge = 0;
            CartageCost = 0;
            GST = 0;
            EPA = 0;
            MinimumCharge = 0;

            Gross1 = 0;
            Gross2 = 0;
            Gross3 = 0;
            Gross4 = 0;
            Gross5 = 0;

            Tare1 = 0;
            Tare2 = 0;
            Tare3 = 0;
            Tare4 = 0;
            Tare5 = 0;

            Net = 0;

            SelectedMixedProducts.Clear();
            Haulage = 0;
        }

        //private string GetWrappedComment()
        //{
        //    string wrappedComment = _Comment;
        //    if (_Comment.Length > 30)
        //        wrappedComment = WrapText(_Comment, 150, "Courier New", 14);
        //    return wrappedComment;
        //}

        //private string WrapText(string text, double pixels, string fontFamily,
        //    float emSize)
        //{
        //    text = text.Replace("\n", "");
        //    text = text.Replace("\r", "");
        //    string[] originalLines = text.Split(new string[] { " " },
        //        StringSplitOptions.None);

        //    string wrappedComment = "";

        //    StringBuilder actualLine = new StringBuilder();
        //    double actualWidth = 0;

        //    foreach (var item in originalLines)
        //    {
        //        FormattedText formatted = new FormattedText(item,
        //            CultureInfo.CurrentCulture,
        //            System.Windows.FlowDirection.LeftToRight,
        //            new Typeface(fontFamily), emSize, System.Windows.Media.Brushes.Black);

        //        actualLine.Append(item + " ");
        //        if ((formatted.Text != "") && (formatted.Text != Environment.NewLine))
        //            actualWidth += formatted.Width;

        //        if ((actualWidth > pixels) && (wrappedComment == ""))
        //        {
        //            wrappedComment += actualLine.ToString() + " " + "\r\n";
        //            actualLine.Clear();
        //            actualWidth = 0;
        //        }
        //    }

        //    if (actualLine.Length > 0)
        //        wrappedComment += actualLine.ToString() + " " + "\r\n";

        //    wrappedComment = String.Format("{0}", wrappedComment.PadRight(30));

        //    return wrappedComment;
        //}
    }
}