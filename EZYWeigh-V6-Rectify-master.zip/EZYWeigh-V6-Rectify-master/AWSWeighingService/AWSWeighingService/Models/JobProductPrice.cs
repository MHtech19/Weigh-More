﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class JobProductPrice : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public int JobID { get; set; }
        [JsonIgnore]
        public Job Job { get; set; }

        public int ProductID { get; set; }
        [JsonIgnore]
        public Product Product { get; set; }

        public decimal Price { get; set; }


        public void Reset(int naEntityID)
        {
            ProductID = Constants.NAEntityID;
            JobID = Constants.NAEntityID;
            Price = 0;
        }
    }
}