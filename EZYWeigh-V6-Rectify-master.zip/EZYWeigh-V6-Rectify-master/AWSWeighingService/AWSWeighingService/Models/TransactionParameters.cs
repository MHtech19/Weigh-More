﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Models
{
    public class TransactionParameters
    {
        public string Payments { set; get; }
        public string LoadType { get; set; }
        public string Direction { get; set; }
        public string VehicleOwner { get; set; }
        public string ChargeRate { get; set; }

        public TransactionParameters()
        {
            Reset();
        }

        public void Reset()
        {
            Payments = string.Empty;
            LoadType = string.Empty;
            Direction = string.Empty;
            VehicleOwner = string.Empty;
            ChargeRate = string.Empty;
        }
    }
}