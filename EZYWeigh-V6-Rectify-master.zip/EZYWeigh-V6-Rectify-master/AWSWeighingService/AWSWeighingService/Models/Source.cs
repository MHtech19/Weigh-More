﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using System.ComponentModel.DataAnnotations.Schema;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Source : BindableBase, IEntityID
    {
        public int ID { get; set; }

        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Code;
        [Required]
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code
        {
            get { return _Code; }
            set { this.SetProperty(ref _Code, value); }
        }


        [JsonIgnore]
        public string Description { get; set; }

        public bool SiteCreated { get; set; }

        [JsonIgnore]
        public string Address1 { get; set; }
        [JsonIgnore]
        public string Address2 { get; set; }
        [JsonIgnore]
        public string Suburb { get; set; }
        [JsonIgnore]
        public string State { get; set; }
        [JsonIgnore]
        public string Postcode { get; set; }
        [JsonIgnore]
        public string Country { get; set; }

        private string _Phone;
        public string Phone
        {
            get { return _Phone; }
            set { this.SetProperty(ref _Phone, value); }
        }

        private string _Mobile;
        public string Mobile
        {
            get { return _Mobile; }
            set { this.SetProperty(ref _Mobile, value); }
        }

        private string _Email;
        public string Email
        {
            get { return _Email; }
            set { this.SetProperty(ref _Email, value); }
        }

        private string _Contact;
        public string Contact
        {
            get { return _Contact; }
            set { this.SetProperty(ref _Contact, value); }
        }

        public bool IsActive { get; set; }

        [JsonIgnore]
        public string Waste_Stream { get; set; }

        [JsonIgnore]
        public string Sub_Stream { get; set; }

        [JsonIgnore]
        public string OWF_Source { get; set; }

        [JsonIgnore]
        public string OWF_EPL_Number { get; set; }

        [JsonIgnore]
        public virtual ICollection<Site> Sites { get; set; }

        [NotMapped]
        public bool IsSelected { set; get; }

        public Source()
        {

            Reset(Constants.NAEntityID);
        }

        public void Reset(int naEntityID)
        {
            SiteCreated = false;

            Waste_Stream = CoreConstants.NA;

            Sub_Stream = CoreConstants.NA;

            OWF_Source = CoreConstants.NA;

            OWF_EPL_Number = CoreConstants.NA;
        }
    }
}
