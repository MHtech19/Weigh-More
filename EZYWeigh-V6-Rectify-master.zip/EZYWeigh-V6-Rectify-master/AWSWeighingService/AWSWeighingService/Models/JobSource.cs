﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{

    public class JobSource : BindableBase, IEntityID
    {

        public int ID { get; set; }

        public int JobID { get; set; }
        [JsonIgnore]
        public virtual Job Job { get; set; }

        public int SourceID { get; set; }
        [JsonIgnore]
        public virtual Source Source { get; set; }

        public void Reset(int naEntityID)
        {

        }
    }
}