﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class JobDestination : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public int JobID { get; set; }
        [JsonIgnore]
        public virtual Job Job { get; set; }

        public int DestinationID { get; set; }
        [JsonIgnore]
        public virtual Destination Destination { get; set; }

        public void Reset(int naEntityID)
        {

        }
    }
}