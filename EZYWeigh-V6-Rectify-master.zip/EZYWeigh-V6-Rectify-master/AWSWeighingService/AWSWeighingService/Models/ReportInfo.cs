﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Models
{
    public class ReportInfo
    {
        
        public string ReportName { get; set; }
        public string ReportDescription { get; set; }
        public string ReportPath{ get; set; }
        public string ReportCommand { get; set; }
        public string ReportSummary { get; set; }

        public string ReportURL
        {
            get
            {
                // example http://AWS-DEV-10/reportserver?/WeighMoreSolutionsReports/TransactionByDate&rs:Command=Render
                return ReportPath + "?/WeighMoreSolutionsReports/" + ReportName + ReportCommand;
            }
        }
    }
}