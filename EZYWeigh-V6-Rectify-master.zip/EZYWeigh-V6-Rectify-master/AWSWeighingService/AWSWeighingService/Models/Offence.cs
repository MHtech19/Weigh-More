﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using WeighBridge.Core.MVVM;
using System.ComponentModel.DataAnnotations.Schema;

namespace AWSWeighingService.Models
{
    public class Offence : BindableBase, IEntityID
    {
        public int ID { get; set; }
        
        [Required]
        [Display(Name="Rego")]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name { get; set; }
        public string Description { get; set; }        

        [Display(Name = "Date Time")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DateTimeIn { get; set; }

        [NotMapped]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime InTime { get; set; }

        public bool IsActive { get; set; }

        [Display(Name = "Site")]
        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }

        [Display(Name = "Weighman")]
        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }

        public Offence()
        {
            Reset(Constants.NAEntityID);
        }

        public void Reset(int naEntityID)
        {
            SiteID = naEntityID;
            WeighmanID = naEntityID;
        }
    }
}