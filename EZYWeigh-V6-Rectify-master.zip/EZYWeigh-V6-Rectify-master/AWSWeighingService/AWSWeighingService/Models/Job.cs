﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Abstract;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Job : BindableBase, IEntityID, IEntityName
    {
        public int ID { get; set; }


        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Code;
        [Required]
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code
        {
            get { return _Code; }
            set { this.SetProperty(ref _Code, value); }
        }


        //[JsonIgnore]
        public string Description { get; set; }

        private string _OrderNumber;
        //[Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string OrderNumber
        {
            get { return _OrderNumber; }
            set { this.SetProperty(ref _OrderNumber, value); }
        }
        
        public bool SiteCreated { get; set; }

        private decimal _CartageCostPerTonne;
        public decimal CartageCostPerTonne
        {
            get { return _CartageCostPerTonne; }
            set { this.SetProperty(ref _CartageCostPerTonne, value); }
        }

        private decimal _CartagePerTonne;
        public decimal CartagePerTonne
        {
            get { return _CartagePerTonne; }
            set { this.SetProperty(ref _CartagePerTonne, value); }
        }

        

        private decimal _MinimumCartage;
        public decimal MinimumCartage
        {
            get { return _MinimumCartage; }
            set { this.SetProperty(ref _MinimumCartage, value); }
        }

//        [JsonIgnore]
        public string Department { get; set; }

        public int CustomerID { get; set; }
        [JsonIgnore]
        public virtual Customer Customer { get; set; }

        //public int DestinationID { get; set; }
        //[JsonIgnore]
        //public virtual Destination Destination { get; set; }

        //public int SourceID { get; set; }
        //[JsonIgnore]
        //public virtual Source Source { get; set; }

        public int ProductID { get; set; }
        [JsonIgnore]
        public virtual Product Product { get; set; }

        public string JobAddress1 { get; set; }
//        [JsonIgnore]
        public string JobAddress2 { get; set; }
//        [JsonIgnore]
        public string JobSuburb { get; set; }
//        [JsonIgnore]
        public string JobState { get; set; }
//        [JsonIgnore]
        public string JobPostcode { get; set; }
//        [JsonIgnore]
        public string JobZone { get; set; }
//        [JsonIgnore]
        public string JobPhone { get; set; }

        public string JobEmail { get; set; }
      
        public bool IsActive { get; set; }

        public bool DocketsShouldBeSigned { get; set; }

        private decimal _OverLoadFee;
        [DefaultValue(0.00)]
        public decimal OverLoadFee
        {
            get { return _OverLoadFee; }
            set { this.SetProperty(ref _OverLoadFee, value); }
        }

        private decimal _TonnageFee;
        [DefaultValue(0.00)]
        public decimal TonnageFee
        {
            get { return _TonnageFee; }
            set { this.SetProperty(ref _TonnageFee, value); }
        }

        public string WorkOrderSystemCode { get; set; }

        [JsonIgnore]
        public virtual ICollection<Site> Sites { get; set; }

        [JsonIgnore]
        public virtual ICollection<JobProductPrice> JobProductPrices { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] JobDestination { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string JobDestinationValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] JobSource { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string JobSourceValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string DestinationNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string SourceNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public bool IsSelected { set; get; }

        private decimal _JobTonnesRunningTotal;
        public decimal JobTonnesRunningTotal
        {
            get { return _JobTonnesRunningTotal; }
            set { this.SetProperty(ref _JobTonnesRunningTotal, value); }
        }

        private decimal _JobTonnesOrdered;
        public decimal JobTonnesOrdered
        {
            get { return _JobTonnesOrdered; }
            set { this.SetProperty(ref _JobTonnesOrdered, value); }
        }

        public Job()
        {   
            Reset(Constants.NAEntityID);
        }



        public void Reset(int naEntityID)
        {
            CustomerID = naEntityID;
            ProductID = naEntityID;
            //DestinationID = naEntityID;
            //SourceID = naEntityID;

            SiteCreated = false;

            CartagePerTonne = 0;
            MinimumCartage = 0;
            CartageCostPerTonne = 0;
        }
    }
}
