﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using AWSWeighingService.Abstract;
using Newtonsoft.Json;
using AWSWeighingService.Infrastructure;
using WeighBridge.Core.MVVM;
using AWSWeighingService.DAL;
using System.Web.Mvc;

namespace AWSWeighingService.Models
{
   
    public class ProductCategory : BindableBase, IEntityID
    {
        
        public int ID { get; set; }

        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Code;
        [Required]
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code
        {
            get { return _Code; }
            set { this.SetProperty(ref _Code, value); }
        }

        public string Description { get; set; }


        public void Reset(int naEntityID)
        {
            
        }
    }
}
