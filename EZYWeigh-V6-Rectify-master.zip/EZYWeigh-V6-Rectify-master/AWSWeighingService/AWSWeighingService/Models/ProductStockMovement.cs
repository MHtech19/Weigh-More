﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Models
{
    public class ProductStockMovement : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public DateTime MovementDate { get; set; }
        public string Docket { get; set; }
        public string Direction { get; set; }

        public bool MANUAL_INPUT { get; set; }

        public decimal STOCKLEVEL { get; set; }

        public decimal IN_TAKE { get; set; }

        public decimal OUT_TAKE { get; set; }

        [JsonIgnore]
        public decimal IN_OUT_TAKE
        {
            get
            {
                if (Direction == CoreConstants.DIRECTION_IN) return IN_TAKE;
                else if (Direction == CoreConstants.DIRECTION_OUT) return OUT_TAKE;
                else return 0;
            }
        }

        public string Comment { get; set; }

        public int ProductID { get; set; }
        [JsonIgnore]
        public virtual Product Product { get; set; }

        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }

        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }





        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }
}