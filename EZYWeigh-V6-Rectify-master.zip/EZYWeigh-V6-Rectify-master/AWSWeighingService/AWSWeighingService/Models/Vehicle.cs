﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using System.ComponentModel;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Vehicle : BindableBase, IEntityID
    {
        public int ID { get; set; }

        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Code;
        [Required]
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code
        {
            get { return _Code; }
            set { this.SetProperty(ref _Code, value); }
        }

//        [JsonIgnore]
        public string Description { get; set; }

        private decimal _NetWeight;
        [DefaultValue(0.00)]
        public decimal NetWeight
        {
            get { return _NetWeight; }
            set { this.SetProperty(ref _NetWeight, value); }
        }

        private decimal _InLocalDiscount;
        [DefaultValue(0.00)]
        public decimal InLocalDiscount
        {
            get { return _InLocalDiscount; }
            set { this.SetProperty(ref _InLocalDiscount, value); }
        }

        private bool _InLocalDiscountGST;
        public bool InLocalDiscountGST
        {
            get { return _InLocalDiscountGST; }
            set { this.SetProperty(ref _InLocalDiscountGST, value); }
        }

        private decimal _InVisitStandard;
        [DefaultValue(0.00)]
        public decimal InVisitStandard
        {
            get { return _InVisitStandard; }
            set { this.SetProperty(ref _InVisitStandard, value); }
        }

        private bool _InVisitStandardGST;
        public bool InVisitStandardGST
        {
            get { return _InVisitStandardGST; }
            set { this.SetProperty(ref _InVisitStandardGST, value); }
        }

        public int ProductID { get; set; }

        public bool IsActive { get; set; }

      
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? SchedulePriceDate { get; set; }

        private decimal _InLocalDiscount_S;
        [DefaultValue(0.00)]
        public decimal InLocalDiscount_S
        {
            get { return _InLocalDiscount_S; }
            set { this.SetProperty(ref _InLocalDiscount_S, value); }
        }

        private decimal _InVisitStandard_S;
        [DefaultValue(0.00)]
        public decimal InVisitStandard_S
        {
            get { return _InVisitStandard_S; }
            set { this.SetProperty(ref _InVisitStandard_S, value); }
        }

        [JsonIgnore]
        public virtual Product Product { get; set; }

        [JsonIgnore]
        public virtual ICollection<VehicleProductPrice> VehicleProductPrices { get; set; }

        public Vehicle()
        {
            Reset(Constants.NAEntityID);
        }

        public void Reset(int naEntityID)
        {
            NetWeight = 0;
            InLocalDiscount = 0;
            InLocalDiscountGST = true;
            InVisitStandard = 0;
            InVisitStandardGST = true;
            ProductID = naEntityID;
            InLocalDiscount_S = 0;
            InVisitStandard_S = 0;
        }
    }
}
