﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class CompanyProfile : BindableBase, IEntityID
    {
        public int ID { get; set; }

        
        public string Name { get; set; }
        public string Description { get; set; }
        public string ABN { get; set; }
        public string ACN { get; set; }
        public string BankName { get; set; }
        public string BankBSB { get; set; }
        public string BankAccountTitle { get; set; }
        public string BankAccountNumber { get; set; }
        public string Licenses { get; set; }

        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Suburb { get; set; }
        public string State { get; set; }
        public string Postcode { get; set; }
        public string Country { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Mobile { get; set; }
        public string Contact { get; set; }
       
        public string Email { get; set; }
        public string WebSite { get; set; }



        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }
}
