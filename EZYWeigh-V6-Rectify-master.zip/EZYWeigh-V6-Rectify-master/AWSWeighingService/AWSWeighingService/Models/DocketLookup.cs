﻿using AWSWeighingService.Abstract;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class DocketLookup : BindableBase, IEntityID
    {
        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        public int ID => throw new NotImplementedException();

        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }
}