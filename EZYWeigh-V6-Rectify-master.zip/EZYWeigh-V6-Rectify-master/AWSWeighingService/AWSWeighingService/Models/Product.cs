﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

using Newtonsoft.Json;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Abstract;
using System.ComponentModel;
using CoreConstants = WeighBridge.Core.Utils.Constants;
using AWSWeighingService.Infrastructure.TransactionChargeCalculators;
using AWSWeighingService.Infrastructure.ProductChargeCalculators;
using System.ComponentModel.DataAnnotations.Schema;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Product : BindableBase, IEntityID
    {
        public int ID { get; set; }

        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Code;
        [Required]
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code
        {
            get { return _Code; }
            set { this.SetProperty(ref _Code, value); }
        }

        [JsonIgnore]
        public string Description { get; set; }

        private string _Direction;
        public string Direction
        {
            get { return _Direction; }
            set { this.SetProperty(ref _Direction, value); }
        }

        public string ProductType { get; set; }

        public bool SiteCreated { get; set; }

        //Local Discount Price
        private decimal _InLocalDiscount;
        [DefaultValue(0.00)]
        public decimal InLocalDiscount
        {
            get { return _InLocalDiscount; }
            set { this.SetProperty(ref _InLocalDiscount, value); }
        }

        private bool _InLocalDiscountGST;
        public bool InLocalDiscountGST
        {
            get { return _InLocalDiscountGST; }
            set { this.SetProperty(ref _InLocalDiscountGST, value); }
        }

        private decimal _OutLocalDiscount;
        [DefaultValue(0.00)]
        public decimal OutLocalDiscount
        {
            get { return _OutLocalDiscount; }
            set { this.SetProperty(ref _OutLocalDiscount, value); }
        }

        private bool _OutLocalDiscountGST;
        public bool OutLocalDiscountGST
        {
            get { return _OutLocalDiscountGST; }
            set { this.SetProperty(ref _OutLocalDiscountGST, value); }
        }

        private decimal _MinLocalDiscount;
        [DefaultValue(0.00)]
        public decimal MinLocalDiscount
        {
            get { return _MinLocalDiscount; }
            set { this.SetProperty(ref _MinLocalDiscount, value); }
        }

        //Visitor Standard Price
        private decimal _InVisitStandard;
        [DefaultValue(0.00)]
        public decimal InVisitStandard
        {
            get { return _InVisitStandard; }
            set { this.SetProperty(ref _InVisitStandard, value); }
        }

        private bool _InVisitStandardGST;
        public bool InVisitStandardGST
        {
            get { return _InVisitStandardGST; }
            set { this.SetProperty(ref _InVisitStandardGST, value); }
        }

        private decimal _OutVisitStandard;
        [DefaultValue(0.00)]
        public decimal OutVisitStandard
        {
            get { return _OutVisitStandard; }
            set { this.SetProperty(ref _OutVisitStandard, value); }
        }

        private bool _OutVisitStandardGST;
        public bool OutVisitStandardGST
        {
            get { return _OutVisitStandardGST; }
            set { this.SetProperty(ref _OutVisitStandardGST, value); }
        }

        private decimal _MinVisitStandard;
        [DefaultValue(0.00)]
        public decimal MinVisitStandard
        {
            get { return _MinVisitStandard; }
            set { this.SetProperty(ref _MinVisitStandard, value); }
        }

        //EPA Charge
        private decimal _EPALevy;
        public decimal EPALevy
        {
            get { return _EPALevy; }
            set { this.SetProperty(ref _EPALevy, value); }
        }

        private decimal _MinEPALevy;
        public decimal MinEPALevy
        {
            get { return _MinEPALevy; }
            set { this.SetProperty(ref _MinEPALevy, value); }
        }

        
        private decimal _Royalty;
        [DefaultValue(0.00)]
        public decimal Royalty
        {
            get { return _Royalty; }
            set { this.SetProperty(ref _Royalty, value); }
        }
        
        private decimal _MinWeight;
        [DefaultValue(0.00)]
        public decimal MinWeight
        {
            get { return _MinWeight; }
            set { this.SetProperty(ref _MinWeight, value); }
        }

        [JsonIgnore]
        public string EPA_Din { get; set; }

        [JsonIgnore]
        public string NGER_Code { get; set; }

        //use this to indicate EPA Source required
        public bool Report_To_EPA { get; set; }

        private decimal _ToVolumeFactor;
        [DefaultValue(0.00)]
        public decimal ToVolumeFactor
        {
            get { return _ToVolumeFactor; }
            set { this.SetProperty(ref _ToVolumeFactor, value); }
        }

        private decimal _InLocalDiscount_S;
        [DefaultValue(0.00)]
        public decimal InLocalDiscount_S
        {
            get { return _InLocalDiscount_S; }
            set { this.SetProperty(ref _InLocalDiscount_S, value); }
        }

        private decimal _OutLocalDiscount_S;
        [DefaultValue(0.00)]
        public decimal OutLocalDiscount_S
        {
            get { return _OutLocalDiscount_S; }
            set { this.SetProperty(ref _OutLocalDiscount_S, value); }
        }

        private decimal _MinLocalDiscount_S;
        [DefaultValue(0.00)]
        public decimal MinLocalDiscount_S
        {
            get { return _MinLocalDiscount_S; }
            set { this.SetProperty(ref _MinLocalDiscount_S, value); }
        }

        private decimal _InVisitStandard_S;
        [DefaultValue(0.00)]
        public decimal InVisitStandard_S
        {
            get { return _InVisitStandard_S; }
            set { this.SetProperty(ref _InVisitStandard_S, value); }
        }

        private decimal _OutVisitStandard_S;
        [DefaultValue(0.00)]
        public decimal OutVisitStandard_S
        {
            get { return _OutVisitStandard_S; }
            set { this.SetProperty(ref _OutVisitStandard_S, value); }
        }

        private decimal _MinVisitStandard_S;
        [DefaultValue(0.00)]
        public decimal MinVisitStandard_S
        {
            get { return _MinVisitStandard_S; }
            set { this.SetProperty(ref _MinVisitStandard_S, value); }
        }

        private decimal _EPALevy_S;
        [DefaultValue(0.00)]
        public decimal EPALevy_S
        {
            get { return _EPALevy_S; }
            set { this.SetProperty(ref _EPALevy_S, value); }
        }

        private decimal _MinEPALevy_S;
        [DefaultValue(0.00)]
        public decimal MinEPALevy_S
        {
            get { return _MinEPALevy_S; }
            set { this.SetProperty(ref _MinEPALevy_S, value); }
        }

        private string _ResourceCode;
        public string ResourceCode
        {
            get { return _ResourceCode; }
            set { this.SetProperty(ref _ResourceCode, value); }
        }

        [JsonIgnore]
        public decimal CurrentCount;

        [JsonIgnore]
        public string EPA_Status { get; set; }

        [JsonIgnore]
        public decimal CurrentAmount;

        [JsonIgnore]
        public decimal CurrentMinimumCharge;

        [JsonIgnore]
        public decimal CurrentPrice;

        [JsonIgnore]
        public decimal CurrentEPA;

        [JsonIgnore]
        public decimal CurrentGST;

        [JsonIgnore]
        public decimal CurrentCartage;

        [JsonIgnore]
        public decimal CurrentCartageCost;

        [JsonIgnore]
        public decimal CurrentCartageGST;

        [JsonIgnore]
        public decimal CurrentTotalCost;

        [JsonIgnore]
        public decimal CurrentTranCost;

        [JsonIgnore]
        public decimal CurrentRoyalty;

        [JsonIgnore]
        public decimal CurrentCustomerDiscount;
        //{
        //    //get
        //    //{
        //    //    return (CurrentPrice * CurrentAmount - CurrentGST > CurrentMinimumCharge - CurrentGST) ? CurrentPrice * CurrentAmount - CurrentGST : CurrentMinimumCharge - CurrentGST;
        //    //}
        //}

        [JsonIgnore]
        public bool CurrentGSTApplies { get; set; }

        public int ProductCategoryID { get; set; }
        [JsonIgnore]
        public virtual ProductCategory ProductCategory { get; set; }

        public int SourceID { get; set; }
        [JsonIgnore]
        public virtual Source Source { get; set; }

        public int DestinationID { get; set; }
        [JsonIgnore]
        public virtual Destination Destination { get; set; }

        [JsonIgnore]
        public virtual ICollection<Site> Sites { get; set; }

        #region Properties exclusively for UI in Win Client
        [NotMapped]
        public bool IsSelected { set; get; }

        [NotMapped]
        public bool Selectable { set; get; }

        [NotMapped]
        public decimal JobProductPrice { set; get; }
        #endregion

        public Product()
        {
            Reset(Constants.NAEntityID);
        }

        public void Reset(int naEntityID)
        {
            InLocalDiscount = 0;
            InLocalDiscountGST = true;
            OutLocalDiscount = 0;
            OutLocalDiscountGST = true;
            MinLocalDiscount = 0;
            InVisitStandard = 0;
            InVisitStandardGST = true;
            OutVisitStandard = 0;
            OutVisitStandardGST = true;
            MinVisitStandard = 0;
            EPALevy = 0;
            MinEPALevy = 0;
            ProductCategoryID = naEntityID;
            SourceID = naEntityID;
            DestinationID = naEntityID;
            SiteCreated = false;
            EPA_Status = "Leviable";
            IsActive = true;
            InLocalDiscount_S = 0;
            OutLocalDiscount_S = 0;
            MinLocalDiscount_S = 0;
            InVisitStandard_S = 0;
            OutVisitStandard_S = 0;
            MinVisitStandard_S = 0;
            EPALevy_S = 0;
            MinEPALevy_S = 0;
        }

        public void SetCurrentCharges(Transaction currentTran, List<JobProductPrice> jobProductPrices = null, List<VehicleProductPrice> vehicleProductPrices = null, decimal manualInputCartage = 0, bool isEditing = false)
        {
            BaseProductCalculator priceCalculator = null;

            CurrentPrice = 0;
            CurrentEPA = 0;
            CurrentGST = 0;
            CurrentCartage = 0;
            CurrentCartageGST = 0;
            CurrentTranCost = 0;
            CurrentTotalCost = 0;
            CurrentCustomerDiscount = 0;
            switch (currentTran.LoadType)
            {
                case "Counted":
                case "StoredTare":
                case "ManualTare":
                case "Mixed":
                case "Second": priceCalculator = new SecondWeighedProductCalculator(this, currentTran, jobProductPrices, manualInputCartage, isEditing); break;
                case "Standard": priceCalculator = new StandardLoadProductCalculator(this, currentTran, vehicleProductPrices, manualInputCartage, isEditing); break;
                case "Rego": priceCalculator = new RegoLoadProductCalculator(this,currentTran); break;
                default: break;
            }

            priceCalculator.CalculateCharges();
            /*
            if (currentTran.ChargeRate == CoreConstants.RATE_LOCAL) //LocalButton.Checked 
            {
                CurrentPrice = InLocalDiscount; //prTranCost = prInLocalCost;
                CurrentGSTApplies = InLocalDiscountGST;
                if (CurrentPrice < 0.0001m)
                {
                    CurrentPrice = currentTran.Vehicle.InLocalDiscount; //prTranCost = prInLocalCost;
                    CurrentGSTApplies = currentTran.Vehicle.InLocalDiscountGST;
                }
            }
            else
            {
                CurrentPrice = InVisitStandard;
                CurrentGSTApplies = InVisitStandardGST;
                if (CurrentPrice < 0.0001m)
                {
                    CurrentPrice = currentTran.Vehicle.InVisitStandard;
                    CurrentGSTApplies = currentTran.Vehicle.InVisitStandardGST;
                }
            }

            CurrentEPA = currentTran.Vehicle.NetWeight * EPALevy;
            */
        }

        [DefaultValue(1)]
        public bool IsActive { get; set; }

        [DefaultValue(0)]
        public bool LiftBoomGate { get; set; }

        [DefaultValue(0)]
        public bool EPA { get; set; }

        public int? NoOfDockets { get; set; }

        public int? LedgerAccount { get; set; }
        
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? SchedulePriceDate { get; set; }

        [DefaultValue(0.00)]
        public decimal? StockLevel { get; set; }
    }
}
