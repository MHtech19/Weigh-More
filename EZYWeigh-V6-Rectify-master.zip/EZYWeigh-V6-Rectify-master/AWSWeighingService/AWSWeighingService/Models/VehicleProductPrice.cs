﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Models
{
    public class VehicleProductPrice : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public int VehicleID { get; set; }
        [JsonIgnore]
        public Vehicle Vehicle { get; set; }

        public int ProductID { get; set; }
        [JsonIgnore]
        public Product Product { get; set; }

        public decimal InLocalDiscount { get; set; }
        public bool InLocalDiscountGST { get; set; }

        public decimal InVisitStandard { get; set; }
        public bool InVisitStandardGST { get; set; }

        [JsonIgnore]
        public decimal CurrentPrice { get; set; }

        [JsonIgnore]
        public decimal CurrentEPA { get; set; }

        [JsonIgnore]
        public decimal CurrentGST { get; set; }

        [JsonIgnore]
        public bool CurrentGSTApplies { get; set; }

        public void SetCurrentPrice(Transaction currentTran)
        {
            CurrentPrice = 0;
            CurrentEPA = 0;
            CurrentGST = 0;

            if (currentTran.ChargeRate == CoreConstants.RATE_LOCAL) //LocalButton.Checked 
            {
                CurrentPrice = InLocalDiscount; //prTranCost = prInLocalCost;
                CurrentGSTApplies = InLocalDiscountGST;
                if (CurrentPrice < 0.0001m)
                {
                    CurrentPrice = currentTran.Vehicle.InLocalDiscount; //prTranCost = prInLocalCost;
                    CurrentGSTApplies = currentTran.Vehicle.InLocalDiscountGST;
                }
            }
            else
            {
                CurrentPrice = InVisitStandard;
                CurrentGSTApplies = InVisitStandardGST;
                if (CurrentPrice < 0.0001m)
                {
                    CurrentPrice = currentTran.Vehicle.InVisitStandard;
                    CurrentGSTApplies = currentTran.Vehicle.InVisitStandardGST;
                }
            }

            CurrentEPA = currentTran.Vehicle.NetWeight * Product.EPALevy;

        }

        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }
}