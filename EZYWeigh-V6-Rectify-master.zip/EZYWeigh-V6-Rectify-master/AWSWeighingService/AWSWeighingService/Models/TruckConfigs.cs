﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class TruckConfigs : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public int TruckID { get; set; }
        [JsonIgnore]
        public virtual Truck Truck { get; set; }

        public int VehicleConfigurationID { get; set; }
        [JsonIgnore]
        public virtual VehicleConfiguration VehicleConfiguration { get; set; }

        public void Reset(int naEntityID)
        {

        }
    }
}