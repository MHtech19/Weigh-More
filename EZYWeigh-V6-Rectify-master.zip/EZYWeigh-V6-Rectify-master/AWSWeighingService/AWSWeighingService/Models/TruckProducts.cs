﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{

    public class TruckProducts : BindableBase, IEntityID
    {
        
        public int ID { get; set; }

        public int TruckID { get; set; }
        [JsonIgnore]
        public virtual Truck Truck { get; set; }

        public int ProductID { get; set; }
        [JsonIgnore]
        public virtual Product Product { get; set; }

        public void Reset(int naEntityID)
        {
            
        }
    }
}