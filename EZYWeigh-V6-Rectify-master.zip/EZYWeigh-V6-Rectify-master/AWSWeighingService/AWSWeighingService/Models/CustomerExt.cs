using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;

using System.ComponentModel.DataAnnotations.Schema;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class CustomerExt : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public int CustomerID { get; set; }

        public decimal CreditLimit { get; set; }

        public CustomerExt()
        {
            Reset(Constants.NAEntityID);
        }


        public void Reset(int naEntityID)
        {
            CustomerID = 0;
            CreditLimit = 0;
        }

    }
}
