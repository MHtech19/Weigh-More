﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Truck : BindableBase, IEntityID
    {
        public int ID { get; set; }

        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Code;
        [Required]
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code
        {
            get { return _Code; }
            set { this.SetProperty(ref _Code, value); }
        }

        public string Description { get; set; }

        private string _ChargeRate;
        public string ChargeRate
        {
            get { return _ChargeRate; }
            set { this.SetProperty(ref _ChargeRate, value); }
        }

        private string _Registration2;
        public string Registration2
        {
            get { return _Registration2; }
            set { this.SetProperty(ref _Registration2, value); }
        }

        private string _Registration3;
        public string Registration3
        {
            get { return _Registration3; }
            set { this.SetProperty(ref _Registration3, value); }
        }

        private string _Fleet;
        public string Fleet
        {
            get { return _Fleet; }
            set { this.SetProperty(ref _Fleet, value); }
        }

        private string _TagID;
        public string TagID
        {
            get { return _TagID; }
            set { this.SetProperty(ref _TagID, value); }
        }

        private decimal _Tare1;
        [DefaultValue(0.00)]
        public decimal Tare1
        {
            get { return _Tare1; }
            set { this.SetProperty(ref _Tare1, value); }
        }

        private decimal _Tare2;
        [DefaultValue(0.00)]
        public decimal Tare2
        {
            get { return _Tare2; }
            set { this.SetProperty(ref _Tare2, value); }
        }

        private decimal _Tare3;
        [DefaultValue(0.00)]
        public decimal Tare3
        {
            get { return _Tare3; }
            set { this.SetProperty(ref _Tare3, value); }
        }

        private decimal _Tare4;
        [DefaultValue(0.00)]
        public decimal Tare4
        {
            get { return _Tare4; }
            set { this.SetProperty(ref _Tare4, value); }
        }

        private decimal _Tare5;
        [DefaultValue(0.00)]
        public decimal Tare5
        {
            get { return _Tare5; }
            set { this.SetProperty(ref _Tare5, value); }
        }

        private decimal _MaxLoad;
        [DefaultValue(0.00)]
        public decimal MaxLoad
        {
            get { return _MaxLoad; }
            set { this.SetProperty(ref _MaxLoad, value); }
        }

        [JsonIgnore]
        public decimal Tare
        {
            get
            {
                return Tare1 + Tare2 + Tare3 + Tare4 + Tare5;
            }
        }

        [JsonIgnore]
        public bool HasStoredTare
        {
            get
            {
                return Tare > 0.001M;
            }
        }

        private string _LoadType;
        public string LoadType
        {
            get { return _LoadType; }
            set { this.SetProperty(ref _LoadType, value); }
        }

        private int _TareTerm;
        public int TareTerm
        {
            get { return _TareTerm; }
            set { this.SetProperty(ref _TareTerm, value); }
        }

        public DateTime? LastTareDate { get; set; }

        private bool _SiteOwned;
        public bool SiteOwned
        {
            get { return _SiteOwned; }
            set { this.SetProperty(ref _SiteOwned, value); }
        }

        private bool _IsStoredTare;
        public bool IsStoredTare
        {
            get { return _IsStoredTare; }
            set { this.SetProperty(ref _IsStoredTare, value); }
        }


        ////linked entities
        //[NotMapped]
        //public int CustomerID { get; set; }
        //[JsonIgnore]
        //public virtual Customer Customer { get; set; }

        //[NotMapped]
        //public int ProductID { get; set; }
        //[JsonIgnore]
        //public virtual Product Product { get; set; }

        //[NotMapped]
        //public int JobID { get; set; }
        //[JsonIgnore]
        //public virtual Job Job { get; set; }

        //[NotMapped]
        //public int DestinationID { get; set; }
        //[JsonIgnore]
        //public virtual Destination Destination { get; set; }

        //[NotMapped]
        //public int SourceID { get; set; }
        //[JsonIgnore]
        //public virtual Source Source { get; set; }


        public int DriverID { get; set; }
        [JsonIgnore]
        public virtual Driver Driver { get; set; }

        //public int VehicleConfigurationID { get; set; }
        //[JsonIgnore]
        //public virtual VehicleConfiguration VehicleConfiguration { get; set; }

        public int VehicleID { get; set; }
        [JsonIgnore]
        public virtual Vehicle Vehicle { get; set; }

        public int MarkID { get; set; }
        [JsonIgnore]
        public virtual Mark Mark { get; set; }

        [DefaultValue(1)]
        public bool IsActive { get; set; }

        public string InOrOut { get; set; }

        [DefaultValue(0)]
        public bool SplitTare { get; set; }

        [DefaultValue(0)]
        public bool ChargeSiteOwned { get; set; }

        public int? ABN { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] TruckJobs { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string TruckJobValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] TruckProducts { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string TruckProductValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] TruckDestination { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string TruckDestinationValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] TruckCustomers { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string TruckCustomerValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] TruckSuppliers { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string TruckSupplierValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] TruckSource { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string TruckSourceValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public int[] TruckConfig { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string TruckConfigValues { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string JobNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string ProductNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string DestinationNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string CustomerNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string SupplierNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string SourceNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string VehicleConfigNames { get; set; }

        [JsonIgnore]
        [NotMapped]
        public string CustomerTypeNames { get; set; }

        [JsonIgnore]
        public virtual ICollection<Site> Sites { get; set; }

        public Truck()
        {
            Reset(Constants.NAEntityID);
        }

        public void Reset(int naEntityID)
        {
            Tare1 = 0;
            Tare2 = 0;
            Tare3 = 0;
            Tare4 = 0;
            Tare5 = 0;
            MaxLoad = 0;
            TareTerm = 0;

            //CustomerID = naEntityID;
            //ProductID = naEntityID;
            //JobID = naEntityID;
            //DestinationID = naEntityID;
            //SourceID = naEntityID;
            DriverID = naEntityID;
            //VehicleConfigurationID = naEntityID;
            MarkID = naEntityID;
            IsActive = true;
        }
    }
}
