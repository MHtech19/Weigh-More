﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using System.Web.Security;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Weighman : BindableBase, IEntityID, IEntityName 
    {
        public int ID { get; set; }

        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name { get; set; }

        [DataType(DataType.Password)]        
        [Required]
        public string Password { get; set; }

//        [Compare("Password")]
//        [DataType(DataType.Password)]
//        [StringLength(40)]
//        [Required()]
////        [JsonIgnore]
//        public string ConfirmPassword { get; set; }

//        [JsonIgnore]
        public string Description { get; set; }

        public bool IsAdmin { get; set; }
        public bool DefaultLogon { get; set; }

        public bool SiteCreated { get; set; }

//        [JsonIgnore]
        public string Address1 { get; set; }
//        [JsonIgnore]
        public string Address2 { get; set; }
//        [JsonIgnore]
        public string Suburb { get; set; }
//        [JsonIgnore]
        public string State { get; set; }
//        [JsonIgnore]
        public string Postcode { get; set; }
//        [JsonIgnore]
        public string Country { get; set; }

        private string _Phone;
        public string Phone
        {
            get { return _Phone; }
            set { this.SetProperty(ref _Phone, value); }
        }

        private string _Mobile;
        public string Mobile
        {
            get { return _Mobile; }
            set { this.SetProperty(ref _Mobile, value); }
        }

        private string _Email;
        public string Email
        {
            get { return _Email; }
            set { this.SetProperty(ref _Email, value); }
        }

        public bool CanNewProduct { get; set; }
        public bool CanEditProduct { get; set; }

        public bool CanNewProductCategory { get; set; }
        public bool CanEditProductCategory { get; set; }

        public bool CanNewCustomer { get; set; }
        public bool CanEditCustomer { get; set; }

        public bool CanNewDestination { get; set; }
        public bool CanEditDestination { get; set; }

        public bool CanNewSource { get; set; }
        public bool CanEditSource { get; set; }

        public bool CanNewJob { get; set; }
        public bool CanEditJob { get; set; }

        public bool CanNewTruck { get; set; }
        public bool CanEditTruck { get; set; }

        public bool CanNewTruckConfiguration { get; set; }
        public bool CanEditTruckConfiguration { get; set; }

        public bool CanNewVehicleType { get; set; }
        public bool CanEditVehicleType { get; set; }

        public bool CanNewWeighman { get; set; }
        public bool CanEditWeighman { get; set; }

        public bool CanNewDriver { get; set; }
        public bool CanEditDriver { get; set; }

        public bool CanNewTransaction { get; set; }
        public bool CanEditTransaction { get; set; }

        public bool CanReportProduct { get; set; }

        public bool CanReportProductCategory { get; set; }

        public bool CanReportCustomer { get; set; }

        public bool CanReportDestination { get; set; }

        public bool CanReportSource { get; set; }

        public bool CanReportJob { get; set; }

        public bool CanReportTruck { get; set; }

        public bool CanReportTruckConfiguration { get; set; }

        public bool CanReportVehicleType { get; set; }

        public bool CanReportWeighman { get; set; }

        public bool CanReportDriver { get; set; }

        public bool CanReportTransaction { get; set; }

        public bool IsAWSSupportUser { get; set; }

        public bool IsDeleted { get; set; }

        [JsonIgnore]
        public virtual ICollection<Site> Sites { get; set; }

        public Weighman()
        {
            Reset(Constants.NAEntityID);
        }

        public void Reset(int naEntityID)
        {
            SiteCreated = false;
        }

        public int RoleID { get; set; }
        [JsonIgnore]
        public virtual Role Role { get; set; }
    }
}
