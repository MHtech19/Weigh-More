 public class GeneratePDF
    {
        public string Value { get; set; }
        public string htmlValue { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string IsImage { get; set; }
    }