﻿using AWSWeighingService.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class CameraSnapshot :  IEntityID
    {
        public int ID { get; set; }

        public int TransactionID { get; set; }
       
        public string Snapshot1 { get; set; }

        public string Snapshot2 { get; set; }

        public string Snapshot3 { get; set; }

        public string Snapshot4 { get; set; }

        public string FirstWeighSnapshot1 { get; set; }

        public string FirstWeighSnapshot2 { get; set; }

        public string FirstWeighSnapshot3 { get; set; }

        public string FirstWeighSnapshot4 { get; set; }



        public void Reset(int naEntityID)
        {
            ID = naEntityID;

            TransactionID = naEntityID;

            Snapshot1 = string.Empty;

            Snapshot2 = string.Empty;

            Snapshot3 = string.Empty;

            Snapshot4 = string.Empty;

            FirstWeighSnapshot1 = string.Empty;

            FirstWeighSnapshot2 = string.Empty;

            FirstWeighSnapshot3 = string.Empty;

            FirstWeighSnapshot4 = string.Empty;
        }
    }
}