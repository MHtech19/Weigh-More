﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Visitor : BindableBase, IEntityID
    {
        public int ID { get; set; }
        
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name { get; set; }
        public string Description { get; set; }
        public string Registration { get; set; }
        public string Organisation { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public string Reason {get; set;}
        public string Visiting { get; set; }

        public bool HasLeft { get; set; }
        
        public DateTime? DateTimeIn { get; set; }

        public DateTime? DateTimeOut { get; set; }

        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }

        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }


        public Visitor()
        {
            Reset(Constants.NAEntityID);
        }


        public void Reset(int naEntityID)
        {
            SiteID = naEntityID;
            WeighmanID = naEntityID;
        }
    }
}
