﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Models
{
    public class WMSEventLog : BindableBase, IEntityID
    {
        public WMSEventLog()
        {
            Reset(CoreConstants.NA_ID);
        }

        public int ID { get; set; }

        private string _Name = string.Empty;
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Registration = string.Empty;
        public string Registration
        {
            get { return _Registration; }
            set { this.SetProperty(ref _Registration, value); }
        }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime EventDateTime { get; set; }

        public string DateStamp { get; set; }

        private string _Comment = string.Empty;
        public string Comment
        {
            get { return _Comment; }
            set { this.SetProperty(ref _Comment, value); }
        }
        private decimal _WeightPass;
        [DefaultValue(0.00)]
        public decimal WeightPass
        {
            get { return _WeightPass; }
            set { this.SetProperty(ref _WeightPass, value); }
        }

        //[Required]
       // public virtual int EventTypeId { get; set; }
       // [EnumDataType(typeof(EventTypes))]
        public int EventType { get; set; }
        //{
        //    get
        //    {
        //        return (EventTypes)this.EventTypeId;
        //    }
        //    set
        //    {
        //        this.EventTypeId = (int)value;
        //    }
        //}

        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }

        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }

        public int TransactionID { get; set; }
        [JsonIgnore]
        public virtual Transaction Transaction { get; set; }

        public int ProductCategoryID { get; set; }
        [JsonIgnore]
        public virtual ProductCategory ProductCategory { get; set; }

        //[Required]
        public int ProductID { get; set; }
        [JsonIgnore]
        public virtual Product Product { get; set; }

        //[Required]
        public int CustomerID { get; set; }
        [JsonIgnore]
        private Customer Customer;

        public int DestinationID { get; set; }
        [JsonIgnore]
        public virtual Destination Destination { get; set; }

        //[Required]
        public int SourceID { get; set; }
        [JsonIgnore]
        public virtual Source Source { get; set; }

        //[Required]
        public int JobID { get; set; }
        [JsonIgnore]
        public virtual Job Job { get; set; }

        //[Required]
        public int TruckID { get; set; }
        [JsonIgnore]
        public virtual Truck Truck { get; set; }

        public int VehicleID { get; set; }
        [JsonIgnore]
        public virtual Vehicle Vehicle { get; set; }

        public int DriverID { get; set; }
        [JsonIgnore]
        public virtual Driver Driver { get; set; }

        public int VehicleConfigurationID { get; set; }
        [JsonIgnore]
        public virtual VehicleConfiguration VehicleConfiguration { get; set; }

        public void Reset(int naEntityID)
        {
            //WeighmanID = naEntityID;
            //SiteID = naEntityID;
            TransactionID = naEntityID;

            ProductCategoryID = naEntityID;
            ProductID = naEntityID;
            CustomerID = naEntityID;
            DestinationID = naEntityID;
            SourceID = naEntityID;
            JobID = naEntityID;
            TruckID = naEntityID;
            VehicleID = naEntityID;
            DriverID = naEntityID;
            VehicleConfigurationID = naEntityID;
        }
    }
}