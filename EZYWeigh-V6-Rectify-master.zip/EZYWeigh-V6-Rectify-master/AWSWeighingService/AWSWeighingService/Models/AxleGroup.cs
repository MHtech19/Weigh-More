﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Models
{
    public class AxleGroup : IEntityID
    {
        
        public int ID { get; set; }

        public Int64 Docket { get; set; }
        public int SiteID { get; set; }

        public string Name { get; set; }
        public string AxleGroupOrder { get; set; }

        public int AxleCount { get; set; }
        public int StartingAxleNumber { get; set; }

        public decimal Weight { get; set; }
        public decimal OverloadedBy { get; set; }

        public bool FromReplication { get; set; }


        private string SetName(int startingAxleNumber, int axleCount)
        {
            string reslutStr = "{ " ;
            string delim;

            for (int i = startingAxleNumber; i < startingAxleNumber + axleCount; i++ )
            {
                delim = (i == startingAxleNumber) ? string.Empty : ",";
                reslutStr = reslutStr + delim + i.ToString();
            }

            reslutStr = reslutStr + " }";

            return reslutStr;
        }

        public AxleGroup()
        { }

        public AxleGroup(string axleGroupOrderParam, int siteIDParam, int axleCountParam, int startingAxleNumberParam, decimal weightParam)
        {
            AxleGroupOrder = axleGroupOrderParam;
            SiteID = siteIDParam;
            AxleCount = axleCountParam;
            StartingAxleNumber = startingAxleNumberParam;
            Name = SetName(StartingAxleNumber, AxleCount);
            Weight = weightParam; 
        }

        public void Reset(int naEntityID)
        {
            
        }

    }
}
