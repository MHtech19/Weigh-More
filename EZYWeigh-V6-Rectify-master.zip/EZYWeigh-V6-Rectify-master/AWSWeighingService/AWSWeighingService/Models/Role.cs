﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using System.Web.Security;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Role : BindableBase, IEntityID, IEntityName, INotifyPropertyChanged
    {
        public int ID { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name { get; set; }
       
        //public bool SiteCreated { get; set; }

        private bool _CanNewProduct;
        public bool CanNewProduct {
            get
            {
                return this._CanNewProduct;
            }
            set
            {
                if(value != this._CanNewProduct)
                {
                    this._CanNewProduct = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditProduct;
        public bool CanEditProduct
        {
            get
            {
                return this._CanEditProduct;
            }
            set
            {
                if (value != this._CanEditProduct)
                {
                    this._CanEditProduct = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewProductCategory;
        public bool CanNewProductCategory
        {
            get
            {
                return this._CanNewProductCategory;
            }
            set
            {
                if (value != this._CanNewProductCategory)
                {
                    this._CanNewProductCategory = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditProductCategory;
        public bool CanEditProductCategory
        {
            get
            {
                return this._CanEditProductCategory;
            }
            set
            {
                if (value != this._CanEditProductCategory)
                {
                    this._CanEditProductCategory = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewCustomer;
        public bool CanNewCustomer
        {
            get
            {
                return this._CanNewCustomer;
            }
            set
            {
                if (value != this._CanNewCustomer)
                {
                    this._CanNewCustomer = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditCustomer;
        public bool CanEditCustomer
        {
            get
            {
                return this._CanEditCustomer;
            }
            set
            {
                if (value != this._CanEditCustomer)
                {
                    this._CanEditCustomer = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewDestination;
        public bool CanNewDestination
        {
            get
            {
                return this._CanNewDestination;
            }
            set
            {
                if (value != this._CanNewDestination)
                {
                    this._CanNewDestination = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditDestination;
        public bool CanEditDestination
        {
            get
            {
                return this._CanEditDestination;
            }
            set
            {
                if (value != this._CanEditDestination)
                {
                    this._CanEditDestination = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewSource;
        public bool CanNewSource
        {
            get
            {
                return this._CanNewSource;
            }
            set
            {
                if (value != this._CanNewSource)
                {
                    this._CanNewSource = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditSource;
        public bool CanEditSource
        {
            get
            {
                return this._CanEditSource;
            }
            set
            {
                if (value != this._CanEditSource)
                {
                    this._CanEditSource = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewJob;
        public bool CanNewJob
        {
            get
            {
                return this._CanNewJob;
            }
            set
            {
                if (value != this._CanNewJob)
                {
                    this._CanNewJob = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditJob;
        public bool CanEditJob
        {
            get
            {
                return this._CanEditJob;
            }
            set
            {
                if (value != this._CanEditJob)
                {
                    this._CanEditJob = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewTruck;
        public bool CanNewTruck
        {
            get
            {
                return this._CanNewTruck;
            }
            set
            {
                if (value != this._CanNewTruck)
                {
                    this._CanNewTruck = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditTruck;
        public bool CanEditTruck
        {
            get
            {
                return this._CanEditTruck;
            }
            set
            {
                if (value != this._CanEditTruck)
                {
                    this._CanEditTruck = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewTruckConfiguration;
        public bool CanNewTruckConfiguration
        {
            get
            {
                return this._CanNewTruckConfiguration;
            }
            set
            {
                if (value != this._CanNewTruckConfiguration)
                {
                    this._CanNewTruckConfiguration = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditTruckConfiguration;
        public bool CanEditTruckConfiguration
        {
            get
            {
                return this._CanEditTruckConfiguration;
            }
            set
            {
                if (value != this._CanEditTruckConfiguration)
                {
                    this._CanEditTruckConfiguration = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewVehicleType;
        public bool CanNewVehicleType
        {
            get
            {
                return this._CanNewVehicleType;
            }
            set
            {
                if (value != this._CanNewVehicleType)
                {
                    this._CanNewVehicleType = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditVehicleType;
        public bool CanEditVehicleType
        {
            get
            {
                return this._CanEditVehicleType;
            }
            set
            {
                if (value != this._CanEditVehicleType)
                {
                    this._CanEditVehicleType = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewWeighman;
        public bool CanNewWeighman
        {
            get
            {
                return this._CanNewWeighman;
            }
            set
            {
                if (value != this._CanNewWeighman)
                {
                    this._CanNewWeighman = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditWeighman;
        public bool CanEditWeighman
        {
            get
            {
                return this._CanEditWeighman;
            }
            set
            {
                if (value != this._CanEditWeighman)
                {
                    this._CanEditWeighman = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewDriver;
        public bool CanNewDriver
        {
            get
            {
                return this._CanNewDriver;
            }
            set
            {
                if (value != this._CanNewDriver)
                {
                    this._CanNewDriver = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditDriver;
        public bool CanEditDriver
        {
            get
            {
                return this._CanEditDriver;
            }
            set
            {
                if (value != this._CanEditDriver)
                {
                    this._CanEditDriver = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewTransaction;
        public bool CanNewTransaction
        {
            get
            {
                return this._CanNewTransaction;
            }
            set
            {
                if (value != this._CanNewTransaction)
                {
                    this._CanNewTransaction = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _CanEditTransaction;
        public bool CanEditTransaction
        {
            get
            {
                return this._CanEditTransaction;
            }
            set
            {
                if (value != this._CanEditTransaction)
                {
                    this._CanEditTransaction = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportProduct;
        public bool CanReportProduct
        {
            get
            {
                return this._CanReportProduct;
            }
            set
            {
                if (value != this._CanReportProduct)
                {
                    this._CanReportProduct = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportProductCategory;
        public bool CanReportProductCategory
        {
            get
            {
                return this._CanReportProductCategory;
            }
            set
            {
                if (value != this._CanReportProductCategory)
                {
                    this._CanReportProductCategory = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportCustomer;
        public bool CanReportCustomer
        {
            get
            {
                return this._CanReportCustomer;
            }
            set
            {
                if (value != this._CanReportCustomer)
                {
                    this._CanReportCustomer = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportDestination;
        public bool CanReportDestination
        {
            get
            {
                return this._CanReportDestination;
            }
            set
            {
                if (value != this._CanReportDestination)
                {
                    this._CanReportDestination = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportSource;
        public bool CanReportSource
        {
            get
            {
                return this._CanReportSource;
            }
            set
            {
                if (value != this._CanReportSource)
                {
                    this._CanReportSource = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportJob;
        public bool CanReportJob
        {
            get
            {
                return this._CanReportJob;
            }
            set
            {
                if (value != this._CanReportJob)
                {
                    this._CanReportJob = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteJob;
        public bool CanDeleteJob
        {
            get
            {
                return this._CanDeleteJob;
            }
            set
            {
                if (value != this._CanDeleteJob)
                {
                    this._CanDeleteJob = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteProduct;
        public bool CanDeleteProduct
        {
            get
            {
                return this._CanDeleteProduct;
            }
            set
            {
                if (value != this._CanDeleteProduct)
                {
                    this._CanDeleteProduct = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteProductCategory;
        public bool CanDeleteProductCategory
        {
            get
            {
                return this._CanDeleteProductCategory;
            }
            set
            {
                if (value != this._CanDeleteProductCategory)
                {
                    this._CanDeleteProductCategory = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteDestination;
        public bool CanDeleteDestination
        {
            get
            {
                return this._CanDeleteDestination;
            }
            set
            {
                if (value != this._CanDeleteDestination)
                {
                    this._CanDeleteDestination = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteTruck;
        public bool CanDeleteTruck
        {
            get
            {
                return this._CanDeleteTruck;
            }
            set
            {
                if (value != this._CanDeleteTruck)
                {
                    this._CanDeleteTruck = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteVehicleType;
        public bool CanDeleteVehicleType
        {
            get
            {
                return this._CanDeleteVehicleType;
            }
            set
            {
                if (value != this._CanDeleteVehicleType)
                {
                    this._CanDeleteVehicleType = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteDriver;
        public bool CanDeleteDriver
        {
            get
            {
                return this._CanDeleteDriver;
            }
            set
            {
                if (value != this._CanDeleteDriver)
                {
                    this._CanDeleteDriver = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteRole;
        public bool CanDeleteRole
        {
            get
            {
                return this._CanDeleteRole;
            }
            set
            {
                if (value != this._CanDeleteRole)
                {
                    this._CanDeleteRole = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteCustomer;
        public bool CanDeleteCustomer
        {
            get
            {
                return this._CanDeleteCustomer;
            }
            set
            {
                if (value != this._CanDeleteCustomer)
                {
                    this._CanDeleteCustomer = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteSource;
        public bool CanDeleteSource
        {
            get
            {
                return this._CanDeleteSource;
            }
            set
            {
                if (value != this._CanDeleteSource)
                {
                    this._CanDeleteSource = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteTruckConfiguration;
        public bool CanDeleteTruckConfiguration
        {
            get
            {
                return this._CanDeleteTruckConfiguration;
            }
            set
            {
                if (value != this._CanDeleteTruckConfiguration)
                {
                    this._CanDeleteTruckConfiguration = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteWeighman;
        public bool CanDeleteWeighman
        {
            get
            {
                return this._CanDeleteWeighman;
            }
            set
            {
                if (value != this._CanDeleteWeighman)
                {
                    this._CanDeleteWeighman = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanDeleteTransaction;
        public bool CanDeleteTransaction
        {
            get
            {
                return this._CanDeleteTransaction;
            }
            set
            {
                if (value != this._CanDeleteTransaction)
                {
                    this._CanDeleteTransaction = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanViewPrintEventLog;
        public bool CanViewPrintEventLog
        {
            get
            {
                return this._CanViewPrintEventLog;
            }
            set
            {
                if (value != this._CanViewPrintEventLog)
                {
                    this._CanViewPrintEventLog = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanUseExportWizard;
        public bool CanUseExportWizard
        {
            get
            {
                return this._CanUseExportWizard;
            }
            set
            {
                if (value != this._CanUseExportWizard)
                {
                    this._CanUseExportWizard = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportTruck;
        public bool CanReportTruck
        {
            get
            {
                return this._CanReportTruck;
            }
            set
            {
                if (value != this._CanReportTruck)
                {
                    this._CanReportTruck = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportTruckConfiguration;
        public bool CanReportTruckConfiguration
        {
            get
            {
                return this._CanReportTruckConfiguration;
            }
            set
            {
                if (value != this._CanReportTruckConfiguration)
                {
                    this._CanReportTruckConfiguration = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportVehicleType;
        public bool CanReportVehicleType
        {
            get
            {
                return this._CanReportVehicleType;
            }
            set
            {
                if (value != this._CanReportVehicleType)
                {
                    this._CanReportVehicleType = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportWeighman;
        public bool CanReportWeighman
        {
            get
            {
                return this._CanReportWeighman;
            }
            set
            {
                if (value != this._CanReportWeighman)
                {
                    this._CanReportWeighman = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportDriver;
        public bool CanReportDriver
        {
            get
            {
                return this._CanReportDriver;
            }
            set
            {
                if (value != this._CanReportDriver)
                {
                    this._CanReportDriver = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportTransaction;
        public bool CanReportTransaction
        {
            get
            {
                return this._CanReportTransaction;
            }
            set
            {
                if (value != this._CanReportTransaction)
                {
                    this._CanReportTransaction = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanNewRole;
        public bool CanNewRole
        {
            get
            {
                return this._CanNewRole;
            }
            set
            {
                if (value != this._CanNewRole)
                {
                    this._CanNewRole = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanEditRole;
        public bool CanEditRole
        {
            get
            {
                return this._CanEditRole;
            }
            set
            {
                if (value != this._CanEditRole)

                    this._CanEditRole = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanReportRole;
        public bool CanReportRole
        {
            get
            {
                return this._CanReportRole;
            }
            set
            {
                if (value != this._CanReportRole)
                {
                    this._CanReportRole = value;
                    NotifyPropertyChanged();
                }
            }
        }


        private bool _CanNewSite;
        public bool CanNewSite
        {
            get
            {
                return this._CanNewSite;
            }
            set
            {
                if (value != this._CanNewSite)
                {
                    this._CanNewSite = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanEditSite;
        public bool CanEditSite
        {
            get
            {
                return this._CanEditSite;
            }
            set
            {
                if (value != this._CanEditSite)

                    this._CanEditSite = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanDeleteSite;
        public bool CanDeleteSite
        {
            get
            {
                return this._CanDeleteSite;
            }
            set
            {
                if (value != this._CanDeleteSite)

                    this._CanDeleteSite = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanReportSite;
        public bool CanReportSite
        {
            get
            {
                return this._CanReportSite;
            }
            set
            {
                if (value != this._CanReportSite)
                {
                    this._CanReportSite = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanReportOperator;
        public bool CanReportOperator
        {
            get
            {
                return this._CanReportOperator;
            }
            set
            {
                if (value != this._CanReportOperator)
                {
                    this._CanReportOperator = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private bool _CanEditXeroIntegration { get; set; }
        public bool CanEditXeroIntegration
        {
            get
            {
                return this._CanEditXeroIntegration;
            }
            set
            {
                if (value != this._CanEditXeroIntegration)

                    this._CanEditXeroIntegration = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanEditAppSettings;
        public bool CanEditAppSettings
        {
            get
            {
                return this._CanEditAppSettings;
            }
            set
            {
                if (value != this._CanEditAppSettings)

                    this._CanEditAppSettings = value;
                NotifyPropertyChanged();
            }
        }

        private bool _IsAWSSupportRole;
        public bool IsAWSSupportRole
        {
            get
            {
                return this._IsAWSSupportRole;
            }
            set
            {
                if (value != this._IsAWSSupportRole)

                    this._IsAWSSupportRole = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanNewOffence;
        public bool CanNewOffence
        {
            get
            {
                return this._CanNewOffence;
            }
            set
            {
                if (value != this._CanNewOffence)

                    this._CanNewOffence = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanEditOffence;
        public bool CanEditOffence
        {
            get
            {
                return this._CanEditOffence;
            }
            set
            {
                if (value != this._CanEditOffence)

                    this._CanEditOffence = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanDeleteOffence;
        public bool CanDeleteOffence
        {
            get
            {
                return this._CanDeleteOffence;
            }
            set
            {
                if (value != this._CanDeleteOffence)

                    this._CanDeleteOffence = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanReportOffence;
        public bool CanReportOffence
        {
            get
            {
                return this._CanReportOffence;
            }
            set
            {
                if (value != this._CanReportOffence)

                    this._CanReportOffence = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanViewFirstWeigh;
        public bool CanViewFirstWeigh
        {
            get
            {
                return this._CanViewFirstWeigh;
            }
            set
            {
                if (value != this._CanViewFirstWeigh)

                    this._CanViewFirstWeigh = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanDeleteFirstWeigh;
        public bool CanDeleteFirstWeigh
        {
            get
            {
                return this._CanDeleteFirstWeigh;
            }
            set
            {
                if (value != this._CanDeleteFirstWeigh)

                    this._CanDeleteFirstWeigh = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanLookupDocketAddSignature;
        public bool CanLookupDocketAddSignature
        {
            get
            {
                return this._CanLookupDocketAddSignature;
            }
            set
            {
                if (value != this._CanLookupDocketAddSignature)

                    this._CanLookupDocketAddSignature = value;
                NotifyPropertyChanged();
            }
        }

        private bool _CanLookupDocketUpdSignature;
        public bool CanLookupDocketUpdSignature
        {
            get
            {
                return this._CanLookupDocketUpdSignature;
            }
            set
            {
                if (value != this._CanLookupDocketUpdSignature)

                    this._CanLookupDocketUpdSignature = value;
                NotifyPropertyChanged();
            }
        }

        public Role()
        {
            Reset(Constants.NAEntityID);
        }

        public void Reset(int naEntityID)
        {
            //SiteCreated = false;
        }

    }
}
