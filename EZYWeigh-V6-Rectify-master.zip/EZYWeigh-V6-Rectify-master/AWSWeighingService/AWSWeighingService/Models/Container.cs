﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Container : BindableBase, IEntityID
    {
        public int ID { get; set; }

        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name { get; set; }
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code { get; set; }

        [JsonIgnore]
        public string Description { get; set; }


        public void Reset(int naEntityID)
        {
            
        }
    }
}