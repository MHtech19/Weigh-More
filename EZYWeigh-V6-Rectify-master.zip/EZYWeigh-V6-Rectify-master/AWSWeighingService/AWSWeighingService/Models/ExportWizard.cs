﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Models
{
    public class ExportWizard 
    {
        public int ID { get; set; }
        public bool Range { get; set ; }
        
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime FromDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime ToDate { get; set; }
        public string FromInvoiceNumber { get; set; }
        public string ToInvoiceNumber { get; set; }
        public string Account { get; set; }
        public string OrderBy { get; set; }
        public string CheckedList { get; set; }
        public string TransColumnsList { get; set; }
        public int WeighmenID { get; set; }

        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }
    }
}