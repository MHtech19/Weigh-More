﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using AWSWeighingService.Infrastructure.Ticket;
using Newtonsoft.Json;
using PublicWeigh.Config.Lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSWeighingService.Models
{
    public class FirstWeigh : BindableBase, IEntityID
    {
        public FirstWeigh()
        {
            Reset();
        }

        public FirstWeigh(Transaction tran)
        {
            Name = tran.Registration1;
            Comment = tran.Comment;
            Registration2 = tran.Registration2;
            Registration3 = tran.Registration3;
            Payments = tran.Payments;
            LoadType = tran.LoadType;
            Direction = tran.Direction;
            VehicleOwner = tran.VehicleOwner;
            ChargeRate = tran.ChargeRate;

            Tare1 = tran.Tare1;
            Tare2 = tran.Tare2;
            Tare3 = tran.Tare3;
            Tare4 = tran.Tare4;
            Tare5 = tran.Tare5;

            Site = tran.Site;
            SiteID = tran.Site.ID;
            Weighman = tran.Weighman;
            WeighmanID = tran.Weighman.ID;
            Customer = tran.Customer;
            CustomerID = tran.Customer.ID;
           
            
            Product = tran.Product;
            ProductID = tran.Product.ID;
            Job = tran.Job;
            JobID = tran.Job.ID;
            //TruckID = CoreConstants.NA_ID;
            Destination = tran.Destination;
            DestinationID = tran.Destination.ID;
            Source = tran.Source;
            SourceID = tran.Source.ID;

            if (tran.ProductCategory != null)
            {
                ProductCategory = tran.ProductCategory;
                ProductCategoryID = tran.ProductCategory.ID;
            }
            else
            {
                // ProductCategory = ProductCategoryNA;
                ProductCategoryID = CoreConstants.NA_ID;
            }

            if (tran.Driver != null)
            {
                Driver = tran.Driver;
                DriverID = tran.Driver.ID;
            }
            else
            {
                // ProductCategory = ProductCategoryNA;
                DriverID = CoreConstants.NA_ID;
            }
           
            //VehicleConfigurationID = CoreConstants.NA_ID;
            //MarkID = CoreConstants.NA_ID;
            //VehicleID = CoreConstants.NA_ID;

            TareInDate = DateTime.Now;

            Haulage = tran.Haulage;
            DeliveryAddress = tran.DeliveryAddress;
            OrderNumber = tran.OrderNumber;
            IsShowAllJobsClicked = tran.IsShowAllJobsClicked;
        }

        public int ID { get; set; }

        public string Name { get; set; }
        public string Comment { get; set; }

        public string Registration2 { get; set; }
        public string Registration3 { get; set; }

        public string Payments { set; get; }
        public string LoadType { get; set; }
        public string Direction {get; set;}
        public string VehicleOwner { get; set; }
        public string ChargeRate { get; set; }

        public DateTime TareInDate { get; set; }

        public decimal Tare1 { get; set; }
        public decimal Tare2 { get; set; }
        public decimal Tare3 { get; set; }
        public decimal Tare4 { get; set; }
        public decimal Tare5 { get; set; }

        public string Snapshot1 { get; set; }
        public string Snapshot2 { get; set; }
        public string Snapshot3 { get; set; }
        public string Snapshot4 { get; set; }

        [DefaultValue(0.00)]
        public decimal Haulage { get; set; }

        public string DeliveryAddress { get; set; }

        public string OrderNumber { get; set; }

        public bool IsShowAllJobsClicked { get; set; }

        [JsonIgnore]
        public decimal Tare
        {
            get
            {
                return Tare1 + Tare2 + Tare3 + Tare4 + Tare5;
            }
        }

        //linked entities
        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }

        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }

        public int JobID { get; set; }
        [JsonIgnore]
        public virtual Job Job { get; set; }

        public int CustomerID { get; set; }
        [JsonIgnore]
        public virtual Customer Customer { get; set; }

        public int SupplierID { get; set; }


        public int ProductID { get; set; }
        [JsonIgnore]
        public virtual Product Product { get; set; }


        public int ProductCategoryID { get; set; }
        [JsonIgnore]
        public virtual ProductCategory ProductCategory { get; set; }

        public int DestinationID { get; set; }
        [JsonIgnore]
        public virtual Destination Destination { get; set; }


        public int SourceID { get; set; }
        [JsonIgnore]
        public virtual Source Source { get; set; }

        public int DriverID { get; set; }
        [JsonIgnore]
        public virtual Driver Driver { get; set; }

        public void Reset()
        {
            Name = CoreConstants.NA;
            Comment = CoreConstants.NA;
            Registration2 = CoreConstants.NA;
            Registration3 = CoreConstants.NA;
            Payments = CoreConstants.NA;
            LoadType = CoreConstants.NA;
            Direction = CoreConstants.NA;
            VehicleOwner = CoreConstants.NA;
            ChargeRate = CoreConstants.NA;

            Tare1 = 0;
            Tare2 = 0;
            Tare3 = 0;
            Tare4 = 0;
            Tare5 = 0;

            SiteID = CoreConstants.NA_ID;
            WeighmanID = CoreConstants.NA_ID;
            CustomerID = CoreConstants.NA_ID;
            ProductCategoryID = CoreConstants.NA_ID;
            ProductID = CoreConstants.NA_ID;
            JobID = CoreConstants.NA_ID;
            //TruckID = CoreConstants.NA_ID;
            DestinationID = CoreConstants.NA_ID;
            SourceID = CoreConstants.NA_ID;
            DriverID = CoreConstants.NA_ID;
            //VehicleConfigurationID = CoreConstants.NA_ID;
            //MarkID = CoreConstants.NA_ID;
            //VehicleID = CoreConstants.NA_ID;

            TareInDate = DateTime.Now;

            Haulage = 0;
            DeliveryAddress = string.Empty;
            OrderNumber = string.Empty;
        }

        public List<string> GenerateTicket(Transaction currentTransaction, AWSConfiguration _conf)
        {
            List<string> ticket = new List<string>();
            BaseTicket firstWeighTicket = new FirstWeighTicket("First Weigh", this, currentTransaction, _conf);
            ticket = firstWeighTicket.GenerateTicket();
            return ticket;
        }

        public void Reset(int naEntityID)
        {
           // throw new NotImplementedException();
        }
    }
}