﻿

using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
   
    public class BinContainer : BindableBase, IEntityID
    {
   
        public int ID { get; set; }

        
        public string Name { get; set; }

       
        public string Description { get; set; }





        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }
}
