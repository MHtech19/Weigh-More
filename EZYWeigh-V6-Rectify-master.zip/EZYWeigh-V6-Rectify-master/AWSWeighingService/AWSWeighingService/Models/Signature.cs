﻿using AWSWeighingService.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWSWeighingService.Models
{
    public class Signature : IEntityID
    {
        public int ID { get; set; }

        public int TransactionID { get; set; }
        
        public byte[] Content { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime? SignedOn { get; set; }

        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }
}