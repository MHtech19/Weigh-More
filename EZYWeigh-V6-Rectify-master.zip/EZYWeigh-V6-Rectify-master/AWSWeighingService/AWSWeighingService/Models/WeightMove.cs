﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class WeightMove : BindableBase, IEntityID
    {
        public int ID { get; set; }
        
        public double WeightPassed { get; set; }
        public DateTime DateTimeIn { get; set; }
        public bool IsWeighPass { get; set; }
        public string Registration { get; set; }
        public string SiteName { get; set; }
        public string WeighmanName { get; set; }
        public string PlatformID { get; set; }
        

        public int SiteID { get; set; }
        [JsonIgnore]
        public virtual Site Site { get; set; }

        public int WeighmanID { get; set; }
        [JsonIgnore]
        public virtual Weighman Weighman { get; set; }


        public void Reset(int naEntityID)
        {
            SiteID = naEntityID;
            WeighmanID = naEntityID;
        }

        public WeightMove()
        {
            Reset(Constants.NAEntityID);
        }
    }
}
