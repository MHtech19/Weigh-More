﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class Driver : BindableBase, IEntityID
    {
        public int ID { get; set; }

        private string _Name;
        [Required]
        [StringLength(40, ErrorMessage = "Name cannot be longer than 40 characters.")]
        public string Name
        {
            get { return _Name; }
            set { this.SetProperty(ref _Name, value); }
        }

        private string _Code;
        [Required]
        [StringLength(40, ErrorMessage = "Code cannot be longer than 40 characters.")]
        public string Code
        {
            get { return _Code; }
            set { this.SetProperty(ref _Code, value); }
        }

        [JsonIgnore]
        public string Description { get; set; }

        [JsonIgnore]
        public string Address1 { get; set; }

        [JsonIgnore]
        public string Address2 { get; set; }

        [JsonIgnore]
        public string Suburb { get; set; }

        [JsonIgnore]
        public string State { get; set; }

        [JsonIgnore]
        public string Postcode { get; set; }

        [JsonIgnore]
        public string Country { get; set; }

        private string _Phone;
        public string Phone
        {
            get { return _Phone; }
            set { this.SetProperty(ref _Phone, value); }
        }

        private string _Mobile;
        public string Mobile
        {
            get { return _Mobile; }
            set { this.SetProperty(ref _Mobile, value); }
        }

        private string _Email;
        public string Email
        {
            get { return _Email; }
            set { this.SetProperty(ref _Email, value); }
        }
        

        public void Reset(int naEntityID)
        {
            throw new NotImplementedException();
        }
    }
}