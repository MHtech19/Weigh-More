﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{

    public class TruckSource : BindableBase, IEntityID
    {
        
        public int ID { get; set; }

        public int TruckID { get; set; }
        [JsonIgnore]
        public virtual Truck Truck { get; set; }

        public int SourceID { get; set; }
        [JsonIgnore]
        public virtual Source Source { get; set; }

        public void Reset(int naEntityID)
        {
            
        }
    }
}