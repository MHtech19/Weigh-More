﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using WeighBridge.Core.MVVM;

namespace AWSWeighingService.Models
{
    public class TruckSuppliers : BindableBase, IEntityID
    {
        public int ID { get; set; }

        public int TruckID { get; set; }
        [JsonIgnore]
        public virtual Truck Truck { get; set; }

        public int CustomerID { get; set; }
        [JsonIgnore]
        public virtual Customer Customer { get; set; }

        public string CustomerType { get; set; }

        public void Reset(int naEntityID)
        {

        }
    }
}