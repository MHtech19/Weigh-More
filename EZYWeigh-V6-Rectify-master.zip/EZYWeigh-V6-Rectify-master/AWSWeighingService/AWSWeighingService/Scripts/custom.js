// JavaScript Document
function ContentContainerHeight(){
	var winHeight = $(window).height();
	var headerHeight = $('header').height();
	var footerHeight = $('footer').height();
    var contentHeight = $('.contentContainer').height();
	var docHeight = winHeight - (headerHeight+footerHeight);
	
	if(contentHeight>docHeight){
		$('.wrapper').css('height',contentHeight);
	}else {
		$('.wrapper').css('height',docHeight);
	}
}

$(document).ready(function(){
	//Content Container Height
    ContentContainerHeight();	

    $('.text-center .btn.btn-primary').next('a').append('<span class="glyphicon glyphicon-chevron-left"></span>');
});

$(window).resize(function(){
	ContentContainerHeight();
});

$(window).load(function () {
    $('#navbar').css('visibility','visible');
});

jQuery(function ($) {
    var path = window.location.href; // because the 'href' property of the DOM element is the absolute path
    $('#navbar .nav li a').each(function () {
        if (this.href === path) {
            $(this).addClass('active');
        }
    });
});