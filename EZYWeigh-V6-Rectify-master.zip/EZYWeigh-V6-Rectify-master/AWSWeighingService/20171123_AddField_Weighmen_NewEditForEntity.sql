﻿use AWSWeighingService;

go
ALTER TABLE Weighmen
  ADD CanNewProduct bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditProduct bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewProductCategory bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditProductCategory bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewCustomer bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditCustomer bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewDestination bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditDestination bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewSource bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditSource bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewJob bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditJob bit NOT NULL default 0;
go
        
ALTER TABLE Weighmen
  ADD CanNewTruck bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditTruck bit NOT NULL default 0;
go
       
ALTER TABLE Weighmen
  ADD CanNewTruckConfiguration bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditTruckConfiguration bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewVehicleType bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditVehicleType bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewWeighman bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditWeighman bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewDriver bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditDriver bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanNewTransaction bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanEditTransaction bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanReportProduct bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanReportProductCategory bit NOT NULL default 0;
go
 
ALTER TABLE Weighmen
  ADD CanReportCustomer bit NOT NULL default 0;
go
 
ALTER TABLE Weighmen
  ADD CanReportDestination bit NOT NULL default 0;
go
 
ALTER TABLE Weighmen
  ADD CanReportSource  bit NOT NULL default 0;
go
 
ALTER TABLE Weighmen
  ADD CanReportJob  bit NOT NULL default 0;
go
 
ALTER TABLE Weighmen
  ADD CanReportTruck  bit NOT NULL default 0;
go
       
ALTER TABLE Weighmen
  ADD CanReportTruckConfiguration  bit NOT NULL default 0;
go
 
ALTER TABLE Weighmen
  ADD CanReportVehicleType  bit NOT NULL default 0;
go

ALTER TABLE Weighmen
  ADD CanReportWeighman  bit NOT NULL default 0;
go
 
ALTER TABLE Weighmen
  ADD CanReportDriver  bit NOT NULL default 0;
go
  
ALTER TABLE Weighmen
  ADD CanReportTransaction  bit NOT NULL default 0;
go
       



Update Weighmen set

CanNewProduct = 1,
CanEditProduct  = 1,

CanNewProductCategory  = 1,
CanEditProductCategory  = 1,

CanNewCustomer  = 1,
CanEditCustomer  = 1,

CanNewDestination  = 1,
CanEditDestination  = 1,

CanNewSource  = 1,
CanEditSource  = 1,

CanNewJob  = 1,
CanEditJob  = 1,

CanNewTruck  = 1,
CanEditTruck  = 1,

CanNewTruckConfiguration  = 1,
CanEditTruckConfiguration  = 1,

CanNewVehicleType  = 1,
CanEditVehicleType  = 1,

CanNewWeighman  = 1,
CanEditWeighman  = 1,

CanNewDriver  = 1,
CanEditDriver  = 1,

CanNewTransaction  = 1,
CanEditTransaction  = 1,

CanReportProduct = 1,
 
CanReportProductCategory = 1,
 
CanReportCustomer = 1,
 
CanReportDestination = 1,
 
CanReportSource = 1,
 
CanReportJob = 1,
 
CanReportTruck = 1,
       
CanReportTruckConfiguration = 1,
 
CanReportVehicleType = 1,
        
CanReportWeighman = 1,
 
CanReportDriver = 1,
  
CanReportTransaction = 1
       

where Name = 'AWS'
or Name = 'MASTER';
go



 
