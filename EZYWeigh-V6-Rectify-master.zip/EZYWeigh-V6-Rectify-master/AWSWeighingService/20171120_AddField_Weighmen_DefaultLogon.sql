﻿use AWSWeighingService;

go
ALTER TABLE Weighmen
  ADD DefaultLogon bit NOT NULL default 0;
go

Update Weighmen set DefaultLogon = 1 where Name = 'AWS';
go



 
