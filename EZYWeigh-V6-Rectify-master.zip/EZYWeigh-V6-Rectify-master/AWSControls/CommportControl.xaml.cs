﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AWSControls
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    /// 
    public delegate void CommPortSelectionChangedHandler(string device);

    public partial class CommportControl : UserControl
    {
        public List<string> AvailablePorts
        {
            get
            {
                List<string> lst = new List<string>();
                for (int i = 0; i < cbPort.Items.Count; i++)
                {
                    lst.Add(cbPort.Items[i].ToString());
                }
                return lst;
            }
        }

        public string SelectedPort
        {
            get { return this.cbPort.SelectedValue.ToString(); }
        }
        public event CommPortSelectionChangedHandler CommPortSelectionChanged;

        public PublicWeigh.Config.Lib.CommPort CommPort
        {
            get
            {
                if (cbPort.SelectedIndex == -1 || cbPort.SelectedValue.ToString() == "Not Fitted")
                {
                    return null;
                }
                else
                {
                    PublicWeigh.Config.Lib.CommPort _commPort = new PublicWeigh.Config.Lib.CommPort();
                    _commPort.PORT = cbPort.SelectedValue.ToString();
                    _commPort.Device = this.Title;
                    if (this.cbBaudRate.SelectedIndex != -1)
                        _commPort.BaudRate = int.Parse(this.cbBaudRate.SelectedValue.ToString());
                    if (this.cbDataBits.SelectedIndex != -1)
                        _commPort.DataBits = int.Parse(this.cbDataBits.SelectedValue.ToString());

                    if (this.cbStopBits.SelectedIndex != -1)
                        _commPort.StopBits = this.cbStopBits.SelectedValue.ToString();
                    if (this.cbParity.SelectedIndex != -1)
                        _commPort.Parity = this.cbParity.SelectedValue.ToString();
                    if (this.cbIndicatorType.SelectedIndex != -1)
                        _commPort.IndicatorType = this.cbIndicatorType.SelectedValue.ToString();

                    _commPort.ZeroCommand = this.txtZeroCommand.Text;

                    return _commPort;
                }
            }
        }

        public static readonly DependencyProperty val = DependencyProperty.Register(
            "Title",
            typeof(string),
            typeof(CommportControl),
            new UIPropertyMetadata(
                "Title",
                new PropertyChangedCallback
                    ((s, e) =>
                    {
                        
                    }
                    )
                ));

        public string Title
        {
            get { return (string)this.GetValue(val); }
            set
            {
                this.Device.Content = value;
                this.SetValue(val, value);
            }
        }


        //public string Text
        //{
        //    get { return this.Device.Content.ToString(); }
        //    set { this.Device.Content = value; }
        //}
        public CommportControl()
        {
            InitializeComponent();
        }
        public PublicWeigh.Config.Lib.ConfigurationDictionary DictionaryDataSource { get; set; }
        public void LoadDictionary(PublicWeigh.Config.Lib.ConfigurationDictionary dictionary)
        {
            this.DictionaryDataSource = dictionary;

            //ports dictionary data are loaded in "LoadPorts" specifically, as the 5 ports are related we need design algorithm in UI.

            //cbPort.Items.Clear();
            //foreach (string s in dictionary.Ports)
            //    cbPort.Items.Add(s);
           // cbPort.SelectedValue = "Not Fitted";

            cbBaudRate.Items.Clear ();
            foreach (int i in dictionary.BaudRates)
                cbBaudRate.Items.Add(i.ToString());

            cbDataBits.Items.Clear();
            foreach (byte b in dictionary.DataBits)
                cbDataBits.Items.Add(b.ToString());

            cbIndicatorType.Items.Clear();
            foreach (string s in dictionary.IndicatorTypes)
                cbIndicatorType.Items.Add(s);

            cbStopBits.Items.Clear();
            foreach (byte b in dictionary.StopBits)
                cbStopBits.Items.Add(b.ToString());

            cbParity.Items.Clear();
            foreach (string s in dictionary.Parities)
                cbParity.Items.Add(s);

            LoadData(new PublicWeigh.Config.Lib.CommPort());
        }

        public void LoadPorts(List<string> Ports)
        {
            string selection = null;
            if (cbPort.SelectedValue != null)
            {
                selection = cbPort.SelectedValue.ToString();
            }
            cbPort.Items.Clear();
            foreach (string s in Ports)
                cbPort.Items.Add(s);
            cbPort.SelectedValue = selection;
        }

        public void LoadData(PublicWeigh.Config.Lib.CommPort commPort)
        {
            if (commPort == null ||commPort.PORT==null || commPort.PORT=="Not Fitted")
            {
                this.cbPort.SelectedValue = "Not Fitted";
                this.cbBaudRate.SelectedIndex = -1;
                this.cbDataBits.SelectedIndex = -1;
                this.cbIndicatorType.SelectedIndex = -1;
                this.cbParity.SelectedIndex = -1;
                this.cbStopBits.SelectedIndex = -1;
                this.txtZeroCommand.Text = null;

                this.cbBaudRate.IsEnabled = false;
                this.cbDataBits.IsEnabled = false;
                this.cbIndicatorType.IsEnabled = false;
                this.cbParity.IsEnabled = false;
                this.cbStopBits.IsEnabled = false;
                this.txtZeroCommand.IsEnabled = false;

            }
            else if (commPort.PORT == "TCP/IP")
            {
                this.cbPort.SelectedValue = "TCP/IP";
                this.cbBaudRate.SelectedIndex = -1;
                this.cbDataBits.SelectedIndex = -1;
                this.cbIndicatorType.SelectedIndex = -1;
                this.cbParity.SelectedIndex = -1;
                this.cbStopBits.SelectedIndex = -1;
                this.txtZeroCommand.Text = commPort.ZeroCommand;

                this.cbBaudRate.IsEnabled = false;
                this.cbDataBits.IsEnabled = false;
                this.cbIndicatorType.IsEnabled = false;
                this.cbParity.IsEnabled = false;
                this.cbStopBits.IsEnabled = false;
                this.txtZeroCommand.IsEnabled = true;

            }

            else
            {
                this.cbPort.SelectedValue = commPort.PORT;
                this.Device.Header = commPort.Device;
                this.cbBaudRate.SelectedValue = commPort.BaudRate.ToString();
                this.cbDataBits.SelectedValue = commPort.DataBits.ToString();
                this.cbIndicatorType.SelectedValue = commPort.IndicatorType;
                this.cbParity.SelectedValue = commPort.Parity;

                //if (this.cbStopBits.SelectedValue != null)
                {
                    this.cbStopBits.SelectedValue = commPort.StopBits.ToString();

                } 
                
                this.txtZeroCommand.Text = commPort.ZeroCommand;

                this.cbBaudRate.IsEnabled = true;
                this.cbDataBits.IsEnabled = true;
                this.cbIndicatorType.IsEnabled = true;
                this.cbParity.IsEnabled = true;
                this.cbStopBits.IsEnabled = true;
                this.txtZeroCommand.IsEnabled = true;
            }
        }

        private void cbPort_SelectionChanged(object sender, MouseEventArgs e)
        {
            
            if (this.cbPort.SelectedValue.ToString() == "" || this.cbPort.SelectedValue.ToString() == "Not Fitted")
            {
                LoadData(null);
            }
            else
            {
                
                this.cbBaudRate.IsEnabled = true;
                this.cbDataBits.IsEnabled = true;
                this.cbIndicatorType.IsEnabled = true;
                this.cbParity.IsEnabled = true;
                this.cbStopBits.IsEnabled = true;
                this.txtZeroCommand.IsEnabled = true;

            }
            CommPortSelectionChanged.Invoke(this.Title);
        }

        private void cbPort_DropDownClosed(object sender, EventArgs e)
        {
            if (this.cbPort.SelectedValue.ToString() == "" || this.cbPort.SelectedValue.ToString() == "Not Fitted")
            {
                LoadData(null);
            }
            else if (this.cbPort.SelectedValue.ToString() == "TCP/IP")
            {
                LoadData(null);
                this.labelZeroCommand.Content = "IP:Port";
                this.cbPort.Text = "TCP/IP"; 
                this.txtZeroCommand.IsEnabled = true;

            }
            else
            {

                this.cbBaudRate.IsEnabled = true;
                this.cbDataBits.IsEnabled = true;
                this.cbIndicatorType.IsEnabled = true;
                this.cbParity.IsEnabled = true;
                this.cbStopBits.IsEnabled = true;
                this.txtZeroCommand.IsEnabled = true;

            }
            CommPortSelectionChanged.Invoke(this.Name);
        }

    }
}
