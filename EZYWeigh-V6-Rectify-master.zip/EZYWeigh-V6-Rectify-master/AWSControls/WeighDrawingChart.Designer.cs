﻿namespace AWSControls
{
    partial class WeighDrawingChart
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Chart = new System.Windows.Forms.PictureBox();
            this.AxleY = new System.Windows.Forms.PictureBox();
            this.AxleX = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AxleY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AxleX)).BeginInit();
            this.SuspendLayout();
            // 
            // Chart
            // 
            this.Chart.BackColor = System.Drawing.Color.Black;
            this.Chart.Location = new System.Drawing.Point(27, 0);
            this.Chart.Name = "Chart";
            this.Chart.Size = new System.Drawing.Size(319, 142);
            this.Chart.TabIndex = 0;
            this.Chart.TabStop = false;
            // 
            // AxleY
            // 
            this.AxleY.Location = new System.Drawing.Point(3, 0);
            this.AxleY.Name = "AxleY";
            this.AxleY.Size = new System.Drawing.Size(27, 142);
            this.AxleY.TabIndex = 1;
            this.AxleY.TabStop = false;
            // 
            // AxleX
            // 
            this.AxleX.Location = new System.Drawing.Point(3, 138);
            this.AxleX.Name = "AxleX";
            this.AxleX.Size = new System.Drawing.Size(343, 30);
            this.AxleX.TabIndex = 2;
            this.AxleX.TabStop = false;
            // 
            // WeighDrawingChart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Controls.Add(this.AxleX);
            this.Controls.Add(this.AxleY);
            this.Controls.Add(this.Chart);
            this.MinimumSize = new System.Drawing.Size(200, 100);
            this.Name = "WeighDrawingChart";
            this.Size = new System.Drawing.Size(349, 171);
            this.Load += new System.EventHandler(this.WeightDrawingChart_Load);
            this.Resize += new System.EventHandler(this.Me_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.Chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AxleY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AxleX)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Chart;
        private System.Windows.Forms.PictureBox AxleY;
        private System.Windows.Forms.PictureBox AxleX;
    }
}
