﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
namespace AWSControls
{
    public partial class BoomGate : UserControl
    {
        private string[] _frames;
        private System.Reflection.Assembly _thisExe;

        private delegate void FrameChangedHandler();
        private event FrameChangedHandler FrameChanged;

       

        private string _currentImage;
        public string CurrentImage
        {
            get
            {
                return _currentImage;
            }
            set
            {
                this._currentImage = value;
                FrameChanged(); 
            }
        }
        public BoomGate()
        {
            InitializeComponent();

            this.FrameChanged += me_FrameChanged;
            _thisExe = System.Reflection.Assembly.GetExecutingAssembly();
            _frames = _thisExe.GetManifestResourceNames();

        }


        private object _lock = new object();
        private void me_FrameChanged()
        {
            lock (this._lock)
            {
                string currentImageFile = "AWSControls.Resources." + _currentImage + ".gif";
                if (this._frames != null)
                {
                    if (this._frames.Contains(currentImageFile))
                    {

                        System.IO.Stream file = _thisExe.GetManifestResourceStream(currentImageFile);
                        //Image img = Image.FromStream(file);
                        //img.Size = new Size(pictureBox1.Size.Width, pictureBox1.Size.Height);
                        this.pictureBox1.Image = Image.FromStream(file);
                        //this.BackgroundImage = Image.FromStream(file);

                    }
                    else
                    {
                        try
                        {
                            if (int.Parse(_currentImage) > 9 && int.Parse(_currentImage) < 14)
                            {
                                System.IO.Stream file = _thisExe.GetManifestResourceStream("AWSControls.Resources.8.gif");
                                //Image img = Image.FromStream(file);
                                //img.Size = new Size(pictureBox1.Size.Width, pictureBox1.Size.Height);
                                this.pictureBox1.Image = Image.FromStream(file);
                            }
                        }
                        catch
                        {
                        }
                    }
                    
                }
                
                
                    
            }
        }

        private void me_SizeChanged(object sender, EventArgs e)
        {
            this.pictureBox1.Size = this.Size;

        }


    }
}
