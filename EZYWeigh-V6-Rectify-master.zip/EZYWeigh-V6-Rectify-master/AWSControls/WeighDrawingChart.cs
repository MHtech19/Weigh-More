﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace AWSControls
{
    public partial class WeighDrawingChart : UserControl
    {

        //private System.Windows.Forms.Timer timer1 = new Timer();

        private delegate void ValueChangedHandler();
        private event ValueChangedHandler ValueChanged;

        private bool _enabled;
        //public bool Enabled
        //{
        //    get { return this._enabled; }
        //    set { this._enabled = value; }
        //}

        private float scale;
        private int _maxScale;
        public int MaxScale
        {
            get { return this._maxScale; }
            set { this._maxScale = value; }
        }


        private int x;
        private int _interval =100;

        //the interval to send data
        public int Interval
        {
            get { return _interval; }
            set { _interval = value; }
        }

        private float y; //the y value which is calculated based on Value

        private float _value;
        public float Value
        {
            get { return this._value; }
            set
            {
                this._value = value;
                if (_enabled == true)
                {
                    ValueChanged();
                }
            }
        }

        private bool _permitNegative = false;
        public bool PermitNegative
        {
            get { return _permitNegative; }
            set { _permitNegative = value; }
        }

        private string _title;
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }


        Bitmap drawingSurface;
        Graphics drawingGraphics;
        Pen _greenPen;
        private object _lock = new object();

        public WeighDrawingChart()
        {
            this.ValueChanged += me_ValueChanged;
            InitializeComponent();
        }

        private void WeightDrawingChart_Load(object sender, EventArgs e)
        {

            init();
        }
        public void init()
        {
            this.x = 0;
            //if (_permitNegative)
            //{
            //    this.scale = (float)this.Size.Height / (this._maxScale * 2);  //permit negative
            //}
            //else
            //{

            //}
            this.AxleY.Location = new Point(0, 0);
            this.AxleY.Size = new Size(20, this.Height - 20);
            this.AxleY.BackgroundImage = new Bitmap(AxleY.Width, AxleY.Height);

            this.AxleX.Location = new Point(0, AxleY.Height);
            this.AxleX.Size = new Size(this.Width, this.Height - AxleY.Height);
            this.AxleX.BackgroundImage = new Bitmap(AxleX.Width, AxleX.Height);
            Graphics graphX = Graphics.FromImage(this.AxleX.BackgroundImage);
            Graphics graphY = Graphics.FromImage(AxleY.BackgroundImage);

            this.scale = (float)this.AxleY.Height / (this._maxScale);

            this.Chart.Width = this.Size.Width - AxleY.Width;
            this.Chart.Height = this.Size.Height - AxleX.Height;

            this.drawingSurface = new Bitmap(this.Chart.Width, this.Chart.Height);
            this.drawingGraphics = Graphics.FromImage(this.drawingSurface);
            this.Chart.BackgroundImage = this.drawingSurface;
            this.Chart.Location = new Point(AxleY.Width, 0);

            System.Drawing.Font drawFont = new System.Drawing.Font("Arial", 8);
            System.Drawing.SolidBrush drawBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Black);
            //draw the Y axle
            //System.Drawing.StringFormat drawFormat = new System.Drawing.StringFormat(StringFormatFlags.DirectionVertical);

            _greenPen = new Pen(Color.Green, 2);
            for (int i = 1; i <= 3; i++)
            {
                this.drawingGraphics.DrawLine(_greenPen, new PointF(0, i * this.AxleY.Height / 4), new PointF(this.AxleY.Width / 4, i * this.AxleY.Height / 4));

            }
            graphY.DrawString("kg", drawFont, drawBrush, 0, 0);

            // draw the X axle

            graphX.DrawString("sec", drawFont, drawBrush, this.AxleX.Width - 30, 0);

            //total how many seconds in X axle:
            int totalSec = this.Chart.Width * this.Interval/1000;
            //how many units:
            int units;
            if (totalSec < 10)  //less than 10, each unit as 5 seconds
                units = 2;
            else
                units = totalSec / 10 + 1;
            
           

            for (int j = 0; j <= units ; j++)
            {
                for (int k=1; k<=4; k++)
                {
                    this.drawingGraphics.DrawLine(_greenPen, new Point(j * this.Chart.Width / units + k * this.Chart.Width / (units * 5), this.Chart.Height - 5), new Point(j * this.Chart.Width / units + k * this.Chart.Width / (units * 5), this.Chart.Height));
                }
                this.drawingGraphics.DrawLine(_greenPen, new Point(j * this.Chart.Width / units, this.Chart.Height - 10), new Point(j * this.Chart.Width / units, this.Chart.Height));
                //if (j != 0)
                //{
                    if(totalSec <10)
                        graphX.DrawString((j * 5).ToString(), drawFont, drawBrush, AxleY.Width + j * this.Chart.Width / units, 0);
                    else
                        graphX.DrawString((j * 10).ToString(), drawFont, drawBrush, AxleY.Width + j * this.Chart.Width / units, 0);
                //}
            }


            drawFont.Dispose();
            drawBrush.Dispose();
            graphX.Dispose();
            graphY.Dispose();


            //for (int i = 1; i <= 5; i++)
            //{
            //    this.drawingGraphics.DrawLine(whitePen, 0, Hei / 2 + i * this.Height / 10, Wid, Hei / 2 + i * this.Height / 10);
            //    this.drawingGraphics.DrawLine(whitePen, 0, Hei / 2 - i * this.Height / 10, Wid, Hei / 2 - i * this.Height / 10);
            //}


            _greenPen = new Pen(Color.Green, 1);

            //if (_permitNegative)
            //{
            //    this.drawingGraphics.DrawLine(_greenPen, 0, Hei / 2, Wid, Hei / 2); //permit negative
            //}
            //else
            //{
            //    this.drawingGraphics.DrawLine(_greenPen, 0, Hei, Wid, Hei);
            //}
        }
        public void Start()
        {
            WeightDrawingChart_Load(null, null);
            this._enabled = true;
            //timer1 = new Timer();


            //timer1.Interval = 100;
            //if(this.Interval >0)
            //    timer1.Interval = Interval;

            //timer1.Enabled = true;
            //timer1.Tick += timer1_Tick;
            //timer1.Start();
        }
        public void Stop()
        {

            //timer1.Stop();
            //timer1.Enabled = false;
            this._enabled = false;
            //this.ValueChanged -= me_ValueChanged;
            this.drawingSurface = new Bitmap(this.Chart.Width, this.Chart.Height);
        }

        private void me_ValueChanged()
        {
            lock (this._lock)
            {
                //int o_x = this.x;  //original x

                PointF original_Point = new PointF(this.x, this.y);

                this.x += 1;
                //float tmpY;

                if (_permitNegative)
                {
                    this.y = this.Chart.Height / 2 + (-1) * (this._value * this.scale);

                }
                else
                {
                    this.y = this.Chart.Height + (-1) * (this._value * this.scale);
                }
                //if (x == 0)
                //{
                //    this.drawingGraphics.FillEllipse(Brushes.Green, x, tmpY, 2, 2);
                //}
                //else
                //{
                //this.drawingGraphics.FillEllipse(Brushes.Green, x, this.y, 1, 1);
                this.drawingGraphics.DrawLine(_greenPen, original_Point, new PointF(this.x, this.y));
                //}
                this.Chart.Invalidate();
                if (this.x > this.Chart.Width)
                    init();
            }
        }

        private void Me_Resize(object sender, EventArgs e)
        {
            init();
        }
    }
}
