﻿using AWSWeighingService.Abstract;
using AWSWeighingService.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AWSDataService.RestService
{
    public class RestService : IRestService
    {
        HttpClient client;

        public RestService()
        {            
            client = new HttpClient();
            //  HttpClientHandler httpClientHandler = new HttpClientHandler(); // these 2 lines are for bypassing some server settings that will cause StatusCode: 417, ReasonPhrase: 'Expectation failed' error
            client.DefaultRequestHeaders.ExpectContinue = false;
            client.MaxResponseContentBufferSize = 25600000;
        }

        /// <summary>
        /// It is used for add the client Secret key to the header
        /// </summary>
        /// <param name="currentWeighmanId"></param>
        /// <returns></returns>
        public Task<string> setRestServiceHeaders(int currentWeighmanId)
        {
            return Task.Run(() =>
            {
                string clientSecret = currentWeighmanId.ToString().Encrypt();
                client.DefaultRequestHeaders.Add("X-Client-Secret", clientSecret);
                return clientSecret;
            });
        }

        public async Task<List<TEntity>> RefreshTEntityListAsync<TEntity>(string uriString) where TEntity : IEntityID
        {
            var entities = new List<TEntity>();
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, string.Empty));

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entities = JsonConvert.DeserializeObject<List<TEntity>>(content);
                }
                

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entities;
        }

        public async Task<List<TEntity>> RefreshTEntityListAsync<TEntity>(int id, string uriString) where TEntity : IEntityID
        {
            var entities = new List<TEntity>();
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}           
            var uri = FormatURI(id, uriString);

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entities = JsonConvert.DeserializeObject<List<TEntity>>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entities;
        }

        public async Task<ObservableCollection<TEntity>> RefreshTEntityObservableCollectionAsync<TEntity>(string uriString) where TEntity : IEntityID
        {
            var entities = new ObservableCollection<TEntity>();
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, string.Empty));

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entities = JsonConvert.DeserializeObject<ObservableCollection<TEntity>>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entities;
        }

        public async Task<bool> PostTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID
        {
            bool returnedResult = false;
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, entity.ID));

            try
            {
                var json = JsonConvert.SerializeObject(entity);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = null;
                response = await client.PostAsync(uri, content);

                returnedResult = response.IsSuccessStatusCode;
                
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return returnedResult;
        }
        
        public async Task<TEntity> CreateTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID
        {
            TEntity returnedEntity = default(TEntity); // to be null
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format(uriString, entity.ID));

            try
            {
                var json = JsonConvert.SerializeObject(entity);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = null;
                response = await client.PostAsync(uri, content); 
            
                if (response.IsSuccessStatusCode)
                {
                    var returnedContent = await response.Content.ReadAsStringAsync();
                    returnedEntity = JsonConvert.DeserializeObject<TEntity>(returnedContent);
                    Debug.WriteLine(@"				TodoItem successfully saved.");
                }
                
                
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return returnedEntity;
        }

        public async Task UpdateTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID
        {
            try
            {
                var json = JsonConvert.SerializeObject(entity);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = null;
                response = await client.PutAsync(FormatURI(entity.ID, uriString), content);

                if (response.IsSuccessStatusCode)
                {
                    Debug.WriteLine(@"				TodoItem successfully saved.");
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }
        }

        private Uri FormatURI(int id, string uriString)
        {
            string insertValue = "/" + id.ToString();
            int questionMarkPos = uriString.IndexOf("?");
            string strURI;
            if (questionMarkPos >= 0)
            {
                strURI = uriString.Insert(questionMarkPos, insertValue);
            }
            else
            {
                // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
                strURI = string.Format("{0}/{1}", uriString, id);
            }

            return new Uri(strURI);
        }

        public async Task<bool> DeleteTEntityAsync<TEntity>(int id, string uriString) where TEntity : IEntityID
        {  
            try
            {
                var response = await client.DeleteAsync(FormatURI(id, uriString));

                if (response.IsSuccessStatusCode)
                {
                    Debug.WriteLine(@"				TodoItem successfully deleted.");
                    return true;
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return false;
        }

        public async Task<TEntity> GetTEntityAsync<TEntity>(int id, string uriString) where TEntity : IEntityID
        {            
            TEntity entity = default(TEntity);
                        
            try
            {
                var response = await client.GetAsync(FormatURI(id, uriString));
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entity = JsonConvert.DeserializeObject<TEntity>(content);
                }
               
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entity;
        }

        public async Task<string> GetNextDocketNumber(int siteID, string uriString)
        {
            string docketNumber = null;            
            try
            {
                var response = await client.GetAsync(FormatURI(siteID, uriString));
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    docketNumber = JsonConvert.DeserializeObject<string>(content);
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return docketNumber;

       }

        public async Task<ObservableCollection<TEntity>> GetTEntityObservableCollectionWithIDAsync<TEntity>(int id, string uriString) where TEntity : IEntityID
        {
            var entities = new ObservableCollection<TEntity>();
          
            try
            {
                var response = await client.GetAsync(FormatURI(id, uriString));
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entities = JsonConvert.DeserializeObject<ObservableCollection<TEntity>>(content);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entities;
        }


        public async Task<TEntity> GetTEntityBy2IDsAsync<TEntity>(int id1, int id2, string connectionStringName, string uriString) where TEntity : IEntityID
        {            
            TEntity entity = default(TEntity);
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems{0}
            var uri = new Uri(string.Format("{0}/?id1={1}&id2={2}&connectionStringName={3}", uriString, id1, id2, connectionStringName));

            try
            {
                var response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    entity = JsonConvert.DeserializeObject<TEntity>(content);


                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return entity;
        }

        public async Task UploadImageFile(string uriString, string transactionID, string filePath)
        {
            int id = int.Parse(transactionID);           
            try
            {
                MultipartFormDataContent form = new MultipartFormDataContent();

                FileStream fs = File.OpenRead(filePath);
                var streamContent = new StreamContent(fs);

                var imageContent = new ByteArrayContent(streamContent.ReadAsByteArrayAsync().Result);
                imageContent.Headers.ContentType = MediaTypeHeaderValue.Parse("multipart/form-data");

                form.Add(imageContent, "image", Path.GetFileName(filePath));
                var response = await client.PostAsync(FormatURI(id, uriString), form);

                if (response.IsSuccessStatusCode)
                {
                    Debug.WriteLine(@"				TodoItem successfully saved.");
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }


        }

        public async Task<string> DownloadImageFromDbOk(string uriString, string transactionID, string filePath)
        {
            int id = int.Parse(transactionID);            
            string returnedFileName = string.Empty;
            try
            {
                var response = await client.GetAsync(FormatURI(id, uriString));
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    using (Stream imageStream = await response.Content.ReadAsStreamAsync())
                    {
                        using (var image = System.Drawing.Image.FromStream(imageStream))
                        {
                            System.IO.Directory.CreateDirectory(filePath);
                            string fileName = DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + @".jpeg";
                            returnedFileName = filePath + @"\" + fileName;
                            image.Save(returnedFileName, ImageFormat.Jpeg);                            
                        }                            
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(@"				ERROR {0}", ex.Message);
            }

            return returnedFileName;
        }

        public  async Task<string> GetResponseText(string address)
        {
            return await client.GetStringAsync(address);
        }
    }
}
