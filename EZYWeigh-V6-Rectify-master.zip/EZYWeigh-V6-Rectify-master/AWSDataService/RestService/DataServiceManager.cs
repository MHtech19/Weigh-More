﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using AWSWeighingService.Models;
using AWSWeighingService.Infrastructure;
using System.Collections.Specialized;
using System.Globalization;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace AWSDataService.RestService
{
    /// <summary>
    /// This class provides the services to the WPF application
    /// 
    /// </summary>
	public class DataServiceManager
    {
        private IRestService restService;
        private string _DataServiceUrlRootPart;
        private string _ConnectionNameAsQueryString;
        private string _ConnectionStringName;

        public DataServiceManager(IRestService service, string dataServiceUrlRootPart, string connectionStringName)
        {
            restService = service;
            _DataServiceUrlRootPart = dataServiceUrlRootPart;

            if ((connectionStringName == null) || (connectionStringName.Trim() == string.Empty))
            {
                _ConnectionStringName = CoreConstants.AWSConnectionStringName;
            }
            else
            {
                _ConnectionStringName = connectionStringName;
            }

            var nvc = new NameValueCollection();
            nvc["connectionStringName"] = _ConnectionStringName;
            _ConnectionNameAsQueryString = nvc.ToQueryString();

        }

        //Expose this method to outside for adding the headers
        public Task<string> setHeaders(int currentWeighmanID)
        {
            return restService.setRestServiceHeaders(currentWeighmanID);
        }

        //BinContainer
        public async Task<List<BinContainer>> GetBinContainers()
        {
            return await restService.RefreshTEntityListAsync<BinContainer>(_DataServiceUrlRootPart + Constants.BinContainerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<BinContainer> GetBinContainer(int id)
        {
            return await restService.GetTEntityAsync<BinContainer>(id, _DataServiceUrlRootPart + Constants.BinContainerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<BinContainer> CreateBinContainerAsync(BinContainer aBinContainer)
        {
            return await restService.CreateTEntityAsync<BinContainer>(aBinContainer, _DataServiceUrlRootPart + Constants.BinContainerRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task UpdateBinContainerAsync(BinContainer aBinContainer)
        {
            await restService.UpdateTEntityAsync<BinContainer>(aBinContainer, _DataServiceUrlRootPart + Constants.BinContainerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteBinContainerAsync(BinContainer aBinContainer)
        {
            await restService.DeleteTEntityAsync<BinContainer>(aBinContainer.ID, _DataServiceUrlRootPart + Constants.BinContainerRestUrl + _ConnectionNameAsQueryString);
        }


        //CompanyProfile
        public async Task<List<CompanyProfile>> GetCompanyProfiles()
        {
            return await restService.RefreshTEntityListAsync<CompanyProfile>(_DataServiceUrlRootPart + Constants.CompanyProfileRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<CompanyProfile> GetCompanyProfile(int id)
        {
            return await restService.GetTEntityAsync<CompanyProfile>(id, _DataServiceUrlRootPart + Constants.CompanyProfileRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<CompanyProfile> CreateCompanyProfileAsync(CompanyProfile CompanyProfile)
        {
            return await restService.CreateTEntityAsync<CompanyProfile>(CompanyProfile, _DataServiceUrlRootPart + Constants.CompanyProfileRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateCompanyProfileAsync(CompanyProfile CompanyProfile)
        {
            await restService.UpdateTEntityAsync<CompanyProfile>(CompanyProfile, _DataServiceUrlRootPart + Constants.CompanyProfileRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteCompanyProfileAsync(CompanyProfile CompanyProfile)
        {
            await restService.DeleteTEntityAsync<CompanyProfile>(CompanyProfile.ID, _DataServiceUrlRootPart + Constants.CompanyProfileRestUrl + _ConnectionNameAsQueryString);
        }

        //Container
        public async Task<List<Container>> GetContainers()
        {
            return await restService.RefreshTEntityListAsync<Container>(_DataServiceUrlRootPart + Constants.ContainerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Container> GetContainer(int id)
        {
            return await restService.GetTEntityAsync<Container>(id, _DataServiceUrlRootPart + Constants.ContainerRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<Container> CreateContainerAsync(Container aContainer)
        {
            return await restService.CreateTEntityAsync<Container>(aContainer, _DataServiceUrlRootPart + Constants.ContainerRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task UpdateContainerAsync(Container aContainer)
        {
            await restService.UpdateTEntityAsync<Container>(aContainer, _DataServiceUrlRootPart + Constants.ContainerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteContainerAsync(Container aContainer)
        {
            await restService.DeleteTEntityAsync<Container>(aContainer.ID, _DataServiceUrlRootPart + Constants.ContainerRestUrl + _ConnectionNameAsQueryString);
        }

        //CameraSnapshot
        public async Task<List<CameraSnapshot>> GetCameraSnapshots()
        {
            return await restService.RefreshTEntityListAsync<CameraSnapshot>(_DataServiceUrlRootPart + Constants.CustomerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<CameraSnapshot> GetCameraSnapshot(int id)
        {
            return await restService.GetTEntityAsync<CameraSnapshot>(id, _DataServiceUrlRootPart + Constants.CameraSnapshotRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<CameraSnapshot> CreateCameraSnapshotAsync(CameraSnapshot aCameraSnapshot)
        {
            return await restService.CreateTEntityAsync<CameraSnapshot>(aCameraSnapshot, _DataServiceUrlRootPart + Constants.CameraSnapshotRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteCameraSnapshotAsync(CameraSnapshot aCameraSnapshot)
        {
            await restService.DeleteTEntityAsync<CameraSnapshot>(aCameraSnapshot.ID, _DataServiceUrlRootPart + Constants.CameraSnapshotRestUrl + _ConnectionNameAsQueryString);
        }

        //Customer
        public async Task<List<Customer>> GetCustomers()
        {
            return await restService.RefreshTEntityListAsync<Customer>(_DataServiceUrlRootPart + Constants.CameraSnapshotRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Customer> GetCustomer(int id)
        {
            return await restService.GetTEntityAsync<Customer>(id, _DataServiceUrlRootPart + Constants.CustomerRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<ObservableCollection<Customer>> GetObservableCustomersAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsync<Customer>(_DataServiceUrlRootPart + Constants.SiteCustomerRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<List<Customer>> GetCustomersAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityListAsync<Customer>(_DataServiceUrlRootPart + Constants.SiteCustomerRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<Customer> CreateCustomerAsync(Customer aCustomer)
        {
            return await restService.CreateTEntityAsync<Customer>(aCustomer, _DataServiceUrlRootPart + Constants.CustomerRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task UpdateCustomerAsync(Customer aCustomer)
        {
            await restService.UpdateTEntityAsync<Customer>(aCustomer, _DataServiceUrlRootPart + Constants.CustomerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteCustomerAsync(Customer aCustomer)
        {
            await restService.DeleteTEntityAsync<Customer>(aCustomer.ID, _DataServiceUrlRootPart + Constants.CustomerRestUrl + _ConnectionNameAsQueryString);
        }

        //CustomerExt
        public async Task<List<CustomerExt>> GetCustomerExts()
        {
            return await restService.RefreshTEntityListAsync<CustomerExt>(_DataServiceUrlRootPart + Constants.CustomerExtRestUrl + _ConnectionNameAsQueryString);
        }

        //Destination
        public async Task<List<Destination>> GetDestinations()
        {
            return await restService.RefreshTEntityListAsync<Destination>(_DataServiceUrlRootPart + Constants.DestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Destination> GetDestination(int id)
        {
            return await restService.GetTEntityAsync<Destination>(id, _DataServiceUrlRootPart + Constants.DestinationRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<ObservableCollection<Destination>> GetObservableDestinationsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsync<Destination>(_DataServiceUrlRootPart + Constants.SiteDestinationRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<List<Destination>> GetDestinationsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityListAsync<Destination>(_DataServiceUrlRootPart + Constants.SiteDestinationRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<Destination> CreateDestinationAsync(Destination aDestination)
        {
            return await restService.CreateTEntityAsync<Destination>(aDestination, _DataServiceUrlRootPart + Constants.DestinationRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task UpdateDestinationAsync(Destination aDestination)
        {
            await restService.UpdateTEntityAsync<Destination>(aDestination, _DataServiceUrlRootPart + Constants.DestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteDestinationAsync(Destination aDestination)
        {
            await restService.DeleteTEntityAsync<Destination>(aDestination.ID, _DataServiceUrlRootPart + Constants.DestinationRestUrl + _ConnectionNameAsQueryString);
        }

        // DestinationVehicleConfiguration
        public async Task<ObservableCollection<DestinationVehicleConfiguration>> GetObservableDestinationVehicleConfigurationWithDestinationID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<DestinationVehicleConfiguration>(id, _DataServiceUrlRootPart + Constants.DestinationVehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<DestinationVehicleConfiguration>> GetDestinationVehicleConfigurationAsync()
        {
            return await restService.RefreshTEntityListAsync<DestinationVehicleConfiguration>(_DataServiceUrlRootPart + Constants.DestinationVehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteDestinationVehicleConfiguration(DestinationVehicleConfiguration destinationVehicleConfiguration)
        {
            await restService.DeleteTEntityAsync<DestinationVehicleConfiguration>(destinationVehicleConfiguration.ID, _DataServiceUrlRootPart + Constants.DestinationVehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateDestinationVehicleConfiguration(DestinationVehicleConfiguration destinationVehicleConfiguration)
        {
            await restService.CreateTEntityAsync<DestinationVehicleConfiguration>(destinationVehicleConfiguration, _DataServiceUrlRootPart + Constants.DestinationVehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }


        //ReplicationLogItem
        public async Task<List<ReplicationLogItem>> GetReplicationLogItems(int id)
        {
            return await restService.RefreshTEntityListAsync<ReplicationLogItem>(_DataServiceUrlRootPart + Constants.ReplicationLogItemRestUrl + "/" + id.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task DeleteReplicationLogItemAsync(ReplicationLogItem aReplicationLogItem)
        {
            await restService.DeleteTEntityAsync<ReplicationLogItem>(aReplicationLogItem.ID, _DataServiceUrlRootPart + Constants.ReplicationLogItemRestUrl + _ConnectionNameAsQueryString);
        }

        //public async Task<ReplicationLogItem> GetReplicationLogItem(int id)
        //{
        //    return await restService.GetTEntityAsync<ReplicationLogItem>(id, _DataServiceUrlRootPart + Constants.ReplicationLogItemRestUrl);
        //}


        //Driver
        public async Task<List<Driver>> GetDrivers()
        {
            return await restService.RefreshTEntityListAsync<Driver>(_DataServiceUrlRootPart + Constants.DriverRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Driver> GetDriver(int id)
        {
            return await restService.GetTEntityAsync<Driver>(id, _DataServiceUrlRootPart + Constants.DriverRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Driver> CreateDriverAsync(Driver aDriver)
        {
            return await restService.CreateTEntityAsync<Driver>(aDriver, _DataServiceUrlRootPart + Constants.DriverRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task UpdateDriverAsync(Driver aDriver)
        {
            await restService.UpdateTEntityAsync<Driver>(aDriver, _DataServiceUrlRootPart + Constants.DriverRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteDriverAsync(Driver aDriver)
        {
            await restService.DeleteTEntityAsync<Driver>(aDriver.ID, _DataServiceUrlRootPart + Constants.DriverRestUrl + _ConnectionNameAsQueryString);
        }

        //EventLog
        public async Task<List<WMSEventLog>> GetEventLogs()
        {
            return await restService.RefreshTEntityListAsync<WMSEventLog>(_DataServiceUrlRootPart + Constants.WMSEventLogRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<WMSEventLog> GetEventLog(int id)
        {
            return await restService.GetTEntityAsync<WMSEventLog>(id, _DataServiceUrlRootPart + Constants.WMSEventLogRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<WMSEventLog> CreateEventLogAsync(WMSEventLog anEventLog)
        {
            return await restService.CreateTEntityAsync<WMSEventLog>(anEventLog, _DataServiceUrlRootPart + Constants.WMSEventLogRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteEventLogAsync(WMSEventLog anEventLog)
        {
            await restService.DeleteTEntityAsync<WMSEventLog>(anEventLog.ID, _DataServiceUrlRootPart + Constants.WMSEventLogRestUrl + _ConnectionNameAsQueryString);
        }



        //FirstWeigh
        public async Task<List<FirstWeigh>> GetFirstWeighs(int id)   //id is for siteID
        {
            //old one
            return await restService.RefreshTEntityListAsync<FirstWeigh>(_DataServiceUrlRootPart + Constants.FirstWeighRestUrl + "/" + id.ToString() + _ConnectionNameAsQueryString);

            //////new code, only get current date firstweighs based on confirmation we should enable this.
            ////string formatDate = DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            ////return await restService.RefreshTEntityListAsync<FirstWeigh>(_DataServiceUrlRootPart + Constants.FirstWeighRestUrl + "/" + id.ToString() + _ConnectionNameAsQueryString + "&date=" + formatDate);
        }


        public async Task<FirstWeigh> GetFirstWeigh(int id)
        {
            //var nvc = new NameValueCollection();
            //nvc["id"] = id.ToString();   
            //nvc["name"] = name;

            //string queryString = nvc.ToQueryString();

            //return await restService.RefreshTEntityListAsync<Transaction>(_DataServiceUrlRootPart + Constants.TransactionRestUrl + queryString);
            //return await restService.GetTEntityAsync<FirstWeigh>(id, _DataServiceUrlRootPart + Constants.FirstWeighRestUrl + queryString);
            return await restService.GetTEntityAsync<FirstWeigh>(id, _DataServiceUrlRootPart + Constants.FirstWeighRestUrl + _ConnectionNameAsQueryString);
        }



        public async Task<FirstWeigh> CreateFirstWeighAsync(FirstWeigh aFirstWeigh)
        {
            return await restService.CreateTEntityAsync<FirstWeigh>(aFirstWeigh, _DataServiceUrlRootPart + Constants.FirstWeighRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateFirstWeighAsync(FirstWeigh aFirstWeigh)
        {
            await restService.UpdateTEntityAsync<FirstWeigh>(aFirstWeigh, _DataServiceUrlRootPart + Constants.FirstWeighRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<bool> DeleteFirstWeighAsync(FirstWeigh aFirstWeigh)
        {
            bool result = await restService.DeleteTEntityAsync<FirstWeigh>(aFirstWeigh.ID, _DataServiceUrlRootPart + Constants.FirstWeighRestUrl + _ConnectionNameAsQueryString);
            return result;
        }


        //Job
        public async Task<List<Job>> GetJobs()
        {
            return await restService.RefreshTEntityListAsync<Job>(_DataServiceUrlRootPart + Constants.JobRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Job> GetJob(int id)
        {
            return await restService.GetTEntityAsync<Job>(id, _DataServiceUrlRootPart + Constants.JobRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<ObservableCollection<Job>> GetObservableJobsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsync<Job>(_DataServiceUrlRootPart + Constants.SiteJobRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<List<Job>> GetJobsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityListAsync<Job>(_DataServiceUrlRootPart + Constants.SiteJobRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<Job> CreateJobAsync(Job aJob)
        {
            return await restService.CreateTEntityAsync<Job>(aJob, _DataServiceUrlRootPart + Constants.JobRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task UpdateJobAsync(Job aJob)
        {
            await restService.UpdateTEntityAsync<Job>(aJob, _DataServiceUrlRootPart + Constants.JobRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteJobAsync(Job aJob)
        {
            await restService.DeleteTEntityAsync<Job>(aJob.ID, _DataServiceUrlRootPart + Constants.JobRestUrl + _ConnectionNameAsQueryString);
        }

        //JobProductPrice
        public async Task<ObservableCollection<JobProductPrice>> GetObservableJobProductPriceWithJobID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<JobProductPrice>(id, _DataServiceUrlRootPart + Constants.JobProductPriceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<JobProductPrice>> GetJobProductPriceAsync()
        {
            return await restService.RefreshTEntityListAsync<JobProductPrice>(_DataServiceUrlRootPart + Constants.JobProductPriceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<JobProductPrice>> GetJobProductPriceByJobId(int jobId)
        {
            return await restService.RefreshTEntityListAsync<JobProductPrice>(jobId, _DataServiceUrlRootPart + Constants.JobProductPriceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteJobProductPrice(JobProductPrice jobProductPrice)
        {
            await restService.DeleteTEntityAsync<JobProductPrice>(jobProductPrice.ID, _DataServiceUrlRootPart + Constants.JobProductPriceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateJobProductPrices(JobProductPrice jobProductPrice)
        {
            await restService.CreateTEntityAsync<JobProductPrice>(jobProductPrice, _DataServiceUrlRootPart + Constants.JobProductPriceRestUrl + _ConnectionNameAsQueryString);
        }

        //JobSource
        public async Task<ObservableCollection<JobSource>> GetObservableJobSourceWithJobID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<JobSource>(id, _DataServiceUrlRootPart + Constants.JobSourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<JobSource>> GetJobSourceAsync()
        {
            return await restService.RefreshTEntityListAsync<JobSource>(_DataServiceUrlRootPart + Constants.JobSourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<JobSource>> GetJobSourcesByJobId(int jobId)
        {
            return await restService.RefreshTEntityListAsync<JobSource>(jobId, _DataServiceUrlRootPart + Constants.JobSourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteJobSource(JobSource jobSource)
        {
            await restService.DeleteTEntityAsync<JobSource>(jobSource.ID, _DataServiceUrlRootPart + Constants.JobSourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateJobSources(JobSource jobSource)
        {
            await restService.CreateTEntityAsync<JobSource>(jobSource, _DataServiceUrlRootPart + Constants.JobSourceRestUrl + _ConnectionNameAsQueryString);
        }

        //JobDestination
        public async Task<ObservableCollection<JobDestination>> GetObservableJobDestinationWithJobID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<JobDestination>(id, _DataServiceUrlRootPart + Constants.JobDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<JobDestination>> GetJobDestinationAsync()
        {
            return await restService.RefreshTEntityListAsync<JobDestination>(_DataServiceUrlRootPart + Constants.JobDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<JobDestination>> GetJobDestinationsByJobId(int jobId)
        {
            return await restService.RefreshTEntityListAsync<JobDestination>(jobId, _DataServiceUrlRootPart + Constants.JobDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteJobDestination(JobDestination jobDestination)
        {
            await restService.DeleteTEntityAsync<JobDestination>(jobDestination.ID, _DataServiceUrlRootPart + Constants.JobDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateJobDestinations(JobDestination jobDestination)
        {
            await restService.CreateTEntityAsync<JobDestination>(jobDestination, _DataServiceUrlRootPart + Constants.JobDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        //JobTonnage
        public async Task<JobTonnage> GetJobTonnage(int id)
        {
            return await restService.GetTEntityAsync<JobTonnage>(id, _DataServiceUrlRootPart + Constants.JobTonnageRestUrl + _ConnectionNameAsQueryString);
        }

        // TruckCustomers
        public async Task<ObservableCollection<TruckCustomers>> GetObservableTruckCustomersWithTruckID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<TruckCustomers>(id, _DataServiceUrlRootPart + Constants.TruckCustomerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckCustomers>> GetTruckCustomersByTruckId(int truckId)
        {
            return await restService.RefreshTEntityListAsync<TruckCustomers>(truckId, _DataServiceUrlRootPart + Constants.TruckCustomerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckCustomers>> GetTruckCustomersAsync()
        {
            return await restService.RefreshTEntityListAsync<TruckCustomers>(_DataServiceUrlRootPart + Constants.TruckCustomerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckCustomers(TruckCustomers truckCustomers)
        {
            await restService.DeleteTEntityAsync<TruckCustomers>(truckCustomers.ID, _DataServiceUrlRootPart + Constants.TruckCustomerRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateTruckCustomers(TruckCustomers truckCustomers)
        {
            await restService.CreateTEntityAsync<TruckCustomers>(truckCustomers, _DataServiceUrlRootPart + Constants.TruckCustomerRestUrl + _ConnectionNameAsQueryString);
        }


        // TruckDestination
        public async Task<ObservableCollection<TruckDestination>> GetObservableTruckDestinationWithTruckID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<TruckDestination>(id, _DataServiceUrlRootPart + Constants.TruckDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckDestination>> GetTruckDestinationsAsync()
        {
            return await restService.RefreshTEntityListAsync<TruckDestination>(_DataServiceUrlRootPart + Constants.TruckDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckDestination>> GetTruckDestinationsByTruckId(int truckId)
        {
            return await restService.RefreshTEntityListAsync<TruckDestination>(truckId, _DataServiceUrlRootPart + Constants.TruckDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckDestination(TruckDestination truckDestination)
        {
            await restService.DeleteTEntityAsync<TruckCustomers>(truckDestination.ID, _DataServiceUrlRootPart + Constants.TruckDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateTruckDestination(TruckDestination truckDestination)
        {
            await restService.CreateTEntityAsync<TruckDestination>(truckDestination, _DataServiceUrlRootPart + Constants.TruckDestinationRestUrl + _ConnectionNameAsQueryString);
        }

        // TruckJobs
        public async Task<ObservableCollection<TruckJobs>> GetObservableTruckJobsWithTruckID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<TruckJobs>(id, _DataServiceUrlRootPart + Constants.TruckJobRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckJobs>> GetTruckJobsAsync()
        {
            return await restService.RefreshTEntityListAsync<TruckJobs>(_DataServiceUrlRootPart + Constants.TruckJobRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckJobs>> GetTruckJobsByTruckId(int truckId)
        {
            return await restService.RefreshTEntityListAsync<TruckJobs>(truckId, _DataServiceUrlRootPart + Constants.TruckJobRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckJobs(TruckJobs truckJobs)
        {
            await restService.DeleteTEntityAsync<TruckJobs>(truckJobs.ID, _DataServiceUrlRootPart + Constants.TruckJobRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateTruckJobs(TruckJobs truckJobs)
        {
            await restService.CreateTEntityAsync<TruckJobs>(truckJobs, _DataServiceUrlRootPart + Constants.TruckJobRestUrl + _ConnectionNameAsQueryString);
        }

        // TruckProducts
        public async Task<ObservableCollection<TruckProducts>> GetObservableTruckProductsWithTruckID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<TruckProducts>(id, _DataServiceUrlRootPart + Constants.TruckProductRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckProducts>> GetTruckProductsByTruckId(int truckId)
        {
            return await restService.RefreshTEntityListAsync<TruckProducts>(truckId, _DataServiceUrlRootPart + Constants.TruckProductRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckProducts>> GetTruckProductsAsync()
        {
            return await restService.RefreshTEntityListAsync<TruckProducts>(_DataServiceUrlRootPart + Constants.TruckProductRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckProducts(TruckProducts truckProducts)
        {
            await restService.DeleteTEntityAsync<TruckProducts>(truckProducts.ID, _DataServiceUrlRootPart + Constants.TruckProductRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateTruckProducts(TruckProducts truckProducts)
        {
            await restService.CreateTEntityAsync<TruckProducts>(truckProducts, _DataServiceUrlRootPart + Constants.TruckProductRestUrl + _ConnectionNameAsQueryString);
        }

        // TruckSource
        public async Task<ObservableCollection<TruckSource>> GetObservableTruckSourceWithTruckID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<TruckSource>(id, _DataServiceUrlRootPart + Constants.TruckSourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckSource>> GetTruckSourceAsync()
        {
            return await restService.RefreshTEntityListAsync<TruckSource>(_DataServiceUrlRootPart + Constants.TruckSourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckSource>> GetTruckSourcesByTruckId(int truckId)
        {
            return await restService.RefreshTEntityListAsync<TruckSource>(truckId, _DataServiceUrlRootPart + Constants.TruckSourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckSource(TruckSource truckSource)
        {
            await restService.DeleteTEntityAsync<TruckSource>(truckSource.ID, _DataServiceUrlRootPart + Constants.TruckSourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateTruckSource(TruckSource truckSource)
        {
            await restService.CreateTEntityAsync<TruckSource>(truckSource, _DataServiceUrlRootPart + Constants.TruckSourceRestUrl + _ConnectionNameAsQueryString);
        }

        // TruckConfigs
        public async Task<ObservableCollection<TruckConfigs>> GetObservableTruckConfigsWithTruckID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<TruckConfigs>(id, _DataServiceUrlRootPart + Constants.TruckConfigRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<TruckConfigs> GetTruckConfigs(int id)
        {
            return await restService.GetTEntityAsync<TruckConfigs>(id, _DataServiceUrlRootPart + Constants.TruckConfigRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<List<TruckConfigs>> GetTruckConfigsAsync()
        {
            return await restService.RefreshTEntityListAsync<TruckConfigs>(_DataServiceUrlRootPart + Constants.TruckConfigRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckConfigs>> GetTruckConfigsByTruckId(int truckId)
        {
            return await restService.RefreshTEntityListAsync<TruckConfigs>(truckId, _DataServiceUrlRootPart + Constants.TruckConfigRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckConfigs(TruckConfigs truckConfigs)
        {
            await restService.DeleteTEntityAsync<TruckConfigs>(truckConfigs.ID, _DataServiceUrlRootPart + Constants.TruckConfigRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateTruckConfigs(TruckConfigs truckConfigs)
        {
            await restService.CreateTEntityAsync<TruckConfigs>(truckConfigs, _DataServiceUrlRootPart + Constants.TruckConfigRestUrl + _ConnectionNameAsQueryString);
        }

        // TruckSuppliers
        public async Task<ObservableCollection<TruckSuppliers>> GetObservableTruckSuppliersWithTruckID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<TruckSuppliers>(id, _DataServiceUrlRootPart + Constants.TruckSupplierRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckSuppliers>> GetTruckSuppliersByTruckId(int truckId)
        {
            return await restService.RefreshTEntityListAsync<TruckSuppliers>(truckId, _DataServiceUrlRootPart + Constants.TruckSupplierRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<TruckSuppliers>> GetTruckSuppliersAsync()
        {
            return await restService.RefreshTEntityListAsync<TruckSuppliers>(_DataServiceUrlRootPart + Constants.TruckSupplierRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckSuppliers(TruckSuppliers truckSuppliers)
        {
            await restService.DeleteTEntityAsync<TruckSuppliers>(truckSuppliers.ID, _DataServiceUrlRootPart + Constants.TruckSupplierRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task CreateTruckSuppliers(TruckSuppliers truckSuppliers)
        {
            await restService.CreateTEntityAsync<TruckSuppliers>(truckSuppliers, _DataServiceUrlRootPart + Constants.TruckSupplierRestUrl + _ConnectionNameAsQueryString);
        }

        //Operator
        public async Task<List<Operator>> GetOperators()
        {
            return await restService.RefreshTEntityListAsync<Operator>(_DataServiceUrlRootPart + Constants.OperatorRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Operator> GetOperator(int id)
        {
            return await restService.GetTEntityAsync<Operator>(id, _DataServiceUrlRootPart + Constants.OperatorRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Operator> CreateOperatorAsync(Operator aOperator)
        {
            return await restService.CreateTEntityAsync<Operator>(aOperator, _DataServiceUrlRootPart + Constants.OperatorRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateOperatorAsync(Operator aOperator)
        {
            await restService.UpdateTEntityAsync<Operator>(aOperator, _DataServiceUrlRootPart + Constants.OperatorRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteOperatorAsync(Operator aOperator)
        {
            await restService.DeleteTEntityAsync<Operator>(aOperator.ID, _DataServiceUrlRootPart + Constants.OperatorRestUrl + _ConnectionNameAsQueryString);
        }

        //Product
        public async Task<List<Product>> UpdateProductsScheduledPrice()
        {
            string formatDate = DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            return await restService.RefreshTEntityListAsync<Product>(_DataServiceUrlRootPart + Constants.ProductRestUrl + _ConnectionNameAsQueryString + "&date=" + formatDate);
        }

        public async Task<List<Product>> GetProducts()
        {
            return await restService.RefreshTEntityListAsync<Product>(_DataServiceUrlRootPart + Constants.ProductRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Product> GetProduct(int id)
        {
            return await restService.GetTEntityAsync<Product>(id, _DataServiceUrlRootPart + Constants.ProductRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<ObservableCollection<Product>> GetObservableProductsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsync<Product>(_DataServiceUrlRootPart + Constants.SiteProductRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<List<Product>> GetProductsAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityListAsync<Product>(_DataServiceUrlRootPart + Constants.SiteProductRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<Product> CreateProductAsync(Product aProduct)
        {
            return await restService.CreateTEntityAsync<Product>(aProduct, _DataServiceUrlRootPart + Constants.ProductRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task UpdateProductAsync(Product aProduct)
        {
            await restService.UpdateTEntityAsync<Product>(aProduct, _DataServiceUrlRootPart + Constants.ProductRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteProductAsync(Product aProduct)
        {
            await restService.DeleteTEntityAsync<Product>(aProduct.ID, _DataServiceUrlRootPart + Constants.ProductRestUrl + _ConnectionNameAsQueryString);
        }

        //ProductCategory
        public async Task<List<ProductCategory>> GetProductCategories()
        {
            return await restService.RefreshTEntityListAsync<ProductCategory>(_DataServiceUrlRootPart + Constants.ProductCategoryRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<ProductCategory> GetProductCategory(int id)
        {
            return await restService.GetTEntityAsync<ProductCategory>(id, _DataServiceUrlRootPart + Constants.ProductCategoryRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<ProductCategory> CreateProductCategoryAsync(ProductCategory aProductCategory)
        {
            return await restService.CreateTEntityAsync<ProductCategory>(aProductCategory, _DataServiceUrlRootPart + Constants.ProductCategoryRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task UpdateProductCategoryAsync(ProductCategory aProductCategory)
        {
            await restService.UpdateTEntityAsync<ProductCategory>(aProductCategory, _DataServiceUrlRootPart + Constants.ProductCategoryRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteProductCategoryAsync(ProductCategory aProductCategory)
        {
            await restService.DeleteTEntityAsync<ProductCategory>(aProductCategory.ID, _DataServiceUrlRootPart + Constants.ProductCategoryRestUrl + _ConnectionNameAsQueryString);
        }

        //Weighman
        public async Task<List<Weighman>> GetWeighmenAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityListAsync<Weighman>(_DataServiceUrlRootPart + Constants.SiteWeighmanRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<Weighman> GetWeighman(int id)
        {
            return await restService.GetTEntityAsync<Weighman>(id, _DataServiceUrlRootPart + Constants.WeighmanRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateWeighmanAsync(Weighman aWeighman)
        {
            await restService.UpdateTEntityAsync<Weighman>(aWeighman, _DataServiceUrlRootPart + Constants.WeighmanRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteWeighmanAsync(Weighman aWeighman)
        {
            await restService.DeleteTEntityAsync<Weighman>(aWeighman.ID, _DataServiceUrlRootPart + Constants.WeighmanRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Weighman> CreateWeighmanAsync(Weighman aWeighman)
        {
            return await restService.CreateTEntityAsync<Weighman>(aWeighman, _DataServiceUrlRootPart + Constants.WeighmanRestUrl + _ConnectionNameAsQueryString);
        }


        //Role
        public async Task<List<Role>> GetRoleAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityListAsync<Role>(_DataServiceUrlRootPart + Constants.RoleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Role> GetRole(int id)
        {
            return await restService.GetTEntityAsync<Role>(id, _DataServiceUrlRootPart + Constants.RoleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateRoleAsync(Role aRole)
        {
            await restService.UpdateTEntityAsync<Role>(aRole, _DataServiceUrlRootPart + Constants.RoleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteRoleAsync(Role aRole)
        {
            await restService.DeleteTEntityAsync<Role>(aRole.ID, _DataServiceUrlRootPart + Constants.RoleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Role> CreateRoleAsync(Role aRole)
        {
            return await restService.CreateTEntityAsync<Role>(aRole, _DataServiceUrlRootPart + Constants.RoleRestUrl + _ConnectionNameAsQueryString);
        }


        //Site
        public async Task<List<Site>> GetSites()
        {
            return await restService.RefreshTEntityListAsync<Site>(_DataServiceUrlRootPart + Constants.SiteRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Site> GetSite(int id)
        {
            return await restService.GetTEntityAsync<Site>(id, _DataServiceUrlRootPart + Constants.SiteRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<ObservableCollection<Site>> GetObservableSites()
        {
            return await restService.RefreshTEntityObservableCollectionAsync<Site>(_DataServiceUrlRootPart + Constants.SiteRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<Site> CreateSiteAsync(Site aSite)
        {
            return await restService.CreateTEntityAsync<Site>(aSite, _DataServiceUrlRootPart + Constants.SiteRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateSiteAsync(Site aSite)
        {
            await restService.UpdateTEntityAsync<Site>(aSite, _DataServiceUrlRootPart + Constants.SiteRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteSiteAsync(Site aSite)
        {
            await restService.DeleteTEntityAsync<Site>(aSite.ID, _DataServiceUrlRootPart + Constants.SiteRestUrl + _ConnectionNameAsQueryString);
        }

        //Source
        public async Task<List<Source>> GetSources()
        {
            return await restService.RefreshTEntityListAsync<Source>(_DataServiceUrlRootPart + Constants.SourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Source> GetSource(int id)
        {
            return await restService.GetTEntityAsync<Source>(id, _DataServiceUrlRootPart + Constants.SourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<ObservableCollection<Source>> GetObservableSourcesAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityObservableCollectionAsync<Source>(_DataServiceUrlRootPart + Constants.SiteSourceRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<List<Source>> GetSourcesAssignedToSite(Site site)
        {
            return await restService.RefreshTEntityListAsync<Source>(_DataServiceUrlRootPart + Constants.SiteSourceRestUrl + site.ID.ToString() + _ConnectionNameAsQueryString);
        }

        public async Task<Source> CreateSourceAsync(Source anSource)
        {
            return await restService.CreateTEntityAsync<Source>(anSource, _DataServiceUrlRootPart + Constants.SourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateSourceAsync(Source anSource)
        {
            await restService.UpdateTEntityAsync<Source>(anSource, _DataServiceUrlRootPart + Constants.SourceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteSourceAsync(Source anSource)
        {
            await restService.DeleteTEntityAsync<Source>(anSource.ID, _DataServiceUrlRootPart + Constants.SourceRestUrl + _ConnectionNameAsQueryString);
        }



        //Transaction
        public async Task<List<Transaction>> GetTransactions(DateRange dateRange)
        {
            var nvc = new NameValueCollection();
            //            nvc["StartingDate"] = dateRange.StartingDate.ToUniversalTime().ToString("s", CultureInfo.InvariantCulture);   //.ToShortDateString();
            //            nvc["EndingDate"] = dateRange.EndingDate.ToUniversalTime().ToString("s", CultureInfo.InvariantCulture);   //.ToShortDateString();
            nvc["StartingDate"] = dateRange.StartingDate.ToString("s", CultureInfo.InvariantCulture);   //.ToShortDateString();
            nvc["EndingDate"] = dateRange.EndingDate.ToString("s", CultureInfo.InvariantCulture);   //.ToShortDateString();
            nvc["SiteID"] = dateRange.SiteID.ToString();
            nvc["connectionStringName"] = _ConnectionStringName;

            string queryString = nvc.ToQueryString();

            return await restService.RefreshTEntityListAsync<Transaction>(_DataServiceUrlRootPart + Constants.TransactionRestUrl + queryString);
        }

        public async Task<Transaction> GetTransaction(int id)
        {
            return await restService.GetTEntityAsync<Transaction>(id, _DataServiceUrlRootPart + Constants.TransactionRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Transaction> CreateTransactionAsync(Transaction aTransaction)
        {
            if (aTransaction.TruckID == 0) aTransaction.TruckID = 1;
            return await restService.CreateTEntityAsync<Transaction>(aTransaction, _DataServiceUrlRootPart + Constants.TransactionRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<bool> PostTransactionAsync(Transaction aTransaction)
        {
            if (aTransaction.TruckID == 0) aTransaction.TruckID = 1;
            return await restService.PostTEntityAsync<Transaction>(aTransaction, _DataServiceUrlRootPart + Constants.TransactionRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateTransactionAsync(Transaction aTransaction)
        {
            await restService.UpdateTEntityAsync<Transaction>(aTransaction, _DataServiceUrlRootPart + Constants.TransactionRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTransactionAsync(Transaction aTransaction)
        {
            await restService.DeleteTEntityAsync<Transaction>(aTransaction.ID, _DataServiceUrlRootPart + Constants.TransactionRestUrl + _ConnectionNameAsQueryString);
        }

        //Truck
        public async Task<List<Truck>> GetTrucks()
        {
            return await restService.RefreshTEntityListAsync<Truck>(_DataServiceUrlRootPart + Constants.TruckRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Truck> GetTruck(int id)
        {
            return await restService.GetTEntityAsync<Truck>(id, _DataServiceUrlRootPart + Constants.TruckRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<ObservableCollection<Truck>> GetObservableTrucks()
        {
            return await restService.RefreshTEntityObservableCollectionAsync<Truck>(_DataServiceUrlRootPart + Constants.TruckRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Truck> CreateTruckAsync(Truck anTruck)
        {
            return await restService.CreateTEntityAsync<Truck>(anTruck, _DataServiceUrlRootPart + Constants.TruckRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateTruckAsync(Truck anTruck)
        {
            await restService.UpdateTEntityAsync<Truck>(anTruck, _DataServiceUrlRootPart + Constants.TruckRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckAsync(Truck anTruck)
        {
            await restService.DeleteTEntityAsync<Truck>(anTruck.ID, _DataServiceUrlRootPart + Constants.TruckRestUrl + _ConnectionNameAsQueryString);
        }

        //Added New Truck
        public async Task<List<Truck>> GetAddedNewTrucks(int id)
        {
            //List<Truck> newTrucks;
            //return newTrucks = (await GetEntityArrayAsync<Truck>(webApiURL + "TruckNewAdded/" + id.ToString())).ToList();

            return await restService.RefreshTEntityListAsync<Truck>(_DataServiceUrlRootPart + Constants.AddedNewTruckRestUrl + id.ToString() + _ConnectionNameAsQueryString);
        }

        //VehicleConfiguration
        public async Task<List<VehicleConfiguration>> GetTruckConfigurations()
        {
            return await restService.RefreshTEntityListAsync<VehicleConfiguration>(_DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<VehicleConfiguration> GetVehicleConfiguration(int id)
        {
            return await restService.GetTEntityAsync<VehicleConfiguration>(id, _DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<ObservableCollection<VehicleConfiguration>> GetObservableVehicleConfigurations()
        {
            return await restService.RefreshTEntityObservableCollectionAsync<VehicleConfiguration>(_DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<VehicleConfiguration> CreateTruckConfigurationAsync(VehicleConfiguration aTruckConfiguration)
        {
            return await restService.CreateTEntityAsync<VehicleConfiguration>(aTruckConfiguration, _DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateTruckConfigurationAsync(VehicleConfiguration aTruckConfiguration)
        {
            await restService.UpdateTEntityAsync<VehicleConfiguration>(aTruckConfiguration, _DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteTruckConfigurationAsync(VehicleConfiguration aTruckConfiguration)
        {
            await restService.DeleteTEntityAsync<VehicleConfiguration>(aTruckConfiguration.ID, _DataServiceUrlRootPart + Constants.VehicleConfigurationRestUrl + _ConnectionNameAsQueryString);
        }

        //Vehicle   

        public async Task<List<Vehicle>> UpdateVehicleScheduledPrice()
        {
            string formatDate = DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            return await restService.RefreshTEntityListAsync<Vehicle>(_DataServiceUrlRootPart + Constants.VehicleRestUrl + _ConnectionNameAsQueryString + "&date=" + formatDate);
        }

        public async Task<List<Vehicle>> GetVehicles()
        {
            return await restService.RefreshTEntityListAsync<Vehicle>(_DataServiceUrlRootPart + Constants.VehicleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Vehicle> GetVehicle(int id)
        {
            return await restService.GetTEntityAsync<Vehicle>(id, _DataServiceUrlRootPart + Constants.VehicleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<ObservableCollection<Vehicle>> GetObservableVehicles()
        {
            return await restService.RefreshTEntityObservableCollectionAsync<Vehicle>(_DataServiceUrlRootPart + Constants.VehicleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Vehicle> CreateVehicleAsync(Vehicle aVehicle)
        {
            return await restService.CreateTEntityAsync<Vehicle>(aVehicle, _DataServiceUrlRootPart + Constants.VehicleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateVehicleAsync(Vehicle aVehicle)
        {
            await restService.UpdateTEntityAsync<Vehicle>(aVehicle, _DataServiceUrlRootPart + Constants.VehicleRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteVehicleAsync(Vehicle aVehicle)
        {
            await restService.DeleteTEntityAsync<Vehicle>(aVehicle.ID, _DataServiceUrlRootPart + Constants.VehicleRestUrl + _ConnectionNameAsQueryString);
        }

        //VehicleProductPrice
        public async Task<List<VehicleProductPrice>> GetVehicleProductPriceAsync()
        {
            return await restService.RefreshTEntityListAsync<VehicleProductPrice>(_DataServiceUrlRootPart + Constants.VehicleProductPriceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<VehicleProductPrice>> GetVehicleProductPriceByVehicleId(int vehicleId)
        {
            return await restService.RefreshTEntityListAsync<VehicleProductPrice>(vehicleId, _DataServiceUrlRootPart + Constants.VehicleProductPriceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<ObservableCollection<VehicleProductPrice>> GetObservableVehicleProductPriceWithVehicleID(int id)
        {
            return await restService.GetTEntityObservableCollectionWithIDAsync<VehicleProductPrice>(id, _DataServiceUrlRootPart + Constants.VehicleProductPriceRestUrl + _ConnectionNameAsQueryString);
        }

        //ProductStockActivation
        //GetTEntityBy2IDsAsync<TEntity>(int id1, int id2, string uriString)
        public async Task<ProductStockActivation> GetProductStockActivationAsync(int id1, int id2)
        {
            return await restService.GetTEntityBy2IDsAsync<ProductStockActivation>(id1, id2, _ConnectionStringName, _DataServiceUrlRootPart + Constants.ProductStockActivationRestUrl);
        }

        public async Task<ProductStockActivation> CreateProductStockActivationAsync(ProductStockActivation anProductStockActivation)
        {
            return await restService.CreateTEntityAsync<ProductStockActivation>(anProductStockActivation, _DataServiceUrlRootPart + Constants.ProductStockActivationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateProductStockActivationAsync(ProductStockActivation anProductStockActivation)
        {
            await restService.UpdateTEntityAsync<ProductStockActivation>(anProductStockActivation, _DataServiceUrlRootPart + Constants.ProductStockActivationRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteProductStockActivationAsync(ProductStockActivation anProductStockActivation)
        {
            await restService.DeleteTEntityAsync<ProductStockActivation>(anProductStockActivation.ID, _DataServiceUrlRootPart + Constants.ProductStockActivationRestUrl + _ConnectionNameAsQueryString);
        }

        //ProductStockMovement
        //GetTEntityBy2IDsAsync<TEntity>(int id1, int id2, string uriString)
        public async Task<ProductStockMovement> GetProductStockMovementAsync(int id1, int id2)
        {
            return await restService.GetTEntityBy2IDsAsync<ProductStockMovement>(id1, id2, _ConnectionStringName, _DataServiceUrlRootPart);
        }

        public async Task<ProductStockMovement> CreateProductStockMovementAsync(ProductStockMovement anProductStockMovement)
        {
            return await restService.CreateTEntityAsync<ProductStockMovement>(anProductStockMovement, _DataServiceUrlRootPart + Constants.ProductStockMovementRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateProductStockMovementAsync(ProductStockMovement anProductStockMovement)
        {
            await restService.UpdateTEntityAsync<ProductStockMovement>(anProductStockMovement, _DataServiceUrlRootPart + Constants.ProductStockMovementRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteProductStockMovementAsync(ProductStockMovement anProductStockMovement)
        {
            await restService.DeleteTEntityAsync<ProductStockMovement>(anProductStockMovement.ID, _DataServiceUrlRootPart + Constants.ProductStockMovementRestUrl + _ConnectionNameAsQueryString);
        }

        //Visitor
        public async Task<List<Visitor>> GetVisitors()
        {
            return await restService.RefreshTEntityListAsync<Visitor>(_DataServiceUrlRootPart + Constants.VisitorRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Visitor> GetVisitor(int id)
        {
            return await restService.GetTEntityAsync<Visitor>(id, _DataServiceUrlRootPart + Constants.VisitorRestUrl + _ConnectionNameAsQueryString);
        }


        public async Task<Visitor> CreateVisitorAsync(Visitor aVisitor)
        {
            return await restService.CreateTEntityAsync<Visitor>(aVisitor, _DataServiceUrlRootPart + Constants.VisitorRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateVisitorAsync(Visitor aVisitor)
        {
            await restService.UpdateTEntityAsync<Visitor>(aVisitor, _DataServiceUrlRootPart + Constants.VisitorRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteVisitorAsync(Visitor aVisitor)
        {
            await restService.DeleteTEntityAsync<Visitor>(aVisitor.ID, _DataServiceUrlRootPart + Constants.VisitorRestUrl + _ConnectionNameAsQueryString);
        }

        //WeighPass
        public async Task<List<WeighPass>> GetWeighPasses()
        {
            return await restService.RefreshTEntityListAsync<WeighPass>(_DataServiceUrlRootPart + Constants.WeighPassRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<WeighPass> CreateWeighPassAsync(WeighPass aWeighPass)
        {
            return await restService.CreateTEntityAsync<WeighPass>(aWeighPass, _DataServiceUrlRootPart + Constants.WeighPassRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task UpdateWeighPassAsync(WeighPass aWeighPass)
        {
            await restService.UpdateTEntityAsync<WeighPass>(aWeighPass, _DataServiceUrlRootPart + Constants.WeighPassRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task DeleteWeighPassAsync(WeighPass aWeighPass)
        {
            await restService.DeleteTEntityAsync<WeighPass>(aWeighPass.ID, _DataServiceUrlRootPart + Constants.WeighPassRestUrl + _ConnectionNameAsQueryString);
        }

        //Docket
        public async Task<string> GetDocketNumber(int siteID)
        {
            return await restService.GetNextDocketNumber(siteID, _DataServiceUrlRootPart + Constants.DocketRestUrl + _ConnectionNameAsQueryString);
        }

        //RealWeight
        //GetTEntityBy2IDsAsync<TEntity>(int id1, int id2, string uriString) 
        public async Task<RealTimeWeight> GetRealTimeWeightAsync(int id1, int id2) //id1:SiteID, id2:PlatformID
        {
            return await restService.GetTEntityBy2IDsAsync<RealTimeWeight>(id1, id2, _ConnectionStringName, _DataServiceUrlRootPart);
        }

        public async Task UpdateRealTimeWeightAsync(RealTimeWeight aRealTimeWeight)
        {
            await restService.UpdateTEntityAsync<RealTimeWeight>(aRealTimeWeight, _DataServiceUrlRootPart + Constants.RealTimeWeightRestUrl + _ConnectionNameAsQueryString);
        }

        //Signature
        public async Task UploadSignatureAsync(string transactionID, string filePath)
        {
            await restService.UploadImageFile(_DataServiceUrlRootPart + Constants.SignatureRestUrl + _ConnectionNameAsQueryString, transactionID, filePath);
        }

        public async Task<string> DownloadSignatureAsync(string transactionID, string filePath)
        {
            return await restService.DownloadImageFromDbOk(_DataServiceUrlRootPart + Constants.SignatureRestUrl + _ConnectionNameAsQueryString, transactionID, filePath);
        }

        //EPASource
        public async Task<EPASource> CreateEPASourceAsync(EPASource anEPASource)
        {
            return await restService.CreateTEntityAsync<EPASource>(anEPASource, _DataServiceUrlRootPart + Constants.EPASourceRestUrl + _ConnectionNameAsQueryString);
        }

        //test
        public async Task<string> GetWebText(string address)
        {
            return await restService.GetResponseText(address);
        }

        //Offence
        public async Task<Offence> CreateOffenceAsync(Offence offence)
        {
            return await restService.CreateTEntityAsync<Offence>(offence, _DataServiceUrlRootPart + Constants.OffenceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<List<Offence>> GetOffences()
        {
            return await restService.RefreshTEntityListAsync<Offence>(_DataServiceUrlRootPart + Constants.OffenceRestUrl + _ConnectionNameAsQueryString);
        }

        public async Task<Offence> GetOffence(int id)
        {
            return await restService.GetTEntityAsync<Offence>(id, _DataServiceUrlRootPart + Constants.OffenceRestUrl + _ConnectionNameAsQueryString);
        }
    }
}
