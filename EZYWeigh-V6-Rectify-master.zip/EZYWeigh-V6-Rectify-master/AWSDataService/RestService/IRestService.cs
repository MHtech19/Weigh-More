﻿using AWSWeighingService.Abstract;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace AWSDataService.RestService
{
    public interface IRestService 
	{
        //TEntity
        Task<List<TEntity>> RefreshTEntityListAsync<TEntity>(string uriString) where TEntity : IEntityID;
        Task<List<TEntity>> RefreshTEntityListAsync<TEntity>(int id, string uriString) where TEntity : IEntityID;
        Task<TEntity> GetTEntityAsync<TEntity>(int id, string uriString) where TEntity : IEntityID;
        Task<TEntity> GetTEntityBy2IDsAsync<TEntity>(int id1, int id2, string connectionStringName, string uriString) where TEntity : IEntityID;
        Task<ObservableCollection<TEntity>> RefreshTEntityObservableCollectionAsync<TEntity>(string uriString) where TEntity : IEntityID;
        Task<ObservableCollection<TEntity>> GetTEntityObservableCollectionWithIDAsync<TEntity>(int id, string uriString) where TEntity : IEntityID;
        Task<TEntity> CreateTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID;
        Task<bool> PostTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID;
        Task UpdateTEntityAsync<TEntity>(TEntity entity, string uriString) where TEntity : IEntityID;
        Task<bool> DeleteTEntityAsync<TEntity>(int id, string uriString) where TEntity : IEntityID;
        Task<string> GetNextDocketNumber(int siteID, string uriString);
        Task UploadImageFile(string uriString, string transactionID, string filePath);
        Task<string> DownloadImageFromDbOk(string uriString, string transactionID, string filePath);
        Task<string> GetResponseText(string address);
        Task<string> setRestServiceHeaders(int id);
    }
}
