﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.MVVM;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace WeighBridge.Core.Utils
{
    public class Weights : BindableBase
    {
        private decimal _Tare1 = 0.00M;
        public decimal Tare1
        {
            get { return _Tare1; }
            set { this.SetProperty(ref _Tare1, value); }
        }

        private decimal _Tare2 = 0.00M;
        public decimal Tare2
        {
            get { return _Tare2; }
            set { this.SetProperty(ref _Tare2, value); }
        }

        private decimal _Tare3 = 0.00M;
        public decimal Tare3
        {
            get { return _Tare3; }
            set { this.SetProperty(ref _Tare3, value); }
        }

        private decimal _Tare4 = 0.00M;
        public decimal Tare4
        {
            get { return _Tare4; }
            set { this.SetProperty(ref _Tare4, value); }
        }

        private decimal _Tare5 = 0.00M;
        public decimal Tare5
        {
            get { return _Tare5; }
            set { this.SetProperty(ref _Tare5, value); }
        }

        private decimal _Gross1 = 0.00M;
        public decimal Gross1
        {
            get { return _Gross1; }
            set { this.SetProperty(ref _Gross1, value); }
        }

        private decimal _Gross2 = 0.00M;
        public decimal Gross2
        {
            get { return _Gross2; }
            set { this.SetProperty(ref _Gross2, value); }
        }

        private decimal _Gross3 = 0.00M;
        public decimal Gross3
        {
            get { return _Gross3; }
            set { this.SetProperty(ref _Gross3, value); }
        }

        private decimal _Gross4 = 0.00M;
        public decimal Gross4
        {
            get { return _Gross4; }
            set { this.SetProperty(ref _Gross4, value); }
        }

        private decimal _Gross5 = 0.00M;
        public decimal Gross5
        {
            get { return _Gross5; }
            set { this.SetProperty(ref _Gross5, value); }
        }

        private decimal _Net = 0.00M;
        public decimal Net
        {
            get { return _Net; }
            set { this.SetProperty(ref _Net, value); }
        }

        public Weights(decimal[] tares, decimal[] grosses, string loadType, decimal net)
        {
            if ((loadType == CoreConstants.Load_Counted) || (loadType == CoreConstants.Load_Standard) || (loadType == CoreConstants.Load_Mixed))
            {
                Tare1 = 0;
                Tare2 = 0;
                Tare3 = 0;
                Tare4 = 0;
                Tare5 = 0;

                Gross1 = 0;
                Gross2 = 0;
                Gross3 = 0;
                Gross4 = 0;
                Gross5 = 0;

                Net = net;

                return;

            }

            if (loadType == CoreConstants.Load_First) // sample current real as tare
            {
                Tare1 = grosses[0];
                Tare2 = grosses[1];
                Tare3 = grosses[2];
                Tare4 = grosses[3];
                Tare5 = grosses[4];

                Net = 0;
                return;
            }
            if (loadType == CoreConstants.Load_Rego) // sample current real as tare
            {
                Gross1 = grosses[0];
                Gross2 = grosses[1];
                Gross3 = grosses[2];
                Gross4 = grosses[3];
                Gross5 = grosses[4];

                Net = Math.Abs((Gross1 + Gross2 + Gross3 + Gross4 + Gross5));

                return;

            }


            Tare1 = tares[0];
            Tare2 = tares[1];
            Tare3 = tares[2];
            Tare4 = tares[3];
            Tare5 = tares[4];

            Gross1 = grosses[0];
            Gross2 = grosses[1];
            Gross3 = grosses[2];
            Gross4 = grosses[3];
            Gross5 = grosses[4];

            if (Tare1 > Gross1)
            {
                Tare1 = grosses[0];
                Tare2 = grosses[1];
                Tare3 = grosses[2];
                Tare4 = grosses[3];
                Tare5 = grosses[4];

                Gross1 = tares[0];
                Gross2 = tares[1];
                Gross3 = tares[2];
                Gross4 = tares[3];
                Gross5 = tares[4];

            }

            Net = Math.Abs((Gross1 + Gross2 + Gross3 + Gross4 + Gross5) - (Tare1 + Tare2 + Tare3 + Tare4 + Tare5)); 
        }
    }
}
