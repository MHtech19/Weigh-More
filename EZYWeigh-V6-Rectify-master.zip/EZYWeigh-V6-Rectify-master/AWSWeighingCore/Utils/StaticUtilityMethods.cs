﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.IO.Ports;
using System.Reflection;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Drawing;

namespace WeighBridge.Core.Utils
{
    public static class StaticUtilityMethods
    {
        public static string DateToStringYYYYMMDDHHMM(this DateTime aDate)
        {
            string month = aDate.Month.ToString();
            string day = aDate.Day.ToString();
            string hour = aDate.Hour.ToString();
            string minute = aDate.Minute.ToString();

            if (month.Length == 1) month = "0" + month;
            if (day.Length == 1) day = "0" + day;
            if (hour.Length == 1) hour = "0" + hour;
            if (minute.Length == 1) minute = "0" + minute;


            return aDate.Year.ToString() + month + day + hour + minute;
        }

        public static string StripAtMark(this string rego1) // strip off the part starting from @
        {
            if (rego1.Contains('@'))
            {
                string[] strArray = rego1.Split('@');
                return strArray[0].Trim();
            }
            else
            {
                return rego1;
            }
        }

        public static string PadSpacePre(string sourceString, int stringLength)
        {
            string outString = sourceString;
            while (outString.Length < stringLength)
            {
                outString = ' ' + outString;   
            }

            return outString;
        }

        public static string Truncate( this string source, int length)
        {
            if (source.Length > length)
            {
                source = source.Substring(0, length);
            }
            return source;
        }

        public static Parity ConvertToParity(this string strParity)
        {
            if (strParity.ToUpper() == "NONE") return Parity.None;
            else if (strParity.ToUpper() == "EVEN") return Parity.Even;
            else if (strParity.ToUpper() == "ODD") return Parity.Odd;
            else if (strParity.ToUpper() == "MARK") return Parity.Mark;
            else if (strParity.ToUpper() == "SPACE") return Parity.Space;
            else return Parity.None;
        }

        public static StopBits ConvertToStopBits(this string strStopBits)
        {
            if (strStopBits == "1") return StopBits.One;
            else if (strStopBits == "1.5") return StopBits.OnePointFive;
            else if (strStopBits == "2") return StopBits.Two;
            else return StopBits.None;
        }

        public static string ToQueryString(this NameValueCollection nvc)
        {
            StringBuilder sb = new StringBuilder("?");

            bool first = true;

            foreach (string key in nvc.AllKeys)
            {
                foreach (string value in nvc.GetValues(key))
                {
                    if (!first)
                    {
                        sb.Append("&");
                    }

                    sb.AppendFormat("{0}={1}", Uri.EscapeDataString(key), Uri.EscapeDataString(value));

                    first = false;
                }
            }

            return sb.ToString();
        }

        public static Bitmap ByteArrayToImage(this byte[] bytesArr)
        {
            MemoryStream memstr = new MemoryStream(bytesArr);
            Bitmap img = (Bitmap)Image.FromStream(memstr);
            //Bitmap img = (Bitmap)((new ImageConverter()).ConvertFrom(bytesArr));
            return img;
        }


        /*
        public static Parity ConvertToParity(string strParity)
        { 
            if (strParity.ToUpper() == "NONE") return Parity.None;
            else if (strParity.ToUpper() == "EVEN") return Parity.Even;
            else if (strParity.ToUpper() == "ODD") return Parity.Odd; 
            else if (strParity.ToUpper() == "MARK") return Parity.Mark;
            else if (strParity.ToUpper() == "SPACE") return Parity.Space;
            else return Parity.None;
        }

        public static StopBits ConvertToStopBits(string strStopBits)
        {
            if (strStopBits == "1") return StopBits.One;
            else if (strStopBits == "1.5") return StopBits.OnePointFive;
            else if (strStopBits == "2") return StopBits.Two;
            else return StopBits.None;
        }
        */

    }
}
