﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeighBridge.Core.Utils
{

    public enum WeighbridgeStates
    {
        Proceed = 0,
        Wait = 1,
        Leave = 2,
        //IsPostingTransaction = 3,
        //IsPrintingTicket = 4, // starts printing Chit
        //Waiting4TruckOutOfWeighbridge = 5,

    }

    public class WeighbridgeStateMachine : INotifyPropertyChanged
    {
        public WeighbridgeStateMachine()
        {
            Reset();
        }

        public void Reset()
        {
            CurrentState = WeighbridgeStates.Proceed;
            //AxleWeightsConcated = string.Empty;
            //CapturedAxleWeigtsResult = WeightCaptureResults.OK;
            //IsCaptureOK = true;
            //ErrorCaptureMessage = string.Empty;
        }

        public void GoNextState(WeighbridgeStates aCurrentState)
        {
            switch (aCurrentState)
            {
                case WeighbridgeStates.Proceed:
                    CurrentState = WeighbridgeStates.Wait;
                    break;
                case WeighbridgeStates.Wait:
                    CurrentState = WeighbridgeStates.Leave;
                    break;
                case WeighbridgeStates.Leave:
                    CurrentState = WeighbridgeStates.Proceed;
                    break;
                  
                default:
                    CurrentState = WeighbridgeStates.Proceed;
                    Reset();
                    break;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private WeighbridgeStates _CurrentState;
        public WeighbridgeStates CurrentState
        {
            get { return _CurrentState; }
            set
            {
                if (value != _CurrentState)
                {
                    _CurrentState = value;
                    OnPropertyChanged("CurrentState");
                }
            }
        }

        protected void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, e);
        }

        //Create the OnPeopertyChanged methods to raise the event
        protected void OnPropertyChanged(string propertyName)
        {
            OnPropertyChanged(new PropertyChangedEventArgs(propertyName));

        }
    }
}
