﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;

namespace WeighBridge.Core.Utils
{
    public static class Constants
    {
        public static readonly string LOCALHOST = "localhost";
        public static readonly string LOCALHOST_IP = "127.0.0.1";
        public static readonly string AussieDateTimeFormat = "dd/MM/yyyy HH:mm tt";
        public static readonly string TCPIP = "TCP/IP";
        public static readonly string GoogleWebSite = "https://www.google.com.au";
        public static readonly string EmailFrom = "info@westconnex.com.au";
        public static readonly decimal GST_Rate = 1.1M;  //this is used when the Price is including GST price
        public static readonly decimal GST_Percentage = 10; //i.e 10% , this is used when the Price is excluding GST price
        public const string AWSConnectionStringName = "AWSWeighingServiceContext";
        public const string AWSWeighingServiceDBName = "AWSWeighingService";

        public static readonly string WestConnexM4East = "West Connex M4 East";
        public static readonly string WestConnexNewM5 = "West Connex New M5";
        public static readonly string WeighMoreSolutions = "Weigh-More Solutions";
        public static readonly string WMS = "WMS";
        public static readonly string WMS_TicketFolder = "C:\\WMS\\Tickets\\";

        public const string InsertOp = "I";
        public const string UpdateOp = "U";
        public const string DeleteOp = "D";

        public const string Error = "***Error***:";

        public const string IncreaseDocketByOne = "++";
        public const string NotIncreaseDocketByOne = "+-";

        public const string Customer = "Customer";
        public const string Destination = "Destination";
        public const string Driver = "Driver";
        public const string FirstWeigh = "FirstWeigh"; 
        public const string Job = "Job";
        public const string Operator = "Operator";
        public const string Product = "Product";
        public const string ProductCategory = "ProductCategory";
        public const string Role = "Role";
        public const string Site = "Site";
        public const string Source = "Source";
        public const string Transaction = "Transaction";
        public const string Truck = "Truck";
        public const string VehicleConfiguration = "VehicleConfiguration";
        public const string Vehicle = "Vehicle";
        public const string Visitor = "Visitor";
        public const string Weighman = "Weighman";
        public const string Offence = "Offence";

        public static readonly char AtMark = '@';
 
        public static readonly string NIL = "NIL";

        public static readonly string CONFIGURATION = "configuration";

        public static readonly string NA = "NA";
        public static readonly int NA_ID = 1;

        public const string PrintToPDFAndEmailToCustomer = "Print to PDF and Sand as Email Attachment to Customer";

        public static readonly string DemoDummyWeight = "Demo Dummy";
        public static readonly string WebServiceWeight = "Web Service";
        public static readonly string UnmannedAutoTransaction = "UnmannedAutoTransaction";

        public static readonly string CentralSiteName = "CENTRAL";   // its ID  is NAEntityID = 1
        public static readonly string MasterWeighmanName = "MASTER"; // its ID  is NAEntityID = 1

        public static readonly string AdminRoleName = "Admin";
        public static readonly string UserName = "User";


        public static readonly string AWSWeighmanName = "AWS";  // its ID  is AWSWeighmanID
        public static readonly int AWSWeighmanID = 2;
        public static readonly string AWSWeighmanPassword = "180366";
        public static readonly string WMS_Snapshots_Folder = "\\WMS_Snapshots";

         //ANPR
        public static readonly string ANPR_Processing = "ANPR Processing";
        public static readonly string ANPR_Failed = "Capture Failed";

        public static readonly int PageSite = 12;

        

         public static readonly string DIRECTION_IN = "IN";
         public static readonly string DIRECTION_OUT = "OUT";

         public static readonly List<string> DIRECTIONS = new List<string>
         {
             DIRECTION_IN,
             DIRECTION_OUT,
             NA
         };

        public static List<string> EPA_STATUS_LIST = new List<string>
        {

        };
        public static readonly string OWNER_PRIVATE = "PRIVATE";
         public static readonly string OWNER_SITE = "SITE";

         public static readonly List<string> OWNERS = new List<string>
         {
             OWNER_PRIVATE,
             OWNER_SITE
         };

         public static readonly string RATE_LOCAL = "LOCAL";
         public static readonly string RATE_VISITOR = "VISITOR";

         public static readonly List<string> CHARGE_RATES = new List<string>
         {
             RATE_LOCAL,
             RATE_VISITOR
         };

         public static readonly string PAYMENT_CASH = "CASH";
         public static readonly string PAYMENT_ACCOUNT = "ACCOUNT";
         public static readonly string PAYMENT_CHEQUE = "CHEQUE";
         public static readonly string PAYMENT_EFTPOS = "EFTPOS";
         public static readonly string PAYMENT_CREDIT = "CREDITCARD";

         public static readonly string ProductType_Weighed = "W";
         public static readonly string ProductType_Counted = "I";

        public static readonly string CustomerType = "C";
        public static readonly string SupplierType = "S";

        public static readonly List<string> PAYMENTS = new List<string>
         {
            
            PAYMENT_CASH,
            PAYMENT_ACCOUNT,
            PAYMENT_CHEQUE,
            PAYMENT_EFTPOS,
            PAYMENT_CREDIT
         };

         public static readonly string TRANSACT_TYPE_2ND = "2nd";

         public const string RINSTRUM_AXLE_GROUP1 = "GROUP:   1,";
         public const string RINSTRUM_AXLE_GROUP2 = "GROUP:   2,";
         public const string RINSTRUM_AXLE_GROUP3 = "GROUP:   3,";
         public const string RINSTRUM_AXLE_GROUP4 = "GROUP:   4,";
         public const string STREAM_AXLE_GROUP1 = ":       1  ,";
         public const string STREAM_AXLE_GROUP2 = ":       2  ,";
         public const string STREAM_AXLE_GROUP3 = ":       3  ,";
         public const string STREAM_AXLE_GROUP4 = ":       4  ,";

        //TicketType
         public static readonly int GrossTicketTypeID = 1;
         public static readonly int TareTicketTypeID = 2;
         public static readonly int AxleTicketTypeID = 3;
         public static readonly int RegoTicketTypeID = 4;
         public static readonly int NetTicketTypeID = 5;

         public static readonly string GrossTicketType = "GROSS";
         public static readonly string TareTicketType = "TARE";
         public static readonly string AxleTicketType = "AXLE";
         public static readonly string RegoTicketType = "REGO";
         public static readonly string NetTicketType = "NET MASS";

         

         //Load Type
         public static readonly string Load_Standard = "Standard";
         public static readonly string Load_Counted = "Counted";
         public static readonly string Load_First = "First";
         public static readonly string Load_Second = "Second";
         public static readonly string Load_StoredTare = "StoredTare";
         public static readonly string Load_ManualTare = "ManualTare";
         public static readonly string Load_Rego = "Rego";
         public static readonly string Load_Mixed = "Mixed";

         public static readonly List<string> LOADTYPES = new List<string>
         {
            Load_Standard,
            Load_Counted,
            Load_StoredTare,
            Load_First,
            Load_Second,
            Load_Rego,
            Load_Mixed
         };

        public static readonly List<string> LOADTYPES_NoSecond = new List<string>
         {
            Load_Standard,
            Load_Counted,
            Load_StoredTare,
            Load_First,
            Load_Mixed,
            Load_Rego,
         };

        public static readonly List<string> LOADTYPE_NO_FIRST = new List<string>
         {
            Load_Counted,
            Load_Standard,
            Load_Second,
            Load_StoredTare,
            Load_Mixed,
            Load_Rego,
         };

         //Aussie States
         public static readonly string NSW = "NSW";
         public static readonly string ACT = "ACT";
         public static readonly string QLD = "QLD";
         public static readonly string VIC = "VIC";
         public static readonly string TAS = "TAS";
         public static readonly string SA = "SA";
         public static readonly string WA = "WA";
         public static readonly string NT = "NT";

         public static readonly List<string> AUS_STATES = new List<string>
         {
            NSW,
            ACT,
            QLD,
            VIC,
            TAS,
            SA,
            WA,
            NT
         };

        public static readonly List<string> TICKET_COPIES = new List<string>
         {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
         };

        public static readonly string UnMannedTicketTypeDescription = "Ticket - Autocard";
         public static readonly string MannedAxleTicketTypeDescription = "Tickets - Dayway(Axle)";
         public static readonly string MannedOtherTicketTypeDescription = "Tickets - Dayway(Direct)";

         public static readonly string UnMannedTicketTypeCode = "WTAC";
         public static readonly string MannedAxleTicketTypeCode = "WTDA";
         public static readonly string MannedOtherTicketTypeCode = "WTDD";

         public static readonly string SemiTrailer = "SEMI TRAILER";
         public static readonly string BDouble = "B DOUBLE";
         public static readonly string Crane = "CRANE";

         public static readonly int ListItemsAllSelected = -10000;
         public static readonly int ListItemsNoneSelected = -1;

         public static readonly int ACCOUNTPaymentID = 2; 

         public static readonly int TransactionExportType = 0;
         public static readonly int CustomerExportType = 1;

         //json file names
         public static readonly string CustomerFileName = "Customers.json";
         public static readonly string CustomerExtFileName = "CustomerExts.json";
         public static readonly string DriverFileName = "Drivers.json";
         public static readonly string TruckFileName = "Trucks.json";
         public static readonly string SiteFileName = "Sites.json";
         public static readonly string JobFileName = "Jobs.json";
         public static readonly string ProductFileName = "Products.json";
         public static readonly string ProductCategoryFileName = "ProductCategories.json";
         public static readonly string DestinationFileName = "Destinations.json";
         public static readonly string SourceFileName = "Sources.json";
         public static readonly string JobProductPriceFileName = "JobProductPrices.json";
         public static readonly string OperatorFileName = "Operators.json";
         public static readonly string WeighmanFileName = "Weighmen.json";
         public static readonly string TruckConfigurationFileName = "TruckConfigurations.json";
         public static readonly string VehicleFileName = "Vehicle.json";
         public static readonly string VehicleProductPriceFileName = "VehicleProductPrices.json";
         public static readonly string TransactionFileName = "Transactions.json";
         public static readonly string AxleGroupFileName = "AxleGroups.json";
         public static readonly string FirstWeighFileName = "FirstWeighs.json";
         public static readonly string OfflineModeDeletedFirstWeighFileName = "OfflineModeDeletedFirstWeighs.json";
         public static readonly string RoleFileName = "Roles.json";
         public static readonly string IOStateFileName = "IOState.json";
         public static readonly string WMSEventLogFileName = "WMSEventLogs.json";
         public static readonly string OffenceFileName = "Offences.json";
        

        public static readonly string JsonFilePath = "Data"; //@"C:\WMS\Data";
        public static readonly string ConfigFilePath = "Config"; //@"C:\WMS\Config";
        public static readonly string XMLConfigFileName = "awsconf.xml";
        public static readonly string SignatureFileName = "Signature.jpeg";
        public static readonly string SignatureBlankFileName = "SignatureBlank.jpeg";
        public static readonly string OrganisationLogoFileName = "OrganisationLogo.jpg";

        public static readonly string JobSourceFileName = "JobSources.json";
        public static readonly string JobDestinationFileName = "JobDestinations.json";

        public static readonly string TruckCustomersFileName = "TruckCustomers.json";
        public static readonly string TruckDestinationFileName = "TruckDestinations.json";
        public static readonly string TruckJobsFileName = "TruckJobs.json";
        public static readonly string TruckProductsFileName = "TruckProducts.json";
        public static readonly string TruckSourceFileName = "TruckSource.json";
        public static readonly string TruckConfigsFileName = "TruckConfigs.json";
        public static readonly string TruckSuppliersFileName = "TruckSuppliers.json";

        //timer intervals
        public static readonly int TwentyMinutes = 20 * 60 * 1000 / 2000;
        public static readonly int TwoMinutes = 2 * 60 * 1000 / 2000;

        public static readonly decimal GradsToggle = 0.06M;
        public static readonly decimal WeighPassThreshold = 0.4M;
        public static readonly string  ANPR_NA = "n.a.";
        public static readonly string NOT_FOUND = "Not Found";
        public static readonly string EXIT_COMMAND = "EXITNOW";

        //remote display
        public static readonly string RemoteDisplayNotConnected = "--------";
        public static readonly string MiDianMa = "!3E$<5dfQXV";

        //Web Input/Relay
        public static readonly string State = "state";
        public static readonly string Relay = "relay";
        public static readonly string Input = "input";
        public static readonly string WebInput1 = Input + "1" + State;
        public static readonly string WebInput2 = Input + "2" + State;
        public static readonly string WebInput3 = Input + "3" + State;
        public static readonly string WebInput4 = Input + "4" + State;
        public static readonly string WebInput5 = Input + "4" + State;

        public static readonly string WebRelay1 = Relay + "1" + State;
        public static readonly string WebRelay2 = Relay + "2" + State;
        public static readonly string WebRelay3 = Relay + "3" + State;
        public static readonly string WebRelay4 = Relay + "4" + State;
        public static readonly string WebRelay5 = Relay + "5" + State;
        public static readonly string WebRelay6 = Relay + "6" + State;
        public static readonly string WebRelay7 = Relay + "7" + State;
        public static readonly string WebRelay8 = Relay + "8" + State;
        public static readonly string WebRelay9 = Relay + "9" + State;
        public static readonly string WebRelay10 = Relay + "10" + State;

        public const string WebFiveInput = "Five-Input Module";
        public const string WebRelayQuad = "WebRelay-Quad";
        public const string WebRelay10Plus = "WebRelay 10 Plus";
        public const string WebX301DuralIII = "WebRelay X-301 Dual-III";

        public static readonly List<string> ControlByWebDevices = new List<string>
         {
            NA,
            WebFiveInput,
            WebRelayQuad,
            WebRelay10Plus,
            WebX301DuralIII,
         };

        public const string ARHSmartCamANPRNew = "ARH SmartCam New";
        public const string ARHSmartCamANPROld = "ARH SmartCam Old";
        public const string HIKVisionANPR = "HIKVision";
        public const string VivotekSurveillanceCamera = "Vivotek";


        public static readonly List<string> ANPRDevices = new List<string>
         {
            NA,
            ARHSmartCamANPRNew,
            ARHSmartCamANPROld,
            HIKVisionANPR
         };

        public static readonly List<string> SurveillanceCameraDevices = new List<string>
         {
            NA,
            HIKVisionANPR,
            VivotekSurveillanceCamera,
         };

        public static readonly string ON = "ON";
        public static readonly string OFF = "OFF";


        //SSRS definitions
        // example http://AWS-DEV-10/reportserver?/WeighMoreSolutionsReports/TransactionByDate&rs:Command=Render
        public const string SSRSRenderCommand = "&rs:Command=Render";
        public const string WeighMoreSolutionsReports = "?/WeighMoreSolutionsReports/";


        public static string GetEnumDescription(Enum e)
        {
            FieldInfo fieldInfo = e.GetType().GetField(e.ToString());
            DescriptionAttribute[] enumAttributes = (DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (enumAttributes.Length > 0)
            {
                return enumAttributes[0].Description;
            }
            return e.ToString();
        }

    }
}
