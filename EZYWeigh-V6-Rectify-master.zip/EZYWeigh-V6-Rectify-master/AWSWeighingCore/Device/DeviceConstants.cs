﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeighBridge.Core.Device
{
    public class DeviceConstants
    {
        /// <remarks>
        /// Private constructor to prevent instantiation of, or inheritance
        // from, this class.
        /// </remarks>
        private DeviceConstants()
        {
        }

        //ASCII Control
        public const byte STX = 2;
        public const byte ETX = 3;
        public const byte CR = 13;

       

        //Rinstrum 
        public const byte RINSTRUM_M = 77;  //Moving
        public const byte RINSTRUM_O = 79;  //Overrange
        public const byte RINSTRUM_N = 45;  //Negative
        public const byte RINSTRUM_E = 69;  //Error

        public const char CHAR_M = 'M';  //Moving
        public const char CHAR_T = 'T';  //weight unit in t
        public const char CHAR_E = 'E';  //Error State
        public const char CHAR_MINUS = '-';  //Error State
        public const char CHAR_DOT = '.';  //Error State
        public const char CHAR_COLUMN = ':';  //Error State
        public const char CHAR_ZERO_COMMAND_SPLITOR = '*';  //TO divide the zero command into 3 parts

        public const string KG = "kg";
        public const string Moving = "US";
        public const string RINSTRUM_AXLE_GROUP1 = "GROUP:   1,";  
        public const string RINSTRUM_AXLE_GROUP2 = "GROUP:   2,";
        public const string RINSTRUM_AXLE_GROUP3 = "GROUP:   3,";
        public const string RINSTRUM_AXLE_GROUP4 = "GROUP:   4,";
        public const string STREAM_AXLE_GROUP1 = ":       1  ,";
        public const string STREAM_AXLE_GROUP2 = ":       2  ,";
        public const string STREAM_AXLE_GROUP3 = ":       3  ,";
        public const string STREAM_AXLE_GROUP4 = ":       4  ,";

        public const string RINSTRUM_IOCOMMAND_SET_RANGE = "20170054:255;";
        public const string RINSTRUM_IO_WRITE_BIT_0 = "20170051:0;"; // all lights off
        public const string RINSTRUM_IO_WRITE_BIT_1 = "20170051:1;"; // green light
        public const string RINSTRUM_IO_WRITE_BIT_2 = "20170051:2;"; // red light
        public const string RINSTRUM_IO_WRITE_BIT_3 = "20170051:4;";
        public const string RINSTRUM_IO_WRITE_BIT_4 = "20170051:8;";
        public const string RINSTRUM_IO_WRITE_BIT_5 = "20170051:16;";
        public const string RINSTRUM_IO_WRITE_BIT_6 = "20170051:32;";
        public const string RINSTRUM_IO_WRITE_BIT_7 = "20170051:64;";
        public const string RINSTRUM_IO_WRITE_BIT_8 = "20170051:128;";

        public const string RINSTRUM_IO_READ_BYTES = "20160051:;";

       // public const string AWS_TICKET_FOOTAGE_FULL = "EEEEEEEEEE";
        public const string AWS_TICKET_FOOTAGE_PARTIAL = "EE";

        //Abnormal Weight Display String
        public const string UNDER_RANGE = "U----";
        public const string OVER_RANGE  = "O----";
        public const string ERROR_STATE = "E----";
        public const string TOO_FAST = "TOO FAST";
        public const string ABORT_OVERLOAD = "ABORT: ERROR O.LOAD";
        public const string NOT_FITTED = "Not Fitted";

        //State machine : relation to output ports property names
        public static string OUTPUT_PORT0_PROPERTY_NAME = "OutputPort0";
        public static string OUTPUT_PORT1_PROPERTY_NAME = "OutputPort1";
        public static string STATEMACHINE_CURRENT_STATE_NAME = "CurrentState";

        public static int TIMER_2_SECONDE = 14;    // 2 * 1000 / 150;
        public static int TIMER_3_SECONDE = 20;   //  3 * 1000 / 150
        public static int TIMER_5_SECONDE = 34;   //  5 * 1000 / 150 = 
        public static int TIMER_24_SECONDS = 160;  // 12 * 1000 /150
        public static int TIMER_5_MINUTES = 2000; // based on a 150ms timer 150ms * 2000 = 300000ms = 300s / 60 = 5 mins

        //Chit Printer Driver
        public const string CITIZEN_PPU_700 = "CITIZEN PPU-700";
        public const int MAX_PRINTER_PAPER_LENGTH = 88;

        public static string WEIGHT_COM_LOST_TEXT = "Weight Scale Communication Lost";
        public static string WEIGHT_COM_LOST_TOKEN = "******";

       

      



        //Modbus addresses
        //Discret Outputs
        public static int MB_DISCRET_COIL_INSERVICE     = 00001;
        public static int MB_DISCRET_COIL_NOT_INSERVICE = 00002;
        public static int MB_DISCRET_COIL_RESET_ALARMS  = 00003;
        public static int MB_DISCRET_COIL_IN_BOOMGATE_UP   = 00004;
        public static int MB_DISCRET_COIL_IN_BOOMGATE_DOWN = 00005;
        public static int MB_DISCRET_COIL_OUT_BOOMGATE_UP  = 00006;
        public static int MB_DISCRET_COIL_OUT_BOOMGATE_DOWN = 00007;

        //Discret Inputs
        public static int MB_DISCRET_INPUT_IN_GATE_UP_FAILED      = 10001;
        public static int MB_DISCRET_INPUT_IN_GATE_DOWN_FAILED    = 10002;
        public static int MB_DISCRET_INPUT_OUT_GATE_UP_FAILED     = 10003;
        public static int MB_DISCRET_INPUT_OUT_GATE_DOWN_FAILED   = 10004;
        public static int MB_DISCRET_INPUT_PRINTER_LOW_PAPER      = 10005;
        public static int MB_DISCRET_INPUT_PRINTER_NO_PAPER       = 10006;
        public static int MB_DISCRET_INPUT_PRINTER_ERROR          = 10007;
        public static int MB_DISCRET_INPUT_POWERSUPPLIER_ERROR    = 10008;
        public static int MB_DISCRET_INPUT_TRUCK_TOOFAST          = 10009;
        public static int MB_DISCRET_INPUT_TOS_CALL_FAILED        = 10010;
        public static int MB_DISCRET_INPUT_TRUCK_OVERHEIGHT       = 10011;
        public static int MB_DISCRET_INPUT_MSIC_READ_ERROR        = 10012;
        public static int MB_DISCRET_INPUT_WEIGHT_INDICATOR_ERROR = 10013;
        public static int MB_DISCRET_INPUT_IS_INSERVICE           = 10014;
        public static int MB_DISCRET_INPUT_NOT_INSERVICE          = 10015;
        public static int MB_DISCRET_INPUT_IN_LIGHTCURTAIN1_BLOCKING_TIMEOUT  = 10016;
        public static int MB_DISCRET_INPUT_IN_LIGHTCURTAIN2_BLOCKING_TIMEOUT  = 10017;
        public static int MB_DISCRET_INPUT_OUT_LIGHTCURTAIN1_BLOCKING_TIMEOUT = 10018;
        public static int MB_DISCRET_INPUT_OUT_LIGHTCURTAIN2_BLOCKING_TIMEOUT = 10019;


        //input registers
        public static int MB_INPUT_REGISTER_COMPLETE_TRANSACTION_COUNT   = 30001;
        public static int MB_INPUT_REGISTER_INCOMPLETE_TRANSACTION_COUNT = 30003;//30002;
        public static int MB_INPUT_REGISTER_CURRENT_STATE = 30005;
        public static int MB_INPUT_REGISTER_WEIGHBRIDGE_ID = 30007;

        
        
    }
}
