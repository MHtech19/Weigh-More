﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace WeighBridge.Core.Device
{
    public class AxleRinstrumScale : AbstractTcpScale
    {
        public string currentCapture;

        private string _CapturedPerAxleWeightConcated ;
        public string CapturedPerAxleWeightConcated
        {
            get { return _CapturedPerAxleWeightConcated; }
            set { _CapturedPerAxleWeightConcated = value; }
        }

        private bool _AllAxlesCaptured;
        public bool AllAxlesCaptured 
        {
            get { return _AllAxlesCaptured; }
            set { _AllAxlesCaptured = value; }
        }

        private bool _TruckJustTouchedWeighbridge;

        public AxleRinstrumScale(IPAddress ipAddress, int portNumber) : base(ipAddress, portNumber)
        {
            Clear();
        }

        protected override void OnDataReceived(IAsyncResult asyn)
        {
            try
            {
                SocketPacket theSockId = (SocketPacket)asyn.AsyncState;
                //end receive...
                int iRx = 0;
                iRx = theSockId.thisSocket.EndReceive(asyn);
                char[] chars = new char[iRx + 1];
                System.Text.Decoder d = System.Text.Encoding.UTF8.GetDecoder();
                int charLen = d.GetChars(theSockId.dataBuffer, 0, iRx, chars, 0);
                System.String szData = new System.String(chars);

                //string newText = txtDataRx.Text + szData;
                //SetTextBoxText(txtGoodsWithTare, szData);
                ParseInputPackage(szData); // get weigh data from raw string sent from socket server
                WaitForData();
            }
            catch (ObjectDisposedException se)
            {
                System.Diagnostics.Debugger.Log(0, "1", "\nOnDataReceived: Socket has been closed\n" + se.Message.ToString());
            }
            catch (SocketException se)
            {
                Logger.LogActivity(se.Message);
            }
        }

        public override void ParseInputPackage(string receivedPackage)
        {
            currentCapture = receivedPackage;
            CapturedPerAxleWeightConcated += receivedPackage;

            _TruckJustTouchedWeighbridge = (CapturedPerAxleWeightConcated == receivedPackage);

            AllAxlesCaptured = receivedPackage.Contains('/'); // Axle weights all captured

             // DateTime.Now.ToLongTimeString();

            if (AllAxlesCaptured || _TruckJustTouchedWeighbridge)
            {
                ScaleEventArgs e = new ScaleEventArgs();
                e.IsNegative = AllAxlesCaptured; //use IsNegative to indicate all axles captured
                e.IsMoving = _TruckJustTouchedWeighbridge;
                e.ScaleDisplayText = CapturedPerAxleWeightConcated; 

                OnScaleHasNewMessage(e);
                if (AllAxlesCaptured) Clear();
            }
         
            

        }

        

        public void Clear()
        {
           CapturedPerAxleWeightConcated = string.Empty;
           AllAxlesCaptured = false;
        }

        public override void Zero()
        {
            
        }


        public override void SendIOControlCommand(string ioCommand)
        {
            throw new NotImplementedException();
        }
    }
}
    