﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Text.RegularExpressions;

namespace WeighBridge.Core.Device
{
    public class RinstrumComScale : AbstractComScale
    {
        const string RinstrumFormatA_RegExpressionPattern = @"[\x20-][\x20\d]{4}[\x20.\d][\x20\d]\dT?[GNUOME]";
        
       
        public RinstrumComScale()
        {
            RegExp = new Regex(RinstrumFormatA_RegExpressionPattern);

        }

        

        public override void ParseInputPackage(string receivedPackage)
        {
            try
            {
                TicksSinceNoWeight = 0;

                Match firstMatch = RegExp.Match(receivedPackage);

                if (firstMatch.Success)
                {
                    string weightFrame = firstMatch.ToString();
                    
                    CurrentDisplayWeight = weightFrame.Substring(1, weightFrame.Length - 2 );

                    if (Double.TryParse(CurrentDisplayWeight, out _currentWeight))
                    {   
                        IsMoving = weightFrame.Contains(DeviceConstants.CHAR_M);
                        IsNegative = weightFrame.Contains(DeviceConstants.CHAR_MINUS);
                        IsError = weightFrame.Contains(DeviceConstants.CHAR_E);
                        IsKg = !weightFrame.Contains(DeviceConstants.CHAR_T) || !weightFrame.Contains(DeviceConstants.CHAR_DOT);
                        //IsOverLoadded = _currentWeight > 60;
                        IsOverLoadded = false;


                        if (IsNegative || IsOverLoadded)
                        {
                            _currentWeight = 0;
                        } 
                        

                        ScaleEventArgs e = new ScaleEventArgs();
                        //more of the event fields here
                        e.ScaleDisplayText = CurrentDisplayWeight;
                        e.IsNegative = IsNegative;
                        e.IsMoving = IsMoving;
                        e.IsError = IsError;
                        e.IsKg = IsKg;

                        
                       // if (!e.Equals(previousScaleEventArgs) || JustTurnedOn)
                        {
                            OnScaleHasNewMessage(e);
                            previousScaleEventArgs = e;
                            JustTurnedOn = false;
                        }

                        return; 

                    }

                     
                }
                else
                {
                    _currentWeight = 0;
                    CurrentDisplayWeight = "0.00"; 
                }

               
                /*
                byte[] receivedBytes = Encoding.ASCII.GetBytes(receivedPackage);
                int len = receivedBytes.Length;
                int poz = len;

                //len must be >0 to get to this point
                do
                {
                    poz--;
                    if (poz == 0) break;

                }
                while (!((receivedBytes[poz] == 2) && ((len - poz) > 10)));   //  ((receivedBytes[poz] == 2) && ((len - poz) > 10)) || (poz == 0);

                if (poz > 0)
                {
                    byte[] tempWeight = { 0, 0, 0, 0, 0, 0 };
                    for (int i = 0; i < tempWeight.Length; i++)
                    {
                        tempWeight[i] = receivedBytes[poz + 3 + i];
                    }

                    currentDisplayWeight = Encoding.ASCII.GetString(tempWeight);
                    //currentWeight = Double.Parse(currentDisplayWeight);

                    if (Double.TryParse(currentDisplayWeight, out currentWeight))
                    {
                        isNegative = ((receivedBytes[poz + 1] == DeviceConstants.RINSTRUM_N) || (receivedBytes[poz + 2] == DeviceConstants.RINSTRUM_N));
                        isMoving = (receivedBytes[poz + 9] == DeviceConstants.RINSTRUM_M);

                        ScaleEventArgs e = new ScaleEventArgs();
                        //more of the event fields here
                        e.ScaleDisplayText = currentDisplayWeight;
                        e.IsNegative = isNegative;
                        e.IsMoving = isMoving;

                        if (!e.Equals(previousScaleEventArgs) || JustTurnedOn)
                        {
                            OnScaleHasNewMessage(e);
                            previousScaleEventArgs = e;
                            JustTurnedOn = false;
                        }

                    }
                    
                }
                 */ 
            }
            catch (Exception excp)
            {
                Logger.LogActivity("Com Error:" + excp.Message);
                Logger.LogActivity("Com Error:" + excp.InnerException.Message);
            }

        }
    }
}
