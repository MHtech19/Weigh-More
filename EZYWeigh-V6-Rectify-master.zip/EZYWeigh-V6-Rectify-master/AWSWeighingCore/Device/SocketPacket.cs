﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeighBridge.Core.Device
{
    public class SocketPacket
    {
        public System.Net.Sockets.Socket thisSocket;
        public byte[] dataBuffer = new byte[1024];
    }
}
