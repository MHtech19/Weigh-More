﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using WeighBridge.Core.Utils;

namespace WeighBridge.Core.Device
{
    public class MISCCardReader : AbstractComScale
    {
        public MISCCardReader()
        {
           
        }

       
        public override void ParseInputPackage(string receivedPackage)
        {
            try
            {
                byte[] receivedBytes = Encoding.ASCII.GetBytes(receivedPackage);
                int len = receivedBytes.Length;
                int poz = len;

            

                if (poz > 0)
                {

                    CurrentDisplayWeight = receivedPackage;

                    // 
                    //currentWeight = Double.Parse(currentDisplayWeight);

                 //   if (currentDisplayWeight.Contains("GROUP"))
                 //   {
                 //       currentDisplayWeight = currentDisplayWeight + "1";
                 //   }

                    ScaleEventArgs e = new ScaleEventArgs();
                    //more of the event fields here
                    
                   //e.IsNegative = isNegative;
                   //e.IsMoving = isMoving;

                //    if (!currentDisplayWeight.Contains("AXLE   ") && !currentDisplayWeight.Contains('/'))
                    {
                        e.ScaleDisplayText = CurrentDisplayWeight;
                       // e.IsNegative = currentDisplayWeight.Contains('/');
                        OnScaleHasNewMessage(e);
                        //  previousScaleEventArgs = e;
                    }
                }
            }
            catch (Exception excp)
            {
               // Globals.AppendOneLineOfText(Constants.ERROR_LOG_FILE, excp.Message);
                Logger.LogActivity("Misc Card Error:" + excp.Message);
                Logger.LogActivity("Misc Card Error:" + excp.InnerException.Message);
            }

        }
    }
}
