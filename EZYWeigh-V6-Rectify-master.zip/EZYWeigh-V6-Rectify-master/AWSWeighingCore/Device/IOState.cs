﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.MVVM;

namespace WeighBridge.Core.Device
{

    

    public class IOState : BindableBase
    {
        private int _ID;
        public int ID
        {
            get { return _ID; }
            set { this.SetProperty(ref _ID, value); }
        }

        private string StateDescriptionComment;
        public string StateDescription
        {
            get { return StateDescriptionComment; }
            set { this.SetProperty(ref StateDescriptionComment, value); }
        }
        
        private bool _OUT1;
        public bool OUT1
        {
            get { return _OUT1; }
            set { this.SetProperty(ref _OUT1, value); }
        }

        private bool _OUT2;
        public bool OUT2
        {
            get { return _OUT2; }
            set { this.SetProperty(ref _OUT2, value); }
        }

        private bool _OUT3;
        public bool OUT3
        {
            get { return _OUT3; }
            set { this.SetProperty(ref _OUT3, value); }
        }

        private bool _OUT4;
        public bool OUT4
        {
            get { return _OUT4; }
            set { this.SetProperty(ref _OUT4, value); }
        }

        private bool _OUT5;
        public bool OUT5
        {
            get { return _OUT5; }
            set { this.SetProperty(ref _OUT5, value); }
        }

        private bool _OUT6;
        public bool OUT6
        {
            get { return _OUT6; }
            set { this.SetProperty(ref _OUT6, value); }
        }

        private bool _OUT7;
        public bool OUT7
        {
            get { return _OUT7; }
            set { this.SetProperty(ref _OUT7, value); }
        }

        private bool _OUT8;
        public bool OUT8
        {
            get { return _OUT8; }
            set { this.SetProperty(ref _OUT8, value); }
        }

        private bool _OUT9;
        public bool OUT9
        {
            get { return _OUT9; }
            set { this.SetProperty(ref _OUT9, value); }
        }

        private bool _OUT10;
        public bool OUT10
        {
            get { return _OUT10; }
            set { this.SetProperty(ref _OUT10, value); }
        }

        private string _RemoteText;
        public string RemoteText
        {
            get { return _RemoteText; }
            set { this.SetProperty(ref _RemoteText, value); }
        }

        private bool _IN1;
        public bool IN1
        {
            get { return _IN1; }
            set { this.SetProperty(ref _IN1, value); }
        }

        private bool _IN2;
        public bool IN2
        {
            get { return _IN2; }
            set { this.SetProperty(ref _IN2, value); }
        }

        private bool _IN3;
        public bool IN3
        {
            get { return _IN3; }
            set { this.SetProperty(ref _IN3, value); }
        }

        private bool _IN4;
        public bool IN4
        {
            get { return _IN4; }
            set { this.SetProperty(ref _IN4, value); }
        }

        private bool _IN5;
        public bool IN5
        {
            get { return _IN5; }
            set { this.SetProperty(ref _IN5, value); }
        }

        private bool _MustMatchInputs;
        public bool MustMatchInputs
        {
            get { return _MustMatchInputs; }
            set { this.SetProperty(ref _MustMatchInputs, value); }
        }

        private StateMachineTrigger _NextStateTrigger;
        public StateMachineTrigger NextStateTrigger
        {
            get { return _NextStateTrigger; }
            set { this.SetProperty(ref _NextStateTrigger, value); }
        }



        public override string ToString()
        {
            return ID.ToString();
        }
    }
}
