﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.Utils;

namespace WeighBridge.Core.Device.ControlByWeb
{
    public class VirtualWebDevice : IControlByWebOperation
    {
        public string WebIoDeviceIp { get; set; }

        public VirtualWebDevice(string webIoDeviceIp)
        {
            if (webIoDeviceIp == null)
            {
                webIoDeviceIp = Constants.LOCALHOST_IP;
            }
            else if (webIoDeviceIp.Trim() == string.Empty)
            {
                webIoDeviceIp = Constants.LOCALHOST_IP;
            }

            WebIoDeviceIp = webIoDeviceIp;
        }

        public Task<bool> GetInputStatusAsync(string inputName)
        {
            return Task.Run(() => false);
        }

        public bool SetOutputStatus(string OutputName, bool statusValue)
        {
            return true;
        }

        public Task<bool> SetOutputStatusAsync(string OutputName, bool statusValue)
        {
            return Task.Run(() => true);
        }

        public void TurnDeviceOff()
        {
            
        }
    }
}
