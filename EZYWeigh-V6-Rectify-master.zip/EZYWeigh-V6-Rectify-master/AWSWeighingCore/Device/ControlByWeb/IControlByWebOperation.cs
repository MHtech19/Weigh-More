﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeighBridge.Core.Device.ControlByWeb
{
    public interface IControlByWebOperation
    {
        string WebIoDeviceIp { get; set; }
        Task<bool> GetInputStatusAsync(string inputName);
        Task<bool> SetOutputStatusAsync(string OutputName, bool statusValue);
        bool SetOutputStatus(string OutputName, bool statusValue);
        void TurnDeviceOff();
    }
}
