﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WeighBridge.Core.Utils;

namespace WeighBridge.Core.Device.ControlByWeb
{
    public class WebFiveInputOperation : IControlByWebOperation
    {  
        public string WebIoDeviceIp { get; set; }

        public WebFiveInputOperation(string webIoDeviceIp)
        {
            if (webIoDeviceIp == null)
            {
                webIoDeviceIp = Constants.LOCALHOST_IP;
            }
            else if (webIoDeviceIp.Trim() == string.Empty)
            {
                webIoDeviceIp = Constants.LOCALHOST_IP;
            }
            WebIoDeviceIp = webIoDeviceIp;

        }

        public async Task<bool> GetInputStatusAsync(string inputName)
        {
            try
            {
                string nodeElementValue = "Web response failure";
                string uri = "http://" + WebIoDeviceIp + "/stateFull.xml";

                using (var client = new HttpClient())
                {
                    //client.
                    using (var response = await client.GetAsync(uri))  //_uRI + "Customer" , "http://localhost:21306/api/customer"
                    {
                        if (response.IsSuccessStatusCode)
                        {

                            using (Stream stream = await response.Content.ReadAsStreamAsync())
                            {
                                XElement xml = XElement.Load(stream);

                                var nodeElement = xml.Descendants(inputName).FirstOrDefault();

                                if (nodeElement == null)
                                {
                                    nodeElementValue = "Invalid element name";
                                }

                                nodeElementValue = nodeElement.Value;

                                if (nodeElementValue == null)
                                {
                                    nodeElementValue = "Invalid element value";
                                }

                                return (nodeElementValue == "1"); // 1 means ON, thus true

                            }

                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

        public Task<bool> SetOutputStatusAsync(string OutputName, bool statusValue)
        {
            return Task.Run(() => true);
        }

        public bool SetOutputStatus(string OutputName, bool statusValue)
        {
            return true;
        }

        public void TurnDeviceOff()
        {
            
        }
    }
}
