﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeighBridge.Core.Device.ControlByWeb
{
    public class ControlByWebDevice
    {
        private IControlByWebOperation _webOperation;

        
        public ControlByWebDevice(IControlByWebOperation webOperation)
        {
            _webOperation = webOperation;
            
        }

        public string GetWebIONameByIONumber(int ioNumber, bool isInput)
        {
            string deviceType = (isInput) ? "input" : "relay";
            string state = (deviceType == "input") ? "state" : "State";
            return deviceType + ioNumber.ToString() + state;
        }

        public async Task<bool> GetInputStatusAsync(int ioNumber)
        {
            string inputName = GetWebIONameByIONumber(ioNumber, true);

            if (IsValidIP())
            {
                return await _webOperation.GetInputStatusAsync(inputName);
            }
            else
            {
                return false;
            }

            
        }

        private bool IsValidIP()
        {
            if (_webOperation.WebIoDeviceIp == null) return false;
            return  _webOperation.WebIoDeviceIp.Trim() != string.Empty;
        }

        public async Task<bool> SetOutputStatusAsync(int ioNumber, bool statusValue)
        {
            string outputName = GetWebIONameByIONumber(ioNumber, false);
            if (IsValidIP())
            {
                return await _webOperation.SetOutputStatusAsync(outputName, statusValue);
            }
            else
            {
                return false;
            }
        }

        public bool SetOutputStatus(int ioNumber, bool statusValue)
        {
            string outputName = GetWebIONameByIONumber(ioNumber, false);

            if (IsValidIP())
            {
                return _webOperation.SetOutputStatus(outputName, statusValue);
            }
            else
            {
                return false;
            }
            
        }

        public void TurnOff()
        {
            if (IsValidIP())
            {
                _webOperation.TurnDeviceOff();
            }
            
            
        }
    }
}
