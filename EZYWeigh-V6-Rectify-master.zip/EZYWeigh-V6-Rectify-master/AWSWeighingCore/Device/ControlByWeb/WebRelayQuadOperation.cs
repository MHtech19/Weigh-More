﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.Utils;

namespace WeighBridge.Core.Device.ControlByWeb
{
    public class WebRelayQuadOperation : IControlByWebOperation
    {
        public string WebIoDeviceIp { get; set; }

        public WebRelayQuadOperation(string webIoDeviceIp)
        {
            if (webIoDeviceIp == null)
            {
                webIoDeviceIp = Constants.LOCALHOST_IP;
            }
            else if (webIoDeviceIp.Trim() == string.Empty)
            {
                webIoDeviceIp = Constants.LOCALHOST_IP;
            }
            WebIoDeviceIp = webIoDeviceIp;
        }

        public Task<bool> GetInputStatusAsync(string inputName)
        {
            return Task.Run(() => false);
        }

        public async Task<bool> SetOutputStatusAsync(string OutputName, bool statusValue)
        {
            try
            {
                string strOnOff = statusValue ? "1" : "0";
                string uriCommand = "http://" + WebIoDeviceIp + "/stateFull.xml" + "?" + OutputName + "=" + strOnOff; //stateFull.xml is used for 4 WebRepay-Quad & Five-Input only
                uriCommand = uriCommand + "&noReply=0"; //&noReply=0 is used for 4 WebRepay-Quad  & Five-Input only

                using (var client = new HttpClient())
                {
                    //client.
                    using (var response = await client.GetAsync(uriCommand))  // "http://192.168.200.2/stateFull.xml?relay1State=1&noReply=1"
                    {
                        return response.IsSuccessStatusCode;
                    }
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool SetOutputStatus(string OutputName, bool statusValue)
        {
            try
            {
                string strOnOff = statusValue ? "1" : "0";
                string uriCommand = "http://" + WebIoDeviceIp + "/stateFull.xml" + "?" + OutputName + "=" + strOnOff; //stateFull.xml is used for 4 WebRepay-Quad & Five-Input only
                uriCommand = uriCommand + "&noReply=1"; //&noReply=1 is used for 4 WebRepay-Quad  & Five-Input only

                using (var client = new HttpClient())
                {
                    //client.
                    using (var response = client.GetAsync(uriCommand).Result) // "http://192.168.200.2/stateFull.xml?relay1State=1&noReply=1"
                    {
                        return response.IsSuccessStatusCode;
                    }
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

        public void TurnDeviceOff()
        {
            try
            {
                int i = 1;
                string deviceName;
                for (i = 1; i <= 4; i++)
                {
                    deviceName = Constants.Relay + i.ToString() + Constants.State;
                    SetOutputStatus(deviceName, false);
                }
            }
            catch (Exception)
            {

                //throw;
            }
        }
    }
}
