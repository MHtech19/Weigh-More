﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WeighBridge.Core.Utils;

namespace WeighBridge.Core.Device.ControlByWeb
{
    public class WebX301Dual3Operation : IControlByWebOperation
    {
        public string WebIoDeviceIp { get; set; }

        public WebX301Dual3Operation(string webIoDeviceIp)
        {
            if (webIoDeviceIp == null)
            {
                webIoDeviceIp = Constants.LOCALHOST_IP;
            }
            else if (webIoDeviceIp.Trim() == string.Empty)
            {
                webIoDeviceIp = Constants.LOCALHOST_IP;
            }
            WebIoDeviceIp = webIoDeviceIp;

        }

        public async Task<bool> GetInputStatusAsync(string inputName)
        {
            string nodeElementValue = "Web response failure";
            string uri = "http://" + WebIoDeviceIp + "/state.xml";

            using (var client = new HttpClient())
            {
                //client.
                using (var response = await client.GetAsync(uri))  //_uRI + "Customer" , "http://localhost:21306/api/customer"
                {
                    if (response.IsSuccessStatusCode)
                    {

                        using (Stream stream = await response.Content.ReadAsStreamAsync())
                        {
                            XElement xml = XElement.Load(stream);

                            var nodeElement = xml.Descendants(inputName).FirstOrDefault();

                            if (nodeElement == null)
                            {
                                nodeElementValue = "Invalid element name";
                            }

                            nodeElementValue = nodeElement.Value;

                            if (nodeElementValue == null)
                            {
                                nodeElementValue = "Invalid element value";
                            }

                            return (nodeElementValue == "1"); // 1 means ON, thus true

                        }

                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }

        public async Task<bool> SetOutputStatusAsync(string OutputName, bool statusValue)
        {
            string strOnOff = statusValue ? "1" : "0";
            string uriCommand = "http://" + WebIoDeviceIp + "/state.xml" + "?" + OutputName + "=" + strOnOff; //stateFull.xml is used for 4 WebRepay-Quad & Five-Input only
            uriCommand = uriCommand + "&noReply=0"; // we have to set &noRelay=0 for WebRelay X-301 to work

            try
            {
                using (var client = new HttpClient())
                {
                    //client.
                    using (var response = await client.GetAsync(uriCommand))  // "http://192.168.200.2/stateFull.xml?relay1State=1&noReply=1"
                    {
                        return response.IsSuccessStatusCode;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public bool SetOutputStatus(string OutputName, bool statusValue)
        {
            try
            {
                string strOnOff = statusValue ? "1" : "0";
                string uriCommand = "http://" + WebIoDeviceIp + "/state.xml" + "?" + OutputName + "=" + strOnOff; //stateFull.xml is used for 4 WebRepay-Quad & Five-Input only
                uriCommand = uriCommand + "&noReply=0"; // we have to set &noRelay=0 for WebRelay X-301 to work

            
                using (var client = new HttpClient())
                {
                    //client.
                    using (var response = client.GetAsync(uriCommand).Result) // "http://192.168.200.2/stateFull.xml?relay1State=1&noReply=1"
                    {
                        return response.IsSuccessStatusCode;
                    }
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

        public void TurnDeviceOff()
        {
            try
            {
                int i = 1;
                string deviceName;
                for (i = 1; i <= 2; i++)
                {
                    deviceName = Constants.Relay + i.ToString() + Constants.State;
                    SetOutputStatus(deviceName, false);
                }
            }
            catch (Exception)
            {

                //throw;
            }
        }
    }
}
