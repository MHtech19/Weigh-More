﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace WeighBridge.Core.Device
{
    public enum TrafficLightColor
    {
        Red,
        Green,
        Yellow,

    }

    public enum RemoteDisplayMode
    {
        TextOnly,
        WeightOnly,
        ToggleWeightText,

    }

    public enum StateMachineTrigger
    {
        RroximitySensedVehicle,
        IDKeyPressented,
        ANPRCapturedRego,
        AboveMinimumWeight,
        WeightAlmostStable,
        WeightBecomesStable,
        TicketPrinted,
        BelowMinimumWeight,
        VehicleStartsMoving,
        PhotoEyesBlocked,
        TicketPrintedLift2ndBoomgateByProduct,
    }

}