﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;

namespace WeighBridge.Core.Device
{
    public class RinstrumTcpScale : AbstractTcpScale
    {
        const string RinstrumFormatA_RegExpressionPattern = @"[\x20-][\x20\d]{4}[\x20.\d][\x20\d]\dT?[GNUOME]";
        

        //public double PreviousWeight { get; set; }

        public RinstrumTcpScale(IPAddress ipAddress, int portNumber, string zeroCommand) : base(ipAddress, portNumber, zeroCommand)
        {
            RegExp = new Regex(RinstrumFormatA_RegExpressionPattern);
        }

        public override void SendIOControlCommand(string ioCommand)
        {
            try
            {

                byte[] byteIOCommand = System.Text.Encoding.ASCII.GetBytes(ioCommand); //+ (char)DeviceConstants.CR
                clientSocket.Send(byteIOCommand);
            }
            catch (SocketException se)
            {
                Logger.LogActivity(se.Message);
            }

        }

        public override void Zero()
        {
            
             try
             {

                 byte[] byteZeroCommand = System.Text.Encoding.ASCII.GetBytes(ZeroCommand); //+ (char)DeviceConstants.CR
                 clientSocket.Send(byteZeroCommand);
             }
             catch (SocketException se)
             {
                 Logger.LogActivity(se.Message);
             }
            
        }

        protected override void OnDataReceived(IAsyncResult asyn)
        {
            try
            {
                SocketPacket theSockId = (SocketPacket)asyn.AsyncState;
                //end receive...
                int iRx = 0;
                iRx = theSockId.thisSocket.EndReceive(asyn);
                char[] chars = new char[iRx + 1];
                System.Text.Decoder d = System.Text.Encoding.UTF8.GetDecoder();
                int charLen = d.GetChars(theSockId.dataBuffer, 0, iRx, chars, 0);
                System.String szData = new System.String(chars);

                //string newText = txtDataRx.Text + szData;
                //SetTextBoxText(txtGoodsWithTare, szData);
                ParseInputPackage(szData); // get weigh data from raw string sent from socket server
                WaitForData();
            }
            catch (ObjectDisposedException se)
            {
                System.Diagnostics.Debugger.Log(0, "1", "\nOnDataReceived: Socket has been closed\n" + se.Message.ToString());
            }
            catch (SocketException se)
            {
                Logger.LogActivity(se.Message);
            }
        }

        public override void ParseInputPackage(string receivedPackage)
        {
            string[] receivedPackageInArray = receivedPackage.Split(DeviceConstants.CHAR_COLUMN);
            string commandEcho = receivedPackageInArray[0];

            if (commandEcho == "81160051")
            {
                try
                {

                    string ioInputValue = receivedPackageInArray[1];
                    ioInputValue = ioInputValue.Replace("\r\n\0",string.Empty);
                    ScaleEventArgs e = new ScaleEventArgs();
                    e.ScaleDisplayText = ioInputValue;
                    OnScaleHasNewMessage(e);
                }
                catch (Exception excp)
                {
                    Logger.LogActivity("Tcp Error:" + excp.Message);
                    Logger.LogActivity("Tcp Error:" + excp.InnerException.Message);
                }

            }
        }
    }
}
