﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace WeighBridge.Core.Device
{
    public interface IScale<InputPackageT>
    {
        //Properties
        Regex RegExp { set; }
        InputPackageT ReceivedPackage { set; }
        double CurrentWeight { get; }
        bool IsNegative { get; }
        bool IsMoving { get; }
        bool IsError { get; }
        bool IsKg { get; }


        //Events
        event ScaleEventHandler ScaleHasNewMessage;

        //Methods
        void OnScaleHasNewMessage(ScaleEventArgs e);
        void ParseInputPackage(InputPackageT receivedPackage);
        void On();
        void Off();
        
       
        


    }
}
