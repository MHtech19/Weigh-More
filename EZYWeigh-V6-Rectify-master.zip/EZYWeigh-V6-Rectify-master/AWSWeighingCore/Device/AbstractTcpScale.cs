﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace WeighBridge.Core.Device
{
    public abstract class AbstractTcpScale : IScale<string>
    {
        public Socket clientSocket;
        protected IPAddress _ipAddress;
        private int _portNumber;
        protected IPEndPoint _ipEndPoint;

        protected Socket zeroingClientSocket;
        protected IPEndPoint _zeroingEndPoint;

        private IAsyncResult asynResult;
        public AsyncCallback asyncCallBackDelegate;
        public string ZeroCommand { get; set; }

        public string CurrentDisplayWeight { get; protected set; }
        

        protected double _CurrentWeight = 0;
        public double CurrentWeight { get { return _CurrentWeight; } }

        public double PreviousWeight { get; set; }


        protected const int MaxContinuesErrorDataAllowed = 10;
        protected int ContinuesErrorDataReceived { get; set; }


        public bool IsNegative { get; protected set; }
        public bool IsMoving { get; protected set; }
        public bool IsError { get; protected set; }
        public bool IsKg { get; protected set; }

        public bool IsSleepMode { get; set; }

        public AbstractTcpScale(IPAddress ipAddress, int portNumber,string zeroCommand)
        {
            _ipAddress = ipAddress;
            _portNumber = portNumber;
            _ipEndPoint = new IPEndPoint(_ipAddress, _portNumber);
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ZeroCommand = zeroCommand;
        }

        public AbstractTcpScale(IPAddress ipAddress, int portNumber)
        {
            _ipAddress = ipAddress;
            _portNumber = portNumber;
            _ipEndPoint = new IPEndPoint(_ipAddress, _portNumber);
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ZeroCommand = string.Empty;
        }

        public abstract void SendIOControlCommand(string ioCommand);

        protected void WaitForData()
        {
            try
            {
                if (asyncCallBackDelegate == null)
                {
                    asyncCallBackDelegate = new AsyncCallback(OnDataReceived);
                }

                SocketPacket theSocPkt = new SocketPacket();
                theSocPkt.thisSocket = clientSocket;

                // now start to listen for any data...
                asynResult = clientSocket.BeginReceive(theSocPkt.dataBuffer, 0, theSocPkt.dataBuffer.Length, SocketFlags.None, asyncCallBackDelegate, theSocPkt);
            }
            catch (SocketException se)
            {
                Logger.LogActivity(se.Message);
            }

        }

        protected abstract void OnDataReceived(IAsyncResult asyn);
        

        public System.Text.RegularExpressions.Regex RegExp
        {
            get;  set; 
        }

        public void Sleep()
        {
            IsSleepMode = true;
        }

        public void WeakUp()
        {
            IsSleepMode = false;
        }
        
        public  void On()
        {
            clientSocket.Connect(_ipEndPoint);
            WaitForData();
        }

        public  void Off()
        {
            clientSocket.Disconnect(true);
            if (zeroingClientSocket != null) zeroingClientSocket.Disconnect(true);
        }

        protected void ProcessErrorReading()
        {
            _CurrentWeight = PreviousWeight;

            if (ContinuesErrorDataReceived <= MaxContinuesErrorDataAllowed)
            {
                ContinuesErrorDataReceived++;
            }
            else
            {
                _CurrentWeight = 0.00;
                PreviousWeight = 0.00;
            }
        }

        protected void ResetContinuesErrorReading()
        {
            ContinuesErrorDataReceived = 0;
            PreviousWeight = _CurrentWeight;
        }


        public string ReceivedPackage { get; set; }

        public event ScaleEventHandler ScaleHasNewMessage;

        public void OnScaleHasNewMessage(ScaleEventArgs e)
        {
            if (ScaleHasNewMessage != null)
                ScaleHasNewMessage(this, e);
        }

        public abstract void ParseInputPackage(string receivedPackage);

        public abstract void Zero();
    }
}
