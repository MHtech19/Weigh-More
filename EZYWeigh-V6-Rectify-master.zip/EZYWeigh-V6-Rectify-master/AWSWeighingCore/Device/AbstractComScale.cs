﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Text.RegularExpressions;

namespace WeighBridge.Core.Device
{
    public abstract class AbstractComScale : IScale<string>, IDisposable
    {
        public string ZeroCommand { get; set; }
        public string CurrentDisplayWeight { get; protected set; }

        public int TicksSinceNoWeight { get; protected set; }

        public void TickNoWeightClock()
        {
            TicksSinceNoWeight++;
        }

        

        protected ScaleEventArgs previousScaleEventArgs;
        
        public bool JustTurnedOn { get; set; }

        public string  ScaleType { get; set; }

       
        public SerialPort comPort;

        public AbstractComScale()
        {
            comPort = new SerialPort();

            //serial port Init
            comPort.ReadBufferSize = 8192;
            comPort.ReadTimeout = 500;
            comPort.ReceivedBytesThreshold = 50;
            comPort.WriteBufferSize = 8192;
            comPort.WriteTimeout = 500;
      
            
            comPort.DataReceived += new SerialDataReceivedEventHandler(ComPort_DataReceived);

        }

        public virtual void SendString(string textLine)
        {
            try
            {
                comPort.Write(textLine);
            }
            catch (Exception)
            {

                //throw;
            }
        }

        protected virtual void ComPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                ReceivedPackage = comPort.ReadExisting();  //ReadLine ReadExisting
            }
            catch (Exception)
            {

                //throw;
            }
            

        }
        
        #region IScale<string> Members

        public Regex RegExp { get; protected set; }

        private string _receivedPackage;
        public string ReceivedPackage
        {           
            set
            {
                _receivedPackage = value;
                ParseInputPackage(_receivedPackage);
            }
        }

        protected double _currentWeight = 0;
        public double CurrentWeight { get { return _currentWeight; } }


        public bool IsNegative { get; protected set; }
        public bool IsMoving { get; protected set; }
        public bool IsError { get; protected set; }
        public bool IsKg { get; protected set; }
        public bool IsOverLoadded { get; set; }

        

        public abstract void ParseInputPackage(string receivedPackage);
        
        public event ScaleEventHandler ScaleHasNewMessage;

        public void OnScaleHasNewMessage(ScaleEventArgs e)
        {
            if (ScaleHasNewMessage != null)
                ScaleHasNewMessage(this, e);
        }

        public void Off()
        {
            try
            {
                comPort.Close();
                JustTurnedOn = false;
            }
            catch (Exception)
            {

                //throw;
            }
        }

        public void On()
        {
            try
            {
                comPort.Open();
                JustTurnedOn = true;
            }
            catch (Exception)
            {

                //throw;
            }
        }

        #endregion




        Regex IScale<string>.RegExp
        {
            set { throw new NotImplementedException(); }
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.
                comPort.Dispose();
                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
         ~AbstractComScale() {
           // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
           Dispose(false);
         }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            GC.SuppressFinalize(this);
        }
        #endregion



    }
}
