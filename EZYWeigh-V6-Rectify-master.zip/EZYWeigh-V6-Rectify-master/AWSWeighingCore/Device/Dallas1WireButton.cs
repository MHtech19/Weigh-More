﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;
using DalSemi.OneWire.Adapter;
using DalSemi.OneWire;

namespace WeighBridge.Core.Device
{
    public class Dallas1WireButton : IDisposable
    {
        private PortAdapter dallasButtonAdapter = null;
        private RegistryKey dallasButtonRegistryKey;

        private string DefaultDallasID { get; set; }
        private string AdapterName { get; set; }
        private string AdapterPort { get; set; }

        public Dallas1WireButton(string defaultDallasID,string adapterName, string adapterPort)
        {
            AdapterName = adapterName;
            AdapterPort = adapterPort;
            Initialise();
            DefaultDallasID = defaultDallasID;
        }

        private bool Initialise()
        {   
            string adapterName = null, adapterPort = null;
            //dallasButtonRegistryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Maxim Integrated Products\\OneWireAPI.NET\\owio", true);
            //if (dallasButtonRegistryKey != null)
            //{
            //    adapterName = (string)dallasButtonRegistryKey.GetValue("adapterName", null);
            //    adapterPort = (string)dallasButtonRegistryKey.GetValue("adapterPort", null);
            //}
            //else
            //{
            //    dallasButtonAdapter = null;
            //    return false;
            //}

            adapterName = "{"+ AdapterName + "}";
            adapterPort = AdapterPort;

            //old code
            //adapterName = "{DS9490}";
            //adapterPort = "USB1";

            try
            {
                if (adapterName != null && adapterPort != null) SetAdapter(adapterName, adapterPort);
                return true;
            }
            catch (Exception)
            {
                //addText("Failure: " + ex.Message + "\n" + ex.StackTrace + "\n" + ((ex.InnerException != null) ? ex.InnerException.Message : ""), Color.Red);
                // AdapterStatus.Text = "Not Loaded";
                dallasButtonAdapter = null;
                return false;
            }

        }

        private void SetAdapter(string adapterName, string portName)
        {
            try
            {
                if (dallasButtonAdapter != null)
                {
                    dallasButtonAdapter.EndExclusive();
                    dallasButtonAdapter.Dispose();
                    dallasButtonAdapter = null;
                }

                dallasButtonAdapter = AccessProvider.GetAdapter(adapterName, portName);

                if (dallasButtonAdapter != null)
                {
                    dallasButtonAdapter.BeginExclusive(true);
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        public string GetDallasID()
        {
            string returnResult = string.Empty;

            if (dallasButtonAdapter != null)
            {
                try
                {
                    string dallasID = string.Empty;
                    dallasButtonAdapter.Speed = OWSpeed.SPEED_REGULAR;
                    dallasButtonAdapter.TargetAllFamilies();
                    byte[] address = new byte[8];
                    if (dallasButtonAdapter.GetFirstDevice(address, 0))
                    {
                        //example Device Address: C500000029153A81 (81 3A 15 29 00 00 00 C5)                        //-----------------------   1st string     (2nd string) 
                        //get 1st string
                        dallasID = Print1WireHexAddress(address);
                        //get 2nd string
                        //dallasID = (ToHex(address, 0, 8));
                    }

                    if ((DefaultDallasID == string.Empty) || (dallasID != DefaultDallasID) && (DefaultDallasID != string.Empty))
                    {
                        returnResult = dallasID;
                    }
                    
                    
                }
                catch (Exception)
                {
                    returnResult = "Error";
                }
            }
            
            
            return returnResult;
        }

        private static string Print1WireHexAddress(byte[] buff)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(buff.Length * 3);
            for (int i = 7; i > -1; i--)
            {
                sb.Append(buff[i].ToString("X2"));
            }
            return sb.ToString();
        }


        private  string ToHex(byte[] buff, int off, int len)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(buff.Length * 3);
            sb.Append(buff[off].ToString("X2"));
            for (int i = 1; i < len; i++)
            {   
                sb.Append(buff[off + i].ToString("X2"));
            }
            return sb.ToString();
        }

        public void Dispose()
        {
            if (dallasButtonRegistryKey == null)
            {
                dallasButtonRegistryKey = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Maxim Integrated Products\\OneWireAPI.NET\\owio");
            }

            if (dallasButtonAdapter != null)
            {
                try
                {
                    dallasButtonRegistryKey.SetValue("adapterName", dallasButtonAdapter.AdapterName);
                    dallasButtonRegistryKey.SetValue("adapterPort", dallasButtonAdapter.PortName);
                    dallasButtonAdapter.EndExclusive();
                    dallasButtonAdapter.Dispose();
                    dallasButtonAdapter = null;
                }
                catch
                { }
            }

            dallasButtonRegistryKey.Close();

            GC.SuppressFinalize(this);
        }


        


    }
}
