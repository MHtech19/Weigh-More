﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace WeighBridge.Core.Device
{
    public interface ITrafficLight
    {
        void UpdateColor(TrafficLightColor newColor);
        

    }
}
