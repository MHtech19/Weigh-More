﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WeighBridge.Core.Utils;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace WeighBridge.Core.Device
{
    public enum ANPRCameraState
    {
        Ready,
        Triggered,
        Captured,
        
    }

    public class ANPRCamera
    {
        const string ANPR_GetIDCommand = "/lpr/cff?cmd=getid&id=last";       //http://camera_ip/lpr/cff?cmd=getid&id=last. cfserver.fcgi?
        const string ANPR_GetIDCommand_Old = "/cfserver.fcgi?cmd=getid&id=last";
        const string ANPR_GetRegoCommand = "/lpr/cff?cmd=getdata&id=";
        const string ANPR_GetRegoCommand_Old = "/cfserver.fcgi?cmd=getdata&id=";
        const string ANPR_GetImageCommand = "/lpr/cff?cmd=getimage&id=last";
        const string ANPR_GetImageCommand_Old = "/cfserver.fcgi?cmd=getimage&id=last";
        const string ANPR_ClearCameraDbCommand = "/lpr/cff?cmd=cleardb";
        const string ANPR_ClearCameraDbCommand_Old = "/cfserver.fcgi?cmd=cleardb";
        const string ANPR_TriggerToShootCommand = "/trigger/swtrigger";
       // const string ANPR_TriggerToShootCommand = "/trigger/swtrigger";

        private string commonWebApiUri { get; set; }
        private bool _IsOldModel { get; set; }
        //public bool RegoCaptured {get; set;}
        //public bool TriggerCameraCaptureCommandIssued { get; set; }
        public ANPRCameraState CurrentState { get; set; }
        

        public ANPRCamera(string cameraIP, bool isOldModel)
        {
            //example url = "http://localhost:21306/api/";
            commonWebApiUri = "http://" + cameraIP;
            CurrentState = ANPRCameraState.Ready;
            _IsOldModel = isOldModel;
        }

        public async Task Reset()
        {
            CurrentState = ANPRCameraState.Ready;
            await ClearCameraDbAsync();
        }

        private async Task<bool> ClearCameraDbAsync()
        {
            string command = (!_IsOldModel) ? ANPR_ClearCameraDbCommand : ANPR_ClearCameraDbCommand_Old;
            string uri = commonWebApiUri + command;
            using (var client = new HttpClient())
            {
                using (var response = await client.GetAsync(uri))  //_uRI + "Customer" , "http://localhost:21306/api/customer"
                {
                    if (response.IsSuccessStatusCode)
                    {
                        //var customerJsonString = await response.Content.ReadAsStringAsync();
                        return true;

                    }
                    else
                    {
                        return false;
                    }

                }

            }

        }

        public async Task<Bitmap> GetLastCapturedImageAsync()
        {
            try
            {
                string command = (!_IsOldModel) ? ANPR_GetImageCommand : ANPR_GetImageCommand_Old; // ANPR_GetImageCommand;
                string uri = commonWebApiUri + command;
                var client = new HttpClient();
                Stream stream = await client.GetStreamAsync(uri);
                Bitmap bitmap = new Bitmap(stream);
                return bitmap;
            }
            catch (Exception)
            {
                
                throw;
            }

            
        }

        private async Task<string> GetLastCapturedRecordIDAsync()
        {
            string id = "-1";
            string command = (!_IsOldModel) ? ANPR_GetIDCommand : ANPR_GetIDCommand_Old; //ANPR_GetIDCommand;
            string uri = commonWebApiUri + command;

            using (var client = new HttpClient())
            {
                using (var response = await client.GetAsync(uri))  //_uRI + "Customer" , "http://localhost:21306/api/customer"
                {
                    if (response.IsSuccessStatusCode)
                    {
                        //var customerJsonString = await response.Content.ReadAsStringAsync();
                        using (Stream stream = await response.Content.ReadAsStreamAsync())
                        {
                            XElement xml = XElement.Load(stream);

                            var idNode = xml.Descendants("id").FirstOrDefault();

                            if (idNode == null)
                            {
                                return id;
                            }

                            var idString = idNode.Attribute("value").Value;

                            if (idString == null)
                            {
                                return id;
                            }

                            return idString;

                        }

                    }
                    else
                    {
                        return id;
                    }
                }
            }
        }

        private async Task<string> GetLastCapturedRegoByIDAsync(string id)
        {
            string rego = CoreConstants.NOT_FOUND;
            string command = (!_IsOldModel) ? ANPR_GetRegoCommand : ANPR_GetRegoCommand_Old; // ANPR_GetRegoCommand;
            string uri = commonWebApiUri + command;

            using (var client = new HttpClient())
            {
                using (var response = await client.GetAsync(uri + id))  //_uRI + "Customer" , "http://localhost:21306/api/customer"
                {
                    if (response.IsSuccessStatusCode)
                    {
                        //var customerJsonString = await response.Content.ReadAsStringAsync();
                        using (Stream stream = await response.Content.ReadAsStreamAsync())
                        {
                            XElement xml = XElement.Load(stream);

                            var textNode = xml.Descendants("text").FirstOrDefault();

                            if (textNode == null)
                            {
                                return rego;
                            }

                            var regoString = textNode.Attribute("value").Value;

                            if (regoString == null)
                            {
                                return rego;
                            }

                            return regoString;

                        }

                    }
                    else
                    {
                        return rego;
                    }
                }
            }
        }

     public async Task<string> GetLastCapturedRego()
    {
        try
        {
            string lastID, rego;

            rego = "";

            lastID = await GetLastCapturedRecordIDAsync();


            if (lastID == "-1")
            {
                await PostTriggerAsync();
                CurrentState = ANPRCameraState.Triggered;
                return CoreConstants.ANPR_Processing;
            }

            rego = await GetLastCapturedRegoByIDAsync(lastID);

            if ((rego == CoreConstants.ANPR_NA) || (rego == CoreConstants.NOT_FOUND))
            {
                await PostTriggerAsync();
                CurrentState = ANPRCameraState.Triggered;
                return CoreConstants.ANPR_Processing;
            }

            CurrentState = ANPRCameraState.Captured;
            return rego;

        }
        catch (Exception execp)
        {

            Logger.LogActivity(execp.Message.ToString());
            return CoreConstants.ANPR_Failed;
        }

        
    }




        public async Task<bool> PostTriggerAsync()
        {
            string command = ANPR_TriggerToShootCommand;
            //http://camera_ip/trigger/swtrigger?sendtrigger=1&wfilter=1
            var nvc = new NameValueCollection();
            nvc["sendtrigger"] = "1";
            nvc["wfilter"] = "1";
            string queryString = nvc.ToQueryString();

            string uri = commonWebApiUri + command + queryString;

            using (var client = new HttpClient())
            {
                using (var response = await client.GetAsync(uri))  //_uRI + "Customer" , "http://localhost:21306/api/customer"
                {
                    if (response.IsSuccessStatusCode)
                    {
                        //var customerJsonString = await response.Content.ReadAsStringAsync();
                        CurrentState = ANPRCameraState.Triggered;
                        return true;

                    }
                    else
                    {
                        return false;
                    }

                }

            }
            
        }
    }
}
