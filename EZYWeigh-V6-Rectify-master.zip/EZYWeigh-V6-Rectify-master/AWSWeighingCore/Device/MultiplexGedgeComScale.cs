﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace WeighBridge.Core.Device
{
    public class MultiplexGedgeComScale : AbstractComScale
    {
        const string MultiplexGedge_RegExpressionPattern = @"0[123]WWG\?[+-][\d]{6}[MS]GI";

        public MultiplexGedgeComScale()
        {
            RegExp = new Regex(MultiplexGedge_RegExpressionPattern);

        }

        public override void ParseInputPackage(string receivedPackage)
        {
            try
            {
                TicksSinceNoWeight = 0;

                Match firstMatch = RegExp.Match(receivedPackage);
                

                if (firstMatch.Success)
                {
                    string weightFrame = firstMatch.ToString();

                    CurrentDisplayWeight = weightFrame.Substring(7, 6);

                    string platformNum = weightFrame.Substring(1, 1);
                    int platInt = 0;
                    if (int.TryParse(platformNum, out platInt))
                    {
                        if ((platInt <1) || (platInt >3))
                        {
                            _currentWeight = 0;
                            CurrentDisplayWeight = "0.00";
                            return;
                        }
                    }
                    else
                    {
                        _currentWeight = 0;
                        CurrentDisplayWeight = "0.00";
                        return;
                    }


                    if (Double.TryParse(CurrentDisplayWeight, out _currentWeight))
                    {
                        IsMoving = weightFrame.Contains(DeviceConstants.CHAR_M);
                        IsNegative = weightFrame.Contains(DeviceConstants.CHAR_MINUS);
                        IsError = weightFrame.Contains(DeviceConstants.CHAR_E);
                        IsKg = false;
                     
                        if (IsNegative)
                        {
                            _currentWeight = 0;
                        }
                        else
                        {
                            _currentWeight = _currentWeight / 100; // to Tonne
                            CurrentDisplayWeight = _currentWeight.ToString();
                        }


                        ScaleEventArgs e = new ScaleEventArgs();
                        //more of the event fields here
                        e.ScaleDisplayText = CurrentDisplayWeight;
                        e.IsNegative = IsNegative;
                        e.IsMoving = IsMoving;
                        e.IsError = IsError;
                        e.IsKg = IsKg;
                        e.PlatformNumber = platInt;

                        if (!e.Equals(previousScaleEventArgs) || JustTurnedOn)
                        {
                            OnScaleHasNewMessage(e);
                            previousScaleEventArgs = e;
                            JustTurnedOn = false;
                        }

                        return;

                    }


                }
                else
                {
                    _currentWeight = 0;
                    CurrentDisplayWeight = "0.00";
                }


            }
            catch (Exception excp)
            {
                Logger.LogActivity("Com Error:" + excp.Message);
                Logger.LogActivity("Com Error:" + excp.InnerException.Message);
            }

        }
    }
}
