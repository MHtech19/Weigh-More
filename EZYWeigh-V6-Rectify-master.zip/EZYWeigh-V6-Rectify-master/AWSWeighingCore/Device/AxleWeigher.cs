﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeighBridge.Core.Device
{
    

    public enum AxleState
    {
        NotAnyWheels,
        WheelsAreHitingBridgeWithWeightRising,
        WheelsAreLeavingBridgeWithWeightFulling,
        WheelsJustLeftBridge,
    }

    public class AxleWeigher
    {
        public event ScaleEventHandler AxleWeightsCaptured;
        private void OnAxleWeighsCapturedMessage(ScaleEventArgs e)
        {
            if (AxleWeightsCaptured != null)
                AxleWeightsCaptured(this, e);
        }

        private void NotifyAllAXlesCaptured(bool tooFast)
        {
            ScaleEventArgs e = new ScaleEventArgs();
            //more of the event fields here
            e.ScaleDisplayText = (tooFast?"TooFast":"OK");
            e.IsNegative = true; // indicates finished capturing
            e.IsMoving = tooFast; // indicates too fast

            OnAxleWeighsCapturedMessage(e);
        }

        private bool _started = false;
        public bool Started
        {
            get { return _started; }
            set
            {
                if ((!_started) && value)
                {
                    _started = true;
                   
                }
                else if (!value)
                {
                    _started = false;
                    ResetAlxeWeigher();
                }


            }
        }

        private const int TOOFAST_COUNT = 5;
        private int sysTimerInterval; // unit Millisecond
        private int maxAxleGroups;
        private int maxAxlesPerGroup;

        public int startCapturingMinimumWeight;

        public AxleWeigher(int maxAxleGroups, int maxAxlesPerGroup, int timerInterval, int minWeightForCapturing, double bridgeIdleTimeOut, double nextAxleGroupTimeUp)
        {
            this.maxAxleGroups = maxAxleGroups;
            this.maxAxlesPerGroup = maxAxlesPerGroup;
            sysTimerInterval = timerInterval;
            startCapturingMinimumWeight = minWeightForCapturing;
            BridgeIdleTimeOut = bridgeIdleTimeOut;
            NextGroupTimeUp = nextAxleGroupTimeUp;
            ResetAlxeWeigher();
        }

        private int _bridgeIdleTimeOutTicks;
        public double BridgeIdleTimeOut  // unit second
        {
            set { _bridgeIdleTimeOutTicks = (int)(value * 1000 / sysTimerInterval); }
        }

        private int _nextGroupTimeUpTicks;
        public double NextGroupTimeUp  // unit second
        {
            set { _nextGroupTimeUpTicks = (int)(value * 1000 / sysTimerInterval); }
        }

        private bool nextGroupTimeIsUp;


        public bool IsTooFast
        {
            get {return (tooFastFactor > TOOFAST_COUNT);}
            
            
        }

        private int tooFastFactor;
        private void ChangeTooFastFactorBy(int increase)
        {
            tooFastFactor += increase;
            if (tooFastFactor < 0) tooFastFactor = 0;
        }

        
        public string GetTooFastFactor()
        {
            return tooFastFactor.ToString();
        }

        private int _currentWeight;
        public int CurrentWeight
        {
            get { return _currentWeight; }
            set
            {

                _currentWeight = value;
            }
        }

        private int lastWeight;

        private int bridgeIdleClock = 0;
        private int nextAxleGroupClock = 0;

        private AxleState _currentAxleState;
        public AxleState CurrentAxleState
        {
            get { return _currentAxleState; }
            set
            {
                if ((_currentAxleState == AxleState.NotAnyWheels ) && (value == AxleState.WheelsAreHitingBridgeWithWeightRising))
                {
                    ChangeTooFastFactorBy(2);
                }
                else if ((_currentAxleState == AxleState.WheelsJustLeftBridge) && (value == AxleState.WheelsAreHitingBridgeWithWeightRising))
                {
                    ChangeTooFastFactorBy(2);
                }
                else if ((_currentAxleState == AxleState.WheelsAreHitingBridgeWithWeightRising) && (value == AxleState.WheelsAreLeavingBridgeWithWeightFulling))
                {
                    ChangeTooFastFactorBy(2);
                }
                else if ((_currentAxleState == AxleState.WheelsAreLeavingBridgeWithWeightFulling) && (value == AxleState.WheelsAreHitingBridgeWithWeightRising))
                {
                    ChangeTooFastFactorBy(2);
                }
                else if ( (_currentAxleState == AxleState.WheelsAreLeavingBridgeWithWeightFulling) && (value == AxleState.WheelsJustLeftBridge))
                {
                    if (currnetAxleNumber < (maxAxlesPerGroup-1))
                    {
                        currnetAxleNumber++; //this indicates the next alxe in the same group
                    }
                }
                _currentAxleState = value;
            }
        }

        public int currnetAxleNumber = 0;
        public int currentGroupNumber = 0;

        public int[,] GroupedAxleWeights = new int[4, 11];

        public int GetAxleGroupSumWeight(int axleGroup)
        {
            int totalWeight = 0;
            for (int i = 0; i < maxAxlesPerGroup; i++)
            {
                if (GroupedAxleWeights[axleGroup, i] > 0)
                {
                    totalWeight += GroupedAxleWeights[axleGroup, i];
                }
            }

            return totalWeight;
        }

        
        public int Group1AxleWeightSum
        {
            get { return GetAxleGroupSumWeight(0); }
        }

        
        public int Group2AxleWeightSum
        {
            get { return GetAxleGroupSumWeight(1); }
        }


        
        public int Group3AxleWeightSum
        {
            get { return GetAxleGroupSumWeight(2); }
        }

      
        public int Group4AxleWeightSum
        {
            get { return GetAxleGroupSumWeight(3); }
        }


        
        public int Group1AxleCount
        {
            get { return GetGroupAxleCount(0); }
        }

        
        public int Group2AxleCount
        {
            get { return GetGroupAxleCount(1); }
        }

       
        public int Group3AxleCount
        {
            get { return GetGroupAxleCount(2); }
        }

        
        public int Group4AxleCount
        {
            get { return GetGroupAxleCount(3); }
        }



        public int GetGroupAxleCount(int axleGroup)
        {
            int axleCount = 0;
            for (int i = 0; i < maxAxlesPerGroup; i++)
            {
                if (GroupedAxleWeights[axleGroup, i] > 0)
                {
                    axleCount++;
                }
            }

            return axleCount;
        }


        
        public int GVM
        {
            get { return GetTruckGVM(); }
        }

        public int GetTruckGVM()
        {
            int gvm = 0;
            for (int i = 0; i < maxAxleGroups; i++)
                for (int j = 0; j < maxAxlesPerGroup-1; j++)
                {
                    if (GroupedAxleWeights[i, j] > 0)
                    {
                        gvm += GroupedAxleWeights[i, j];
                    }
                }

            return gvm;
        }

        public void ClearGroupedAxleWeights()
        {
            for (int i = 0; i < maxAxleGroups; i++)
                for (int j = 0; j < maxAxlesPerGroup; j++)
                {
                    GroupedAxleWeights[i, j] = 0;
                }
        }

        public void ResetAlxeWeigher()
        {
            // Active = true;
            _currentWeight = 0;
            lastWeight = 0;

            bridgeIdleClock = 0;
            

            currnetAxleNumber = 0;
            currentGroupNumber = 0;

            nextGroupTimeIsUp = false;
            nextAxleGroupClock = 0;

            tooFastFactor = 0;

            _currentAxleState = AxleState.NotAnyWheels;

           
            ClearGroupedAxleWeights();
        }


        private void ShiftAxleStateByCurrentWeight()
        {
            switch (_currentAxleState)
            {
                case AxleState.NotAnyWheels:
                    {
                        if ((lastWeight >= startCapturingMinimumWeight) && (_currentWeight >= lastWeight))
                        {
                            CurrentAxleState = AxleState.WheelsAreHitingBridgeWithWeightRising;
                        }

                    }
                    break;
                
                case AxleState.WheelsAreHitingBridgeWithWeightRising:
                    {
                        if ((lastWeight >= startCapturingMinimumWeight) && (_currentWeight < (lastWeight - 300)))
                        {
                            CurrentAxleState = AxleState.WheelsAreLeavingBridgeWithWeightFulling;
                        }
                    }
                    break;
                case AxleState.WheelsAreLeavingBridgeWithWeightFulling:
                    {
                        if ((lastWeight < startCapturingMinimumWeight) && (_currentWeight < startCapturingMinimumWeight))
                        {
                            CurrentAxleState = AxleState.WheelsJustLeftBridge;
                            return ;
                        }

                        if (lastWeight > 0)
                        {
                            int weightRisingRage = (_currentWeight - lastWeight) * 100  / lastWeight;

                            if (weightRisingRage > 30)
                                CurrentAxleState = AxleState.WheelsAreHitingBridgeWithWeightRising;
                        }
                        
                    }
                    break;
                case AxleState.WheelsJustLeftBridge:
                    {
                        if ((lastWeight < startCapturingMinimumWeight) && (_currentWeight < startCapturingMinimumWeight) && (bridgeIdleClock > _bridgeIdleTimeOutTicks))
                        {
                            CurrentAxleState = AxleState.NotAnyWheels;
                            //NotifyAllAXlesCaptured(IsTooFast);
                        }
                        else  if ((lastWeight >= startCapturingMinimumWeight) && (_currentWeight >= lastWeight))
                        {
                            CurrentAxleState = AxleState.WheelsAreHitingBridgeWithWeightRising;
                        }
                    }
                    break;
                default:
                    break;
            }


        }

        private void DoTaskByCurrentAxleState()
        {
            switch (_currentAxleState)
            {
                case AxleState.NotAnyWheels:
                    {
                        bridgeIdleClock = 0;
                        nextAxleGroupClock = 0;
                                           }
                    break;
                case AxleState.WheelsJustLeftBridge:
                    {
                        if (lastWeight != _currentWeight) 
                        {
                            ChangeTooFastFactorBy(-1);
                        }

                        nextAxleGroupClock++;
                        nextGroupTimeIsUp = (nextAxleGroupClock > _nextGroupTimeUpTicks);
                        

                        bridgeIdleClock++;
                        if (bridgeIdleClock > _bridgeIdleTimeOutTicks)
                        {

                            NotifyAllAXlesCaptured(IsTooFast);
                        }
                    }
                    break;
                case AxleState.WheelsAreHitingBridgeWithWeightRising:
                    {
                        bridgeIdleClock = 0;
                        nextAxleGroupClock = 0;
                        //IsTooFast = IncreaseTooFastFactor();
                        if (nextGroupTimeIsUp) //
                        {
                           
                            if (currentGroupNumber < maxAxleGroups - 1)
                            {
                                currentGroupNumber++;
                                currnetAxleNumber = 0;
                            }
                            nextAxleGroupClock = 0;
                            nextGroupTimeIsUp = false;
                        }

                        if ((lastWeight >= startCapturingMinimumWeight) && (_currentWeight >= lastWeight))
                        {
                            GroupedAxleWeights[currentGroupNumber, currnetAxleNumber] = _currentWeight;
                        }

                        if (lastWeight == _currentWeight)
                        {
                            ChangeTooFastFactorBy(-1);
                        }

                    }
                    break;
                case AxleState.WheelsAreLeavingBridgeWithWeightFulling:
                    {
                        bridgeIdleClock = 0;
                        nextAxleGroupClock = 0;
                        if (lastWeight == _currentWeight)
                        {
                            ChangeTooFastFactorBy(-1);
                        }
                    }
                    break;
                default:
                    break;
            }

        }


        public void ParseCurrentWeight(int currentWeightValue)
        {
            if (Started)
            {
                lastWeight = _currentWeight;
                _currentWeight = currentWeightValue;
                ShiftAxleStateByCurrentWeight();
                DoTaskByCurrentAxleState();
            }
            
        }

    }
}

