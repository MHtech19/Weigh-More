﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WeighBridge.Core.Device
{
    public class PreciaMolenI35 : AbstractComScale
    {
        const string PreciaMolenI35Format_RegExpressionPattern = @"010[\d]{3}.[\d]{2}[\x20k][gt]"; // @" t 03[\d]{4}.[\d]{2} t" ;
        const string PreciaMolenI35WeightMoving_RegExpressionPattern = @"04\d8";//@"041800" ;
        // @"\x01\x02040[:8]00\x0201[\d]{4}.[\d]{2} [tk]";

        Regex weightMovingRegExp;


        public PreciaMolenI35()
        {
            RegExp = new Regex(PreciaMolenI35Format_RegExpressionPattern);
            weightMovingRegExp = new Regex(PreciaMolenI35WeightMoving_RegExpressionPattern);

        }

        public override void ParseInputPackage(string receivedPackage)
        {
            try
            {
                TicksSinceNoWeight = 0;

                Match firstMatch = RegExp.Match(receivedPackage);

                Match weightMovingMatch = weightMovingRegExp.Match(receivedPackage);

                if (firstMatch.Success)
                {
                    string weightFrame = firstMatch.ToString();

                    CurrentDisplayWeight = weightFrame.Substring(3, 6);

                    if (Double.TryParse(CurrentDisplayWeight, out _currentWeight))
                    {
                        //IsMoving = weightFrame.Contains(DeviceConstants.Moving);
                        //_currentWeight = Math.Truncate(_currentWeight * 100) / 100;
                        IsMoving = weightMovingMatch.Success;
                        IsNegative = false;
                        IsError = false;
                        IsKg = weightFrame.Contains(DeviceConstants.KG);
                        IsOverLoadded = false;

                        if (IsNegative)
                        {
                            _currentWeight = 0;
                        }


                        ScaleEventArgs e = new ScaleEventArgs();
                        //more of the event fields here
                        e.ScaleDisplayText = CurrentWeight.ToString("F");
                        e.IsNegative = IsNegative;
                        e.IsMoving = IsMoving;
                        e.IsError = IsError;
                        e.IsKg = IsKg;


                        // if (!e.Equals(previousScaleEventArgs) || JustTurnedOn)
                        {
                            OnScaleHasNewMessage(e);
                            previousScaleEventArgs = e;
                            JustTurnedOn = false;
                        }

                        return;

                    }


                }
                else
                {
                    _currentWeight = 0;
                    CurrentDisplayWeight = "0.00";
                    Match overLoadMatch = new Regex(@"999999.").Match(receivedPackage);
                    if (overLoadMatch.Success)
                    {
                        IsOverLoadded = true;
                    }
                    else
                    {
                        IsOverLoadded = false;
                    }
                }


            }
            catch (Exception excp)
            {
                Logger.LogActivity("Com Error:" + excp.Message);
                Logger.LogActivity("Com Error:" + excp.InnerException.Message);
            }

        }
    }
}
