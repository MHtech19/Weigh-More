﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeighBridge.Core.Device
{
    public class HIDCardComReader : AbstractComScale
    {
        public HIDCardComReader()
        {
            comPort.ReceivedBytesThreshold = 5;
        }

        protected override void ComPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            ReceivedPackage = comPort.ReadLine();  //ReadLine ReadExisting


        }

        public override void ParseInputPackage(string receivedPackage)
        {
            try
            {
                TicksSinceNoWeight = 0;

                var cardID = receivedPackage.TrimEnd();
                cardID = receivedPackage.TrimStart();

                ScaleEventArgs e = new ScaleEventArgs();

                e.ScaleDisplayText = cardID;
                e.IsNegative = false;
                e.IsMoving = false;
                e.IsError = false;
                e.IsKg = false;

                OnScaleHasNewMessage(e);

                return;
            }
            catch (Exception excp)
            {
                Logger.LogActivity("Com Error:" + excp.Message);
                Logger.LogActivity("Com Error:" + excp.InnerException.Message);
            }
        }
    
    }
}
