﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using WeighBridge.Core.Utils;

namespace WeighBridge.Core.Device
{
    public class RinstrumRemoteDisplay : AbstractComScale
    {
        public RinstrumRemoteDisplay()
        {  }

        public override void ParseInputPackage(string receivedPackage)
        {  }

        public string FormatWeightToRinstrumRemoteDisplay(string sourceString)
        {
            try
            {
                string outString = (char)DeviceConstants.STX + StaticUtilityMethods.PadSpacePre(sourceString, 8) + "G" + (char)DeviceConstants.ETX;
                return outString;
            }
            catch (Exception)
            {

                return string.Empty;//throw;
            }
        }

        public string FormatTextToRinstrumRemoteDisplay(string sourceString)
        {
            try
            {
                string outString = (char)DeviceConstants.STX + sourceString + "G" + (char)DeviceConstants.ETX;
                return outString;
            }
            catch (Exception)
            {

                return string.Empty;//throw;
            }
        }
    }
}
