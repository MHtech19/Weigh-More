﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.Device.ControlByWeb;
using WeighBridge.Core.MVVM;
using CoreConstants = WeighBridge.Core.Utils.Constants;

namespace WeighBridge.Core.Device
{
    public class StateMachine : BindableBase
    {
        public event EventHandler CurrentStateChanged;

        private ControlByWebDevice _ControlByWebDevice;

        private string _jasonFileName;
        private string _webControlDeviceModel;

        public bool IsInConfigMode { get; set; }

        public bool[] SampledInputsAsBoolArray = new bool[] { false, false, false, false, false };
        public string[] SampledInputsAsStringArray = new string[] { CoreConstants.NA, CoreConstants.NA, CoreConstants.NA, CoreConstants.NA, CoreConstants.NA };

        //public event dele
        public StateMachine() // for easy  unit test
        {

        }

        public StateMachine(ControlByWebDevice controlByWebDevice, string jsonFileName, string webControlDeviceModel, bool isInConfigMode)
        {
            _ControlByWebDevice = controlByWebDevice;
            _jasonFileName = jsonFileName;
            _webControlDeviceModel = webControlDeviceModel;
            IsInConfigMode = isInConfigMode;

            if (!File.Exists(jsonFileName))
            {
                ObservableCollection<IOState> ioStates = new ObservableCollection<IOState>() { new IOState() { ID = 0, StateDescription = "Ready", RemoteText = "DriveOn", NextStateTrigger = StateMachineTrigger.AboveMinimumWeight, IN1 = false, OUT1 = true } };
                IOStates = ioStates;
                SaveToJson(jsonFileName);
            }

            ReadFromJason(_jasonFileName);

            CurrentState = IOStates[0];
        }

        protected virtual void OnCurrentStateChanged(EventArgs e)
        {
            if (CurrentStateChanged != null)
            {
                CurrentStateChanged(this, e);
            }
        }

        private IOState _CurrentState;
        public IOState CurrentState
        {
            get { return _CurrentState; }
            set
            {
                var stateChanged = (_CurrentState != null) && (value.ID != _CurrentState.ID);

                this.SetProperty(ref _CurrentState, value);
                if (!IsInConfigMode) ExecuteCurrentStateOutput(_CurrentState);
                if (stateChanged) OnCurrentStateChanged(EventArgs.Empty);  // _CurrentState  changed, raise the notify event

            }
        }

        private ObservableCollection<IOState> _IOStates;
        public ObservableCollection<IOState> IOStates
        {
            get { return _IOStates; }
            set { this.SetProperty(ref _IOStates, value); }
        }

        public void SaveToJson(string jasonFileName)
        {
            try
            {
                var json = JsonConvert.SerializeObject(IOStates);
                File.WriteAllText(jasonFileName, json.ToString());
            }
            catch (Exception)
            {

                // throw;
            }
        }

        public void ReadFromJason(string jasonFileName)
        {
            try
            {
                string json = File.ReadAllText(jasonFileName);
                IOStates = JsonConvert.DeserializeObject<ObservableCollection<IOState>>(json);
            }
            catch (Exception)
            {

                //throw;
            }
        }

        public void MoveToNextStateByTrigger(StateMachineTrigger nextStateTrigger)
        {
            try
            {
                int minStateID = IOStates[0].ID;
                int maxStateID = IOStates[IOStates.Count - 1].ID;
                int currentStateID = CurrentState.ID;

                if (CurrentState.NextStateTrigger == nextStateTrigger)
                {
                    currentStateID = (currentStateID == maxStateID) ? minStateID : IOStates[currentStateID + 1].ID;
                    CurrentState = IOStates[currentStateID];
                }
            }
            catch (Exception)
            {

                //throw;
            }

        }

        public void MoveToNextStateByTrigger(StateMachineTrigger nextStateTrigger, int relayOutNo)
        {
            try
            {
                int minStateID = IOStates[0].ID;
                int maxStateID = IOStates[IOStates.Count - 1].ID;
                int currentStateID = CurrentState.ID;

                if (CurrentState.NextStateTrigger == nextStateTrigger)
                {
                    currentStateID = (currentStateID == maxStateID) ? minStateID : IOStates[currentStateID + 1].ID;
                    //CurrentState = IOStates[currentStateID];
                    var currentObjStatus = IOStates[currentStateID];
                    switch (relayOutNo)
                    {
                        case 1:
                            currentObjStatus.OUT1 = true;
                            break;
                        case 2:
                            currentObjStatus.OUT2 = true;
                            break;
                        case 3:
                            currentObjStatus.OUT3 = true;
                            break;
                        case 4:
                            currentObjStatus.OUT4 = true;
                            break;
                        case 5:
                            currentObjStatus.OUT5 = true;
                            break;
                        case 6:
                            currentObjStatus.OUT6 = true;
                            break;
                        case 7:
                            currentObjStatus.OUT7 = true;
                            break;
                        case 8:
                            currentObjStatus.OUT8 = true;
                            break;
                        case 9:
                            currentObjStatus.OUT9 = true;
                            break;
                        case 10:
                            currentObjStatus.OUT10 = true;
                            break;
                    }

                    CurrentState = currentObjStatus;
                }
            }
            catch (Exception)
            {

                //throw;
            }

        }

        public void UpdateCurrentStateStatusBack(int relayOutNo)
        {
            try
            {
                switch (relayOutNo)
                {
                    case 1:
                        CurrentState.OUT1 = false;
                        break;
                    case 2:
                        CurrentState.OUT2 = false;
                        break;
                    case 3:
                        CurrentState.OUT3 = false;
                        break;
                    case 4:
                        CurrentState.OUT4 = false;
                        break;
                    case 5:
                        CurrentState.OUT5 = false;
                        break;
                    case 6:
                        CurrentState.OUT6 = false;
                        break;
                    case 7:
                        CurrentState.OUT7 = false;
                        break;
                    case 8:
                        CurrentState.OUT8 = false;
                        break;
                    case 9:
                        CurrentState.OUT9 = false;
                        break;
                    case 10:
                        CurrentState.OUT10 = false;
                        break;                   
                }
            }
            catch (Exception)
            {
                //throw;
            }
        }

        public async void ExecuteCurrentStateOutput(IOState iOState)
        {
            // string returnMsg = "Ok";
            try
            {
                if (_ControlByWebDevice != null)
                {

                    _ControlByWebDevice.SetOutputStatusAsync(1, iOState.OUT1).GetAwaiter();
                    _ControlByWebDevice.SetOutputStatusAsync(2, iOState.OUT2).GetAwaiter();

                    if (_webControlDeviceModel == CoreConstants.WebRelayQuad || _webControlDeviceModel == CoreConstants.WebRelay10Plus)
                    {
                        _ControlByWebDevice.SetOutputStatusAsync(3, iOState.OUT3).GetAwaiter();
                        _ControlByWebDevice.SetOutputStatusAsync(4, iOState.OUT4).GetAwaiter();
                    }


                    if (_webControlDeviceModel == CoreConstants.WebRelay10Plus)
                    {
                        _ControlByWebDevice.SetOutputStatusAsync(5, iOState.OUT5).GetAwaiter();
                        _ControlByWebDevice.SetOutputStatusAsync(6, iOState.OUT6).GetAwaiter();
                        _ControlByWebDevice.SetOutputStatusAsync(7, iOState.OUT7).GetAwaiter();
                        _ControlByWebDevice.SetOutputStatusAsync(8, iOState.OUT8).GetAwaiter();
                        _ControlByWebDevice.SetOutputStatusAsync(9, iOState.OUT9).GetAwaiter();
                        _ControlByWebDevice.SetOutputStatusAsync(10, iOState.OUT10).GetAwaiter();

                    }

                }
            }
            catch
            {
                // returnMsg = CoreConstants.Error + ecp.Message.ToString();
            }

            // return returnMsg;
        }

        public async Task<bool[]> SampleInputStatus()
        {
            bool[] readInput = new bool[] { false, false, false, false, false };


            try
            {
                if ((_ControlByWebDevice != null) && ((_webControlDeviceModel == CoreConstants.WebRelay10Plus) || (_webControlDeviceModel == CoreConstants.WebFiveInput) || (_webControlDeviceModel == CoreConstants.WebX301DuralIII)))
                {
                    readInput[0] = await _ControlByWebDevice.GetInputStatusAsync(1);
                    readInput[1] = await _ControlByWebDevice.GetInputStatusAsync(2);


                    if (_webControlDeviceModel == CoreConstants.WebFiveInput)
                    {
                        readInput[2] = await _ControlByWebDevice.GetInputStatusAsync(3);
                        readInput[3] = await _ControlByWebDevice.GetInputStatusAsync(4);
                        readInput[4] = await _ControlByWebDevice.GetInputStatusAsync(5);
                    }

                }
            }
            catch (Exception)
            {


            }

            return readInput;


        }

        public bool CurrentInputMatchsPredefinition(bool[] sampledInputAsBoolArray)
        {
            bool result = true;

            result = result && (sampledInputAsBoolArray[0] == CurrentState.IN1);  //CurrentState.IN1 is predefined;
            result = result && (sampledInputAsBoolArray[1] == CurrentState.IN2);  //CurrentState.IN2 is predefined;
            result = result && (sampledInputAsBoolArray[2] == CurrentState.IN3);  //CurrentState.IN3 is predefined;
            result = result && (sampledInputAsBoolArray[3] == CurrentState.IN4);  //CurrentState.IN4 is predefined;
            result = result && (sampledInputAsBoolArray[4] == CurrentState.IN5);  //CurrentState.IN5 is predefined;

            return result;
        }

        public string[] ConvertSampledInputToString(bool[] sampledInputAsBoolArray)
        {
            string[] sampledInputAsStringArray = new string[] { CoreConstants.NA, CoreConstants.NA, CoreConstants.NA, CoreConstants.NA, CoreConstants.NA };

            if ((_ControlByWebDevice != null) && ((_webControlDeviceModel == CoreConstants.WebRelay10Plus) || (_webControlDeviceModel == CoreConstants.WebFiveInput) || (_webControlDeviceModel == CoreConstants.WebX301DuralIII)))
            {
                sampledInputAsStringArray[0] = sampledInputAsBoolArray[0] ? CoreConstants.ON : CoreConstants.OFF;
                sampledInputAsStringArray[1] = sampledInputAsBoolArray[1] ? CoreConstants.ON : CoreConstants.OFF;

                if (_webControlDeviceModel == CoreConstants.WebFiveInput)
                {
                    sampledInputAsStringArray[2] = sampledInputAsBoolArray[2] ? CoreConstants.ON : CoreConstants.OFF;
                    sampledInputAsStringArray[3] = sampledInputAsBoolArray[3] ? CoreConstants.ON : CoreConstants.OFF;
                    sampledInputAsStringArray[4] = sampledInputAsBoolArray[4] ? CoreConstants.ON : CoreConstants.OFF;
                }

            }

            return sampledInputAsStringArray;

        }



        public void AddNewIOState()
        {
            var lastStateID = IOStates.Last().ID;
            var newState = new IOState
            {
                ID = lastStateID + 1,
                NextStateTrigger = StateMachineTrigger.AboveMinimumWeight,
                RemoteText = "Text",
                StateDescription = "Type State Discription Here"
            };
            IOStates.Add(newState);
        }

        public void RemoveLastIOState()
        {
            var lastStateID = IOStates.Last().ID;
            IOStates.RemoveAt(lastStateID);
        }

        public void TurnDeviceOff()
        {
            _ControlByWebDevice.TurnOff();
        }
    }
}
