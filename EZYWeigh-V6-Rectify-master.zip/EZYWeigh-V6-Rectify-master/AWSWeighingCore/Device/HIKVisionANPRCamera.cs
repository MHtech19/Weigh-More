﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using WeighBridge.Core.Utils;

namespace WeighBridge.Core.Device
{
    public class HIKVisionANPRCamera
    {
        public static string GetRegoFromRawUrl(string rawURL)
        {
            string rego = string.Empty;

            try
            {
                //String currurl = HttpContext.Current.Request.RawUrl;
                string querystring = null;

                int iqs = rawURL.IndexOf('?');

                if (iqs >= 0)
                {
                    querystring = (iqs < rawURL.Length - 1) ? rawURL.Substring(iqs + 1) : String.Empty;
                }

                if (querystring == null) return rego;

                // Parse the query string variables into a NameValueCollection.
                NameValueCollection qscoll = HttpUtility.ParseQueryString(querystring);
                rego = qscoll["licensePlate"].ToString();
            }
            catch (Exception)
            {

                //throw;
            }
            return rego;
        }


        public static Bitmap GetImageFromPostData(HttpListenerRequest request)
        {
            try
            {
                if (!request.HasEntityBody)
                {
                    return null;
                }

                using (System.IO.Stream body = request.InputStream) // here we have data
                {
                    return (Bitmap)Bitmap.FromStream(body);
                }
            }
            catch (Exception)
            {

                return null;
            }
        }
    }
}
