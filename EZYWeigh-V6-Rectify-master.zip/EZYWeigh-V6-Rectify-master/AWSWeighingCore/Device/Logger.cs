﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace WeighBridge.Core.Device
{
    public class Logger
    {

        public static void LogActivity(string msg)
        {

            //HttpApplicationState application = HttpContext.Current.Application;

            //string path =  application["path"].ToString() + @"App_Data\log.txt";

            try
            {
                using (FileStream f = new FileStream(@"log.txt", FileMode.Append))
                //using (FileStream f = new FileStream(@"c:\AWSLog\log.txt", FileMode.Append))
                {
                    StreamWriter sw = new StreamWriter(f);

                    sw.WriteLine(DateTime.Now.ToString("yyyy-MM-dd: HH:mm:ss => ") + msg);
                    sw.Flush(); //.Close();
                    f.Close();

                }

            }
            catch (Exception)
            {

                
            }
            
                
        }

 
    }
}