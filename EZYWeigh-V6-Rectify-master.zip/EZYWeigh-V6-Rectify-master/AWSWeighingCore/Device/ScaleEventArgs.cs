﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeighBridge.Core.Device
{
    public delegate void ScaleEventHandler(object sender, ScaleEventArgs e);

    public class ScaleEventArgs : EventArgs
    {
        // Properties.
        public string ScaleDisplayText { get; set; }
        public bool IsNegative { get; set; }
        public bool IsMoving { get; set; }
        public bool IsError { get; set; }
        public bool IsKg { get; set; }

        public int PlatformNumber { get; set; }

        public override bool Equals(Object obj)
        {
            //Check for null and compare run-time types.
            if (obj == null || GetType() != obj.GetType()) return false;
            ScaleEventArgs e = (ScaleEventArgs)obj;
            return (ScaleDisplayText == e.ScaleDisplayText)
                    && (IsNegative == e.IsNegative)
                    && (IsMoving == e.IsMoving)
                    && (IsError == e.IsError)
                    ;
        }

        public override int GetHashCode()
        {
            return ScaleDisplayText.GetHashCode()
                   ^ (IsNegative ? 1 : 0) 
                   ^ (IsMoving ? 1 : 0)
                   ^ (IsError ? 1 : 0)
                   ;
        }


        
    }

}
