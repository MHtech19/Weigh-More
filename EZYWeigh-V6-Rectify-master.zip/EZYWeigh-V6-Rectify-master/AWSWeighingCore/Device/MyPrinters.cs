﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace WeighBridge.Core.Device
{
    public static  class MyPrinters
    {
        
        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetDefaultPrinter(string Name);
        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool GetDefaultPrinter(StringBuilder pszBuffer, ref int size);

        public static string CurrentDefaultPrinter
        { 
            get
            {
                string defaultPrinter = null;
                StringBuilder dp = new StringBuilder(256);
                int size = dp.Capacity;
                if (GetDefaultPrinter(dp, ref size))
                {
                    defaultPrinter = dp.ToString().Trim();
                }

                return defaultPrinter;
            }
        
        }
    }

   
}
