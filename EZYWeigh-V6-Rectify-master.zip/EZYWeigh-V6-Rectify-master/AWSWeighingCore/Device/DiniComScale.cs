﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WeighBridge.Core.Device
{
    public class DiniComScale : AbstractComScale
    {
        const string DiniFormat_RegExpressionPattern = @"GS,[\x20\d]{5}.[\d]{2}, t";

        public DiniComScale()
        {
            //the negtiveLookAhead looks for the last occurence
            string negtiveLookAhead = DiniFormat_RegExpressionPattern + "(?!.*" + DiniFormat_RegExpressionPattern + ")";
            RegExp = new Regex(negtiveLookAhead); 
            //RegExp = new Regex(DiniFormat_RegExpressionPattern);

        }

        public override void ParseInputPackage(string receivedPackage)
        {
            try
            {
                TicksSinceNoWeight = 0;

                Match firstMatch = RegExp.Match(receivedPackage);

                if (firstMatch.Success)
                {
                    string weightFrame = firstMatch.ToString();

                    CurrentDisplayWeight = weightFrame.Substring(3, 8);

                    if (Double.TryParse(CurrentDisplayWeight, out _currentWeight))
                    {
                        IsMoving = weightFrame.Contains(DeviceConstants.Moving);
                        IsNegative = false;
                        IsError = false;
                        IsKg = weightFrame.Contains(DeviceConstants.KG);

                        if (IsNegative)
                        {
                            _currentWeight = 0;
                        }


                        ScaleEventArgs e = new ScaleEventArgs();
                        //more of the event fields here
                        e.ScaleDisplayText = CurrentDisplayWeight;
                        e.IsNegative = IsNegative;
                        e.IsMoving = IsMoving;
                        e.IsError = IsError;
                        e.IsKg = IsKg;


                        OnScaleHasNewMessage(e);
                        previousScaleEventArgs = e;
                        JustTurnedOn = false;

                        return;

                    }


                }
                else
                {
                    _currentWeight = 0;
                    CurrentDisplayWeight = "0.00";
                }

                
            }
            catch (Exception excp)
            {
                Logger.LogActivity("Com Error:" + excp.Message);
                Logger.LogActivity("Com Error:" + excp.InnerException.Message);
            }

        }

    }
}
