﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeighBridge.Core.Device
{
     
    //public delegate void NotifyEventHandler(object sender, NotifyEventArgs e);
    public class NotifyEventArgs : EventArgs
    {
        public string NotifyMessage { get; set; }
    }

    
}
