﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WeighBridge.Core.Utils;
//using System.Windows.Media.Imaging;

namespace WeighBridge.Core.Device
{
    public class VivotekSurveillanceCamera
    {
        HttpClient client;
        string _CameraModel { get; set; }
        string _CameraIpAddress { get; set; }
        public string CameraSnapshotLocation { get; set; }
        string _CameraNumber { get; set; }
        string _HttpCommand { get; set; }

        const string USER_NAME = "root";
        const string PASSWORD = "Admin123"; //"180366@aws";
        
        //var httpClientHandler = new HttpClientHandler()
        //{
        //    Credentials = new NetworkCredential("userName", "Password", "Domain"),
        //};

        public VivotekSurveillanceCamera(string cameraIpAddress, string cameraModel, string cameraSnapshotLocation, string cameraNumber)
        {
            //var authData = string.Format ("{0}:{1}", Constants.Username, Constants.Password);
            //var authHeaderValue = Convert.ToBase64String (Encoding.UTF8.GetBytes (authData));

            
            HttpClientHandler httpClientHandler = new HttpClientHandler( )
            {
                Credentials = new NetworkCredential(USER_NAME, PASSWORD),
            };

            client = new HttpClient(httpClientHandler);

            // these 2 lines are for bypassing some server settings that will cause StatusCode: 417, ReasonPhrase: 'Expectation failed' error
            client.DefaultRequestHeaders.ExpectContinue = false;
            client.MaxResponseContentBufferSize = 2560000;
            //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue ("Basic", authHeaderValue);

            _CameraIpAddress = cameraIpAddress;
            _CameraModel = cameraModel;
            _CameraNumber = cameraNumber;

            if (cameraSnapshotLocation.Trim() != string.Empty)
            {
                CameraSnapshotLocation = cameraSnapshotLocation + Constants.WMS_Snapshots_Folder;
            }
            else
            {
                CameraSnapshotLocation = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + Constants.WMS_Snapshots_Folder; 
            
            }
        }

        private string BuildVivotekGetSnapShotCommand(int channel)
        {
            return "http://" + _CameraIpAddress + "/cgi-bin/viewer/video.jpg?channel=" + channel.ToString();
        }

        private string BuildHikvisionGetSnapShotCommand(int channel)
        {
            string command = "http://" + _CameraIpAddress + ":8088/Streaming/channels/" + channel.ToString() + "/picture";
            return command; //http://172.16.0.1:8088/Streaming/channels/1/picture        
        }

        public async Task<string> TakeSnapShotAndSaveAsFileFromCamera(int channel)
        {
            string ErrorMessage = Constants.Error;
            try
            {
            if (_CameraModel == Constants.VivotekSurveillanceCamera)
            {
                _HttpCommand = BuildVivotekGetSnapShotCommand(channel);
            }
            else if (_CameraModel == Constants.HIKVisionANPR)
            {
                _HttpCommand = BuildHikvisionGetSnapShotCommand(channel);
            }
            else
            {
                return string.Empty;
            }

           
                var response = await client.GetAsync(_HttpCommand);
                
                if (response != null && response.StatusCode == HttpStatusCode.OK)
                {
                    using (var stream = await response.Content.ReadAsStreamAsync())
                    {
                        //return Image.FromStream(stream);
                        Image img = System.Drawing.Image.FromStream(stream);
                        System.IO.Directory.CreateDirectory(CameraSnapshotLocation);
                        string fileName = CameraSnapshotLocation + "\\" + DateTime.Now.DateToStringYYYYMMDDHHMM() + "_C" + _CameraNumber + ".Jpg";
                        img.Save(fileName, ImageFormat.Jpeg);
                        return fileName;
                    }

                }
                else
                {
                    ErrorMessage = ErrorMessage + response.ReasonPhrase;
                    return ErrorMessage;
                }
                
            }
            catch (Exception ecp)
            {
                ErrorMessage = ErrorMessage + ecp.Message.ToString();
                return ErrorMessage;
            }
        }


    }
}
