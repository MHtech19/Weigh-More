﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeighBridge.Core.Device
{
    class ANDFVComScale : AbstractComScale
    {
        public override void ParseInputPackage(string receivedPackage)
        {
            try
            {
                TicksSinceNoWeight = 0;

                byte[] receivedBytes = Encoding.ASCII.GetBytes(receivedPackage);
                int len = receivedBytes.Length;
                int poz = len;




                //len must be >0 to get to this point
                poz = Array.IndexOf(receivedBytes, ',');

                if (poz > 0)
                {
                    byte[] tempWeight = { 0, 0, 0, 0, 0, 0 };
                    for (int i = 0; i < tempWeight.Length; i++)
                    {
                        tempWeight[i] = receivedBytes[poz + 3 + i];
                    }

                    CurrentDisplayWeight = Encoding.ASCII.GetString(tempWeight);
                    //currentWeight = Double.Parse(currentDisplayWeight);

                    if (Double.TryParse(CurrentDisplayWeight, out _currentWeight))
                    {
                        IsNegative = ((receivedBytes[poz + 1] == DeviceConstants.RINSTRUM_N) || (receivedBytes[poz + 2] == DeviceConstants.RINSTRUM_N));
                        IsMoving = (receivedBytes[poz + 9] == DeviceConstants.RINSTRUM_M);

                        ScaleEventArgs e = new ScaleEventArgs();
                        //more of the event fields here
                        e.ScaleDisplayText = CurrentDisplayWeight;
                        e.IsNegative = IsNegative;
                        e.IsMoving = IsMoving;

                        if (!e.Equals(previousScaleEventArgs) || JustTurnedOn)
                        {
                            OnScaleHasNewMessage(e);
                            previousScaleEventArgs = e;
                            JustTurnedOn = false;
                        }

                    }

                }
            }
            catch (Exception excp)
            {
                Logger.LogActivity("Com Error:" + excp.Message);
                Logger.LogActivity("Com Error:" + excp.InnerException.Message);
            }
        }
    }
}
