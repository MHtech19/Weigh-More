﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using WeighBridge.Core.Device;

namespace WeighBridge.Core.Device
{
    public class TrafficLight
    {

        private ITrafficLight _trafficControl;
        
        public TrafficLightColor CurrentTrafficLightColor { get; set; }

        private bool _IsManualControl = false;
        public bool IsManualControl
        { 
            get{ return _IsManualControl; } 
            set
            {
                
                if (!value && _IsManualControl)
                {
                    if (_currentWeight >= _minimumWeight)
                    {
                        
                        CurrentTrafficLightColor = TrafficLightColor.Red;
                        OutputTrafficLight(CurrentTrafficLightColor);
                    }
                    else
                    {
                        
                        CurrentTrafficLightColor = TrafficLightColor.Green;
                        OutputTrafficLight(CurrentTrafficLightColor);

                    }

                }
                

                _IsManualControl = value;
            }
        }


        private decimal _minimumWeight;
        private decimal _currentWeight;
        public decimal CurrentWeight
        {
            get { return _currentWeight; }
            set
            {
                if (IsManualControl)
                {
                    _currentWeight = value;
                }
                else
                {
                    if ((value > _minimumWeight) && (_currentWeight <= _minimumWeight))
                    {
                        _currentWeight = value;
                        
                        
                        CurrentTrafficLightColor = TrafficLightColor.Red;
                        
                        OutputTrafficLight(CurrentTrafficLightColor);
                    }
                    else if ((value <= _minimumWeight)  && (_currentWeight >= _minimumWeight))
                    {
                        _currentWeight = value;
                        
                        
                        CurrentTrafficLightColor = TrafficLightColor.Green;
                        
                        OutputTrafficLight(CurrentTrafficLightColor);
                    }
                }
                
            }
        }

        public void OutputTrafficLight(TrafficLightColor newColor)
        {
            if (_trafficControl != null)
            {
                _trafficControl.UpdateColor(newColor);

            }
        }

        public TrafficLight(decimal minimumWeight, ITrafficLight trafficControl)
        {
            _minimumWeight = minimumWeight;
            _trafficControl = trafficControl;
            CurrentTrafficLightColor = TrafficLightColor.Red;
        }
        
       
        
    }
}
