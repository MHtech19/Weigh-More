﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace WeighBridge.Core.Device
{
    public class AxleRinstrumScale : RinstrumScale
    {
        private string capturedPerAxleWeightConcated;
        private bool allAxlesCaptured;

        public AxleRinstrumScale(IPAddress ipAddress, int portNumber) : base(ipAddress, portNumber) { }

        protected override void TCPParseInputPackage(string receivedPackage)
        {
            capturedPerAxleWeightConcated += receivedPackage;

            allAxlesCaptured = receivedPackage.Contains('/'); // Axle weights all captured

            ScaleEventArgs e = new ScaleEventArgs();
            
            e.IsNegative = allAxlesCaptured; //use IsNegative to indicate all axles captured
           
            if (!allAxlesCaptured)
            {
                e.ScaleDisplayText = receivedPackage;

            }
            else
            {
                e.ScaleDisplayText = capturedPerAxleWeightConcated;
                Clear();
            }

            OnScaleHasNewMessage(e);
            
        }

        private void Clear()
        {
            capturedPerAxleWeightConcated = string.Empty;
            allAxlesCaptured = false;
        }

    }
}
    